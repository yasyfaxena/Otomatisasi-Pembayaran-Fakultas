<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header('Location: mhs_login.php');
    exit;
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard - History Pembayaran</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: #f5f5f5;
            display: flex;
        }

        .sidebar {
            width: 260px;
            background-color: #1a1a1a;
            color: white;
            height: 100vh;
            position: fixed;
            left: 0;
            top: 0;
        }

        .logo {
            padding: 20px;
            text-align: center;
            border-bottom: 1px solid #333;
        }

        .logo img {
            width: 80px;
            height: auto;
        }

        .user-info {
            padding: 30px 20px;
            text-align: center;
            border-bottom: 1px solid #333;
        }

        .user-id {
            font-size: 14px;
            margin-bottom: 8px;
            color: #999;
        }

        .user-name {
            font-size: 16px;
            font-weight: 600;
            margin-bottom: 15px;
        }

        .user-actions {
            display: flex;
            gap: 8px;
            justify-content: center;
        }

        .user-actions a {
            padding: 8px 12px;
            background: #246140;
            color: white;
            text-decoration: none;
            border-radius: 5px;
            font-size: 12px;
            transition: background 0.3s;
        }

        .user-actions a:hover {
            background: #1a4c2e;
        }

        .user-actions a.logout {
            background: #dc3545;
        }

        .user-actions a.logout:hover {
            background: #c82333;
        }

        .menu {
            padding: 20px 0;
        }

        .menu-item {
            padding: 15px 20px;
            cursor: pointer;
            display: flex;
            align-items: center;
            gap: 12px;
            transition: background-color 0.3s;
        }

        .menu-item:hover {
            background-color: #333;
        }

        .menu-item.active {
            background-color: #4CAF50;
        }

        .menu-icon {
            width: 24px;
            height: 24px;
            display: flex;
            align-items: center;
            justify-content: center;
        }
        .menu a {
            text-decoration: none;
            color: inherit;
        }

        .main-content {
            margin-left: 260px;
            flex: 1;
            padding: 20px 40px;
        }

        .header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 40px;
            background: white;
            padding: 15px 25px;
            border-radius: 8px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
        }

        .header-title {
            font-size: 20px;
            color: #666;
            display: flex;
            align-items: center;
            gap: 15px;
        }

        .menu-dots {
            font-size: 24px;
            cursor: pointer;
            color: #999;
        }

        .user-avatar {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            cursor: pointer;
            object-fit: cover;
            border: 2px solid #4169E1;
            transition: transform 0.2s;
        }
        
        .user-avatar:hover {
            transform: scale(1.1);
        }

        .section {
            background: white;
            border-radius: 8px;
            padding: 25px;
            margin-bottom: 30px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
        }

        .section-title {
            font-size: 18px;
            margin-bottom: 20px;
            color: #333;
        }

        table {
            width: 100%;
            border-collapse: collapse;
        }

        th {
            background-color: #f8f8f8;
            padding: 12px;
            text-align: left;
            font-weight: 600;
            color: #555;
            border-bottom: 2px solid #e0e0e0;
        }

        td {
            padding: 15px 12px;
            border-bottom: 1px solid #f0f0f0;
            color: #666;
        }

        tr:hover {
            background-color: #fafafa;
        }

        .btn-lihat-bukti {
            background-color: #2196F3;
            color: white;
            border: none;
            padding: 8px 16px;
            border-radius: 4px;
            cursor: pointer;
            font-weight: 600;
            transition: background-color 0.3s;
            font-size: 13px;
        }

        .btn-lihat-bukti:hover {
            background-color: #1976D2;
        }

        .btn-lihat-bukti.disabled {
            background-color: #cccccc;
            cursor: not-allowed;
        }

        .btn-lihat-bukti.disabled:hover {
            background-color: #cccccc;
        }

        .btn-upload {
            background-color: #4CAF50;
            color: white;
            border: none;
            padding: 8px 16px;
            border-radius: 4px;
            cursor: pointer;
            font-weight: 600;
            transition: background-color 0.3s;
            font-size: 13px;
            margin-right: 8px;
            display: flex;
            align-items: center;
            gap: 6px;
        }

        .btn-upload:hover {
            background-color: #45a049;
        }

        .upload-icon {
            font-size: 14px;
        }

        .status-lunas {
            background-color: #4CAF50;
            color: white;
            padding: 6px 16px;
            border-radius: 20px;
            font-size: 13px;
            font-weight: 600;
            display: inline-block;
        }

        .status-belum-lunas {
            background-color: #f44336;
            color: white;
            padding: 6px 16px;
            border-radius: 20px;
            font-size: 13px;
            font-weight: 600;
            display: inline-block;
        }

        .status-menunggu {
            background-color: #FF9800;
            color: white;
            padding: 6px 16px;
            border-radius: 20px;
            font-size: 13px;
            font-weight: 600;
            display: inline-block;
        }

        .stats-container {
            display: flex;
            gap: 20px;
            margin-bottom: 30px;
        }

        .stat-card {
            flex: 1;
            padding: 25px;
            border-radius: 12px;
            color: white;
            display: flex;
            align-items: center;
            gap: 20px;
            box-shadow: 0 4px 6px rgba(0,0,0,0.1);
            transition: transform 0.3s;
        }

        .stat-card:hover {
            transform: translateY(-5px);
        }

        .stat-card.blue {
            background: linear-gradient(135deg, #4169E1 0%, #2E5BBE 100%);
        }

        .stat-card.green {
            background: linear-gradient(135deg, #4CAF50 0%, #45A049 100%);
        }

        .stat-card.red {
            background: linear-gradient(135deg, #EF5350 0%, #E53935 100%);
        }

        .stat-icon {
            width: 60px;
            height: 60px;
            background: rgba(255, 255, 255, 0.2);
            border-radius: 12px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 28px;
            flex-shrink: 0;
        }

        .stat-content {
            flex: 1;
        }

        .stat-label {
            font-size: 13px;
            opacity: 0.9;
            margin-bottom: 8px;
            font-weight: 500;
        }

        .stat-value {
            font-size: 28px;
            font-weight: 700;
            margin-bottom: 5px;
        }

        .stat-subtitle {
            font-size: 12px;
            opacity: 0.85;
        }

        /* Modal untuk upload bukti */
        .modal-overlay {
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background-color: rgba(0, 0, 0, 0.5);
            display: flex;
            justify-content: center;
            align-items: center;
            z-index: 1000;
            opacity: 0;
            visibility: hidden;
            transition: all 0.3s ease;
        }

        .modal-overlay.active {
            opacity: 1;
            visibility: visible;
        }

        .modal-content {
            background-color: white;
            border-radius: 10px;
            width: 90%;
            max-width: 500px;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.3);
            transform: translateY(-20px);
            transition: transform 0.3s ease;
        }

        .modal-overlay.active .modal-content {
            transform: translateY(0);
        }

        .modal-header {
            padding: 20px 25px;
            border-bottom: 1px solid #e0e0e0;
            display: flex;
            justify-content: space-between;
            align-items: center;
            position: relative;
        }

        .modal-title {
            font-size: 18px;
            font-weight: 600;
            color: #333;
            text-align: center;
            flex: 1;
        }

        .modal-close {
            background: none;
            border: none;
            font-size: 24px;
            cursor: pointer;
            color: #666;
            line-height: 1;
            width: 30px;
            height: 30px;
            display: flex;
            align-items: center;
            justify-content: center;
            border-radius: 50%;
            transition: background-color 0.2s;
            position: absolute;
            right: 20px;
        }

        .modal-close:hover {
            background-color: #f5f5f5;
        }

        .modal-body {
            padding: 25px;
        }

        .upload-details {
            background-color: #f9f9f9;
            padding: 20px;
            border-radius: 8px;
            margin-bottom: 25px;
            border: 1px solid #e8e8e8;
        }

        .upload-details-title {
            font-size: 16px;
            font-weight: 600;
            color: #333;
            margin-bottom: 15px;
            padding-bottom: 8px;
            border-bottom: 1px solid #e0e0e0;
        }

        .detail-row {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 8px 0;
            font-size: 14px;
        }

        .detail-label {
            color: #666;
            font-weight: 500;
        }

        .detail-value {
            color: #333;
            font-weight: 600;
            text-align: right;
        }

        .upload-area {
            border: 2px dashed #ddd;
            border-radius: 8px;
            padding: 40px 20px;
            text-align: center;
            cursor: pointer;
            transition: all 0.3s ease;
            margin-bottom: 20px;
            background-color: #fafafa;
        }

        .upload-area:hover {
            border-color: #2196F3;
            background-color: #f0f8ff;
        }

        .upload-area.drag-over {
            border-color: #4CAF50;
            background-color: #f1f8e9;
        }

        .upload-icon-large {
            font-size: 48px;
            color: #666;
            margin-bottom: 15px;
        }

        .upload-text {
            font-size: 16px;
            color: #666;
            margin-bottom: 10px;
        }

        .upload-subtext {
            font-size: 14px;
            color: #999;
        }

        .file-info {
            background-color: #e8f5e8;
            padding: 15px;
            border-radius: 6px;
            margin-top: 15px;
            display: none;
        }

        .file-info.show {
            display: block;
        }

        .file-name {
            font-weight: 600;
            color: #333;
            margin-bottom: 5px;
        }

        .file-size {
            font-size: 13px;
            color: #666;
        }

        .modal-footer {
            padding: 20px 25px;
            border-top: 1px solid #e0e0e0;
            display: flex;
            justify-content: flex-end;
            gap: 10px;
        }

        .btn-cancel {
            background-color: #f5f5f5;
            color: #333;
            border: 1px solid #ddd;
            padding: 10px 20px;
            border-radius: 4px;
            cursor: pointer;
            font-weight: 600;
            transition: background-color 0.3s;
            min-width: 80px;
        }

        .btn-cancel:hover {
            background-color: #e0e0e0;
        }

        .btn-upload-modal {
            background-color: #4CAF50;
            color: white;
            border: none;
            padding: 10px 20px;
            border-radius: 4px;
            cursor: pointer;
            font-weight: 600;
            transition: background-color 0.3s;
            min-width: 100px;
        }

        .btn-upload-modal:hover {
            background-color: #45a049;
        }

        .btn-upload-modal.disabled {
            background-color: #cccccc;
            cursor: not-allowed;
        }

        .btn-upload-modal.disabled:hover {
            background-color: #cccccc;
        }

        .action-buttons {
            display: flex;
            gap: 10px;
            align-items: center;
        }

        .upload-note {
            font-size: 12px;
            color: #666;
            text-align: center;
            margin-top: 10px;
        }

        .file-input {
            display: none;
        }
    </style>
</head>
<body>
    <div class="sidebar">
        <div class="logo">
            <img src="pictures/logo umi.png" alt="Logo">
        </div>
        <div class="user-info">
            <div class="user-id">-</div>
            <div class="user-name">Mahasiswa</div>
            <div class="user-actions">
            <a href="index.php" onclick="logout();">Logout</a>
            </div>
        </div>
        <div class="menu">
            <a href="dashboard_mahasiswa.php" class="menu-item">
                <div class="menu-icon">📊</div>
                <div>Dashboard</div>
            </a>

            <a href="mhs_tagihan.php" class="menu-item">
                <div class="menu-icon">💳</div>
                <div>Tagihan</div>
            </a>

            <a href="mhs_riwayat_pembayaran.php" class="menu-item active">
                <div class="menu-icon">🔄</div>
                <div>Riwayat Pembayaran</div>
            </a>
        </div>
    </div>

    <div class="main-content">
        <div class="header">
            <div class="header-title">
                <span class="menu-dots">⋮</span>
                <span>Riwayat Pembayaran</span>
            </div>
            <?php
            if (isset($_SESSION['role']) && $_SESSION['role'] === 'mahasiswa') {
                $userId = isset($_SESSION['user_id']) ? $_SESSION['user_id'] : rand(1, 70);
                echo '<img src="https://api.dicebear.com/7.x/avataaars/svg?seed=' . $userId . '" alt="Avatar" class="user-avatar" onclick="openProfilModal()" title="Lihat Profil" id="headerAvatar">';
            }
            ?>
        </div>

        <!-- Card Statistics -->
        <div class="stats-container">
            <div class="stat-card blue">
                <div class="stat-icon">📄</div>
                <div class="stat-content">
                    <div class="stat-label">Total Transaksi</div>
                    <div class="stat-value" id="cardTotalTransaksi">0</div>
                    <div class="stat-subtitle">Semua periode</div>
                </div>
            </div>
            <div class="stat-card green">
                <div class="stat-icon">✓</div>
                <div class="stat-content">
                    <div class="stat-label">Total Dibayar</div>
                    <div class="stat-value" id="cardTotalDibayar">Rp 0</div>
                    <div class="stat-subtitle">Pembayaran sukses</div>
                </div>
            </div>
            <div class="stat-card red">
                <div class="stat-icon">⚠</div>
                <div class="stat-content">
                    <div class="stat-label">Transaksi Tertunda</div>
                    <div class="stat-value" id="cardTertunda">0</div>
                    <div class="stat-subtitle">Belum dikonfirmasi</div>
                </div>
            </div>
        </div>

        <div class="section">
            <h2 class="section-title">History Pembayaran</h2>
            <table>
                <thead>
                    <tr>
                        <th>No</th>
                        <th>Semester</th>
                        <th>Jenis Pembayaran</th>
                        <th>Jumlah Bayar</th>
                        <th>Status</th>
                        <th>Tanggal Bayar</th>
                        <th>Bukti Pembayaran</th>
                    </tr>
                </thead>
                <tbody id="historyTable">
                    <tr>
                        <td colspan="7" style="text-align: center; padding: 20px;">Loading data riwayat pembayaran...</td>
                    </tr>
                </tbody>
            </table>
        </div>
    </div>

    <!-- Modal untuk upload bukti pembayaran -->
    <div class="modal-overlay" id="uploadModal">
        <div class="modal-content">
            <div class="modal-header">
                <div class="modal-title">Upload Bukti Pembayaran</div>
                <button class="modal-close" id="modalClose">&times;</button>
            </div>
            <div class="modal-body">
                <div class="upload-details">
                    <div class="upload-details-title">Detail Transaksi</div>
                    <div class="detail-row">
                        <span class="detail-label">Periode</span>
                        <span class="detail-value" id="modalPeriode">-</span>
                    </div>
                    <div class="detail-row">
                        <span class="detail-label">Jenis Pembayaran</span>
                        <span class="detail-value" id="modalJenis">-</span>
                    </div>
                    <div class="detail-row">
                        <span class="detail-label">Jumlah Bayar</span>
                        <span class="detail-value" id="modalJumlah">-</span>
                    </div>
                    <div class="detail-row">
                        <span class="detail-label">Tanggal Bayar</span>
                        <span class="detail-value" id="modalTanggal">-</span>
                    </div>
                </div>
                
                <div class="upload-area" id="uploadArea">
                    <div class="upload-icon-large">📤</div>
                    <div class="upload-text">Seret file ke sini atau klik untuk mengupload</div>
                    <div class="upload-subtext">Format yang didukung: JPG, PNG, PDF (Maks. 5MB)</div>
                    <input type="file" id="fileInput" class="file-input" accept=".jpg,.jpeg,.png,.pdf">
                </div>
                
                <div class="file-info" id="fileInfo">
                    <div class="file-name" id="fileName">-</div>
                    <div class="file-size" id="fileSize">-</div>
                </div>
                
                <div class="upload-note">
                    Pastikan bukti pembayaran jelas terbaca dan sesuai dengan nominal transaksi.
                </div>
            </div>
            <div class="modal-footer">
                <button class="btn-cancel" id="modalCancel">Batal</button>
                <button class="btn-upload-modal" id="modalUpload" disabled>Upload</button>
            </div>
        </div>
    </div>

    <script src="js/auth.js"></script>
    <script>
        // Format Rupiah
        function formatRupiah(angka) {
            return 'Rp. ' + angka.toLocaleString('id-ID');
        }

        // Format Rupiah Card
        function formatRupiahCard(angka) {
            return 'Rp ' + angka.toLocaleString('id-ID');
        }

        // Format file size
        function formatFileSize(bytes) {
            if (bytes === 0) return '0 Bytes';
            const k = 1024;
            const sizes = ['Bytes', 'KB', 'MB', 'GB'];
            const i = Math.floor(Math.log(bytes) / Math.log(k));
            return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
        }

        // Get auth token
        function getAuthToken() {
            return localStorage.getItem('auth_token');
        }

        // Fetch riwayat pembayaran from backend
        async function fetchRiwayatPembayaran() {
            try {
                const token = getAuthToken();
                if (!token) {
                    console.error('No auth token');
                    return null;
                }

                const response = await fetch('/projek_plbs/api/index.php/api/mahasiswa/pembayaran/riwayat', {
                    method: 'GET',
                    credentials: 'include',
                    headers: {
                        'Authorization': `Bearer ${token}`,
                        'Content-Type': 'application/json'
                    }
                });

                if (!response.ok) {
                    throw new Error(`HTTP error! status: ${response.status}`);
                }

                const data = await response.json();
                if (data.status === 'success') {
                    return data.data;
                } else {
                    console.error('API Error:', data.message);
                    return null;
                }
            } catch (error) {
                console.error('Error fetching riwayat:', error);
                return null;
            }
        }

        // Render history table
        function renderHistoryTable(riwayatData) {
            const tableBody = document.getElementById('historyTable');
            
            if (!riwayatData || !riwayatData.pembayaran || riwayatData.pembayaran.length === 0) {
                tableBody.innerHTML = `
                    <tr>
                        <td colspan="7" style="text-align: center; padding: 20px;">
                            Belum ada riwayat pembayaran.
                        </td>
                    </tr>
                `;
                return;
            }

            tableBody.innerHTML = '';
            riwayatData.pembayaran.forEach((payment, index) => {
                const row = document.createElement('tr');
                
                // Status badge - MUST use status_validasi (pembayaran status), not tagihan status
                let statusBadge = '';
                if (payment.status_validasi === 'menunggu_validasi') {
                    statusBadge = '<span class="status-menunggu">MENUNGGU</span>';
                } else if (payment.status_validasi === 'ditolak') {
                    statusBadge = '<span class="status-belum-lunas">DITOLAK</span>';
                } else if (payment.status_validasi === 'valid' || payment.status_validasi === 'divalidasi') {
                    statusBadge = '<span class="status-lunas">DITERIMA</span>';
                }
                
                // Lihat bukti button - HANYA tampilkan jika bukti ada
                let buktiButton = '';
                if (payment.bukti_pembayaran_url && payment.bukti_pembayaran_url.trim() !== '') {
                    buktiButton = `
                        <button class="btn-lihat-bukti" onclick="lihatBukti('${payment.pembayaran_id}', '${payment.bukti_pembayaran_url}')">
                            LIHAT BUKTI
                        </button>
                    `;
                } else {
                    buktiButton = `<button class="btn-lihat-bukti disabled" disabled>TIDAK ADA</button>`;
                }
                
                // Format semester display
                const semesterDisplay = `${payment.tahun_akademik} - Sem ${payment.semester}`;
                
                row.innerHTML = `
                    <td>${index + 1}</td>
                    <td>${semesterDisplay}</td>
                    <td>${payment.jenis_tagihan}</td>
                    <td>${formatRupiah(payment.jumlah_pembayaran)}</td>
                    <td>${statusBadge}</td>
                    <td>${payment.tgl_pembayaran}</td>
                    <td>${buktiButton}</td>
                `;
                tableBody.appendChild(row);
            });
        }

        // Update summary statistics
        function updateSummary(riwayatData) {
            if (!riwayatData || !riwayatData.pembayaran) {
                document.getElementById('cardTotalTransaksi').textContent = '0';
                document.getElementById('cardTotalDibayar').textContent = 'Rp 0';
                document.getElementById('cardTertunda').textContent = '0';
                return;
            }

            const pembayaran = riwayatData.pembayaran;
            const totalTransaksi = pembayaran.length;
            
            // PENTING: Hitung total HANYA dari pembayaran VALID (status_validasi = 'valid')
            const validPayments = pembayaran.filter(item => item.status_validasi === 'valid');
            const totalNominal = validPayments.reduce((sum, item) => sum + (item.jumlah_pembayaran || 0), 0);
            
            const transaksiTertunda = pembayaran.filter(item => item.status_validasi === 'menunggu_validasi').length;
            
            document.getElementById('cardTotalTransaksi').textContent = totalTransaksi;
            document.getElementById('cardTotalDibayar').textContent = formatRupiahCard(totalNominal);
            document.getElementById('cardTertunda').textContent = transaksiTertunda;
        }

        // Lihat bukti pembayaran
        function lihatBukti(pembayaranId, buktiBuktiUrl) {
            // Jika bukti ada, buka di tab baru atau modal
            if (!buktiBuktiUrl) {
                alert('Bukti pembayaran belum tersedia');
                return;
            }
            
            // Buka file bukti di tab baru
            window.open(buktiBuktiUrl, '_blank');
        }

        // Initialize page
        document.addEventListener('DOMContentLoaded', async function() {
            requireAuth('mahasiswa');
            
            const user = getCurrentUser();
            
            // Update sidebar
            document.querySelector('.user-id').textContent = user.nim || user.user_id || '-';
            document.querySelector('.user-name').textContent = user.nama_lengkap || 'Mahasiswa';

            // Fetch and render riwayat
            const riwayatData = await fetchRiwayatPembayaran();
            renderHistoryTable(riwayatData);
            updateSummary(riwayatData);
            
            // Event listeners untuk modal
            document.getElementById('modalClose').addEventListener('click', function() {
                document.getElementById('uploadModal').classList.remove('active');
            });
            
            // Tutup modal saat klik di luar modal
            document.getElementById('uploadModal').addEventListener('click', function(e) {
                if (e.target === this) {
                    document.getElementById('uploadModal').classList.remove('active');
                }
            });
            
            // Menu interactions
            const menuItems = document.querySelectorAll('.menu-item');
            menuItems.forEach(item => {
                item.addEventListener('click', function() {
                    menuItems.forEach(mi => mi.classList.remove('active'));
                    this.classList.add('active');
                });
            });
        });
    </script>
</body>
</html>

    <?php include 'components/profil_modal.php'; ?>
