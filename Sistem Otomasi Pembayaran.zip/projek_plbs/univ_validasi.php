<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header('Location: login_admin_universitas.php');
    exit;
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Validasi Bukti Pembayaran - Tabel</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.13.1/font/bootstrap-icons.min.css">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: #f5f5f5;
            display: flex;
        }

        .sidebar {
            width: 260px;
            background-color: #1a1a1a;
            color: white;
            height: 100vh;
            position: fixed;
            left: 0;
            top: 0;
        }

        .logo {
            padding: 20px;
            text-align: center;
            border-bottom: 1px solid #333;
        }

        .logo img {
            width: 80px;
            height: auto;
        }

        .user-info {
            padding: 30px 20px;
            text-align: center;
            border-bottom: 1px solid #333;
        }

        .user-name {
            font-size: 16px;
            font-weight: 600;
            margin-bottom: 15px;
        }

        .user-actions {
            display: flex;
            gap: 8px;
            justify-content: center;
        }

        .user-actions a {
            padding: 8px 12px;
            background: #3b82f6;
            color: white;
            text-decoration: none;
            border-radius: 5px;
            font-size: 12px;
            transition: background 0.3s;
        }

        .user-actions a:hover {
            background: #1d4ed8;
        }

        .menu {
            padding: 20px 0;
        }

        .menu-item {
            padding: 15px 20px;
            cursor: pointer;
            display: flex;
            align-items: center;
            gap: 12px;
            transition: background-color 0.3s;
        }
         .menu-item.active { 
            background-color: #4CAF50; }


        .menu-item:hover {
            background-color: #333;
        }

        .menu-item.active {
            background-color: #4CAF50;
        }

        .menu-icon {
            width: 24px;
            height: 24px;
            display: flex;
            align-items: center;
            justify-content: center;
        }

        .menu a {
            text-decoration: none;
            color: inherit;
        }

        .main-content {
            margin-left: 260px;
            flex: 1;
            padding: 20px 40px;
        }

        .header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 30px;
            background: white;
            padding: 15px 25px;
            border-radius: 8px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
        }

        .header-title {
            font-size: 20px;
            color: #666;
            display: flex;
            align-items: center;
            gap: 15px;
        }

        .menu-dots {
            font-size: 24px;
            cursor: pointer;
            color: #999;
        }



        .section {
            background: white;
            border-radius: 8px;
            padding: 30px;
            margin-bottom: 30px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
        }

        .section-title {
            font-size: 22px;
            margin-bottom: 25px;
            color: #333;
            font-weight: 600;
            border-bottom: 2px solid #4169E1;
            padding-bottom: 10px;
        }

        /* Tabel Styling */
        .table-container {
            overflow-x: auto;
            margin-bottom: 20px;
            border: 1px solid #e9ecef;
            border-radius: 8px;
        }

        .payment-table {
            width: 100%;
            border-collapse: collapse;
        }

        .payment-table th {
            background-color: #f8f9fa;
            color: #333;
            font-weight: 600;
            text-align: left;
            padding: 15px 12px;
            border-bottom: 2px solid #dee2e6;
            font-size: 14px;
            white-space: nowrap;
        }

        .payment-table td {
            padding: 15px 12px;
            border-bottom: 1px solid #e9ecef;
            vertical-align: middle;
        }

        .payment-table tbody tr:last-child td {
            border-bottom: none;
        }

        .payment-table tbody tr:hover {
            background-color: #f8f9fa;
        }

        /* Data cell styling - menghapus info-label */
        .data-cell {
            font-size: 14px;
            color: #333;
            font-weight: 500;
        }

        /* Bukti Pembayaran dalam Tabel */
        .proof-cell {
            text-align: center;
        }

        .proof-btn {
            background-color: #6c757d;
            color: white;
            border: none;
            padding: 8px 16px;
            border-radius: 4px;
            cursor: pointer;
            font-size: 12px;
            font-weight: 600;
            transition: all 0.3s;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            gap: 6px;
            min-width: 100px;
        }

        .proof-btn:hover {
            background-color: #5a6268;
            transform: translateY(-2px);
            box-shadow: 0 4px 8px rgba(0,0,0,0.1);
        }

        .proof-btn:disabled {
            background-color: #e9ecef;
            color: #6c757d;
            cursor: not-allowed;
            transform: none;
            box-shadow: none;
        }
        /* Bukti pembayaran langsung tampil di modal */
        .proof-image-direct {
            max-width: 100%;
            border-radius: 8px;
            border: 1px solid #dee2e6;
            cursor: zoom-in;
            transition: transform 0.3s;
        }

        .proof-image-direct:hover {
            transform: scale(1.02);
        }



        /* Status Badge */
        .status-badge {
            display: inline-block;
            padding: 6px 12px;
            border-radius: 20px;
            font-size: 12px;
            font-weight: 600;
            min-width: 120px;
            text-align: center;
            white-space: nowrap;
        }

        .status-pending {
            background-color: #fff3cd;
            color: #856404;
            border: 1px solid #ffeaa7;
        }

        .status-approved {
            background-color: #d4edda;
            color: #155724;
            border: 1px solid #c3e6cb;
        }

        .status-rejected {
            background-color: #f8d7da;
            color: #721c24;
            border: 1px solid #f5c6cb;
        }

        /* Action Buttons - SEMUA TOMBOL SEJALAR */
        .action-cell {
            min-width: 200px;
        }

        .action-buttons {
            display: flex;
            gap: 6px;
            flex-wrap: nowrap;
            align-items: center;
        }

        .action-btn {
            padding: 6px 10px;
            border: none;
            border-radius: 4px;
            font-size: 12px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 4px;
            white-space: nowrap;
            min-width: 70px;
            height: 32px;
            flex: 1;
        }

        .btn-approve {
            background-color: #28a745;
            color: white;
        }

        .btn-approve:hover {
            background-color: #218838;
            transform: translateY(-2px);
            box-shadow: 0 4px 8px rgba(40, 167, 69, 0.3);
        }

        .btn-reject {
            background-color: #dc3545;
            color: white;
        }

        .btn-reject:hover {
            background-color: #c82333;
            transform: translateY(-2px);
            box-shadow: 0 4px 8px rgba(220, 53, 69, 0.3);
        }

        .btn-details {
            background-color: #007bff;
            color: white;
        }

        .btn-details:hover {
            background-color: #0056b3;
            transform: translateY(-2px);
        }

        .btn-krs {
            background-color: #17a2b8;
            color: white;
        }

        .btn-krs:hover {
            background-color: #138496;
            transform: translateY(-2px);
        }

        .btn-disabled {
            background-color: #6c757d;
            color: white;
            cursor: not-allowed;
            opacity: 0.6;
        }

        .btn-disabled:hover {
            transform: none;
            box-shadow: none;
        }

        /* Filter Section */
        .filter-section {
            display: flex;
            gap: 15px;
            margin-bottom: 25px;
            flex-wrap: wrap;
            align-items: center;
            background-color: #f8f9fa;
            padding: 15px;
            border-radius: 6px;
        }

        .filter-group {
            display: flex;
            flex-direction: column;
            min-width: 180px;
        }

        .filter-label {
            font-size: 13px;
            font-weight: 600;
            margin-bottom: 5px;
            color: #495057;
        }

        .filter-select {
            padding: 8px 12px;
            border: 1px solid #ced4da;
            border-radius: 4px;
            font-size: 14px;
            background-color: white;
        }

        .filter-buttons {
            display: flex;
            gap: 10px;
            align-self: flex-end;
            margin-top: 10px;
        }

        /* Modal untuk preview gambar bukti */
        .image-modal {
            display: none;
            position: fixed;
            z-index: 1000;
            left: 0;
            top: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(0,0,0,0.9);
        }

        .image-modal-content {
            margin: auto;
            display: block;
            max-width: 90%;
            max-height: 90%;
            position: absolute;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
        }

        .close-image-modal {
            position: absolute;
            top: 20px;
            right: 35px;
            color: #f1f1f1;
            font-size: 40px;
            font-weight: bold;
            cursor: pointer;
        }

        .close-image-modal:hover {
            color: #bbb;
        }

        /* Modal untuk detail pembayaran - SEDERHANA DAN TERPUSAT */
        .detail-modal {
            display: none;
            position: fixed;
            z-index: 1001;
            left: 0;
            top: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(0,0,0,0.5);
            animation: fadeIn 0.3s ease-out;
        }

        @keyframes fadeIn {
            from { opacity: 0; }
            to { opacity: 1; }
        }

        .detail-modal-content {
            background-color: white;
            margin: 30px auto;
            width: 95%;
            max-width: 600px;
            border-radius: 12px;
            box-shadow: 0 5px 20px rgba(0,0,0,0.15);
            overflow: hidden;
            animation: slideIn 0.4s ease-out;
            max-height: 85vh;
            display: flex;
            flex-direction: column;
        }

        @keyframes slideIn {
            from { transform: translateY(-30px); opacity: 0; }
            to { transform: translateY(0); opacity: 1; }
        }

        .detail-modal-header {
            background: #f8f9fa;
            color: #333;
            padding: 20px 25px;
            border-bottom: 1px solid #e9ecef;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .detail-modal-title {
            font-size: 18px;
            font-weight: 600;
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .close-detail-modal {
            color: #6c757d;
            font-size: 28px;
            font-weight: bold;
            cursor: pointer;
            width: 36px;
            height: 36px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            transition: all 0.3s;
        }

        .close-detail-modal:hover {
            background: #e9ecef;
            color: #333;
        }

        .detail-modal-body {
            padding: 25px;
            flex: 1;
            overflow-y: auto;
        }

        /* Detail info dalam satu container */
        .detail-container {
            background: #f8f9fa;
            border-radius: 8px;
            padding: 25px;
        }

        .detail-row {
            display: flex;
            margin-bottom: 16px;
            padding-bottom: 16px;
            border-bottom: 1px solid #e9ecef;
            align-items: center;
        }

        .detail-row:last-child {
            margin-bottom: 0;
            padding-bottom: 0;
            border-bottom: none;
        }

        .detail-label {
            flex: 0 0 160px;
            font-size: 14px;
            color: #666;
            font-weight: 500;
        }

        .detail-value {
            flex: 1;
            font-size: 14px;
            color: #333;
            font-weight: 500;
        }

        .detail-value strong {
            font-weight: 600;
        }

        .detail-status {
            display: inline-block;
            padding: 6px 12px;
            border-radius: 20px;
            font-size: 13px;
            font-weight: 600;
        }

        .status-pending-modal {
            background-color: #fff3cd;
            color: #856404;
        }

        .status-approved-modal {
            background-color: #d4edda;
            color: #155724;
        }

        .status-rejected-modal {
            background-color: #f8d7da;
            color: #721c24;
        }

        /* Bukti pembayaran dalam modal */
        .proof-preview {
            display: inline-flex;
            align-items: center;
            gap: 8px;
            padding: 8px 16px;
            background-color: #007bff;
            color: white;
            border-radius: 4px;
            cursor: pointer;
            transition: all 0.3s;
            font-size: 14px;
            font-weight: 500;
        }

        .proof-preview:hover {
            background-color: #0056b3;
            transform: translateY(-2px);
            box-shadow: 0 4px 8px rgba(0,0,0,0.1);
        }

        .no-proof {
            color: #6c757d;
            font-style: italic;
        }

        /* Catatan */
        .detail-notes {
            margin-top: 25px;
            padding: 20px;
            background-color: #fff;
            border: 1px solid #e9ecef;
            border-radius: 8px;
        }

        .notes-title {
            font-size: 15px;
            font-weight: 600;
            color: #333;
            margin-bottom: 12px;
            display: flex;
            align-items: center;
            gap: 8px;
        }

        .notes-content {
            font-size: 14px;
            color: #333;
            line-height: 1.6;
            white-space: pre-line;
        }

        .no-notes {
            color: #6c757d;
            font-style: italic;
        }

        /* Footer modal */
        .detail-modal-footer {
            padding: 20px 25px;
            background-color: #f8f9fa;
            border-top: 1px solid #e9ecef;
            display: flex;
            justify-content: space-between;
            gap: 10px;
        }

        .modal-btn {
            padding: 10px 20px;
            border: none;
            border-radius: 6px;
            font-size: 14px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 8px;
            min-width: 140px;
        }

        .modal-btn-primary {
            background-color: #28a745;
            color: white;
        }

        .modal-btn-primary:hover {
            background-color: #218838;
            transform: translateY(-2px);
            box-shadow: 0 4px 8px rgba(40, 167, 69, 0.3);
        }

        .modal-btn-secondary {
            background-color: #6c757d;
            color: white;
        }

        .modal-btn-secondary:hover {
            background-color: #5a6268;
            transform: translateY(-2px);
        }

        .modal-btn-danger {
            background-color: #dc3545;
            color: white;
        }

        .modal-btn-danger:hover {
            background-color: #c82333;
            transform: translateY(-2px);
        }

        .modal-btn-info {
            background-color: #17a2b8;
            color: white;
        }

        .modal-btn-info:hover {
            background-color: #138496;
            transform: translateY(-2px);
        }

        /* Pagination dengan Prev/Next */
        .pagination-container {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-top: 30px;
            padding-top: 20px;
            border-top: 1px solid #e9ecef;
        }

        .pagination-info {
            font-size: 14px;
            color: #6c757d;
        }

        .pagination-controls {
            display: flex;
            gap: 10px;
            align-items: center;
        }

        .page-btn {
            padding: 8px 16px;
            background-color: white;
            border: 1px solid #dee2e6;
            border-radius: 4px;
            cursor: pointer;
            font-size: 14px;
            font-weight: 600;
            display: flex;
            align-items: center;
            gap: 6px;
            transition: all 0.3s;
        }

        .page-btn:hover:not(:disabled) {
            background-color: #007bff;
            color: white;
            border-color: #007bff;
        }

        .page-btn:disabled {
            opacity: 0.5;
            cursor: not-allowed;
        }

        .page-numbers {
            display: flex;
            gap: 5px;
        }

        .page-number {
            padding: 8px 12px;
            background-color: white;
            border: 1px solid #dee2e6;
            border-radius: 4px;
            cursor: pointer;
            font-size: 14px;
            min-width: 40px;
            text-align: center;
        }

        .page-number.active {
            background-color: #007bff;
            color: white;
            border-color: #007bff;
        }

        .page-number:hover:not(.active) {
            background-color: #e9ecef;
        }

        /* Summary Stats */
        .summary-stats {
            display: flex;
            gap: 20px;
            margin-bottom: 25px;
            flex-wrap: wrap;
        }

        .stat-card {
            flex: 1;
            min-width: 200px;
            background: white;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
        }

        .stat-title {
            font-size: 14px;
            color: #6c757d;
            margin-bottom: 10px;
        }

        .stat-value {
            font-size: 24px;
            font-weight: 700;
            color: #333;
        }

        .stat-pending { border-left: 4px solid #ffc107; }
        .stat-approved { border-left: 4px solid #28a745; }
        .stat-rejected { border-left: 4px solid #dc3545; }
        .stat-total { border-left: 4px solid #007bff; }

        /* Responsive */
        @media (max-width: 1200px) {
            .main-content {
                margin-left: 0;
                padding: 15px;
            }
            
            .sidebar {
                display: none;
            }
            
            .payment-table {
                font-size: 13px;
            }
            
            .action-buttons {
                flex-direction: row;
                flex-wrap: wrap;
            }
            
            .action-btn {
                min-width: 60px;
                font-size: 11px;
                padding: 5px 8px;
            }
        }

        @media (max-width: 768px) {
            .pagination-container {
                flex-direction: column;
                gap: 15px;
            }
            
            .page-numbers {
                order: -1;
            }
            
            .filter-section {
                flex-direction: column;
                align-items: stretch;
            }
            
            .filter-buttons {
                align-self: stretch;
                justify-content: center;
            }
            
            .action-buttons {
                flex-direction: column;
            }
            
            .action-btn {
                width: 100%;
            }
            
            .detail-modal-content {
                width: 95%;
                margin: 20px auto;
                max-height: 90vh;
            }
            
            .detail-row {
                flex-direction: column;
                gap: 5px;
                align-items: flex-start;
                margin-bottom: 20px;
            }
            
            .detail-label {
                flex: none;
                margin-bottom: 2px;
            }
            
            .detail-value {
                flex: none;
                width: 100%;
            }
            
            .detail-modal-footer {
                flex-direction: column;
            }
            
            .modal-btn {
                width: 100%;
                justify-content: center;
            }
        }
    </style>
</head>
<body>
    <div class="sidebar">
        <div class="logo">
            <img src="pictures/logo umi.png" alt="Logo">
        </div>
        <div class="user-info">
            <div class="user-name">Admin Universitas</div>
            <div class="user-actions">
                <a href="#" onclick="logout(); return false;">Logout</a>
            </div>
        </div>
        <div class="menu">
            <a href="dashboard_admin_universitas.php" class="menu-item">
                <div class="menu-icon"><i class="bi bi-house-door"></i></div>
                <div>Dashboard</div>
            </a>

            <a href="univ_validasi.php" class="menu-item active">
                <div class="menu-icon"><i class="bi bi-clipboard-check"></i></div>
                <div>Validasi Pembayaran</div>
            </a>

            <a href="univ_riwayat_pembayaran.php" class="menu-item">
                <div class="menu-icon"><i class="bi bi-card-checklist"></i></div>
                <div>Riwayat Pembayaran</div>
            </a>
        </div>
    </div>

    <div class="main-content">
        <div class="header">
            <div class="header-title">
                <span class="menu-dots">⋮</span>
                <span>Validasi Bukti Pembayaran - Tabel</span>
            </div>
        </div>

        <div class="section">
            <h2 class="section-title">Daftar Pembayaran Mahasiswa</h2>
            
            <!-- Summary Statistics -->
            <div class="summary-stats">
                <div class="stat-card stat-total">
                    <div class="stat-title">Total Pembayaran</div>
                    <div class="stat-value" id="totalCount">0</div>
                </div>
                <div class="stat-card stat-pending">
                    <div class="stat-title">Menunggu Validasi</div>
                    <div class="stat-value" id="pendingCount">0</div>
                </div>
                <div class="stat-card stat-approved">
                    <div class="stat-title">Disetujui</div>
                    <div class="stat-value" id="approvedCount">0</div>
                </div>
                <div class="stat-card stat-rejected">
                    <div class="stat-title">Ditolak</div>
                    <div class="stat-value" id="rejectedCount">0</div>
                </div>
            </div>

            <!-- Filter Section -->
            <div class="filter-section">
                <div class="filter-group">
                    <label class="filter-label">Status</label>
                    <select class="filter-select" id="statusFilter">
                        <option value="all">Semua Status</option>
                        <option value="pending">Menunggu Validasi</option>
                        <option value="approved">Disetujui</option>
                        <option value="rejected">Ditolak</option>
                    </select>
                </div>
                
                <div class="filter-group">
                    <label class="filter-label">Jenis Pembayaran</label>
                    <select class="filter-select" id="typeFilter">
                        <option value="all">Semua Jenis</option>
                        <option value="BPP">BPP</option>
                        <option value="UKT">UKT</option>
                        <option value="SPP">SPP</option>
                        <option value="Lainnya">Lainnya</option>
                    </select>
                </div>
                
                <div class="filter-group">
                    <label class="filter-label">Periode</label>
                    <select class="filter-select" id="periodFilter">
                        <option value="all">Semua Periode</option>
                        <option value="2025/2026">2025/2026</option>
                        <option value="2024/2025">2024/2025</option>
                        <option value="2023/2024">2023/2024</option>
                    </select>
                </div>
                
                <div class="filter-buttons">
                    <button class="action-btn" onclick="resetFilters()" style="background-color: #6c757d; color: white;">Reset</button>
                </div>
            </div>

            <!-- Payment Table -->
            <div class="table-container">
                <table class="payment-table">
                    <thead>
                        <tr>
                            <th width="4%">No</th>
                            <th width="9%">NIM</th>
                            <th width="13%">Nama Mahasiswa</th>
                            <th width="9%">Jenis</th>
                            <th width="8%">Tipe Bayar</th>
                            <th width="9%">Periode</th>
                            <th width="11%">Jumlah</th>
                            <th width="9%">Tanggal Upload</th>
                            <th width="8%">Status</th>
                            <th width="11%">Bukti Pembayaran</th>
                            <th width="14%" class="action-cell">Aksi</th>
                        </tr>
                    </thead>
                    <tbody id="paymentTableBody">
                        <!-- Data akan diisi oleh JavaScript -->
                    </tbody>
                </table>
            </div>

            <!-- Pagination dengan Prev/Next -->
            <div class="pagination-container">
                <div class="pagination-info" id="pageInfo">
                    Menampilkan 0-0 dari 0 data
                </div>
                <div class="pagination-controls">
                    <button class="page-btn" id="prevBtn" onclick="prevPage()" disabled>
                        ← Prev
                    </button>
                    <div class="page-numbers" id="pageNumbers">
                        <!-- Nomor halaman akan diisi oleh JavaScript -->
                    </div>
                    <button class="page-btn" id="nextBtn" onclick="nextPage()">
                        Next →
                    </button>
                </div>
            </div>
        </div>
    </div>

    <!-- Modal untuk preview gambar bukti -->
    <div id="imageModal" class="image-modal" onclick="closeImageModal()">
        <span class="close-image-modal">&times;</span>
        <img class="image-modal-content" id="modalImage">
    </div>

    <!-- Modal untuk detail pembayaran - SEDERHANA DAN TERPUSAT -->
    <div id="detailModal" class="detail-modal">
        <div class="detail-modal-content">
            <div class="detail-modal-header">
                <div class="detail-modal-title">
                    📋 Detail Pembayaran
                </div>
                <span class="close-detail-modal" onclick="closeDetailModal()">&times;</span>
            </div>
            
            <div class="detail-modal-body" id="detailModalBody">
                <!-- Detail akan diisi oleh JavaScript -->
            </div>
            
            <div class="detail-modal-footer" id="detailModalFooter">
                <!-- Footer akan diisi oleh JavaScript -->
            </div>
        </div>
    </div>

    <script>
        // Data pembayaran dari backend API
        let paymentData = [];
        let allPaymentData = [];

        // Variabel untuk menyimpan payment yang sedang dilihat
        let currentPaymentDetail = null;

        // Variabel untuk pagination
        let currentPage = 1;
        let itemsPerPage = 5;
        let filteredData = [];

        // Fetch pending payments from backend API
        function loadPaymentData() {
            const token = localStorage.getItem('auth_token');
            
            console.log('[LoadPaymentData] Starting data load...');
            console.log('[LoadPaymentData] Token exists:', !!token);
            
            if (!token) {
                console.error('[LoadPaymentData] No auth token found in localStorage');
                alert('Anda belum login atau session berakhir. Silakan login kembali.');
                window.location.href = 'login_admin_universitas.php';
                return;
            }
            
            const endpoint = '/projek_plbs/api/index.php/api/admin/pembayaran/menunggu-validasi?page=1&limit=100';
            console.log('[LoadPaymentData] Fetching from endpoint:', endpoint);
            
            fetch(endpoint, {
                method: 'GET',
                credentials: 'include',
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': `Bearer ${token}`
                }
            })
            .then(response => {
                console.log('[LoadPaymentData] Response status:', response.status);
                console.log('[LoadPaymentData] Response headers:', response.headers);
                
                if (!response.ok) {
                    const errorMsg = `HTTP ${response.status}: ${response.statusText}`;
                    console.error('[LoadPaymentData] Response error:', errorMsg);
                    throw new Error(errorMsg);
                }
                return response.json();
            })
            .then(data => {
                console.log('[LoadPaymentData] API Response received:', data);
                
                if (data.status === 'success' && data.data && data.data.pembayaran) {
                    console.log('[LoadPaymentData] Processing payment data...');
                    
                    // Transform API response to match expected format
                    paymentData = data.data.pembayaran.map(p => ({
                        pembayaran_id: p.pembayaran_id,
                        id: p.pembayaran_id,
                        nim: p.mahasiswa.nim,
                        name: p.mahasiswa.nama_lengkap,
                        paymentType: p.tagihan.jenis_tagihan,
                        paymentMethod: p.metode_pembayaran || 'Lunas',
                        period: `${p.tagihan.semester}`,
                        amount: parseInt(p.pembayaran_detail.jumlah_pembayaran),
                        totalAmount: parseInt(p.tagihan.jumlah_tagihan),
                        uploadDate: p.created_at,
                        transactionType: p.pembayaran_detail.nomor_va || 'Transfer',
                        status: 'pending', // menunggu_validasi maps to pending
                        notes: '',
                        proofImage: p.bukti_pembayaran ? p.bukti_pembayaran.url : null,
                        bukti_filename: p.bukti_pembayaran ? p.bukti_pembayaran.filename : null
                    }));
                    
                    console.log('[LoadPaymentData] Successfully loaded', paymentData.length, 'payments');
                    allPaymentData = [...paymentData];
                    filteredData = [...paymentData];
                    console.log('[LoadPaymentData] Rendering table...');
                    renderTable();
                    console.log('[LoadPaymentData] Complete!');
                } else {
                    const errorMsg = data.message || 'Unknown error';
                    console.error('[LoadPaymentData] API returned error:', errorMsg);
                    console.error('[LoadPaymentData] Full response:', data);
                    alert('Gagal memuat data pembayaran:\n\n' + errorMsg);
                }
            })
            .catch(error => {
                console.error('[LoadPaymentData] Fetch error:', error);
                console.error('[LoadPaymentData] Error message:', error.message);
                console.error('[LoadPaymentData] Error stack:', error.stack);
                alert('Gagal memuat data pembayaran:\n\n' + error.message + '\n\nSilakan buka DevTools (F12) dan lihat Console tab untuk detail lengkap error.');
            });
        }

        // Format tanggal
        function formatDate(dateString) {
            const date = new Date(dateString);
            const day = date.getDate().toString().padStart(2, '0');
            const month = (date.getMonth() + 1).toString().padStart(2, '0');
            const year = date.getFullYear();
            const hours = date.getHours().toString().padStart(2, '0');
            const minutes = date.getMinutes().toString().padStart(2, '0');
            
            return `${day}/${month}/${year} ${hours}:${minutes}`;
        }

        // Format Rupiah
        function formatRupiah(angka) {
            return 'Rp ' + angka.toLocaleString('id-ID');
        }

        // Update statistik
        function updateStats() {
            const total = filteredData.length;
            const pending = filteredData.filter(p => p.status === 'pending').length;
            const approved = filteredData.filter(p => p.status === 'approved').length;
            const rejected = filteredData.filter(p => p.status === 'rejected').length;
            
            document.getElementById('totalCount').textContent = total;
            document.getElementById('pendingCount').textContent = pending;
            document.getElementById('approvedCount').textContent = approved;
            document.getElementById('rejectedCount').textContent = rejected;
        }

        // Render tabel
        function renderTable() {
            const tableBody = document.getElementById('paymentTableBody');
            tableBody.innerHTML = '';
            
            // Hitung data yang ditampilkan
            const startIndex = (currentPage - 1) * itemsPerPage;
            const endIndex = startIndex + itemsPerPage;
            const currentData = filteredData.slice(startIndex, endIndex);
            
            if (currentData.length === 0) {
                tableBody.innerHTML = `
                    <tr>
                        <td colspan="11" style="text-align: center; padding: 40px; color: #6c757d;">
                            Tidak ada data pembayaran yang ditemukan.
                        </td>
                    </tr>
                `;
                updatePagination();
                updateStats();
                return;
            }
            
            currentData.forEach((item, index) => {
                const row = document.createElement('tr');
                const globalIndex = startIndex + index;
                
                // Status badge
                let statusBadge = '';
                if (item.status === 'pending') {
                    statusBadge = `<span class="status-badge status-pending">Menunggu Validasi</span>`;
                } else if (item.status === 'approved') {
                    statusBadge = `<span class="status-badge status-approved">Disetujui</span>`;
                } else if (item.status === 'rejected') {
                    statusBadge = `<span class="status-badge status-rejected">Ditolak</span>`;
                }
                
                // Tombol Lihat Bukti
                let proofButton = '';
                if (item.proofImage) {
                    proofButton = `
                        <button class="proof-btn" onclick="viewProof(${item.id})" title="Klik untuk melihat bukti pembayaran">
                            👁 Lihat
                        </button>
                    `;
                } else {
                    proofButton = `
                        <button class="proof-btn" disabled title="Tidak ada bukti pembayaran">
                            Tidak Tersedia
                        </button>
                    `;
                }
                
                // Action buttons - SEMUA TOMBOL SEJALAR
                let actionButtons = '';
                if (item.status === 'pending') {
                    actionButtons = `
                        <div class="action-buttons">
                            <button class="action-btn btn-approve" onclick="approvePayment(${item.id})" title="Validasi pembayaran">
                                ✓ Validasi
                            </button>
                            <button class="action-btn btn-reject" onclick="rejectPayment(${item.id})" title="Tolak pembayaran">
                                ✕ Tolak
                            </button>
                            <button class="action-btn btn-details" onclick="viewPaymentDetails(${item.id})" title="Lihat detail">
                                📋 Detail
                            </button>
                        </div>
                    `;
                } else {
                    actionButtons = `
                        <div class="action-buttons">
                            <button class="action-btn btn-details" onclick="viewPaymentDetails(${item.id})" title="Lihat detail">
                                📋 Detail
                            </button>
                            ${item.status === 'approved' ? 
                                `<button class="action-btn btn-krs" onclick="activateKRS(${item.id})" title="Aktifkan KRS">
                                    🎓 KRS
                                </button>` : 
                                '<button class="action-btn btn-disabled" disabled>Sudah Valid</button>'
                            }
                        </div>
                    `;
                }
                
                // Data langsung ditampilkan tanpa label duplikat
                row.innerHTML = `
                    <td class="data-cell">${globalIndex + 1}</td>
                    <td class="data-cell">${item.nim}</td>
                    <td class="data-cell">${item.name}</td>
                    <td class="data-cell">${item.paymentType}</td>
                    <td class="data-cell"><span style="padding: 4px 8px; border-radius: 4px; font-size: 11px; font-weight: 600; ${item.paymentMethod === 'Cicilan' ? 'background: #fff3cd; color: #856404;' : 'background: #d4edda; color: #155724;'}">${item.paymentMethod}</span></td>
                    <td class="data-cell">${item.period}</td>
                    <td class="data-cell">${formatRupiah(item.amount)}</td>
                    <td class="data-cell">${formatDate(item.uploadDate)}</td>
                    <td>${statusBadge}</td>
                    <td class="proof-cell">${proofButton}</td>
                    <td class="action-cell">${actionButtons}</td>
                `;
                
                tableBody.appendChild(row);
            });
            
            updatePagination();
            updateStats();
        }

        // Update pagination controls
        function updatePagination() {
            const totalPages = Math.ceil(filteredData.length / itemsPerPage);
            const pageNumbersContainer = document.getElementById('pageNumbers');
            const prevBtn = document.getElementById('prevBtn');
            const nextBtn = document.getElementById('nextBtn');
            const pageInfo = document.getElementById('pageInfo');
            
            // Update info
            const startIndex = (currentPage - 1) * itemsPerPage + 1;
            const endIndex = Math.min(currentPage * itemsPerPage, filteredData.length);
            pageInfo.textContent = `Menampilkan ${startIndex}-${endIndex} dari ${filteredData.length} data`;
            
            // Update button states
            prevBtn.disabled = currentPage === 1;
            nextBtn.disabled = currentPage === totalPages || totalPages === 0;
            
            // Update page numbers
            pageNumbersContainer.innerHTML = '';
            
            // Tampilkan maksimal 5 nomor halaman
            let startPage = Math.max(1, currentPage - 2);
            let endPage = Math.min(totalPages, startPage + 4);
            
            // Sesuaikan jika terlalu dekat ke akhir
            if (endPage - startPage < 4) {
                startPage = Math.max(1, endPage - 4);
            }
            
            for (let i = startPage; i <= endPage; i++) {
                const pageBtn = document.createElement('button');
                pageBtn.className = `page-number ${i === currentPage ? 'active' : ''}`;
                pageBtn.textContent = i;
                pageBtn.onclick = () => goToPage(i);
                pageNumbersContainer.appendChild(pageBtn);
            }
        }

        // Pagination functions
        function goToPage(page) {
            currentPage = page;
            renderTable();
        }

        function prevPage() {
            if (currentPage > 1) {
                currentPage--;
                renderTable();
            }
        }

        function nextPage() {
            const totalPages = Math.ceil(filteredData.length / itemsPerPage);
            if (currentPage < totalPages) {
                currentPage++;
                renderTable();
            }
        }

        // Fungsi untuk validasi pembayaran
        function approvePayment(id) {
            const payment = paymentData.find(p => p.id === id);
            
            if (confirm(`Apakah Anda yakin ingin memvalidasi pembayaran dari ${payment.name} (NIM: ${payment.nim})?`)) {
                const token = localStorage.getItem('auth_token');
                const endpoint = `/projek_plbs/api/index.php/api/admin-universitas/pembayaran/${id}/validasi`;
                
                console.log('[ApprovePayment] Starting approval for ID:', id);
                console.log('[ApprovePayment] Endpoint:', endpoint);
                
                // Kirim data ke backend API
                fetch(endpoint, {
                    method: 'POST',
                    credentials: 'include',
                    headers: {
                        'Content-Type': 'application/json',
                        'Authorization': `Bearer ${token}`
                    },
                    body: JSON.stringify({
                        status_validasi: 'valid',
                        catatan_validasi: ''
                    })
                })
                .then(response => {
                    console.log('[ApprovePayment] Response status:', response.status);
                    if (!response.ok) {
                        throw new Error(`HTTP ${response.status}: ${response.statusText}`);
                    }
                    return response.json();
                })
                .then(data => {
                    console.log('[ApprovePayment] API Response:', data);
                    if (data.status === 'success') {
                        alert(`✓ Pembayaran dari ${payment.name} berhasil divalidasi!`);
                        // Reload data from backend
                        loadPaymentData();
                    } else {
                        alert('Error: ' + (data.message || 'Gagal memvalidasi pembayaran'));
                    }
                })
                .catch(error => {
                    console.error('[ApprovePayment] Error:', error);
                    console.error('[ApprovePayment] Error message:', error.message);
                    alert('Gagal memvalidasi pembayaran:\n\n' + error.message);
                });
            }
        }

        // Fungsi untuk menolak pembayaran
        function rejectPayment(id) {
            const payment = paymentData.find(p => p.id === id);
            const reason = prompt(`Masukkan alasan penolakan untuk ${payment.name}:`);
            
            if (reason && reason.trim()) {
                if (confirm(`Apakah Anda yakin ingin menolak pembayaran dari ${payment.name}?`)) {
                    const token = localStorage.getItem('auth_token');
                    const endpoint = `/projek_plbs/api/index.php/api/admin-universitas/pembayaran/${id}/validasi`;
                    
                    console.log('[RejectPayment] Starting rejection for ID:', id);
                    console.log('[RejectPayment] Endpoint:', endpoint);
                    console.log('[RejectPayment] Reason:', reason);
                    
                    // Kirim data ke backend API
                    fetch(endpoint, {
                        method: 'POST',
                        credentials: 'include',
                        headers: {
                            'Content-Type': 'application/json',
                            'Authorization': `Bearer ${token}`
                        },
                        body: JSON.stringify({
                            status_validasi: 'ditolak',
                            catatan_validasi: reason
                        })
                    })
                    .then(response => {
                        console.log('[RejectPayment] Response status:', response.status);
                        if (!response.ok) {
                            throw new Error(`HTTP ${response.status}: ${response.statusText}`);
                        }
                        return response.json();
                    })
                    .then(data => {
                        console.log('[RejectPayment] API Response:', data);
                        if (data.status === 'success') {
                            alert(`✕ Pembayaran dari ${payment.name} telah ditolak.`);
                            // Reload data from backend
                            loadPaymentData();
                        } else {
                            alert('Error: ' + (data.message || 'Gagal menolak pembayaran'));
                        }
                    })
                    .catch(error => {
                        console.error('[RejectPayment] Error:', error);
                        console.error('[RejectPayment] Error message:', error.message);
                        alert('Gagal menolak pembayaran:\n\n' + error.message);
                    });
                }
            } else if (reason !== null) {
                alert('Alasan penolakan harus diisi.');
            }
        }

        // Fungsi untuk melihat detail pembayaran (modal sederhana)
        function viewPaymentDetails(id) {
            const payment = paymentData.find(p => p.id === id);
            currentPaymentDetail = payment;
            
            // Status text dan class
            let statusText = '';
            let statusClass = '';
            if (payment.status === 'pending') {
                statusText = 'Menunggu Validasi';
                statusClass = 'status-pending-modal';
            } else if (payment.status === 'approved') {
                statusText = 'Disetujui';
                statusClass = 'status-approved-modal';
            } else if (payment.status === 'rejected') {
                statusText = 'Ditolak';
                statusClass = 'status-rejected-modal';
            }
            
            // Bukti pembayaran langsung tampil
            let proofContent = '';
            if (payment.proofImage) {
                proofContent = `
                    <img 
                        src="${payment.proofImage}" 
                        alt="Bukti Pembayaran"
                        class="proof-image-direct"
                        onclick="viewProof(${payment.id})"
                        title="Klik untuk memperbesar"
                    >
                `;
            } else {
                proofContent = `<div class="no-proof">Tidak ada bukti pembayaran</div>`;
            }

            
            const detailHTML = `
                <div class="detail-container">
                    <!-- Informasi Mahasiswa -->
                    <div class="detail-row">
                        <div class="detail-label">NIM</div>
                        <div class="detail-value"><strong>${payment.nim}</strong></div>
                    </div>
                    
                    <div class="detail-row">
                        <div class="detail-label">Nama Mahasiswa</div>
                        <div class="detail-value">${payment.name}</div>
                    </div>
                    
                    <!-- Informasi Pembayaran -->
                    <div class="detail-row">
                        <div class="detail-label">Jenis Pembayaran</div>
                        <div class="detail-value">${payment.paymentType}</div>
                    </div>
                    
                    <div class="detail-row">
                        <div class="detail-label">Periode</div>
                        <div class="detail-value">${payment.period}</div>
                    </div>
                    
                    <div class="detail-row">
                        <div class="detail-label">Jumlah</div>
                        <div class="detail-value"><strong>${formatRupiah(payment.amount)}</strong></div>
                    </div>
                    
                    <!-- Informasi Transaksi -->
                    <div class="detail-row">
                        <div class="detail-label">Tanggal Upload</div>
                        <div class="detail-value">${formatDate(payment.uploadDate)}</div>
                    </div>
                    
                    <div class="detail-row">
                        <div class="detail-label">Jenis Transaksi</div>
                        <div class="detail-value">${payment.transactionType}</div>
                    </div>
                    
                    <div class="detail-row">
                        <div class="detail-label">Status</div>
                        <div class="detail-value">
                            <span class="detail-status ${statusClass}">${statusText}</span>
                        </div>
                    </div>
                    
                    <div class="detail-row">
                        <div class="detail-label">Bukti Pembayaran</div>
                        <div class="detail-value">
                            ${proofContent}
                        </div>
                    </div>
                </div>
                
                <!-- Catatan -->
                <div class="detail-notes">
                    <div class="notes-title">📝 Catatan Validasi</div>
                    <div class="notes-content">
                        ${payment.notes ? payment.notes : '<div class="no-notes">Belum ada catatan</div>'}
                    </div>
                </div>
            `;
            
            document.getElementById('detailModalBody').innerHTML = detailHTML;
            
            // Buat footer tombol berdasarkan status
            let footerHTML = '';
            if (payment.status === 'pending') {
                footerHTML = `
                    <button class="modal-btn modal-btn-secondary" onclick="closeDetailModal()">
                        ✕ Tutup
                    </button>
                    <div style="display: flex; gap: 10px;">
                        <button class="modal-btn modal-btn-danger" onclick="rejectPaymentFromModal()">
                            ✕ Tolak
                        </button>
                        <button class="modal-btn modal-btn-primary" onclick="approvePaymentFromModal()">
                            ✓ Validasi
                        </button>
                    </div>
                `;
            } else if (payment.status === 'approved') {
                footerHTML = `
                   
                    <button class="modal-btn modal-btn-info" onclick="activateKRSFromModal()">
                        🎓 Aktifkan KRS
                    </button>
                `;
            } else {
                footerHTML = `
                    <button class="modal-btn modal-btn-primary" onclick="reviewRejection()">
                        🔍 Tinjau Ulang
                    </button>
                `;
            }
            
            document.getElementById('detailModalFooter').innerHTML = footerHTML;
            
            // Tampilkan modal
            document.getElementById('detailModal').style.display = 'block';
        }

        // Fungsi untuk menutup modal detail
        function closeDetailModal() {
            document.getElementById('detailModal').style.display = 'none';
            currentPaymentDetail = null;
        }

        // Fungsi untuk validasi dari modal
        function approvePaymentFromModal() {
            if (currentPaymentDetail) {
                if (confirm(`Validasi pembayaran dari ${currentPaymentDetail.name}?`)) {
                    const token = localStorage.getItem('auth_token');
                    const endpoint = `/projek_plbs/api/index.php/api/admin-universitas/pembayaran/${currentPaymentDetail.id}/validasi`;
                    
                    fetch(endpoint, {
                        method: 'POST',
                        credentials: 'include',
                        headers: {
                            'Content-Type': 'application/json',
                            'Authorization': `Bearer ${token}`
                        },
                        body: JSON.stringify({
                            status_validasi: 'valid',
                            catatan_validasi: ''
                        })
                    })
                    .then(response => {
                        if (!response.ok) {
                            throw new Error(`HTTP ${response.status}: ${response.statusText}`);
                        }
                        return response.json();
                    })
                    .then(data => {
                        if (data.status === 'success') {
                            alert('✓ Pembayaran berhasil divalidasi!');
                            closeDetailModal();
                            loadPaymentData();
                        } else {
                            alert('Error: ' + (data.message || 'Gagal memvalidasi'));
                        }
                    })
                    .catch(error => {
                        alert('Gagal memvalidasi: ' + error.message);
                    });
                }
            }
        }

        // Fungsi untuk menolak dari modal
        function rejectPaymentFromModal() {
            if (currentPaymentDetail) {
                const reason = prompt('Masukkan alasan penolakan:');
                if (reason && reason.trim()) {
                    if (confirm(`Tolak pembayaran dari ${currentPaymentDetail.name}?`)) {
                        const token = localStorage.getItem('auth_token');
                        const endpoint = `/projek_plbs/api/index.php/api/admin-universitas/pembayaran/${currentPaymentDetail.id}/validasi`;
                        
                        fetch(endpoint, {
                            method: 'POST',
                            credentials: 'include',
                            headers: {
                                'Content-Type': 'application/json',
                                'Authorization': `Bearer ${token}`
                            },
                            body: JSON.stringify({
                                status_validasi: 'ditolak',
                                catatan_validasi: reason
                            })
                        })
                        .then(response => {
                            if (!response.ok) {
                                throw new Error(`HTTP ${response.status}: ${response.statusText}`);
                            }
                            return response.json();
                        })
                        .then(data => {
                            if (data.status === 'success') {
                                alert('✕ Pembayaran telah ditolak.');
                                closeDetailModal();
                                loadPaymentData();
                            } else {
                                alert('Error: ' + (data.message || 'Gagal menolak'));
                            }
                        })
                        .catch(error => {
                            alert('Gagal menolak: ' + error.message);
                        });
                    }
                } else if (reason !== null) {
                    alert('Alasan penolakan harus diisi.');
                }
            }
        }

        // Fungsi untuk mengaktifkan KRS dari modal
        function activateKRSFromModal() {
            if (currentPaymentDetail) {
                if (confirm(`Aktifkan KRS untuk ${currentPaymentDetail.name}?`)) {
                    alert(`✓ KRS untuk ${currentPaymentDetail.name} telah diaktifkan!`);
                    closeDetailModal();
                }
            }
        }

        // Fungsi untuk meninjau ulang penolakan
        function reviewRejection() {
            if (currentPaymentDetail) {
                alert(`Alasan Penolakan:\n\n${currentPaymentDetail.notes}`);
            }
        }

        // Fungsi untuk melihat bukti pembayaran
        function viewProof(id) {
            const payment = paymentData.find(p => p.id === id);
            if (!payment.proofImage) return;
            
            const modal = document.getElementById('imageModal');
            const modalImg = document.getElementById('modalImage');
            
            modal.style.display = 'block';
            modalImg.src = payment.proofImage;
        }

        // Fungsi untuk mengaktifkan KRS
        function activateKRS(id) {
            const payment = paymentData.find(p => p.id === id);
            
            if (confirm(`Aktifkan KRS untuk ${payment.name} (NIM: ${payment.nim})?`)) {
                alert(`✓ KRS untuk ${payment.name} telah diaktifkan!`);
            }
        }

        // Filter functions
        function applyFilters() {
            const statusFilter = document.getElementById('statusFilter').value;
            const typeFilter = document.getElementById('typeFilter').value;
            const periodFilter = document.getElementById('periodFilter').value;
            
            filteredData = paymentData.filter(payment => {
                // Filter berdasarkan status
                // menunggu_validasi = pending, ditolak = rejected, valid = approved
                let statusMatch = true;
                if (statusFilter !== 'all') {
                    if (statusFilter === 'pending' && payment.status !== 'pending') statusMatch = false;
                    if (statusFilter === 'approved' && payment.status !== 'pending') statusMatch = false;
                    if (statusFilter === 'rejected' && payment.status !== 'pending') statusMatch = false;
                }
                
                if (!statusMatch) return false;
                
                // Filter berdasarkan jenis pembayaran
                if (typeFilter !== 'all' && payment.paymentType !== typeFilter) {
                    return false;
                }
                
                // Filter berdasarkan periode
                if (periodFilter !== 'all' && !payment.period.includes(periodFilter)) {
                    return false;
                }
                
                return true;
            });
            
            // Reset ke halaman pertama
            currentPage = 1;
            renderTable();
        }

        function resetFilters() {
            document.getElementById('statusFilter').value = 'all';
            document.getElementById('typeFilter').value = 'all';
            document.getElementById('periodFilter').value = 'all';
            
            filteredData = [...paymentData];
            currentPage = 1;
            renderTable();
        }

        // Modal functions
        function closeImageModal() {
            document.getElementById('imageModal').style.display = 'none';
        }

        // Menu interaction
        const menuItems = document.querySelectorAll('.menu-item');
        menuItems.forEach(item => {
            item.addEventListener('click', function() {
                menuItems.forEach(mi => mi.classList.remove('active'));
                this.classList.add('active');
            });
        });

        // Close modal dengan ESC key
        document.addEventListener('keydown', function(event) {
            if (event.key === 'Escape') {
                closeDetailModal();
                closeImageModal();
            }
        });

        // Event listener untuk filter (enter key)
        document.querySelectorAll('.filter-select').forEach(select => {
            select.addEventListener('change', applyFilters);
        });

        // Initialize
        document.addEventListener('DOMContentLoaded', function() {
            // Verify authentication
            requireAuth('admin_universitas');
            
            // Update user info
            const user = getCurrentUser();
            if (user) {
                document.querySelector('.user-name').textContent = user.nama_lengkap || 'Admin Universitas';
            }
            
            // Load data from API
            loadPaymentData();
            
            renderTable();
            console.log('Sistem validasi pembayaran siap digunakan.');
        });
    </script>
    
    <script src="js/auth.js"></script>
</body>
</html>
