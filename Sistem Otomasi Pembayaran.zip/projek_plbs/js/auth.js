/**
 * Authentication Helper Functions
 * Handle auth checks, token management, and redirects
 */

// Check if user is authenticated
function isAuthenticated() {
    const token = localStorage.getItem('auth_token');
    const role = localStorage.getItem('role');
    return token && role;
}

// Get current user info
function getCurrentUser() {
    return {
        user_id: localStorage.getItem('user_id'),
        username: localStorage.getItem('username'),
        role: localStorage.getItem('role'),
        nama_lengkap: localStorage.getItem('nama_lengkap'),
        nim: localStorage.getItem('nim'),
        mahasiswa_id: localStorage.getItem('mahasiswa_id'),
        semester_aktif: localStorage.getItem('semester_aktif'),
        tahun_akademik: localStorage.getItem('tahun_akademik'),
        token: localStorage.getItem('auth_token')
    };
}

// Check if user has required role
function hasRole(requiredRoles) {
    if (!Array.isArray(requiredRoles)) {
        requiredRoles = [requiredRoles];
    }
    const userRole = localStorage.getItem('role');
    return requiredRoles.includes(userRole);
}

// Redirect to login if not authenticated
function requireAuth(requiredRole = null) {
    if (!isAuthenticated()) {
        window.location.href = 'index.html';
        return false;
    }

    if (requiredRole) {
        const userRole = localStorage.getItem('role');
        if (userRole !== requiredRole) {
            alert('Anda tidak memiliki akses ke halaman ini');
            window.location.href = 'index.html';
            return false;
        }
    }

    return true;
}

// Logout user
function logout() {
    // Clear localStorage
    localStorage.removeItem('auth_token');
    localStorage.removeItem('user_id');
    localStorage.removeItem('username');
    localStorage.removeItem('role');
    localStorage.removeItem('nama_lengkap');
    localStorage.removeItem('nim');
    localStorage.removeItem('mahasiswa_id');
    localStorage.removeItem('semester_aktif');
    localStorage.removeItem('tahun_akademik');
    
    // Redirect to logout.php to clear session
    window.location.href = 'logout.php';
}

// Make API call with auth token
async function apiCall(endpoint, options = {}) {
    const user = getCurrentUser();
    
    const headers = {
        'Content-Type': 'application/json',
        ...(options.headers || {})
    };

    if (user.token) {
        headers['Authorization'] = 'Bearer ' + user.token;
    }

    const response = await fetch(endpoint, {
        ...options,
        credentials: 'include',  // ⭐ PENTING: Kirim session cookie
        headers: headers
    });

    const data = await response.json();

    // If unauthorized, redirect to login
    if (response.status === 401) {
        logout();
    }

    return data;
}

// Format rupiah currency
function formatRupiah(amount) {
    if (!amount) return 'Rp 0';
    return 'Rp ' + parseInt(amount).toLocaleString('id-ID');
}

// Format date to Indonesian format
function formatDate(dateString) {
    if (!dateString) return '-';
    const date = new Date(dateString);
    return date.toLocaleDateString('id-ID', {
        year: 'numeric',
        month: 'long',
        day: 'numeric'
    });
}

// Show loading indicator
function showLoading(elementId) {
    const element = document.getElementById(elementId);
    if (element) {
        element.innerHTML = '<div style="text-align: center; padding: 20px;"><i class="fas fa-spinner fa-spin"></i> Loading...</div>';
    }
}

// Show error message
function showError(elementId, message) {
    const element = document.getElementById(elementId);
    if (element) {
        element.innerHTML = '<div style="color: #c33; padding: 15px; background: #fee; border-radius: 8px; text-align: center;">' + message + '</div>';
    }
}

// Show success message
function showSuccess(elementId, message) {
    const element = document.getElementById(elementId);
    if (element) {
        element.innerHTML = '<div style="color: #3c3; padding: 15px; background: #efe; border-radius: 8px; text-align: center;">' + message + '</div>';
    }
}
