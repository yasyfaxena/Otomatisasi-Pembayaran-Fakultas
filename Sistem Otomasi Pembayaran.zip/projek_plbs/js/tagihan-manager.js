/**
 * Tagihan Frontend Integration
 * Sistem berbasis tabel tarif sebagai sumber kebenaran
 */

class TagihanManager {
    constructor() {
        this.apiBaseUrl = '/projek_plbs/api';
        this.tagihanData = null;
    }

    async initializeTagihan() {
        try {
            this.showLoading();
            
            const response = await fetch(`${this.apiBaseUrl}/mahasiswa/tagihan-proses`, {
                method: 'GET',
                credentials: 'include',
                headers: { 'Content-Type': 'application/json' }
            });

            const result = await response.json();

            if (!response.ok) {
                throw new Error(result.error || 'Gagal memuat tagihan');
            }

            this.tagihanData = result;
            this.renderTagihan(result);
            
        } catch (error) {
            console.error('Error loading tagihan:', error);
            this.showError(error.message);
        } finally {
            this.hideLoading();
        }
    }

    renderTagihan(data) {
        const container = document.getElementById('tagihan-container');
        
        if (!container) {
            console.error('Container tagihan tidak ditemukan');
            return;
        }

        let html = '';
        
        // Render tagihan dari tabel tarif
        if (data.message) {
            html = `<div class="alert alert-info"><i class="bi bi-info-circle"></i> ${data.message}</div>`;
        } else if (data.tagihan && data.tagihan.length > 0) {
            html += '<div class="tagihan-section"><h3>Tagihan Aktif</h3><div class="tagihan-list">';
            data.tagihan.forEach(tagihan => {
                html += this.createTagihanCard(tagihan);
            });
            html += '</div></div>';
        }
        
        if (data.has_active_installment === true) {
            html += '<div class="cicilan-section"><h3>Cicilan Aktif</h3><div class="cicilan-list">';
            data.cicilan.forEach(cicilan => {
                html += this.createCicilanCard(cicilan);
            });
            html += '</div></div>';
        }
        
        container.innerHTML = html;
    }

    createTagihanCard(tagihan) {
        const formatRupiah = (amount) => {
            return new Intl.NumberFormat('id-ID', {
                style: 'currency',
                currency: 'IDR'
            }).format(amount);
        };

        return `
            <div class="tagihan-card">
                <div class="tagihan-header">
                    <h4>${tagihan.jenis_tagihan}</h4>
                    ${tagihan.semester ? `<span class="semester-badge">Semester ${tagihan.semester}</span>` : ''}
                </div>
                <div class="tagihan-body">
                    <div class="tagihan-amount">${formatRupiah(tagihan.nominal)}</div>
                    <div class="tagihan-info">
                        <small>Tahun Akademik: ${tagihan.tahun_akademik}</small>
                    </div>
                </div>
                <div class="tagihan-actions">
                    <button class="btn btn-primary" onclick="tagihanManager.bayarTagihan('${tagihan.jenis_tagihan}', ${tagihan.semester || 0})">
                        Bayar Sekarang
                    </button>
                </div>
            </div>
        `;
    }
    
    createCicilanCard(cicilan) {
        const formatRupiah = (amount) => {
            return new Intl.NumberFormat('id-ID', {
                style: 'currency',
                currency: 'IDR'
            }).format(amount);
        };
        
        const formatTanggal = (tanggal) => {
            return new Date(tanggal).toLocaleDateString('id-ID');
        };

        return `
            <div class="cicilan-card">
                <div class="cicilan-header">
                    <h4>${cicilan.jenis_tagihan} - Cicilan ${cicilan.cicilan_ke}</h4>
                    <span class="status-badge status-${cicilan.status_pembayaran}">${cicilan.status_pembayaran}</span>
                </div>
                <div class="cicilan-body">
                    <div class="cicilan-amount">${formatRupiah(cicilan.nominal_cicilan)}</div>
                    <div class="cicilan-info">
                        <small>Jatuh Tempo: ${formatTanggal(cicilan.tanggal_jatuh_tempo)}</small>
                    </div>
                </div>
                <div class="cicilan-actions">
                    <button class="btn btn-warning" onclick="tagihanManager.bayarCicilan(${cicilan.cicilan_id})">
                        Bayar Cicilan
                    </button>
                </div>
            </div>
        `;
    }

    async bayarTagihan(jenisTagihan, semester) {
        console.log(`Memproses pembayaran ${jenisTagihan} semester ${semester}`);
    }
    
    async bayarCicilan(cicilanId) {
        console.log(`Memproses pembayaran cicilan ID: ${cicilanId}`);
    }

    showLoading() {
        const container = document.getElementById('tagihan-container');
        if (container) {
            container.innerHTML = `
                <div class="loading-container">
                    <div class="spinner"></div>
                    <p>Memuat tagihan dari tabel tarif...</p>
                </div>
            `;
        }
    }

    hideLoading() {}

    showError(message) {
        const container = document.getElementById('tagihan-container');
        if (container) {
            container.innerHTML = `
                <div class="alert alert-danger">
                    <i class="bi bi-exclamation-triangle"></i>
                    Error: ${message}
                </div>
            `;
        }
    }
}

const tagihanManager = new TagihanManager();

document.addEventListener('DOMContentLoaded', function() {
    if (window.location.pathname.includes('tagihan') || document.getElementById('tagihan-container')) {
        tagihanManager.initializeTagihan();
    }
});

// CSS untuk styling (tambahkan ke file CSS utama)
const tagihanStyles = `
    .tagihan-list {
        display: grid;
        gap: 20px;
        margin-top: 20px;
    }

    .tagihan-card {
        background: white;
        border-radius: 8px;
        padding: 20px;
        box-shadow: 0 2px 4px rgba(0,0,0,0.1);
        border-left: 4px solid #4169E1;
    }

    .tagihan-header {
        display: flex;
        justify-content: space-between;
        align-items: center;
        margin-bottom: 15px;
    }

    .tagihan-header h4 {
        margin: 0;
        color: #333;
    }

    .semester-badge {
        background: #4169E1;
        color: white;
        padding: 4px 12px;
        border-radius: 20px;
        font-size: 12px;
        font-weight: 600;
    }

    .tagihan-amount {
        font-size: 24px;
        font-weight: 700;
        color: #4169E1;
        margin-bottom: 10px;
    }

    .tagihan-info {
        color: #666;
        margin-bottom: 15px;
    }

    .tagihan-actions {
        text-align: right;
    }

    .loading-container {
        text-align: center;
        padding: 40px;
    }

    .spinner {
        border: 4px solid #f3f3f3;
        border-top: 4px solid #4169E1;
        border-radius: 50%;
        width: 40px;
        height: 40px;
        animation: spin 1s linear infinite;
        margin: 0 auto 20px;
    }

    @keyframes spin {
        0% { transform: rotate(0deg); }
        100% { transform: rotate(360deg); }
    }

    .alert {
        padding: 15px;
        border-radius: 4px;
        margin-bottom: 20px;
    }

    .alert-info {
        background-color: #d1ecf1;
        border-color: #bee5eb;
        color: #0c5460;
    }

    .alert-danger {
        background-color: #f8d7da;
        border-color: #f5c6cb;
        color: #721c24;
    }
`;

// Inject CSS
const styleSheet = document.createElement('style');
styleSheet.textContent = tagihanStyles;
document.head.appendChild(styleSheet);