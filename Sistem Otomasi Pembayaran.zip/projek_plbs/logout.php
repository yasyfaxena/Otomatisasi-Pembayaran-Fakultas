<?php
session_start();
session_unset();
session_destroy();

// Clear auth token from cookie if exists
if (isset($_COOKIE['auth_token'])) {
    setcookie('auth_token', '', time() - 3600, '/');
}

// Redirect ke index.php
header('Location: index.php');
exit;
