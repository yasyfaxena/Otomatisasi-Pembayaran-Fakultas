<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header('Location: mhs_login.php');
    exit;
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard Mahasiswa</title>
    <!-- Font Awesome Icons -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="js/auth.js">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: #f5f5f5;
            display: flex;
        }

        .sidebar {
            width: 260px;
            background-color: #1a1a1a;
            color: white;
            height: 100vh;
            position: fixed;
            left: 0;
            top: 0;
            overflow-y: auto;
        }

        .logo {
            padding: 20px;
            text-align: center;
            border-bottom: 1px solid #333;
        }

        .logo img {
            width: 80px;
            height: auto;
        }

        .user-info {
            padding: 30px 20px;
            text-align: center;
            border-bottom: 1px solid #333;
        }

        .user-id {
            font-size: 14px;
            margin-bottom: 8px;
            color: #999;
        }

        .user-name {
            font-size: 16px;
            font-weight: 600;
            margin-bottom: 15px;
        }

        .user-actions {
            display: flex;
            gap: 8px;
            justify-content: center;
        }

        .user-actions a {
            padding: 8px 12px;
            background: #246140;
            color: white;
            text-decoration: none;
            border-radius: 5px;
            font-size: 12px;
            transition: background 0.3s;
        }

        .user-actions a:hover {
            background: #1a4c2e;
        }

        .user-actions a.logout {
            background: #dc3545;
        }

        .user-actions a.logout:hover {
            background: #c82333;
        }

        .menu {
            padding: 20px 0;
        }

        .menu-item {
            padding: 15px 20px;
            cursor: pointer;
            display: flex;
            align-items: center;
            gap: 12px;
            transition: background-color 0.3s;
        }

        .menu-item:hover {
            background-color: #333;
        }

        .menu-item.active {
            background-color: #4CAF50;
        }

        .menu-icon {
            width: 24px;
            height: 24px;
            display: flex;
            align-items: center;
            justify-content: center;
        }

        .menu a {
            text-decoration: none;
            color: inherit;
        }

        .main-content {
            margin-left: 260px;
            flex: 1;
            padding: 20px 40px;
        }

        .header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 40px;
            background: white;
            padding: 15px 25px;
            border-radius: 8px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
        }

        .header-title {
            font-size: 20px;
            color: #666;
            display: flex;
            align-items: center;
            gap: 15px;
        }

        .menu-dots {
            font-size: 24px;
            cursor: pointer;
            color: #999;
        }

        .user-avatar {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            cursor: pointer;
            object-fit: cover;
            border: 2px solid #4169E1;
            transition: transform 0.2s;
        }
        
        .user-avatar:hover {
            transform: scale(1.1);
        }

        /* Welcome Section */
        .welcome-section {
            background: linear-gradient(135deg, #4169E1 0%, #2E5BBE 100%);
            color: white;
            border-radius: 15px;
            padding: 40px;
            margin-bottom: 40px;
            box-shadow: 0 10px 20px rgba(65, 105, 225, 0.2);
        }

        .welcome-content {
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .welcome-text h1 {
            font-size: 32px;
            margin-bottom: 15px;
            font-weight: 700;
        }

        .welcome-text p {
            font-size: 18px;
            opacity: 0.9;
            line-height: 1.6;
            max-width: 700px;
        }

        .welcome-icon {
            font-size: 100px;
            opacity: 0.8;
        }

        /* Stats Cards */
        .stats-container {
            display: grid;
            grid-template-columns: repeat(4, 1fr);
            gap: 25px;
            margin-bottom: 40px;
        }

        .stat-card {
            background-color: white;
            border-radius: 15px;
            padding: 30px;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.08);
            transition: transform 0.3s, box-shadow 0.3s;
        }

        .stat-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 8px 25px rgba(0, 0, 0, 0.12);
        }

        .stat-card.red {
            border-top: 5px solid #f44336;
        }

        .stat-card.green {
            border-top: 5px solid #4CAF50;
        }

        .stat-card.orange {
            border-top: 5px solid #FF9800;
        }

        .stat-card.blue {
            border-top: 5px solid #2196F3;
        }

        .stat-header {
            display: flex;
            justify-content: space-between;
            align-items: flex-start;
            margin-bottom: 20px;
        }

        .stat-title {
            font-size: 14px;
            color: #666;
            font-weight: 500;
            text-transform: uppercase;
            letter-spacing: 1px;
        }

        .stat-icon {
            width: 50px;
            height: 50px;
            border-radius: 12px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 24px;
        }

        .stat-card.red .stat-icon {
            background-color: rgba(244, 67, 54, 0.1);
            color: #f44336;
        }

        .stat-card.green .stat-icon {
            background-color: rgba(76, 175, 80, 0.1);
            color: #4CAF50;
        }

        .stat-card.orange .stat-icon {
            background-color: rgba(255, 152, 0, 0.1);
            color: #FF9800;
        }

        .stat-card.blue .stat-icon {
            background-color: rgba(33, 150, 243, 0.1);
            color: #2196F3;
        }

        .stat-value {
            font-size: 32px;
            font-weight: 700;
            color: #333;
            margin-bottom: 15px;
        }

        .stat-change {
            font-size: 14px;
            display: flex;
            align-items: center;
            gap: 8px;
        }

        .change-up {
            color: #4CAF50;
            font-weight: 500;
        }

        .change-down {
            color: #f44336;
            font-weight: 500;
        }

        .change-neutral {
            color: #666;
            font-weight: 500;
        }

        /* Container untuk menengahkan 2 div */
        .centered-container {
            display: flex;
            justify-content: center;
            gap: 40px;
            margin-bottom: 40px;
            flex-wrap: wrap;
        }

        /* Card untuk menengahkan */
        .centered-card {
            background-color: white;
            border-radius: 15px;
            padding: 30px;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.08);
            min-width: 300px;
            max-width: 400px;
            transition: transform 0.3s, box-shadow 0.3s;
        }

        .centered-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 8px 25px rgba(0, 0, 0, 0.12);
        }

        .centered-card-title {
            font-size: 20px;
            font-weight: 700;
            color: #333;
            margin-bottom: 20px;
            text-align: center;
            padding-bottom: 15px;
            border-bottom: 2px solid #f0f0f0;
        }

        .centered-card-content {
            text-align: center;
        }

        /* Card 1: Pesan Penting */
        .centered-card-important {
            border-top: 5px solid #FF9800;
        }

        .centered-card-important .centered-card-title {
            color: #FF9800;
        }

        .important-icon {
            font-size: 48px;
            color: #FF9800;
            margin-bottom: 15px;
        }

        .important-message {
            font-size: 16px;
            color: #666;
            line-height: 1.6;
            margin-bottom: 20px;
        }

        /* Card 2: Update Terbaru */
        .centered-card-update {
            border-top: 5px solid #2196F3;
        }

        .centered-card-update .centered-card-title {
            color: #2196F3;
        }

        .update-icon {
            font-size: 48px;
            color: #2196F3;
            margin-bottom: 15px;
        }

        .update-list {
            list-style-type: none;
        }

        .update-item {
            padding: 12px 0;
            border-bottom: 1px solid #f0f0f0;
            text-align: left;
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .update-item:last-child {
            border-bottom: none;
        }

        .update-item i {
            color: #4CAF50;
            font-size: 14px;
        }

        .update-text {
            font-size: 14px;
            color: #666;
        }

        .update-time {
            font-size: 12px;
            color: #999;
            margin-top: 3px;
            display: block;
        }

        /* Status Badge */
        .status-badge {
            display: inline-block;
            padding: 6px 12px;
            border-radius: 12px;
            font-size: 12px;
            font-weight: 600;
            margin-top: 8px;
        }

        .status-badge.belum-bayar {
            background-color: #FFE5E5;
            color: #C41C3B;
        }

        .status-badge.cicilan {
            background-color: #FFF3E0;
            color: #E65100;
        }

        .status-badge.lunas {
            background-color: #E8F5E9;
            color: #1B5E20;
        }

        /* Notifikasi Cicilan */
        .notification-section {
            background: linear-gradient(135deg, #FF9800 0%, #F57C00 100%);
            color: white;
            border-radius: 15px;
            padding: 25px;
            margin-bottom: 40px;
            box-shadow: 0 8px 16px rgba(255, 152, 0, 0.2);
            display: none;
        }

        .notification-section.show {
            display: block;
        }

        .notification-header {
            display: flex;
            align-items: center;
            gap: 12px;
            margin-bottom: 15px;
        }

        .notification-icon {
            font-size: 28px;
        }

        .notification-title {
            font-size: 18px;
            font-weight: 700;
        }

        .notification-content {
            font-size: 15px;
            line-height: 1.6;
            margin-bottom: 15px;
        }

        .notification-items {
            background: rgba(255, 255, 255, 0.1);
            border-radius: 8px;
            padding: 12px 15px;
            margin-bottom: 15px;
            font-size: 14px;
        }

        .notification-button {
            background-color: white;
            color: #667eea;
            border: none;
            padding: 10px 20px;
            border-radius: 6px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s;
        }

        .notification-button:hover {
            background-color: #FFF;
            transform: translateY(-2px);
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.15);
        }

        .stat-card-status {
            position: absolute;
            top: 15px;
            right: 15px;
        }

        .stat-card.relative {
            position: relative;
        }

        /* Quick Actions */
        .quick-actions-section {
            background: white;
            border-radius: 15px;
            padding: 30px;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.08);
        }

        .section-title {
            font-size: 20px;
            font-weight: 700;
            color: #333;
            margin-bottom: 25px;
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .section-title i {
            color: #4169E1;
        }

        .actions-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 20px;
        }

        .action-card {
            background-color: white;
            border-radius: 12px;
            padding: 25px 20px;
            text-align: center;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.05);
            transition: all 0.3s;
            cursor: pointer;
            text-decoration: none;
            color: inherit;
            display: block;
            border: 2px solid #f0f0f0;
        }

        .action-card:hover {
            transform: translateY(-3px);
            box-shadow: 0 8px 16px rgba(65, 105, 225, 0.15);
            border-color: #4169E1;
            background-color: #f8f9ff;
        }

        .action-icon {
            width: 60px;
            height: 60px;
            border-radius: 50%;
            background-color: rgba(65, 105, 225, 0.1);
            display: flex;
            align-items: center;
            justify-content: center;
            margin: 0 auto 15px;
            font-size: 24px;
            color: #4169E1;
            transition: all 0.3s;
        }

        .action-card:hover .action-icon {
            background-color: #4169E1;
            color: white;
        }

        .action-text {
            font-size: 16px;
            font-weight: 600;
            color: #333;
        }

        /* Footer */
        .footer {
            text-align: center;
            padding: 20px;
            color: #666;
            font-size: 14px;
            margin-top: 40px;
            border-top: 1px solid #e0e0e0;
        }

        /* Responsive */
        @media (max-width: 1200px) {
            .stats-container {
                grid-template-columns: repeat(2, 1fr);
            }
            
            .centered-container {
                justify-content: center;
            }
            
            .centered-card {
                min-width: 280px;
            }
        }

        @media (max-width: 768px) {
            .main-content {
                margin-left: 0;
                padding: 15px;
            }
            
            .sidebar {
                display: none;
            }
            
            .header {
                flex-direction: column;
                align-items: flex-start;
                gap: 15px;
            }
            
            .welcome-content {
                flex-direction: column;
                text-align: center;
                gap: 30px;
            }
            
            .welcome-icon {
                font-size: 70px;
                order: -1;
            }
            
            .welcome-text h1 {
                font-size: 24px;
            }
            
            .welcome-text p {
                font-size: 16px;
            }
            
            .stats-container {
                grid-template-columns: 1fr;
            }
            
            .centered-container {
                flex-direction: column;
                align-items: center;
            }
            
            .centered-card {
                width: 100%;
                max-width: 100%;
            }
        }
    </style>
</head>
<body>
    <div class="sidebar">
        <div class="logo">
            <img src="pictures/logo umi.png" alt="Logo">
        </div>
        <div class="user-info">
            <div class="user-id" id="userNIM"></div>
            <div class="user-name" id="userFullName"></div>
            <div class="user-actions">
                <a href="index.php" onclick="logout();">Logout</a>
            </div>
        </div>
        <div class="menu">
            <a href="dashboard_mahasiswa.php" class="menu-item active">
                <div class="menu-icon">📊</div>
                <div>Dashboard</div>
            </a>
            <a href="mhs_tagihan.php" class="menu-item">
                <div class="menu-icon">💳</div>
                <div>Tagihan</div>
            </a>
            <a href="mhs_riwayat_pembayaran.php" class="menu-item">
                <div class="menu-icon">🔄</div>
                <div>Riwayat Pembayaran</div>
            </a>
        </div>
    </div>

    <div class="main-content">
        <div class="header">
            <div class="header-title">
                <span class="menu-dots">⋮</span>
                <span>Dashboard Mahasiswa</span>
            </div>
            <?php
            // Role-based avatar rendering (SERVER-SIDE) - Foto profil untuk Mahasiswa
            // Use NIM from session for consistent avatar across pages
            if (isset($_SESSION['role']) && $_SESSION['role'] === 'mahasiswa') {
                $nim = isset($_SESSION['nim']) ? $_SESSION['nim'] : (isset($_SESSION['user_id']) ? $_SESSION['user_id'] : rand(1, 70));
                echo '<img src="https://api.dicebear.com/7.x/avataaars/svg?seed=' . $nim . '" alt="Avatar" class="user-avatar" onclick="openProfilModal()" title="Lihat Profil" id="headerAvatar">';
            }
            ?>
        </div>

        <!-- Notification KRS Aktif (tampil hanya jika status_krs = 'aktif') -->
        <div class="notification-section" id="notifikasiKRS" style="background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); display: none;">
            <div class="notification-header">
                <div class="notification-icon">✅</div>
                <div class="notification-title">KRS Telah Diaktifkan</div>
            </div>
            <div class="notification-content">
                Selamat! KRS Anda telah diaktifkan oleh Admin Fakultas. Anda sekarang dapat mengisi Kartu Rencana Studi (KRS) untuk semester ini.
            </div>
            <button class="notification-button" onclick="window.location.href='mhs_krs.php'">
                Isi KRS Sekarang
            </button>
        </div>



        <!-- Welcome Section -->
        <div class="welcome-section" id="welcomeSection" style="display: none;">
            <div class="welcome-content">
                <div class="welcome-text">
                    <h1 id="welcomeGreeting"></h1>
                    <p>Silahkan mengakses menu pada panel di sebelah kiri untuk mengolah data. Terima kasih atas kunjungan anda.</p>
                </div>
                <div class="welcome-icon">
                    <span style="font-size: 80px;">👋</span>
                </div>
            </div>
        </div>

        <!-- Tagihan Display Section -->
        <div class="centered-container" id="tagihanContainer">
            <!-- Tagihan cards will be dynamically loaded here -->
        </div>

        <!-- Container untuk 2 div yang ditengah -->
        <div class="centered-container">
            <!-- Card 1: Pesan Penting -->
            <div class="centered-card centered-card-important">
                <h3 class="centered-card-title">Pesan Penting</h3>
                <div class="centered-card-content">
                    <div class="important-icon">
                        <i class="fas fa-exclamation-circle"></i>
                    </div>
                    <p class="important-message" id="pesanPenting">
                        Segera lakukan pembayaran untuk semua tagihan yang belum dibayar sesuai dengan deadline untuk menghindari denda keterlambatan.
                    </p>
                    <button style="
                        background-color: #FF9800;
                        color: white;
                        border: none;
                        padding: 10px 20px;
                        border-radius: 6px;
                        font-weight: 600;
                        cursor: pointer;
                        transition: background-color 0.3s;
                    " onclick="window.location.href='mhs_tagihan.php'">
                        Lihat Detail
                    </button>
                </div>
            </div>

            <!-- Card 2: Update Terbaru -->
            <div class="centered-card centered-card-update">
                <h3 class="centered-card-title">Update Terbaru</h3>
                <div class="centered-card-content">
                    <div class="update-icon">
                        <i class="fas fa-bell"></i>
                    </div>
                    <ul class="update-list" id="updateList">
                        <li class="update-item">
                            <i class="fas fa-info-circle"></i>
                            <div>
                                <span class="update-text">Dashboard diperbarui dengan data dari database</span>
                                <span class="update-time">Sekarang</span>
                            </div>
                        </li>
                    </ul>
                </div>
            </div>
        </div>

        <!-- Quick Actions (opsional, bisa dihapus jika tidak perlu) -->
        <!--
        <div class="quick-actions-section">
            <h2 class="section-title">
                <i class="fas fa-bolt"></i> Akses Cepat
            </h2>
            <div class="actions-grid">
                <a href="#" class="action-card">
                    <div class="action-icon">
                        <i class="fas fa-credit-card"></i>
                    </div>
                    <div class="action-text">Bayar Tagihan</div>
                </a>
                
                <a href="#" class="action-card">
                    <div class="action-icon">
                        <i class="fas fa-calendar-alt"></i>
                    </div>
                    <div class="action-text">Isi KRS</div>
                </a>
                
                <a href="#" class="action-card">
                    <div class="action-icon">
                        <i class="fas fa-file-upload"></i>
                    </div>
                    <div class="action-text">Upload Bukti</div>
                </a>
                
                <a href="#" class="action-card">
                    <div class="action-icon">
                        <i class="fas fa-history"></i>
                    </div>
                    <div class="action-text">Riwayat Bayar</div>
                </a>
            </div>
        </div>
        -->

    <?php include 'components/profil_modal.php'; ?>

    <script src="js/auth.js"></script>
    <script>
        // Format Rupiah
        function formatRupiah(angka) {
            return angka.toLocaleString('id-ID');
        }

        // Get auth token
        function getAuthToken() {
            return localStorage.getItem('auth_token');
        }

        // Initialize sidebar with localStorage data (immediate display before API call)
        function initializeSidebar() {
            const currentUser = getCurrentUser();
            
            // STEP 1: Display NIM from localStorage
            // NIM must be present in session after successful login
            const nimElement = document.getElementById('userNIM');
            if (currentUser.nim && currentUser.nim.trim() !== '') {
                nimElement.textContent = currentUser.nim;
            } else {
                // If NIM is missing, this indicates session data loss or invalid login
                nimElement.textContent = '';
                console.warn('User NIM not found in session - session may be invalid');
            }
            
            // STEP 2: Display student name from localStorage  
            // Name must be present in session after successful login
            const nameElement = document.getElementById('userFullName');
            if (currentUser.nama_lengkap && currentUser.nama_lengkap.trim() !== '') {
                nameElement.textContent = currentUser.nama_lengkap;
                
                // STEP 3: Show welcome greeting immediately with name from session
                // This displays BEFORE API call for better user experience
                const welcomeGreeting = document.getElementById('welcomeGreeting');
                if (welcomeGreeting) {
                    welcomeGreeting.textContent = `Selamat Datang, ${currentUser.nama_lengkap}!`;
                    document.getElementById('welcomeSection').style.display = 'block';
                }
            } else {
                // If name is missing, leave welcome section hidden until API provides it
                nameElement.textContent = '';
                console.warn('User nama_lengkap not found in session - welcome will display after API verification');
            }
        }

        // Fetch semua tagihan (untuk filtering di frontend)
        async function fetchAllTagihan() {
            try {
                const token = getAuthToken();
                if (!token) {
                    console.error('No auth token found');
                    return [];
                }

                const response = await fetch('/projek_plbs/api/index.php/api/mahasiswa/semua-tagihan', {
                    method: 'GET',
                    credentials: 'include',
                    headers: {
                        'Authorization': `Bearer ${token}`,
                        'Content-Type': 'application/json'
                    }
                });

                if (!response.ok) {
                    console.error(`HTTP error! status: ${response.status}`);
                    return [];
                }

                const data = await response.json();

                if (data.status === 'success') {
                    return data.data.tagihan || [];
                } else {
                    console.error('API Error:', data.message);
                    return [];
                }
            } catch (error) {
                console.error('Error fetching tagihan:', error);
                return [];
            }
        }

        // Filter tagihan berdasarkan semester dan status pembayaran
        /**
         * Render tagihan cards and handle "no active billing" state
         * 
         * @param {Object} tagihanAktif - Current active tagihan from API (or null)
         * @param {Boolean} hasUnpaidObligation - TRUE if student has unpaid obligations, FALSE if all complete
         * 
         * LOGIC:
         * - If hasUnpaidObligation = FALSE: Show "No active billing" message (all obligations complete)
         * - If tagihanAktif exists: Show the current active tagihan
         * - If tagihanAktif is null but hasUnpaidObligation = TRUE: This shouldn't happen (backend auto-creates)
         *   but show a status message
         */
        function renderTagihanCards(tagihanAktif, hasUnpaidObligation) {
            const container = document.getElementById('tagihanContainer');
            
            // NO ACTIVE BILLING: Show ONLY when all obligations are complete
            if (!hasUnpaidObligation) {
                container.innerHTML = `
                    <div class="centered-card" style="min-width: 100%; text-align: center; background-color: #e8f5e9;">
                        <h3 class="centered-card-title">Tidak Ada Tagihan Aktif</h3>
                        <p style="color: #666; margin: 20px 0;">
                            <i class="fas fa-check-circle" style="font-size: 48px; color: #4CAF50; margin-bottom: 15px;"></i><br>
                            Semua kewajiban akademik Anda telah lunas. Selamat!
                        </p>
                    </div>
                `;
                return;
            }

            // HAS UNPAID OBLIGATIONS: Show current active tagihan
            if (tagihanAktif && tagihanAktif.tagihan_id) {
                // Determine status display based on backend status
                let statusClass, statusText;
                
                if (tagihanAktif.status_pembayaran === 'cicilan_berjalan') {
                    statusClass = 'cicilan';
                    statusText = 'CICILAN BERJALAN';
                } else if (tagihanAktif.status_pembayaran === 'belum_bayar') {
                    statusClass = 'belum-bayar';
                    statusText = 'BELUM BAYAR';
                } else if (tagihanAktif.status_pembayaran === 'lunas') {
                    statusClass = 'lunas';
                    statusText = 'LUNAS';
                } else {
                    statusClass = 'belum-bayar';
                    statusText = tagihanAktif.status_pembayaran.toUpperCase().replace('_', ' ');
                }

                // Use sisa_tagihan if available, otherwise use total_tagihan
                const displayAmount = tagihanAktif.sisa_tagihan || tagihanAktif.total_tagihan || 0;

                // Build semester display (for BPP) or generic (for Proposal/Skripsi)
                const semesterDisplay = tagihanAktif.semester 
                    ? `Semester: ${tagihanAktif.semester} (${tagihanAktif.tahun_akademik})`
                    : `Tahun Akademik: ${tagihanAktif.tahun_akademik}`;

                container.innerHTML = `
                    <div class="centered-card centered-card-important">
                        <h3 class="centered-card-title">${tagihanAktif.jenis_tagihan.toUpperCase()}</h3>
                        <div class="centered-card-content">
                            <div class="important-icon">
                                <i class="fas fa-file-invoice-dollar"></i>
                            </div>
                            <div style="text-align: center; margin-bottom: 20px;">
                                <p style="margin: 5px 0; font-size: 14px; color: #666;">
                                    <strong>${semesterDisplay}</strong>
                                </p>
                                <p style="margin: 5px 0; font-size: 16px; color: #333; font-weight: 600;">
                                    <strong>Sisa Tagihan:</strong> <span>Rp ${formatRupiah(displayAmount)}</span>
                                </p>
                                <p style="margin: 5px 0; font-size: 14px; color: #666;">
                                    <strong>Status:</strong> <span class="status-badge ${statusClass}">${statusText}</span>
                                </p>
                            </div>
                            <button style="
                                background-color: #FF9800;
                                color: white;
                                border: none;
                                padding: 10px 20px;
                                border-radius: 6px;
                                font-weight: 600;
                                cursor: pointer;
                                transition: background-color 0.3s;
                                width: 100%;
                            " onclick="window.location.href='mhs_tagihan.php'">
                                Lihat Detail Pembayaran
                            </button>
                        </div>
                    </div>
                `;
                return;
            }

            // FALLBACK: Should not reach here with smart backend auto-creation
            container.innerHTML = `
                <div class="centered-card" style="min-width: 100%; text-align: center; background-color: #fff3e0;">
                    <h3 class="centered-card-title">Loading Tagihan...</h3>
                    <p style="color: #666; margin: 20px 0;">
                        Sedang memproses data tagihan Anda...
                    </p>
                </div>
            `;
        }

        // Fetch dashboard data from API
        async function fetchDashboardData() {
            try {
                const token = getAuthToken();
                if (!token) {
                    console.error('No auth token found');
                    return;
                }

                const response = await fetch('/projek_plbs/api/index.php/api/mahasiswa/dashboard-info', {
                    method: 'GET',
                    credentials: 'include',
                    headers: {
                        'Authorization': `Bearer ${token}`,
                        'Content-Type': 'application/json'
                    }
                });

                if (!response.ok) {
                    throw new Error(`HTTP error! status: ${response.status}`);
                }

                const data = await response.json();

                if (data.status === 'success') {
                    updateDashboard(data.data);
                } else {
                    console.error('API Error:', data.message);
                }
            } catch (error) {
                console.error('Error fetching dashboard data:', error);
            }
        }

        // Update dashboard display with API data
        async function updateDashboard(dashboardData) {
            try {
                const { user, semester, tagihan_aktif, has_unpaid_obligation, cicilan_summary, info } = dashboardData;

                // DEBUG: Log entire dashboard data
                console.log('=== DASHBOARD DATA ===');
                console.log('Full data:', dashboardData);
                console.log('Tagihan aktif:', tagihan_aktif);
                console.log('Status KRS:', tagihan_aktif?.status_krs);

                // VALIDATION: Ensure required data exists before updating display
                if (!user) {
                    console.error('Invalid dashboard data: user object missing', dashboardData);
                    return;
                }

                if (!user.nim || user.nim.trim() === '' || !user.nama_lengkap || user.nama_lengkap.trim() === '') {
                    console.error('Invalid user data from API: missing required fields', user);
                    return;
                }

                // UPDATE SIDEBAR: Use API data as authoritative source (nim now from nim_or_id)
                document.getElementById('userNIM').textContent = user.nim;
                document.getElementById('userFullName').textContent = user.nama_lengkap;

                // UPDATE HEADER AVATAR: Use NIM for consistent avatar
                const headerAvatar = document.getElementById('headerAvatar');
                if (headerAvatar && user.nim) {
                    headerAvatar.src = `https://api.dicebear.com/7.x/avataaars/svg?seed=${user.nim}`;
                }

                // UPDATE WELCOME SECTION: Use API data to refresh welcome greeting
                const welcomeGreeting = document.getElementById('welcomeGreeting');
                welcomeGreeting.textContent = `Selamat Datang, ${user.nama_lengkap}!`;
                
                // Ensure welcome section is visible after successful API validation
                const welcomeSection = document.getElementById('welcomeSection');
                welcomeSection.style.display = 'block';

                // RENDER TAGIHAN CARDS: Display using has_unpaid_obligation flag
                // Backend automatically creates BPP/Proposal/Skripsi based on payment history
                // Frontend only needs to display the primary active tagihan
                renderTagihanCards(tagihan_aktif, has_unpaid_obligation);

                // UPDATE KRS INFO: Display KRS notification if status_krs = 'aktif'
                updateKRSInfo(tagihan_aktif);

            } catch (error) {
                console.error('Error updating dashboard:', error);
            }
        }

        // Update KRS notification
        function updateKRSInfo(tagihanAktif) {
            const notifSection = document.getElementById('notifikasiKRS');
            
            // Show KRS notification ONLY if status_krs === 'aktif'
            if (tagihanAktif && tagihanAktif.status_krs === 'aktif') {
                console.log('KRS Status: aktif - Showing notification');
                notifSection.style.display = 'block';
            } else {
                console.log('KRS Status:', tagihanAktif?.status_krs || 'not found', '- Hiding notification');
                notifSection.style.display = 'none';
            }
        }

        // Initialize on page load
        document.addEventListener('DOMContentLoaded', function() {
            requireAuth('mahasiswa');

            // Initialize sidebar with localStorage data immediately
            initializeSidebar();

            // Fetch and update dashboard data with API
            fetchDashboardData();

            // Menu interactions
            const menuItems = document.querySelectorAll('.menu-item');
            menuItems.forEach(item => {
                item.addEventListener('click', function() {
                    menuItems.forEach(mi => mi.classList.remove('active'));
                    this.classList.add('active');
                });
            });
        });
    </script>
</body>
</html>