# ============================================
# Auto-Create Tagihan - PowerShell Script
# ============================================
# Script ini akan dijalankan otomatis setiap hari
# untuk membuat tagihan semester berikutnya
# ============================================

$logFile = "d:\laragon\www\projek_plbs\logs\auto_create_tagihan.log"
$apiUrl = "http://localhost/projek_plbs/api/trigger/auto-create-tagihan"

# Buat folder logs jika belum ada
$logDir = Split-Path $logFile -Parent
if (!(Test-Path $logDir)) {
    New-Item -ItemType Directory -Path $logDir -Force | Out-Null
}

# Log start
$timestamp = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
Add-Content -Path $logFile -Value "[$timestamp] Starting auto-create tagihan..."

try {
    # Panggil API endpoint
    $response = Invoke-RestMethod -Uri $apiUrl -Method Get -ContentType "application/json"
    
    # Log response
    $timestamp = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
    Add-Content -Path $logFile -Value "[$timestamp] Status: $($response.status)"
    Add-Content -Path $logFile -Value "[$timestamp] Message: $($response.message)"
    Add-Content -Path $logFile -Value "[$timestamp] Total Mahasiswa: $($response.data.total_mahasiswa)"
    Add-Content -Path $logFile -Value "[$timestamp] Total Created: $($response.data.total_created)"
    
    if ($response.data.details.Count -gt 0) {
        Add-Content -Path $logFile -Value "[$timestamp] Details:"
        foreach ($detail in $response.data.details) {
            Add-Content -Path $logFile -Value "  - $detail"
        }
    }
    
    Add-Content -Path $logFile -Value "[$timestamp] Completed successfully`n"
    
} catch {
    # Log error
    $timestamp = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
    Add-Content -Path $logFile -Value "[$timestamp] ERROR: $($_.Exception.Message)"
    Add-Content -Path $logFile -Value "[$timestamp] Failed`n"
    exit 1
}

exit 0
