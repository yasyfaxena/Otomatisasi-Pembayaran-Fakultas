<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header('Location: login_admin_universitas.php');
    exit;
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard Admin Universitas</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.13.1/font/bootstrap-icons.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: #f5f5f5;
            display: flex;
        }

        .sidebar {
            width: 260px;
            background-color: #1a1a1a;
            color: white;
            height: 100vh;
            position: fixed;
            left: 0;
            top: 0;
            overflow-y: auto;
        }

        .logo {
            padding: 20px;
            text-align: center;
            border-bottom: 1px solid #333;
        }

        .logo img {
            width: 80px;
            height: auto;
        }

        .user-info {
            padding: 30px 20px;
            text-align: center;
            border-bottom: 1px solid #333;
        }

        .user-id {
            font-size: 14px;
            margin-bottom: 8px;
            color: #999;
        }

        .user-name {
            font-size: 16px;
            font-weight: 600;
            margin-bottom: 15px;
        }

        .user-actions {
            display: flex;
            gap: 8px;
            justify-content: center;
        }

        .user-actions a {
            padding: 8px 12px;
            background: #3b82f6;
            color: white;
            text-decoration: none;
            border-radius: 5px;
            font-size: 12px;
            transition: background 0.3s;
        }

        .user-actions a:hover {
            background: #1d4ed8;
        }

        .user-actions a.logout {
            background: #dc3545;
        }

        .user-actions a.logout:hover {
            background: #c82333;
        }

        .menu {
            padding: 20px 0;
        }

        .menu-item {
            padding: 15px 20px;
            cursor: pointer;
            display: flex;
            align-items: center;
            gap: 12px;
            transition: background-color 0.3s;
            text-decoration: none;
            color: white;
        }

        .menu-item:hover {
            background-color: #333;
        }

        .menu-item.active {
            background-color: #4CAF50;
        }

        .menu-icon {
            width: 24px;
            height: 24px;
            display: flex;
            align-items: center;
            justify-content: center;
        }

        .main-content {
            margin-left: 260px;
            flex: 1;
            padding: 20px 40px;
        }

        .header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 30px;
            background: white;
            padding: 15px 25px;
            border-radius: 8px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
        }

        .header-title {
            font-size: 20px;
            color: #666;
            display: flex;
            align-items: center;
            gap: 15px;
        }

        .menu-dots {
            font-size: 24px;
            cursor: pointer;
            color: #999;
        }

        .user-avatar {
            width: 32px;
            height: 32px;
            background-color: #666;
            border-radius: 50%;
            cursor: pointer;
        }

        .section {
            background: white;
            border-radius: 8px;
            padding: 30px;
            margin-bottom: 30px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
        }

        .section-title {
            font-size: 22px;
            margin-bottom: 25px;
            color: #333;
            font-weight: 600;
            border-bottom: 2px solid #4169E1;
            padding-bottom: 10px;
        }

        /* Summary Stats */
        .summary-stats {
            display: flex;
            gap: 20px;
            margin-bottom: 25px;
            flex-wrap: wrap;
        }

        .stat-card {
            flex: 1;
            min-width: 200px;
            background: white;
            padding: 25px;
            border-radius: 8px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
            border-left: 4px solid #007bff;
            transition: transform 0.3s;
        }

        .stat-card:hover {
            transform: translateY(-5px);
        }

        .stat-title {
            font-size: 14px;
            color: #6c757d;
            margin-bottom: 10px;
            display: flex;
            align-items: center;
            gap: 8px;
        }

        .stat-value {
            font-size: 28px;
            font-weight: 700;
            color: #333;
            margin-bottom: 5px;
        }

        .stat-trend {
            font-size: 13px;
            display: flex;
            align-items: center;
            gap: 5px;
        }

        .trend-up {
            color: #28a745;
        }

        .trend-down {
            color: #dc3545;
        }

        .stat-card-total { border-left-color: #007bff; }
        .stat-card-pending { border-left-color: #ffc107; }
        .stat-card-approved { border-left-color: #28a745; }
        .stat-card-rejected { border-left-color: #dc3545; }
        .stat-card-mahasiswa { border-left-color: #6c757d; }
        .stat-card-tagihan { border-left-color: #17a2b8; }

        /* Responsive */
        @media (max-width: 1200px) {
            .main-content {
                margin-left: 0;
                padding: 15px;
            }
            
            .sidebar {
                display: none;
            }
            
            .summary-stats {
                grid-template-columns: repeat(2, 1fr);
            }
        }

        @media (max-width: 768px) {
            .summary-stats {
                grid-template-columns: 1fr;
            }
            
            .header {
                flex-direction: column;
                gap: 15px;
                text-align: center;
            }
        }

        /* Welcome Message */
        .welcome-message {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 30px;
            border-radius: 12px;
            margin-bottom: 30px;
            box-shadow: 0 4px 12px rgba(0,0,0,0.1);
        }

        .welcome-title {
            font-size: 24px;
            margin-bottom: 10px;
            font-weight: 700;
        }

        .welcome-subtitle {
            font-size: 16px;
            opacity: 0.9;
            margin-bottom: 20px;
        }

        .current-time {
            background: rgba(255,255,255,0.1);
            padding: 8px 16px;
            border-radius: 20px;
            display: inline-block;
            font-size: 14px;
            font-weight: 500;
        }

        /* Simple Info Section */
        .info-box {
            background: #f8f9fa;
            border-radius: 8px;
            padding: 20px;
            margin-top: 20px;
            border-left: 4px solid #4169E1;
        }

        .info-title {
            font-size: 16px;
            font-weight: 600;
            color: #333;
            margin-bottom: 10px;
            display: flex;
            align-items: center;
            gap: 8px;
        }

        .info-content {
            font-size: 14px;
            color: #666;
            line-height: 1.6;
        }
    </style>
</head>
<body>
    <div class="sidebar">
        <div class="logo">
            <img src="pictures/logo umi.png" alt="Logo">
        </div>
        <div class="user-info">
            <div class="user-name">Admin Universitas</div>
            <div class="user-actions">
                <a href="#" onclick="logout(); return false;">Logout</a>
            </div>
        </div>
        <nav class="menu">
            <a href="dashboard_admin_universitas.php" class="menu-item active">
                <div class="menu-icon"><i class="bi bi-house-door"></i></div>
                <div>Dashboard</div>
            </a>
            <a href="univ_validasi.php" class="menu-item">
                <div class="menu-icon"><i class="bi bi-clipboard-check"></i></div>
                <div>Validasi Pembayaran</div>
            </a>
            <a href="univ_riwayat_pembayaran.php" class="menu-item">
                <div class="menu-icon"><i class="bi bi-card-checklist"></i></div>
                <div>Riwayat Pembayaran</div>
            </a>
        </div>
    </div>

    <div class="main-content">
        <!-- Header -->
        <div class="header">
            <div class="header-title">
                <span class="menu-dots">⋮</span>
                <span>Dashboard Admin Portal Pembayaran</span>
            </div>
            <?php
            // NO AVATAR for admin_universitas (role-based logic)
            // Avatar only shown for mahasiswa role
            ?>
        </div>

        <!-- Welcome Message -->
        <div class="welcome-message">
            <h1 class="welcome-title" id="welcomeTitle">Selamat Datang, Admin!</h1>
            <p class="welcome-subtitle">Sistem Manajemen Pembayaran Mahasiswa</p>
            <div class="current-time" id="currentTime">Loading...</div>
        </div>

        <!-- Summary Statistics -->
        <div class="section">
            <h2 class="section-title">Statistik Overview</h2>
            <div class="summary-stats">
                <div class="stat-card stat-card-mahasiswa">
                    <div class="stat-title">👥 Total Mahasiswa</div>
                    <div class="stat-value" id="totalMahasiswa">0</div>
                    <div class="stat-trend trend-up" id="mahasiswaTrend">
                        ↑ Loading...
                    </div>
                </div>
                
                <div class="stat-card stat-card-tagihan">
                    <div class="stat-title">💰 Total Tagihan</div>
                    <div class="stat-value" id="totalTagihan">Rp 0</div>
                    <div class="stat-trend trend-up" id="tagihanTrend">
                        ↑ Loading...
                    </div>
                </div>
                
                <div class="stat-card stat-card-pending">
                    <div class="stat-title">⏳ Validasi Menunggu</div>
                    <div class="stat-value" id="validasiMenunggu">0</div>
                    <div class="stat-trend trend-down" id="validasiTrend">
                        ↓ Loading...
                    </div>
                </div>
                
                <div class="stat-card stat-card-approved">
                    <div class="stat-title">✅ Pembayaran Disetujui</div>
                    <div class="stat-value" id="pembayaranDisetujui">0</div>
                    <div class="stat-trend trend-up" id="disetujuiTrend">
                        ↑ Loading...
                    </div>
                </div>
            </div>

            <!-- Simple Info Section -->
            <div class="info-box">
                <div class="info-title">📋 Informasi Sistem</div>
                <div class="info-content">
                    Sistem pembayaran mahasiswa aktif dan berjalan dengan baik. 
                    Gunakan menu di sidebar untuk mengakses fitur-fitur lengkap.
                </div>
            </div>
        </div>

        <!-- Simple Dashboard Info -->
        <div class="section">
            <h2 class="section-title">Sistem Status</h2>
            <div style="display: flex; flex-direction: column; gap: 15px;">
                <div style="display: flex; align-items: center; gap: 10px; padding: 15px; background: #f8f9fa; border-radius: 8px;">
                    <div style="width: 12px; height: 12px; background: #28a745; border-radius: 50%;"></div>
                    <div style="flex: 1;">
                        <strong>Server:</strong> Online & Responsif
                    </div>
                    <div style="font-size: 14px; color: #666;">✓</div>
                </div>
                
                <div style="display: flex; align-items: center; gap: 10px; padding: 15px; background: #f8f9fa; border-radius: 8px;">
                    <div style="width: 12px; height: 12px; background: #28a745; border-radius: 50%;"></div>
                    <div style="flex: 1;">
                        <strong>Database:</strong> Terhubung & Stabil
                    </div>
                    <div style="font-size: 14px; color: #666;">✓</div>
                </div>
                
                <div style="display: flex; align-items: center; gap: 10px; padding: 15px; background: #f8f9fa; border-radius: 8px;">
                    <div style="width: 12px; height: 12px; background: #ffc107; border-radius: 50%;"></div>
                    <div style="flex: 1;">
                        <strong>Validasi Tertunda:</strong> <span id="validasiStatus">0 pembayaran menunggu</span>
                    </div>
                    <div style="font-size: 14px; color: #666;">⚠️</div>
                </div>
            </div>
        </div>
    </div>

    <script>
        // Fungsi untuk format Rupiah
        function formatRupiah(angka) {
            return angka.toLocaleString('id-ID');
        }

        // Update current time
        function updateTime() {
            const now = new Date();
            const options = { 
                weekday: 'long', 
                year: 'numeric', 
                month: 'long', 
                day: 'numeric',
                hour: '2-digit',
                minute: '2-digit'
            };
            const timeString = now.toLocaleDateString('id-ID', options);
            document.getElementById('currentTime').textContent = timeString;
        }

        // Fungsi untuk mendapatkan token dari localStorage
        function getAuthToken() {
            return localStorage.getItem('auth_token');
        }

        // Fetch dashboard data dari backend
        async function fetchDashboardData() {
            try {
                const token = getAuthToken();
                if (!token) {
                    console.error('No auth token found');
                    return;
                }

                const response = await fetch('/projek_plbs/api/index.php/api/admin-universitas/dashboard-info', {
                    method: 'GET',
                    credentials: 'include',
                    headers: {
                        'Authorization': `Bearer ${token}`,
                        'Content-Type': 'application/json'
                    }
                });

                if (!response.ok) {
                    throw new Error(`HTTP error! status: ${response.status}`);
                }

                const data = await response.json();

                if (data.status === 'success') {
                    updateDashboard(data.data);
                } else {
                    console.error('API Error:', data.message);
                }
            } catch (error) {
                console.error('Error fetching dashboard data:', error);
            }
        }

        // Fungsi untuk update dashboard dengan data dari API
        function updateDashboard(dashboardData) {
            try {
                const { admin, statistik_mahasiswa, statistik_pembayaran } = dashboardData;

                // Update welcome title
                document.getElementById('welcomeTitle').textContent = `Selamat Datang, ${admin.nama_lengkap}!`;

                // Update statistik mahasiswa
                document.getElementById('totalMahasiswa').textContent = 
                    (statistik_mahasiswa.total_mahasiswa || 0).toLocaleString('id-ID');
                document.getElementById('totalTagihan').textContent = 
                    `Rp ${formatRupiah(statistik_mahasiswa.total_amount_tervalidasi || 0)}`;

                // Update statistik pembayaran
                document.getElementById('validasiMenunggu').textContent = 
                    statistik_pembayaran.menunggu_validasi || 0;
                document.getElementById('pembayaranDisetujui').textContent = 
                    statistik_pembayaran.divalidasi || 0;

                // Update status message
                document.getElementById('validasiStatus').textContent = 
                    `${statistik_pembayaran.menunggu_validasi || 0} pembayaran menunggu`;

            } catch (error) {
                console.error('Error updating dashboard:', error);
            }
        }

        // Menu interaction
        const menuItems = document.querySelectorAll('.menu-item');
        menuItems.forEach(item => {
            item.addEventListener('click', function() {
                menuItems.forEach(mi => mi.classList.remove('active'));
                this.classList.add('active');
                
                // Update header title based on menu selection
                const menuText = this.querySelector('div:nth-child(2)').textContent;
                document.querySelector('.header-title span:nth-child(2)').textContent = menuText;
            });
        });

        // Simulate real-time data updates
        function simulateDataUpdates() {
            // Update time every minute
            setInterval(updateTime, 60000);
        }

        // Initialize dashboard
        document.addEventListener('DOMContentLoaded', function() {
            updateTime();
            simulateDataUpdates();
            
            // Fetch dan update dashboard data
            fetchDashboardData();
            
            // Add welcome animation
            setTimeout(() => {
                const welcomeMessage = document.querySelector('.welcome-message');
                welcomeMessage.style.transition = 'transform 0.5s ease';
                welcomeMessage.style.transform = 'translateY(-10px)';
                
                setTimeout(() => {
                    welcomeMessage.style.transform = 'translateY(0)';
                }, 500);
            }, 1000);
            
            // Add card hover effects
            const statCards = document.querySelectorAll('.stat-card');
            statCards.forEach(card => {
                card.addEventListener('mouseenter', function() {
                    this.style.boxShadow = '0 8px 16px rgba(0,0,0,0.1)';
                });
                
                card.addEventListener('mouseleave', function() {
                    this.style.boxShadow = '0 2px 4px rgba(0,0,0,0.1)';
                });
            });
        });

        // Keyboard shortcuts
        document.addEventListener('keydown', function(event) {
            // Number shortcuts 1-3 for menu items
            if (event.key >= '1' && event.key <= '3') {
                event.preventDefault();
                const menuIndex = parseInt(event.key) - 1;
                if (menuItems[menuIndex]) {
                    menuItems[menuIndex].click();
                }
            }
            
            // Ctrl + T for time refresh
            if (event.ctrlKey && event.key === 't') {
                event.preventDefault();
                updateTime();
            }
        });
    </script>

    <script src="js/auth.js"></script>
    <script>
        // Auth check
        document.addEventListener('DOMContentLoaded', function() {
            requireAuth('admin_universitas');
            
            const user = getCurrentUser();
            
            // Update user info di sidebar
            document.querySelector('.user-name').textContent = user.nama_lengkap || 'Admin Universitas';
        });
    </script>
</body>
</html>
