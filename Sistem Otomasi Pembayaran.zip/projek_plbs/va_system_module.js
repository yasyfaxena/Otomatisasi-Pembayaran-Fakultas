/**
 * VIRTUAL ACCOUNT (VA) SYSTEM MODULE
 * Sistem generate dan manage Virtual Account untuk pembayaran BPP per Semester (1-8)
 * 
 * FITUR:
 * - Generate VA unik per (NIM + Semester + JenisPembayaran)
 * - Validasi pembayaran otomatis
 * - Update status KRS saat valid
 * - Tracking cicilan per semester
 * 
 * @module VASystem
 */

// ============================================================================
// 1. VA CONFIGURATION & DATABASE
// ============================================================================

/**
 * Konfigurasi VA Codes berdasarkan Semester dan Jenis Pembayaran
 */
const VA_CONFIG = {
    BPP_LUNAS: {
        semester_1: 'VA_BPP_S1_LUNAS',
        semester_2: 'VA_BPP_S2_LUNAS',
        semester_3: 'VA_BPP_S3_LUNAS',
        semester_4: 'VA_BPP_S4_LUNAS',
        semester_5: 'VA_BPP_S5_LUNAS',
        semester_6: 'VA_BPP_S6_LUNAS',
        semester_7: 'VA_BPP_S7_LUNAS',
        semester_8: 'VA_BPP_S8_LUNAS'
    },
    BPP_CICILAN: {
        semester_1: 'VA_BPP_S1_CICIL',
        semester_2: 'VA_BPP_S2_CICIL',
        semester_3: 'VA_BPP_S3_CICIL',
        semester_4: 'VA_BPP_S4_CICIL',
        semester_5: 'VA_BPP_S5_CICIL',
        semester_6: 'VA_BPP_S6_CICIL',
        semester_7: 'VA_BPP_S7_CICIL',
        semester_8: 'VA_BPP_S8_CICIL'
    },
    SKRIPSI: 'VA_SKRIPSI',
    PROPOSAL: 'VA_PROPOSAL'
};

/**
 * Harga BPP per Semester
 * @type {Object}
 */
const BPP_PRICES = {
    1: 4750000,
    2: 4750000,
    3: 4750000,
    4: 4750000,
    5: 4750000,
    6: 4750000,
    7: 4750000,
    8: 4750000
};

/**
 * Cicilan options per semester
 */
const CICILAN_OPTIONS = {
    default: [
        { count: 2, label: '2 Kali Cicilan', amounts: [2500000, 2250000] },
        { count: 3, label: '3 Kali Cicilan', amounts: [1700000, 1700000, 1350000] },
        { count: 4, label: '4 Kali Cicilan', amounts: [1250000, 1250000, 1250000, 1000000] }
    ]
};

// ============================================================================
// 2. VA GENERATOR ENGINE
// ============================================================================

/**
 * Generate Virtual Account Number berdasarkan NIM, Semester, dan Jenis Pembayaran
 * 
 * Format VA: [BANK_CODE][COMPANY_CODE][NIM_LAST_4][SEMESTER][JENIS_KODE]
 * Contoh: 5646 113020 0029 01 01
 * 
 * @param {string} nim - Nomor Induk Mahasiswa
 * @param {number} semester - Semester (1-8)
 * @param {string} jenis - Jenis pembayaran ('BPP_LUNAS', 'BPP_CICILAN', 'SKRIPSI', 'PROPOSAL')
 * @param {string} bank - Kode Bank (default: 'BSI')
 * @returns {Object} VA data dengan VA number dan metadata
 */
function generateVirtualAccount(nim, semester, jenis, bank = 'BSI') {
    // Validasi input
    if (!nim || nim.length < 4) {
        throw new Error('NIM tidak valid');
    }
    
    if (semester < 1 || semester > 8) {
        throw new Error('Semester harus 1-8');
    }
    
    // Extract NIM last 4 digits
    const nimLast4 = nim.slice(-4);
    
    // Get company code berdasarkan bank
    const companyCode = getCompanyCode(bank);
    
    // Get jenis code
    const jenisCode = getJenisCode(jenis, semester);
    
    // Generate unique suffix (timestamp-based untuk unikness)
    const timestamp = Date.now().toString().slice(-6);
    
    // Format VA berdasarkan bank
    let vaNumber;
    if (bank === 'BSI') {
        // Format BSI: 5646 [Company] [NIM Last 4] [Semester] [Jenis] [Timestamp]
        vaNumber = `5646${companyCode}${nimLast4}${String(semester).padStart(2, '0')}${jenisCode}`;
    } else if (bank === 'MANDIRI') {
        // Format Mandiri: 8900 [Company] [NIM Last 4] [Semester] [Jenis] [Timestamp]
        vaNumber = `8900${companyCode}${nimLast4}${String(semester).padStart(2, '0')}${jenisCode}`;
    }
    
    return {
        va_number: vaNumber,
        bank: bank,
        nim: nim,
        semester: semester,
        jenis: jenis,
        va_code: VA_CONFIG[jenis]?.['semester_' + semester] || VA_CONFIG[jenis],
        created_at: new Date().toISOString(),
        status: 'ACTIVE',
        is_valid: false
    };
}

/**
 * Get company code berdasarkan bank
 */
function getCompanyCode(bank) {
    const codes = {
        'BSI': '113',
        'MANDIRI': '889'
    };
    return codes[bank] || codes['BSI'];
}

/**
 * Get jenis code untuk VA generation
 */
function getJenisCode(jenis, semester = null) {
    const codes = {
        'BPP_LUNAS': '01',
        'BPP_CICILAN': '02',
        'SKRIPSI': '03',
        'PROPOSAL': '04'
    };
    return codes[jenis] || '01';
}

// ============================================================================
// 3. SEMESTER PARSER & DATA MANAGER
// ============================================================================

/**
 * Parse semester dari format "YYYY/YYYY Awal" atau "YYYY/YYYY Akhir"
 * Returns semester number 1-8 berdasarkan tahun akademik
 * 
 * @param {string} semesterStr - String semester seperti "2025/2026 Awal"
 * @returns {Object} { year: number, period: 'awal'|'akhir', semesterNum: 1-8 }
 */
function parseSemester(semesterStr) {
    // Format: "YYYY/YYYY Awal" atau "YYYY/YYYY Akhir"
    const match = semesterStr.match(/(\d{4})\/(\d{4})\s+(Awal|Akhir)/i);
    
    if (!match) {
        throw new Error('Format semester tidak valid: ' + semesterStr);
    }
    
    const startYear = parseInt(match[1]);
    const endYear = parseInt(match[2]);
    const period = match[3].toLowerCase();
    
    // Hitung semester berdasarkan tahun dan periode
    // Awal = ganjil (1,3,5,7), Akhir = genap (2,4,6,8)
    // Tapi ini bergantung pada angkatan, jadi gunakan mapping sederhana
    
    // Untuk simplicity: gunakan current academic year dan count
    // In real system, ini akan diambil dari database
    
    const academicYear = `${startYear}/${endYear}`;
    
    // Temporary mapping (dalam real system, ini dari database)
    const semesterMap = {
        '2025/2026 Awal': 1,
        '2025/2026 Akhir': 2,
        '2024/2025 Awal': 3,
        '2024/2025 Akhir': 4,
        '2023/2024 Awal': 5,
        '2023/2024 Akhir': 6,
        '2022/2023 Awal': 7,
        '2022/2023 Akhir': 8
    };
    
    const semesterNum = semesterMap[semesterStr] || 1;
    
    return {
        year: startYear,
        period: period,
        semester_num: semesterNum,
        display: semesterStr
    };
}

// ============================================================================
// 4. PAYMENT DATA STRUCTURE & STORAGE
// ============================================================================

/**
 * Payment record structure
 * Disimpan di localStorage untuk simulasi database
 */
class PaymentRecord {
    constructor(nim, semesterStr, jenis, metode, amount) {
        this.payment_id = generatePaymentId();
        this.nim = nim;
        this.semester = parseSemester(semesterStr);
        this.semester_display = semesterStr;
        this.jenis = jenis; // 'BPP_LUNAS', 'BPP_CICILAN', 'SKRIPSI', 'PROPOSAL'
        this.metode = metode; // 'Lunas', 'Cicilan'
        this.amount_total = amount;
        this.amount_paid = 0;
        this.cicilan_data = null; // Untuk cicilan
        this.va_data = null;
        this.status = 'PENDING'; // PENDING, WAITING_PAYMENT, PAID, VALIDATED
        this.created_at = new Date().toISOString();
        this.bukti_pembayaran = [];
        this.notes = '';
    }
    
    /**
     * Generate VA untuk payment ini
     */
    generateVA(bank = 'BSI') {
        this.va_data = generateVirtualAccount(
            this.nim,
            this.semester.semester_num,
            this.jenis,
            bank
        );
        this.status = 'WAITING_PAYMENT';
        return this.va_data;
    }
    
    /**
     * Add cicilan configuration
     */
    setCicilanConfig(cicilanCount, amounts) {
        this.cicilan_data = {
            total_cicilan: cicilanCount,
            cicilan_list: amounts.map((amt, idx) => ({
                cicilan_ke: idx + 1,
                amount: amt,
                status: 'BELUM_BAYAR',
                va_number: null
            })),
            amount_paid: 0
        };
    }
    
    /**
     * Record bukti pembayaran
     */
    addBuktiPembayaran(buktiData) {
        this.bukti_pembayaran.push({
            file_name: buktiData.file_name,
            upload_date: new Date().toISOString(),
            amount: buktiData.amount,
            notes: buktiData.notes || ''
        });
    }
    
    /**
     * Validate payment (dilakukan oleh admin)
     */
    validate() {
        this.status = 'VALIDATED';
        this.va_data.is_valid = true;
    }
}

/**
 * Generate unique payment ID
 */
function generatePaymentId() {
    return 'PAY_' + Date.now() + '_' + Math.random().toString(36).substr(2, 9);
}

/**
 * Save payment record ke localStorage
 */
function savePaymentRecord(record) {
    const payments = JSON.parse(localStorage.getItem('payments') || '{}');
    const key = `${record.nim}_${record.payment_id}`;
    payments[key] = JSON.stringify(record);
    localStorage.setItem('payments', JSON.stringify(payments));
    return record;
}

/**
 * Get payment records untuk NIM tertentu
 */
function getPaymentsByNIM(nim) {
    const payments = JSON.parse(localStorage.getItem('payments') || '{}');
    return Object.entries(payments)
        .filter(([key]) => key.startsWith(nim))
        .map(([_, value]) => JSON.parse(value));
}

/**
 * Get payment record by ID
 */
function getPaymentRecord(paymentId) {
    const payments = JSON.parse(localStorage.getItem('payments') || '{}');
    for (const [key, value] of Object.entries(payments)) {
        const record = JSON.parse(value);
        if (record.payment_id === paymentId) {
            return record;
        }
    }
    return null;
}

// ============================================================================
// 5. VALIDATION & KRS ACTIVATION
// ============================================================================

/**
 * Check if semester pembayaran bisa activate KRS
 * KRS bisa aktif jika:
 * - BPP Lunas ATAU
 * - BPP Cicilan sudah terbayar >= 50% dari total
 */
function canActivateKRS(nim, semesterNum) {
    const payments = getPaymentsByNIM(nim);
    
    // Find BPP payment untuk semester ini
    const bppPayments = payments.filter(p => 
        p.semester.semester_num === semesterNum && 
        (p.jenis === 'BPP_LUNAS' || p.jenis === 'BPP_CICILAN') &&
        p.status === 'VALIDATED'
    );
    
    if (bppPayments.length === 0) return false;
    
    for (const payment of bppPayments) {
        if (payment.jenis === 'BPP_LUNAS' && payment.status === 'VALIDATED') {
            return true; // BPP Lunas sudah validated
        }
        
        if (payment.jenis === 'BPP_CICILAN' && payment.cicilan_data) {
            const totalPaid = payment.cicilan_data.cicilan_list
                .filter(c => c.status === 'VALID')
                .reduce((sum, c) => sum + c.amount, 0);
            
            if (totalPaid >= payment.amount_total * 0.5) {
                return true; // Cicilan >= 50%
            }
        }
    }
    
    return false;
}

/**
 * Activate KRS untuk mahasiswa pada semester tertentu
 */
function activateKRS(nim, semesterNum) {
    if (!canActivateKRS(nim, semesterNum)) {
        return {
            success: false,
            message: 'Pembayaran belum mencukupi untuk aktivasi KRS'
        };
    }
    
    // Simulate KRS activation
    const krsData = JSON.parse(localStorage.getItem('krs_status') || '{}');
    krsData[`${nim}_s${semesterNum}`] = {
        status: 'AKTIF',
        activated_at: new Date().toISOString()
    };
    localStorage.setItem('krs_status', JSON.stringify(krsData));
    
    return {
        success: true,
        message: 'KRS berhasil diaktifkan',
        status: 'AKTIF'
    };
}

/**
 * Get KRS status
 */
function getKRSStatus(nim, semesterNum) {
    const krsData = JSON.parse(localStorage.getItem('krs_status') || '{}');
    return krsData[`${nim}_s${semesterNum}`] || { status: 'BELUM_AKTIF' };
}

// ============================================================================
// 6. NOTIFICATION SYSTEM
// ============================================================================

/**
 * Send notification ke mahasiswa
 */
function sendNotificationToStudent(nim, title, message, type = 'info') {
    const notifications = JSON.parse(localStorage.getItem('notifications') || '{}');
    
    if (!notifications[nim]) {
        notifications[nim] = [];
    }
    
    notifications[nim].push({
        id: 'notif_' + Date.now(),
        title: title,
        message: message,
        type: type,
        created_at: new Date().toISOString(),
        read: false
    });
    
    localStorage.setItem('notifications', JSON.stringify(notifications));
}

/**
 * Get unread notifications
 */
function getUnreadNotifications(nim) {
    const notifications = JSON.parse(localStorage.getItem('notifications') || '{}');
    return (notifications[nim] || []).filter(n => !n.read);
}

// ============================================================================
// 7. VALIDATION FLOW (Admin Side)
// ============================================================================

/**
 * Admin menekan tombol "Valid" untuk validasi pembayaran
 * Flow:
 * 1. Terima bukti pembayaran
 * 2. Validasi VA & amount
 * 3. Update status pembayaran
 * 4. Trigger otomatis KRS activation jika eligible
 * 5. Send notifikasi ke mahasiswa
 */
function adminValidatePayment(paymentId, validationData) {
    const payment = getPaymentRecord(paymentId);
    
    if (!payment) {
        return { success: false, message: 'Payment tidak ditemukan' };
    }
    
    // Validasi VA matching
    if (payment.va_data?.va_number !== validationData.va_from_bukti) {
        return { 
            success: false, 
            message: 'VA tidak cocok dengan bukti pembayaran' 
        };
    }
    
    // Validasi amount
    if (payment.amount_total !== validationData.amount_paid) {
        return { 
            success: false, 
            message: 'Nominal pembayaran tidak cocok' 
        };
    }
    
    // Update status
    payment.status = 'VALIDATED';
    payment.amount_paid = validationData.amount_paid;
    savePaymentRecord(payment);
    
    // Try to activate KRS
    const krsResult = activateKRS(payment.nim, payment.semester.semester_num);
    
    // Send notification
    let notifMessage = `Pembayaran ${payment.jenis} Semester ${payment.semester.semester_num} telah divalidasi.`;
    if (krsResult.success) {
        notifMessage += ` KRS berhasil diaktifkan.`;
    }
    
    sendNotificationToStudent(
        payment.nim,
        'Pembayaran Divalidasi',
        notifMessage,
        'success'
    );
    
    return {
        success: true,
        message: 'Pembayaran berhasil divalidasi',
        krs_activated: krsResult.success,
        payment: payment
    };
}

// ============================================================================
// 8. HELPER FUNCTIONS
// ============================================================================

/**
 * Format currency to Rupiah
 */
function formatCurrency(amount) {
    return new Intl.NumberFormat('id-ID', {
        style: 'currency',
        currency: 'IDR',
        minimumFractionDigits: 0
    }).format(amount);
}

/**
 * Get semester display name
 */
function getSemesterDisplayName(semesterNum) {
    const names = {
        1: 'Semester 1 (Awal TA 2025/2026)',
        2: 'Semester 2 (Akhir TA 2025/2026)',
        3: 'Semester 3 (Awal TA 2024/2025)',
        4: 'Semester 4 (Akhir TA 2024/2025)',
        5: 'Semester 5 (Awal TA 2023/2024)',
        6: 'Semester 6 (Akhir TA 2023/2024)',
        7: 'Semester 7 (Awal TA 2022/2023)',
        8: 'Semester 8 (Akhir TA 2022/2023)'
    };
    return names[semesterNum] || `Semester ${semesterNum}`;
}

// ============================================================================
// EXPORTS untuk digunakan di HTML files
// ============================================================================

if (typeof module !== 'undefined' && module.exports) {
    module.exports = {
        generateVirtualAccount,
        PaymentRecord,
        parseSemester,
        savePaymentRecord,
        getPaymentsByNIM,
        canActivateKRS,
        activateKRS,
        getKRSStatus,
        sendNotificationToStudent,
        adminValidatePayment,
        formatCurrency,
        getSemesterDisplayName,
        VA_CONFIG,
        BPP_PRICES,
        CICILAN_OPTIONS
    };
}
