<?php
session_start();
// Register page - tidak perlu check session karena belum login
?>
<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Register Akun - Mahasiswa</title>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">

<style>
:root {
    --primary: #246140;
    --primary-dark: #113120;
    --bg: #f5f7fa;
    --card: #ffffff;
    --text: #333;
    --muted: #777;
}

* {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
    font-family: 'Segoe UI', Tahoma, sans-serif;
}

body {
    min-height: 100vh;
    background-image: url('pictures/background_fikom.jpg');
    background-size: cover;
    background-position: center;
    background-repeat: no-repeat;
    background-attachment: fixed;
    display: flex;
    align-items: center;
    justify-content: center;
    padding: 20px;
}

.auth-container {
    width: 100%;
    max-width: 500px;
    background: var(--card);
    padding: 35px;
    border-radius: 14px;
    box-shadow: 0 15px 40px rgba(0,0,0,0.12);
}

.auth-header {
    text-align: center;
    margin-bottom: 25px;
}

.auth-header h2 {
    color: var(--primary-dark);
    font-size: 24px;
}

.auth-header p {
    font-size: 14px;
    color: var(--muted);
}

.form-group {
    margin-bottom: 18px;
}

.form-group label {
    display: block;
    margin-bottom: 6px;
    font-size: 14px;
    font-weight: 600;
}

.input-wrapper {
    position: relative;
}

.input-wrapper i {
    position: absolute;
    top: 50%;
    left: 12px;
    transform: translateY(-50%);
    color: var(--muted);
}

.input-wrapper input,
.input-wrapper select {
    width: 100%;
    padding: 12px 12px 12px 38px;
    border-radius: 8px;
    border: 1px solid #ddd;
    font-size: 14px;
    outline: none;
    transition: 0.3s;
}

.input-wrapper input:focus,
.input-wrapper select:focus {
    border-color: var(--primary);
    box-shadow: 0 0 0 2px rgba(36,97,64,0.15);
}

.btn-primary {
    width: 100%;
    padding: 12px;
    background: linear-gradient(135deg, var(--primary), var(--primary-dark));
    border: none;
    border-radius: 10px;
    color: white;
    font-size: 15px;
    font-weight: 600;
    cursor: pointer;
    transition: 0.3s;
}

.btn-primary:hover:not(:disabled) {
    opacity: 0.9;
    transform: translateY(-1px);
}

.btn-primary:disabled {
    opacity: 0.6;
    cursor: not-allowed;
}

.auth-footer {
    text-align: center;
    margin-top: 20px;
    font-size: 14px;
}

.auth-footer a {
    color: var(--primary);
    text-decoration: none;
    font-weight: 600;
}

.auth-footer a:hover {
    text-decoration: underline;
}

.message {
    display: none;
    margin-bottom: 15px;
    padding: 12px;
    border-radius: 8px;
    text-align: center;
    font-size: 14px;
}

.message.error {
    background: #fee;
    color: #c33;
    border: 1px solid #fcc;
}

.message.success {
    background: #efe;
    color: #3c3;
    border: 1px solid #cfc;
}

.message.info {
    background: #eef;
    color: #33c;
    border: 1px solid #ccf;
}

@media (max-width: 480px) {
    .auth-container {
        padding: 30px 20px;
    }
    
    .auth-header h2 {
        font-size: 20px;
    }
}
</style>
</head>

<body>

<div class="auth-container">
    <div class="auth-header">
        <h2>Daftar Akun Mahasiswa</h2>
        <p>Buat akun baru untuk mengakses sistem</p>
    </div>

    <div id="errorMessage" class="message error"></div>
    <div id="successMessage" class="message success"></div>
    <div id="infoMessage" class="message info"></div>

    <form id="registerForm">
        <div class="form-group">
            <label>Nama Lengkap</label>
            <div class="input-wrapper">
                <i class="fas fa-user"></i>
                <input type="text" id="nama_lengkap" name="nama_lengkap" placeholder="Masukkan nama lengkap" required>
            </div>
        </div>

        <div class="form-group">
            <label>NIM (Nomor Induk Mahasiswa)</label>
            <div class="input-wrapper">
                <i class="fas fa-id-card"></i>
                <input type="text" id="nim" name="nim" placeholder="Masukkan NIM Anda" required>
            </div>
        </div>

        <div class="form-group">
            <label>Program Studi</label>
            <div class="input-wrapper">
                <i class="fas fa-book"></i>
                <select id="prodi_id" name="prodi_id" required>
                    <option value="">-- Pilih Program Studi --</option>
                    <option value="1">Teknik Informatika</option>
                    <option value="2">Sistem Informasi</option>
                </select>
            </div>
        </div>

        <div class="form-group">
            <label>Email</label>
            <div class="input-wrapper">
                <i class="fas fa-envelope"></i>
                <input type="email" id="email" name="email" placeholder="Masukkan email Anda" required>
            </div>
        </div>

        <div class="form-group">
            <label>Username</label>
            <div class="input-wrapper">
                <i class="fas fa-at"></i>
                <input type="text" id="username" name="username" placeholder="Masukkan username" required>
            </div>
        </div>

        <div class="form-group">
            <label>Password</label>
            <div class="input-wrapper">
                <i class="fas fa-lock"></i>
                <input type="password" id="password" name="password" placeholder="Masukkan password (min 6 karakter)" required>
            </div>
        </div>

        <div class="form-group">
            <label>Konfirmasi Password</label>
            <div class="input-wrapper">
                <i class="fas fa-lock"></i>
                <input type="password" id="confirm_password" name="confirm_password" placeholder="Ulangi password" required>
            </div>
        </div>

        <button class="btn-primary" type="submit" id="registerBtn">
            <i class="fas fa-user-plus"></i> Daftar
        </button>
    </form>

    <div class="auth-footer">
        Sudah punya akun?
        <a href="mhs_login.php">Login</a>
    </div>
</div>

<script>
document.getElementById('registerForm').addEventListener('submit', async function(e) {
    e.preventDefault();

    const nama_lengkap = document.getElementById('nama_lengkap').value.trim();
    const nim = document.getElementById('nim').value.trim();
    const prodi_id = document.getElementById('prodi_id').value;
    const email = document.getElementById('email').value.trim();
    const username = document.getElementById('username').value.trim();
    const password = document.getElementById('password').value;
    const confirm_password = document.getElementById('confirm_password').value;

    const errorMsg = document.getElementById('errorMessage');
    const successMsg = document.getElementById('successMessage');
    const infoMsg = document.getElementById('infoMessage');
    const registerBtn = document.getElementById('registerBtn');

    errorMsg.style.display = 'none';
    successMsg.style.display = 'none';
    infoMsg.style.display = 'none';

    if (!nama_lengkap || !nim || !prodi_id || !email || !username || !password || !confirm_password) {
        errorMsg.textContent = 'Semua field harus diisi';
        errorMsg.style.display = 'block';
        return;
    }

    if (password.length < 6) {
        errorMsg.textContent = 'Password harus minimal 6 karakter';
        errorMsg.style.display = 'block';
        return;
    }

    if (password !== confirm_password) {
        errorMsg.textContent = 'Password dan konfirmasi password tidak sesuai';
        errorMsg.style.display = 'block';
        return;
    }

    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(email)) {
        errorMsg.textContent = 'Format email tidak valid';
        errorMsg.style.display = 'block';
        return;
    }

    registerBtn.disabled = true;
    registerBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Sedang mendaftar...';

    try {
        const response = await fetch('/projek_plbs/api/index.php/api/auth/register', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                nama_lengkap: nama_lengkap,
                nim: nim,
                prodi_id: parseInt(prodi_id),
                email: email,
                username: username,
                password: password
            })
        });

        const data = await response.json();

        if (data.status === 'success') {
            successMsg.textContent = 'Pendaftaran berhasil! Silakan login dengan akun Anda.';
            successMsg.style.display = 'block';

            document.getElementById('registerForm').reset();

            setTimeout(() => {
                window.location.href = 'mhs_login.php';
            }, 2000);
        } else {
            errorMsg.textContent = data.message || 'Pendaftaran gagal. Coba lagi.';
            errorMsg.style.display = 'block';
        }
    } catch (error) {
        errorMsg.textContent = 'Terjadi kesalahan: ' + error.message;
        errorMsg.style.display = 'block';
    } finally {
        registerBtn.disabled = false;
        registerBtn.innerHTML = '<i class="fas fa-user-plus"></i> Daftar';
    }
});
</script>

</body>
</html>
