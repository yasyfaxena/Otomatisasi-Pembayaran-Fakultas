<?php
session_start();
// Index page - public landing page untuk memilih tipe login
// No session check needed, ini adalah halaman publik
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sistem Pembayaran BPP - Pilih Login</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }

        body {
            min-height: 100vh;
            background-image: url('pictures/universitas.jpg');
            background-size: cover;
            background-position: center;
            background-repeat: no-repeat;
            background-attachment: fixed;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 20px;
            position: relative;
        }

        body::before {
            content: '';
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background-image: url('pictures/universitas.jpg');
            background-size: cover;
            background-position: center;
            background-repeat: no-repeat;
            background-attachment: fixed;
            filter: blur(1px);
            z-index: -1;
        }

        .container {
            max-width: 1100px;
            width: 100%;
        }

        .header {
            text-align: center;
            color: white;
            margin-bottom: 50px;
        }

        .header h1 {
            font-size: 2.5rem;
            margin-bottom: 10px;
            text-shadow: 0 2px 4px rgba(0,0,0,0.2);
        }

        .header p {
            font-size: 1.1rem;
            opacity: 0.9;
            text-shadow: 0 1px 2px rgba(0,0,0,0.2);
        }

        .login-options {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
            gap: 30px;
            margin-top: 40px;
        }

        .login-card {
            background: white;
            border-radius: 15px;
            padding: 40px 30px;
            box-shadow: 0 10px 40px rgba(0,0,0,0.2);
            text-align: center;
            transition: all 0.3s ease;
            cursor: pointer;
        }

        .login-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 15px 50px rgba(0,0,0,0.3);
        }

        .login-card i {
            font-size: 60px;
            color: #667eea;
            margin-bottom: 20px;
        }

        .login-card h2 {
            color: #333;
            font-size: 1.5rem;
            margin-bottom: 10px;
        }

        .login-card p {
            color: #666;
            font-size: 0.95rem;
            margin-bottom: 25px;
            line-height: 1.6;
        }

        .login-card .btn {
            display: inline-block;
            padding: 12px 30px;
            background: linear-gradient(135deg, #667eea, #764ba2);
            color: white;
            border: none;
            border-radius: 8px;
            text-decoration: none;
            font-size: 1rem;
            font-weight: 600;
            transition: all 0.3s ease;
            width: 100%;
        }

        .login-card .btn:hover {
            opacity: 0.9;
            transform: scale(1.02);
        }

        .login-card .btn i {
            margin-right: 10px;
            font-size: 1rem;
        }

        .mahasiswa-card {
            border-top: 4px solid #10b981;
        }

        .mahasiswa-card i {
            color: #10b981;
        }

        .mahasiswa-card .btn {
            background: linear-gradient(135deg, #10b981, #059669);
        }

        .admin-fakultas-card {
            border-top: 4px solid #080808
        }

        .admin-fakultas-card i {
            color: #080808;
        }

        .admin-fakultas-card .btn {
            background: linear-gradient(135deg, #eee, #333);
        }

        .admin-universitas-card {
            border-top: 4px solid #059669;
        }

        .admin-universitas-card i {
            color: #059669;
        }

        .admin-universitas-card .btn {
            background: linear-gradient(135deg, #113120, #246140);
        }

        .footer {
            text-align: center;
            color: rgb(0, 0, 0);
            margin-top: 50px;
            background: rgba(255, 255, 255, 0.15);
            padding: 20px;
            border-radius: 10px;
            backdrop-filter: blur(10px);
        }

        @media (max-width: 768px) {
            .header h1 {
                font-size: 1.8rem;
            }

            .header p {
                font-size: 0.95rem;
            }

            .login-card {
                padding: 30px 20px;
            }

            .login-card i {
                font-size: 45px;
            }

            .login-card h2 {
                font-size: 1.2rem;
            }
        }
    </style>
</head>
<body>

<div class="container">

    <div class="login-options">
        <!-- Login Mahasiswa -->
        <div class="login-card mahasiswa-card">
            <i class="fas fa-graduation-cap"></i>
            <h2>Login Mahasiswa</h2>
            <p>Masuk dengan akun mahasiswa untuk mengakses dashboard, lihat tagihan, dan kelola pembayaran Anda.</p>
            <a href="mhs_login.php" class="btn">
                <i class="fas fa-sign-in-alt"></i> Login
            </a>
        </div>

        <!-- Login Admin Fakultas -->
        <div class="login-card admin-fakultas-card">
            <i class="fas fa-users-cog"></i>
            <h2>Login Admin Fakultas</h2>
            <p>Akses sebagai administrator fakultas untuk mengelola data mahasiswa dan aktivasi KRS.</p>
            <a href="login_admin_fakultas.php" class="btn">
                <i class="fas fa-sign-in-alt"></i> Login
            </a>
        </div>

        <!-- Login Admin Universitas -->
        <div class="login-card admin-universitas-card">
            <i class="fas fa-university"></i>
            <h2>Login Admin Universitas</h2>
            <p>Masuk sebagai administrator universitas untuk validasi pembayaran dan laporan keuangan.</p>
            <a href="login_admin_universitas.php" class="btn">
                <i class="fas fa-sign-in-alt"></i> Login
            </a>
        </div>
    </div>

    <div class="footer">
        <h2>&copy; 2025 Sistem Pembayaran BPP Terpusat - Universitas Muslim Indonesia</h2>
    </div>
</div>

</body>
</html>
