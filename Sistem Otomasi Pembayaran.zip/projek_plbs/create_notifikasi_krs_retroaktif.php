<?php
/**
 * SCRIPT: Buat Notifikasi Retroaktif untuk KRS yang Sudah Aktif
 * Jalankan: php create_notifikasi_krs_retroaktif.php
 */

require_once __DIR__ . '/api/config/database.php';
require_once __DIR__ . '/api/helpers/notification_helper.php';

try {
    $database = new Database();
    $conn = $database->connect();
    
    echo "=== BUAT NOTIFIKASI KRS RETROAKTIF ===\n\n";
    
    // Ambil semua tagihan dengan KRS aktif tapi belum punya notifikasi
    $query = "SELECT DISTINCT 
                t.mahasiswa_id, 
                t.semester, 
                t.tahun_akademik,
                m.nim,
                u.nama_lengkap
              FROM tagihan t
              JOIN mahasiswa m ON t.mahasiswa_id = m.mahasiswa_id
              JOIN users u ON m.user_id = u.user_id
              WHERE t.status_krs = 'aktif'
                AND NOT EXISTS (
                    SELECT 1 FROM notifikasi n 
                    WHERE n.mahasiswa_id = t.mahasiswa_id 
                    AND n.judul LIKE '%KRS%'
                    AND n.pesan LIKE CONCAT('%Semester ', t.semester, '%')
                )";
    
    $stmt = $conn->query($query);
    $krs_list = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    if (count($krs_list) == 0) {
        echo "✓ Tidak ada KRS yang perlu dibuatkan notifikasi.\n";
        echo "  Semua notifikasi sudah ada atau tidak ada KRS yang aktif.\n\n";
    } else {
        echo "Ditemukan " . count($krs_list) . " KRS yang perlu dibuatkan notifikasi:\n\n";
        
        $success = 0;
        $failed = 0;
        
        foreach ($krs_list as $krs) {
            echo "- Mahasiswa: {$krs['nama_lengkap']} (NIM: {$krs['nim']})\n";
            echo "  Semester: {$krs['semester']}, TA: {$krs['tahun_akademik']}\n";
            
            $result = createKRSNotification(
                $conn, 
                $krs['mahasiswa_id'], 
                $krs['semester'], 
                $krs['tahun_akademik']
            );
            
            if ($result) {
                echo "  ✓ Notifikasi berhasil dibuat\n\n";
                $success++;
            } else {
                echo "  ✗ Gagal membuat notifikasi\n\n";
                $failed++;
            }
        }
        
        echo "=== HASIL ===\n";
        echo "Berhasil: $success\n";
        echo "Gagal: $failed\n";
        echo "Total: " . count($krs_list) . "\n\n";
    }
    
    // Cek total notifikasi KRS
    $stmt = $conn->query("SELECT COUNT(*) as total FROM notifikasi WHERE judul LIKE '%KRS%'");
    $total = $stmt->fetch(PDO::FETCH_ASSOC);
    echo "Total notifikasi KRS di database: {$total['total']}\n\n";
    
    echo "=== SELESAI ===\n";
    
} catch (Exception $e) {
    echo "ERROR: " . $e->getMessage() . "\n";
    echo "Stack trace:\n" . $e->getTraceAsString() . "\n";
}
