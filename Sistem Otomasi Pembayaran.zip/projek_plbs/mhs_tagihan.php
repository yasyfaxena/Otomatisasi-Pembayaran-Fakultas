<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header('Location: mhs_login.php');
    exit;
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tagihan Pembayaran</title>
    <!-- Font Awesome Icons -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: #f5f5f5;
            display: flex;
        }

        .sidebar {
            width: 260px;
            background-color: #1a1a1a;
            color: white;
            height: 100vh;
            position: fixed;
            left: 0;
            top: 0;
        }
            .page-header {
            font-size: 20px;
            color: #666;
            display: flex;
            align-items: center;
            gap: 15px;
        }

        .logo { padding: 20px; text-align: center; border-bottom: 1px solid #333; }
        .logo img { width: 80px; height: auto; }
        .user-info { padding: 30px 20px; text-align: center; border-bottom: 1px solid #333; }
        .user-id { font-size: 14px; margin-bottom: 8px; color: #999; }
        .user-name { font-size: 16px; font-weight: 600; margin-bottom: 15px; }
        .user-actions { display: flex; gap: 8px; justify-content: center; }
        .user-actions a { padding: 8px 12px; background: #246140; color: white; text-decoration: none; border-radius: 5px; font-size: 12px; transition: background 0.3s; }
        .user-actions a:hover { background: #1a4c2e; }
        .user-actions a.logout { background: #dc3545; }
        .user-actions a.logout:hover { background: #c82333; }
        .menu { padding: 20px 0; }
        .menu-item { padding: 15px 20px; cursor: pointer; display: flex; align-items: center; gap: 12px; transition: background-color 0.3s; text-decoration: none; color: inherit; }
        .menu-item:hover { background-color: #333; }
        .menu-item.active { background-color: #4CAF50; }
        .menu-icon { width: 24px; height: 24px; }
        
        .main-content { margin-left: 260px; flex: 1; padding: 30px 40px; }
        
        .page-header { 
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 30px;
            background: white;
            padding: 15px 25px;
            border-radius: 8px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
        }
        
        .user-avatar {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            cursor: pointer;
            object-fit: cover;
            border: 2px solid #4169E1;
            transition: transform 0.2s;
        }
        
        .user-avatar:hover {
            transform: scale(1.1);
        }
        
        .page-title { font-size: 20px; font-weight: 700; color: #333; margin-bottom: 0; }
        .page-subtitle { font-size: 14px; color: #666; margin-bottom: 0; display: none; }

        /* BPP Card Styles */
        .tagihan-card {
            background: white;
            border-radius: 12px;
            padding: 25px;
            box-shadow: 0 4px 12px rgba(0,0,0,0.08);
            border: 1px solid #e0e0e0;
            margin-bottom: 30px;
        }
        .tagihan-header { font-size: 20px; font-weight: 700; color: #1a1a1a; padding-bottom: 15px; margin-bottom: 20px; border-bottom: 1px solid #eee; }
        .tagihan-row { display: grid; grid-template-columns: 150px 1fr; align-items: center; margin-bottom: 15px; font-size: 16px; }
        .tagihan-label { color: #555; font-weight: 600; }
        .tagihan-value { color: #333; font-weight: 600; }
        .tagihan-actions { margin-top: 25px; padding-top: 20px; border-top: 1px solid #eee; display: flex; flex-direction: column; align-items: flex-end; gap: 15px; }
        .action-buttons { display: flex; gap: 12px; }
        .va-sub-notification { font-size: 13px; color: #777; text-align: right; }

        /* Table Styles */
        .table-container { background: white; border-radius: 12px; padding: 25px; box-shadow: 0 4px 12px rgba(0,0,0,0.08); }
        .table-header { font-size: 20px; font-weight: 700; color: #1a1a1a; margin-bottom: 20px; }
        .tagihan-table { width: 100%; border-collapse: collapse; }
        .tagihan-table th, .tagihan-table td { padding: 15px; text-align: left; border-bottom: 1px solid #f0f0f0; }
        .tagihan-table th { background-color: #f8f9fa; font-size: 14px; color: #555; text-transform: uppercase; }
        .tagihan-table td { font-size: 15px; color: #333; }
        .tagihan-table tr:last-child td { border-bottom: none; }

        /* Common Component Styles */
        .status { padding: 6px 16px; border-radius: 20px; font-size: 13px; font-weight: 700; display: inline-block; text-transform: uppercase; }
        .status-merah { background-color: #FFE5E5; color: #C41C3B; }
        .status-oranye { background-color: #FFF3E0; color: #E65100; }
        .status-hijau { background-color: #E8F5E9; color: #1B5E20; }
        
        .btn { border: none; padding: 10px 20px; border-radius: 8px; cursor: pointer; font-weight: 700; font-size: 14px; transition: all 0.3s; }
        .btn-green { background-color: #4CAF50; color: white; }
        .btn-green:hover { background-color: #45a049; }
        .btn-blue { background-color: #2196F3; color: white; }
        .btn-blue:hover { background-color: #1976D2; }

        /* Empty State */
        .empty-state { text-align: center; padding: 80px 40px; background: white; border-radius: 12px; box-shadow: 0 4px 12px rgba(0,0,0,0.05); }
        .empty-state-icon { font-size: 50px; margin-bottom: 20px; }
        .empty-state-title { font-size: 22px; font-weight: 700; color: #333; margin-bottom: 8px; }
        .empty-state-text { font-size: 16px; color: #666; }

        /* Modal Styles */
        .modal-overlay { position: fixed; top: 0; left: 0; right: 0; bottom: 0; background-color: rgba(0, 0, 0, 0.6); display: flex; justify-content: center; align-items: center; z-index: 1000; opacity: 0; visibility: hidden; transition: all 0.3s ease; }
        .modal-overlay.active { opacity: 1; visibility: visible; }
        .modal-content { background-color: white; border-radius: 12px; width: 90%; max-width: 480px; box-shadow: 0 10px 30px rgba(0, 0, 0, 0.2); transform: scale(0.95); transition: transform 0.3s ease; }
        .modal-overlay.active .modal-content { transform: scale(1); }
        .modal-header { padding: 20px 25px; border-bottom: 1px solid #e0e0e0; }
        .modal-title { font-size: 20px; font-weight: 700; color: #333; }
        .modal-body { padding: 25px; }
        .modal-notification { font-size: 14px; padding: 15px; background-color: #e3f2fd; border-radius: 8px; color: #1d4b73; margin-top: 20px; }
        .modal-footer { padding: 20px 25px; border-top: 1px solid #e0e0e0; display: flex; justify-content: flex-end; gap: 12px; }
        .btn-secondary { background-color: #f1f1f1; color: #333; border: 1px solid #ddd; }
        .btn-secondary:hover { background-color: #e0e0e0; }

        /* Payment Method Selection Styles */
        .payment-method-section { margin-top: 25px; padding-top: 20px; border-top: 1px solid #eee; }
        .payment-method-label { font-size: 14px; font-weight: 700; color: #555; margin-bottom: 15px; text-transform: uppercase; letter-spacing: 0.5px; }
        .payment-method-selection { display: flex; gap: 15px; margin-bottom: 20px; flex-wrap: wrap; }
        .payment-method-btn { 
            flex: 1; 
            min-width: 180px;
            padding: 15px 20px; 
            border: 2px solid #ddd; 
            border-radius: 8px; 
            background-color: white; 
            cursor: pointer; 
            font-size: 15px; 
            font-weight: 600; 
            color: #333;
            transition: all 0.3s ease;
        }
        .payment-method-btn:hover { 
            border-color: #4CAF50;
            background-color: #f0f8f5;
        }
        .payment-method-btn:disabled { 
            border-color: #ccc; 
            background-color: #f5f5f5; 
            color: #999;
            cursor: not-allowed;
            opacity: 0.6;
        }
        .payment-method-btn:disabled::after {
            content: ' (Tidak Tersedia)';
        }
        .payment-method-btn.selected { 
            border-color: #4CAF50; 
            background-color: #4CAF50; 
            color: white;
        }
        .ringkasan-pembayaran { background-color: #f8f9fa; padding: 15px; border-radius: 8px; border: 1px solid #e0e0e0; display: none; margin-bottom: 15px; font-size: 14px; }
        .ringkasan-pembayaran.active { display: block; }
        .ringkasan-row { display: flex; justify-content: space-between; padding: 8px 0; border-bottom: 1px solid #e0e0e0; }
        .ringkasan-row:last-child { border-bottom: none; }
        .ringkasan-label { color: #666; font-weight: 600; }
        .ringkasan-value { color: #333; font-weight: 700; }
    </style>
</head>
<body>
    <aside class="sidebar">
        <div class="logo"><img src="pictures/logo umi.png" alt="Logo"></div>
        <div class="user-info">
            <div class="user-id">-</div>
            <div class="user-name">Mahasiswa</div>
            <div class="user-actions">
               <a href="index.php" onclick="logout();">Logout</a>
            </div>
        </div>
        <nav class="menu">
            <a href="dashboard_mahasiswa.php" class="menu-item"><span class="menu-icon">📊</span><span>Dashboard</span></a>
            <a href="mhs_tagihan.php" class="menu-item active"><span class="menu-icon">💳</span><span>Tagihan</span></a>
            <a href="mhs_riwayat_pembayaran.php" class="menu-item"><span class="menu-icon">🔄</span><span>Riwayat Pembayaran</span></a>
        </nav>
    </aside>

    <main class="main-content" id="main-content-area">
        <div class="page-header">
            <div>
                <span class="menu-dots">⋮</span>
                <span>Tagihan Pembayaran</span>
            </div>
            <?php
            if (isset($_SESSION['role']) && $_SESSION['role'] === 'mahasiswa') {
                $userId = isset($_SESSION['user_id']) ? $_SESSION['user_id'] : rand(1, 70);
                echo '<img src="https://api.dicebear.com/7.x/avataaars/svg?seed=' . $userId . '" alt="Avatar" class="user-avatar" onclick="openProfilModal()" title="Lihat Profil" id="headerAvatar">';
            }
            ?>
        </div>
        <div id="tagihan-container" class="tagihan-container">
            <div style="text-align: center; padding: 40px;">
                <p>Loading data tagihan...</p>
            </div>
        </div>
    </main>

    <script src="js/auth.js"></script>
    <script>
        // Format Rupiah
        function formatRupiah(angka) {
            return 'Rp ' + angka.toLocaleString('id-ID');
        }

        // Get auth token
        function getAuthToken() {
            return localStorage.getItem('auth_token');
        }

        // Fetch tagihan data from backend endpoint
        async function fetchTagihanData() {
            try {
                // Fetch dari mhs_tagihan_proses.php (PHP backend, bukan API)
                // Ini lebih reliable karena:
                // 1. Langsung ambil data dari $_SESSION['user_id']
                // 2. Validasi data mahasiswa dari database
                // 3. Auto-create BPP jika perlu
                // 4. Return JSON response yang konsisten
                const response = await fetch('mhs_tagihan_proses.php', {
                    method: 'GET',
                    credentials: 'include',
                    headers: {
                        'Content-Type': 'application/json'
                    }
                });

                if (!response.ok) {
                    // Jika 401, redirect ke login
                    if (response.status === 401) {
                        window.location.href = 'mhs_login.php';
                        return;
                    }
                    throw new Error(`HTTP error! status: ${response.status}`);
                }

                const data = await response.json();
                return data;

            } catch (error) {
                console.error('Error fetching tagihan:', error);
                return {
                    status: 'error',
                    message: error.message,
                    code: 'FETCH_ERROR'
                };
            }
        }

        // Render tagihan page
        function renderTagihanPage(data, userInfo) {
            const container = document.getElementById('tagihan-container');
            
            // Handle error from API
            if (data.status === 'error' || data.error) {
                const errorMessage = data.message || data.error || 'Terjadi kesalahan saat mengambil data tagihan';
                container.innerHTML = `
                    <div class="empty-state">
                        <div class="empty-state-icon">⚠️</div>
                        <h2 class="empty-state-title">Error</h2>
                        <p class="empty-state-text">${errorMessage}</p>
                    </div>
                `;
                return;
            }
            
            // Extract tagihan data from different response formats
            let tagihanList = [];
            if (data.data && Array.isArray(data.data.tagihan)) {
                tagihanList = data.data.tagihan;
            } else if (data.tagihan && Array.isArray(data.tagihan)) {
                tagihanList = data.tagihan;
            }
            
            // Handle "Tidak ada tagihan aktif"
            if (tagihanList.length === 0) {
                const message = data.data?.message || data.message || 'Tidak ada tagihan aktif';
                container.innerHTML = `
                    <div class="empty-state">
                        <div class="empty-state-icon">🎉</div>
                        <h2 class="empty-state-title">${message}</h2>
                        <p class="empty-state-text">Semua kewajiban pembayaran telah diselesaikan.</p>
                    </div>
                `;                // Hide cicilan reminder when no tagihan
                handleCicilanDisplay(data);                return;
            }
            
            // Render tagihan dari tabel tarif
            let html = '';
            
            // DEBUG: Log tagihan data
            console.log('Tagihan List:', tagihanList);
            
            tagihanList.forEach((tagihan, index) => {
                // DEBUG: Log each tagihan flags
                console.log(`Tagihan ${index}:`, {
                    jenis: tagihan.jenis_tagihan,
                    can_pay_lunas: tagihan.can_pay_lunas,
                    can_pay_cicilan: tagihan.can_pay_cicilan
                });
                
                // Get total from backend tagihan object
                const total = tagihan.jumlah_tagihan || 0;
                // Get program_studi from backend mahasiswa data
                const mahasiswaData = data.data && data.data.mahasiswa ? data.data.mahasiswa : {};
                const program_studi = mahasiswaData.nama_prodi || 'Program Studi Tidak Ditemukan';
                
                // HARDCODE: PROPOSAL dan SKRIPSI hanya boleh bayar lunas
                const jenisUpper = (tagihan.jenis_tagihan || '').toUpperCase();
                const isProposalOrSkripsi = (jenisUpper === 'PROPOSAL' || jenisUpper === 'SKRIPSI');
                const showCicilanButton = !isProposalOrSkripsi && tagihan.can_pay_cicilan === true;
                
                html += `
                    <div class="tagihan-card" id="tagihan-card-${index}">
                        <h3 class="tagihan-header">TAGIHAN ${
                            tagihan.jenis_tagihan === 'BPP' 
                                ? `BPP SEMESTER ${tagihan.semester}` 
                                : tagihan.jenis_tagihan.toUpperCase()
                        }</h3>
                        <div style="background-color: #e8f5e9; padding: 12px 16px; border-radius: 6px; margin-bottom: 15px; border-left: 4px solid #4caf50; font-size: 13px; color: #2e7d32;">
                            <strong>ℹ️ Informasi:</strong> Data tagihan diambil dari tabel tarif berdasarkan kewajiban pembayaran yang berlaku.
                        </div>
                        <div class="tagihan-row">
                            <span class="tagihan-label">Program Studi</span>
                            <span class="tagihan-value">${program_studi}</span>
                        </div>
                        <div class="tagihan-row">
                            <span class="tagihan-label">Tahun Akademik</span>
                            <span class="tagihan-value">${tagihan.tahun_akademik || '-'}</span>
                        </div>
                        ${tagihan.semester ? `
                        <div class="tagihan-row">
                            <span class="tagihan-label">Semester</span>
                            <span class="tagihan-value">${tagihan.semester}</span>
                        </div>
                        ` : ''}
                        <div class="tagihan-row">
                            <span class="tagihan-label">Total Tagihan</span>
                            <span class="tagihan-value">${formatRupiah(total)}</span>
                        </div>
                        <div class="tagihan-row">
                            <span class="tagihan-label">Status</span>
                            <span class="tagihan-value"><span class="status status-merah">${(tagihan.status_pembayaran || 'belum_bayar').replace(/_/g, ' ').toUpperCase()}</span></span>
                        </div>
                        
                        <div class="payment-method-section">
                            <div class="payment-method-label">Pilih Metode Pembayaran</div>
                            <div class="payment-method-selection">
                                <button type="button" class="payment-method-btn" data-tagihan_id="${tagihan.tagihan_id}" data-method="lunas" data-total="${total}" data-jenis="${tagihan.jenis_tagihan}" data-semester="${tagihan.semester || 0}">
                                    💳 Bayar Lunas
                                </button>
                                ${showCicilanButton ? `
                                <button type="button" class="payment-method-btn" data-tagihan_id="${tagihan.tagihan_id}" data-method="cicilan" data-total="${total}" data-jenis="${tagihan.jenis_tagihan}" data-semester="${tagihan.semester || 0}">
                                    📅 Bayar Cicilan
                                </button>
                                ` : ''}
                            </div>
                            
                            <div class="ringkasan-pembayaran" id="ringkasan-lunas-${index}">
                                <strong>Ringkasan Pembayaran</strong>
                                <div class="ringkasan-row">
                                    <span class="ringkasan-label">Metode</span>
                                    <span class="ringkasan-value">Lunas</span>
                                </div>
                                <div class="ringkasan-row">
                                    <span class="ringkasan-label">Total Bayar</span>
                                    <span class="ringkasan-value">${formatRupiah(total)}</span>
                                </div>
                            </div>
                            
                            <div class="ringkasan-pembayaran" id="ringkasan-cicilan-${index}">
                                <strong>Ringkasan Cicilan</strong>
                                <div class="ringkasan-row">
                                    <span class="ringkasan-label">Metode</span>
                                    <span class="ringkasan-value">Cicilan</span>
                                </div>
                                <div class="ringkasan-row">
                                    <span class="ringkasan-label">Jumlah Cicilan</span>
                                    <span class="ringkasan-value">2x</span>
                                </div>
                                <div class="ringkasan-row">
                                    <span class="ringkasan-label">Nominal / Cicilan</span>
                                    <span class="ringkasan-value">${formatRupiah(total / 2)}</span>
                                </div>
                                <div class="ringkasan-row">
                                    <span class="ringkasan-label">Total Tagihan</span>
                                    <span class="ringkasan-value">${formatRupiah(total)}</span>
                                </div>
                            </div>
                            
                            <button class="btn btn-green" id="lanjutkan-pembayaran-${index}" style="display: none;">Lanjutkan Pembayaran</button>
                            <div class="va-sub-notification">* Pembayaran akan menggunakan Virtual Account yang digenerate dari sistem.</div>
                        </div>
                    </div>
                `;
            });
            
            container.innerHTML = html;
            
            // Handle cicilan display based on backend flag (STRICT)
            handleCicilanDisplay(data);
            
            // Attach event listeners for payment buttons
            attachEventListeners(data);
        }

        // Attach event listeners
        function attachEventListeners(data) {
            const methodBtns = document.querySelectorAll('.payment-method-btn');
            const lanjutkanBtns = document.querySelectorAll('[id^="lanjutkan-pembayaran-"]');

            // Create VA immediately when payment method button clicked (SYNCHRONOUS)
            methodBtns.forEach(btn => {
                btn.addEventListener('click', async function(e) {
                    e.preventDefault();
                    
                    // Check if button is disabled
                    if (this.disabled) {
                        alert('Metode pembayaran ini tidak tersedia. Anda sudah memulai cicilan untuk tagihan ini. Silakan selesaikan cicilan terlebih dahulu atau pilih "Bayar Cicilan".');
                        return;
                    }
                    
                    // Remove selected from all buttons in the same card
                    const card = this.closest('.tagihan-card');
                    const cardBtns = card.querySelectorAll('.payment-method-btn');
                    cardBtns.forEach(b => b.classList.remove('selected'));
                    
                    this.classList.add('selected');
                    
                    const cardIndex = Array.from(document.querySelectorAll('.tagihan-card')).indexOf(card);
                    const tagihan_id = this.dataset.tagihan_id;
                    const method = this.dataset.method;
                    const ringkasanLunas = document.getElementById(`ringkasan-lunas-${cardIndex}`);
                    const ringkasanCicilan = document.getElementById(`ringkasan-cicilan-${cardIndex}`);
                    const lanjutkanBtn = document.getElementById(`lanjutkan-pembayaran-${cardIndex}`);
                    
                    // Update UI display
                    if (method === 'lunas') {
                        ringkasanLunas.classList.add('active');
                        ringkasanCicilan.classList.remove('active');
                    } else if (method === 'cicilan') {
                        ringkasanCicilan.classList.add('active');
                        ringkasanLunas.classList.remove('active');
                    }
                    
                    // Disable button during creation
                    lanjutkanBtn.disabled = true;
                    lanjutkanBtn.textContent = '⏳ Membuat Virtual Account...';
                    lanjutkanBtn.style.display = 'block';
                    
                    // CREATE VA IMMEDIATELY (SYNCHRONOUS - NO REDIRECT)
                    try {
                        const response = await fetch('/projek_plbs/api/index.php/api/mahasiswa/tagihan/' + tagihan_id + '/buat-va', {
                            method: 'POST',
                            credentials: 'include',
                            headers: {
                                'Content-Type': 'application/json',
                                'Authorization': 'Bearer ' + getAuthToken()
                            },
                            body: JSON.stringify({
                                metode_pembayaran: method
                            })
                        });
                        
                        const result = await response.json();
                        
                        if (!response.ok || result.status !== 'success') {
                            throw new Error(result.message || 'Gagal membuat Virtual Account');
                        }
                        
                        // VA created successfully - enable button
                        lanjutkanBtn.disabled = false;
                        lanjutkanBtn.textContent = '✅ Lanjutkan Pembayaran';
                        
                        // Store VA data for redirect
                        window.vaCreated = result.data;
                        console.log('VA berhasil dibuat:', result.data);
                        
                    } catch (error) {
                        console.error('Error creating VA:', error);
                        lanjutkanBtn.disabled = false;
                        lanjutkanBtn.textContent = '❌ Ulang - Gagal Membuat VA';
                        alert('Gagal membuat Virtual Account: ' + error.message);
                        
                        this.classList.remove('selected');
                        ringkasanLunas.classList.remove('active');
                        ringkasanCicilan.classList.remove('active');
                        lanjutkanBtn.style.display = 'none';
                    }
                });
            });

            // Redirect to detail page AFTER VA created
            lanjutkanBtns.forEach(btn => {
                btn.addEventListener('click', function() {
                    const card = this.closest('.tagihan-card');
                    const selectedBtn = card.querySelector('.payment-method-btn.selected');
                    
                    if (!selectedBtn) {
                        alert('Silakan pilih metode pembayaran terlebih dahulu.');
                        return;
                    }

                    const tagihan_id = selectedBtn.dataset.tagihan_id;
                    const method = selectedBtn.dataset.method;
                    
                    const params = new URLSearchParams({
                        tagihan_id: tagihan_id,
                        method: method
                    });

                    window.location.href = `mhs_detail_pembayaran.php?${params.toString()}`;
                });
            });
        }
        
        // Handle cicilan display with STRICT backend flag checking
        function handleCicilanDisplay(data) {
            // Extract has_active_installment flag from backend
            const hasActiveInstallment = data.info && data.info.has_active_installment === true;
            const cicilanList = data.cicilan || [];
            
            // STRICT RULE: Only display cicilan section if flag === true
            if (hasActiveInstallment === true) {
                // Backend says there's active cicilan, display it
                if (cicilanList.length > 0) {
                    let html = '<div class="table-container"><h3 class="table-header">Cicilan Aktif</h3>';
                    html += '<table class="tagihan-table"><thead><tr><th>Jenis</th><th>Cicilan Ke</th><th>Nominal</th><th>Jatuh Tempo</th><th>Status</th><th>Aksi</th></tr></thead><tbody>';
                    
                    cicilanList.forEach(cicilan => {
                        html += `
                            <tr>
                                <td>${cicilan.jenis_tagihan}</td>
                                <td>${cicilan.cicilan_ke}</td>
                                <td>${formatRupiah(cicilan.nominal_cicilan)}</td>
                                <td>${new Date(cicilan.tanggal_jatuh_tempo).toLocaleDateString('id-ID')}</td>
                                <td><span class="status status-merah">${cicilan.status_pembayaran.replace(/_/g, ' ').toUpperCase()}</span></td>
                                <td><button class="btn btn-blue" onclick="bayarCicilan(${cicilan.cicilan_id})">Bayar</button></td>
                            </tr>
                        `;
                    });
                    
                    html += '</tbody></table></div>';
                    document.getElementById('tagihan-container').innerHTML += html;
                }
            } else {
                // MUST HIDE: Backend says no active cicilan (flag === false or undefined)
                // Do not display any cicilan section
                console.log('No active installments - cicilan section hidden');
            }
        }
        
        // Function untuk bayar cicilan
        function bayarCicilan(cicilanId) {
            const params = new URLSearchParams({
                cicilan_id: cicilanId,
                method: 'cicilan'
            });
            window.location.href = `mhs_detail_pembayaran.php?${params.toString()}`;
        }

        // Initialize page
        document.addEventListener('DOMContentLoaded', async function() {
            requireAuth('mahasiswa');
            
            const user = getCurrentUser();
            
            // Update sidebar
            document.querySelector('.user-id').textContent = user.nim || user.user_id || '-';
            document.querySelector('.user-name').textContent = user.nama_lengkap || 'Mahasiswa';

            // Fetch and render tagihan
            const data = await fetchTagihanData();
            renderTagihanPage(data, user);
        });
    </script>
</body>
</html>



    <?php include 'components/profil_modal.php'; ?>
