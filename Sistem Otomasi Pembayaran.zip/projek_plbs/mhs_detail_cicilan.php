<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header('Location: mhs_login.php');
    exit;
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Detail Pembayaran Cicilan</title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; background-color: #f5f5f5; display: flex; justify-content: center; align-items: center; min-height: 100vh; padding: 20px; }
        .container { width: 100%; max-width: 750px; background: white; border-radius: 12px; padding: 30px 40px; box-shadow: 0 6px 20px rgba(0,0,0,0.1); }
        .page-header { text-align: center; margin-bottom: 25px; padding-bottom: 15px; border-bottom: 1px solid #eee; }
        .page-title { font-size: 24px; font-weight: 700; color: #333; }
        .details-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 15px; margin-bottom: 25px; }
        .detail-item { background-color: #f8f9fa; padding: 15px; border-radius: 8px; }
        .detail-label { font-size: 14px; color: #666; margin-bottom: 5px; }
        .detail-value { font-size: 17px; font-weight: 600; color: #333; }
        .detail-value.total { color: #0056b3; }
        .detail-value.paid { color: #218838; }
        .detail-value.remaining { color: #c82333; }
        .va-item { grid-column: 1 / -1; }
        .va-value { font-family: 'Courier New', Courier, monospace; font-size: 20px; color: #0056b3; word-break: break-all; }
        .status-section { text-align: center; margin: 25px 0; }
        .status-label { font-size: 14px; color: #666; margin-bottom: 8px; }
        .status { padding: 8px 25px; border-radius: 20px; font-size: 16px; font-weight: 700; display: inline-block; text-transform: uppercase; }
        .status-berjalan { background-color: #fff3e0; color: #e65100; }
        .status-lunas { background-color: #e8f5e9; color: #1b5e20; }
        .action-area { display: flex; justify-content: center; gap: 15px; margin-top: 30px; }
        .btn { border: none; padding: 12px 25px; border-radius: 8px; cursor: pointer; font-weight: 700; font-size: 15px; text-decoration: none; display: inline-flex; align-items: center; gap: 8px; }
        .btn-primary { background-color: #28a745; color: white; }
        .btn-secondary { background-color: #6c757d; color: white; }
    </style>
</head>
<body>
    <div class="container" id="payment-container" style="display: none;">
        <header class="page-header"><h1 class="page-title">DETAIL PEMBAYARAN CICILAN</h1></header>

        <div class.details-grid">
            <div class="detail-item"><div class="detail-label">Jenis Pembayaran</div><div class="detail-value" id="jenis-pembayaran">-</div></div>
            <div class="detail-item"><div class="detail-label">Nominal / Cicilan</div><div class="detail-value" id="nominal-cicilan">-</div></div>
            <div class="detail-item"><div class="detail-label">Total Tagihan</div><div class="detail-value total" id="total-tagihan">-</div></div>
            <div class="detail-item"><div class="detail-label">Sudah Dibayar</div><div class="detail-value paid" id="sudah-dibayar">-</div></div>
            <div class="detail-item"><div class="detail-label">Sisa Tagihan</div><div class="detail-value remaining" id="sisa-tagihan">-</div></div>
            <div class="detail-item va-item">
                <div class="detail-label">Virtual Account</div>
                <div class="va-value" id="virtual-account">-</div>
            </div>
        </div>

        <div class="status-section" id="status-display"></div>

        <div class="action-area" id="action-area"></div>
    </div>

    <script>
        document.addEventListener('DOMContentLoaded', function() {
            const params = new URLSearchParams(window.location.search);
            const va = params.get('va');

            if (!va) {
                alert('Virtual Account tidak valid. Silakan ulangi.');
                window.location.href = 'mhs_tagihan.php';
                return;
            }

            const payments = JSON.parse(localStorage.getItem('payments')) || {};
            const record = payments[va];

            if (!record) {
                alert('Data pembayaran tidak ditemukan. Silakan ulangi.');
                window.location.href = 'mhs_tagihan.php';
                return;
            }
            
            const formatRupiah = (angka) => 'Rp ' + (angka || 0).toLocaleString('id-ID');
            const nominalPerCicilan = record.total / record.installments;
            const sisaTagihan = record.total - record.amount_paid;
            
            // --- 1. Populate UI ---
            document.getElementById('jenis-pembayaran').textContent = `${record.type} (${record.semester})`;
            document.getElementById('total-tagihan').textContent = formatRupiah(record.total);
            document.getElementById('sudah-dibayar').textContent = formatRupiah(record.amount_paid);
            document.getElementById('sisa-tagihan').textContent = formatRupiah(sisaTagihan);
            document.getElementById('nominal-cicilan').textContent = formatRupiah(nominalPerCicilan);
            document.getElementById('virtual-account').textContent = record.va;

            const statusDisplay = document.getElementById('status-display');
            const actionArea = document.getElementById('action-area');
            
            // --- 2. Determine Status and Actions ---
            if (sisaTagihan <= 0) {
                // LUNAS
                record.status = 'LUNAS';
                statusDisplay.innerHTML = `<div class="status-label">Status</div><div class="status status-lunas">LUNAS</div>`;
                actionArea.innerHTML = `<a href="mhs_tagihan.php" class="btn btn-secondary">Kembali ke Tagihan</a>`;
            } else {
                // CICILAN BERJALAN
                record.status = 'CICILAN BERJALAN';
                const nextInstallment = record.installments_paid + 1;
                statusDisplay.innerHTML = `<div class="status-label">Status</div><div class="status status-berjalan">Cicilan Berjalan</div>`;
                
                const uploadParams = new URLSearchParams({
                    va: record.va,
                    type: record.type,
                    total: record.total,
                    semester: record.semester,
                    installment: nextInstallment,
                    installment_amount: nominalPerCicilan
                });
                
                actionArea.innerHTML = `
                    <a href="mhs_tagihan.php" class="btn btn-secondary">Kembali ke Tagihan</a>
                    <a href="mhs_upload_bukti.php?${uploadParams.toString()}" class="btn btn-primary">
                        📤 Upload Bukti Pembayaran Cicilan ${nextInstallment}
                    </a>
                `;
            }

            // --- 3. Save updated status to localStorage ---
            payments[va] = record;
            localStorage.setItem('payments', JSON.stringify(payments));

            // Show the page content
            document.getElementById('payment-container').style.display = 'block';
        });
    </script>
</body>
</html>


