<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header('Location: mhs_login.php');
    exit;
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Detail Pembayaran</title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; background-color: #f5f5f5; display: flex; justify-content: center; align-items: center; min-height: 100vh; padding: 20px; }
        .container { width: 100%; max-width: 700px; background: white; border-radius: 12px; padding: 30px 40px; box-shadow: 0 6px 20px rgba(0,0,0,0.1); border: 1px solid #e0e0e0; }
        .page-header { text-align: center; margin-bottom: 25px; padding-bottom: 15px; border-bottom: 1px solid #eee; }
        .page-title { font-size: 24px; font-weight: 700; color: #333; }
        .details-grid { display: grid; gap: 15px 20px; margin-bottom: 25px; }
        .detail-item { background-color: #f8f9fa; padding: 15px; border-radius: 8px; border: 1px solid #e9ecef; }
        .detail-label { font-size: 14px; color: #666; margin-bottom: 5px; }
        .detail-value { font-size: 16px; font-weight: 600; color: #333; }
        .detail-value.highlight { font-family: 'Courier New', Courier, monospace; font-size: 20px; color: #0056b3; word-break: break-all; }
        .status-section { text-align: center; margin: 25px 0; }
        .status-label { font-size: 14px; color: #666; margin-bottom: 8px; }
        .status { padding: 8px 25px; border-radius: 20px; font-size: 16px; font-weight: 700; display: inline-block; text-transform: uppercase; }
        .status-menunggu { background-color: #e3f2fd; color: #1565c0; border: 1px solid #1565c0; }
        .status-verifikasi { background-color: #fff3e0; color: #e65100; border: 1px solid #e65100; }
        .instructions { padding: 20px; background-color: #f0f4f8; border-radius: 8px; color: #334e68; font-size: 15px; line-height: 1.6; margin-bottom: 30px; }
        .instructions h3 { margin-bottom: 10px; color: #0d47a1; }
        .action-area { display: flex; justify-content: center; gap: 15px; margin-top: 20px; }
        .btn { border: none; padding: 12px 25px; border-radius: 8px; cursor: pointer; font-weight: 700; font-size: 15px; transition: all 0.3s; text-decoration: none; display: inline-flex; align-items: center; gap: 8px; }
        .btn-primary { background-color: #28a745; color: white; box-shadow: 0 4px 10px rgba(40, 167, 69, 0.2); }
        .btn-primary:hover { background-color: #218838; transform: translateY(-2px); }
        .btn-secondary { background-color: #6c757d; color: white; }
        .btn-secondary:hover { background-color: #5a6268; }
    </style>
</head>
<body>
    <div class="container">
        <header class="page-header"><h1 class="page-title">DETAIL PEMBAYARAN</h1></header>

        <div class="details-grid">
            <div class="detail-item"><div class="detail-label">Jenis Pembayaran</div><div class="detail-value" id="jenis-pembayaran">-</div></div>
            <div class="detail-item" id="semester-item" style="display: none;"><div class="detail-label">Tahun Akademik</div><div class="detail-value" id="tahun-akademik">-</div></div>
            <div class="detail-item"><div class="detail-label">Total Tagihan</div><div class="detail-value" id="total-tagihan">-</div></div>
        </div>
        
        <div class="detail-item">
             <div class="detail-label">Virtual Account</div>
             <div class="detail-value highlight" id="virtual-account">-</div>
        </div>

        <div class="status-section" id="status-display">
            <div class="status-label">Status</div>
            <div class="status status-menunggu">Menunggu Pembayaran</div>
        </div>

        <div class="instructions">
            <h3>Instruksi Pembayaran</h3>
            <p>Silakan lakukan pembayaran ke rekening resmi universitas. <strong>Gunakan nomor Virtual Account di atas</strong> pada kolom berita atau keterangan transfer.</p>
        </div>

        <div class="action-area">
            <a href="mhs_tagihan.php" class="btn btn-secondary">Kembali ke Tagihan</a>
            <a href="#" id="upload-btn" class="btn btn-primary">📤 Upload Bukti Pembayaran</a>
        </div>
    </div>

    <script src="js/auth.js"></script>
    <script>
        // Format Rupiah
        function formatRupiah(angka) {
            return 'Rp ' + parseInt(angka).toLocaleString('id-ID');
        }

        // Fetch tagihan details from backend
        async function fetchTagihanDetail() {
            try {
                const response = await fetch('mhs_tagihan_proses.php', {
                    method: 'GET',
                    credentials: 'include',
                    headers: {
                        'Content-Type': 'application/json'
                    }
                });

                if (!response.ok) {
                    if (response.status === 401) {
                        window.location.href = 'mhs_login.php';
                        return null;
                    }
                    throw new Error(`HTTP error! status: ${response.status}`);
                }

                return await response.json();
            } catch (error) {
                console.error('Error fetching tagihan detail:', error);
                return null;
            }
        }

        document.addEventListener('DOMContentLoaded', async function() {
            requireAuth('mahasiswa');
            
            const params = new URLSearchParams(window.location.search);
            const tagihan_id = params.get('tagihan_id');
            const method = params.get('method'); // 'lunas' atau 'cicilan'

            // VALIDASI: Jika tagihan_id tidak ada, tampilkan error
            if (!tagihan_id) {
                document.querySelector('.container').innerHTML = `
                    <div style="text-align: center; padding: 40px;">
                        <h2>Error</h2>
                        <p>ID Tagihan tidak valid</p>
                        <a href="mhs_tagihan.php" class="btn btn-secondary">Kembali ke Tagihan</a>
                    </div>
                `;
                return;
            }

            // VALIDASI: Jika method tidak ada, tampilkan error
            if (!method || !['lunas', 'cicilan'].includes(method)) {
                document.querySelector('.container').innerHTML = `
                    <div style="text-align: center; padding: 40px;">
                        <h2>Error</h2>
                        <p>Metode pembayaran tidak valid</p>
                        <a href="mhs_tagihan.php" class="btn btn-secondary">Kembali ke Tagihan</a>
                    </div>
                `;
                return;
            }

            // FETCH: Ambil data tagihan dari backend
            const backendData = await fetchTagihanDetail();
            
            if (!backendData || backendData.status !== 'success') {
                document.querySelector('.container').innerHTML = `
                    <div style="text-align: center; padding: 40px;">
                        <h2>Error</h2>
                        <p>Gagal mengambil data tagihan</p>
                        <a href="mhs_tagihan.php" class="btn btn-secondary">Kembali ke Tagihan</a>
                    </div>
                `;
                return;
            }

            // PARSE: Ekstrak data tagihan dari response
            const tagihanList = backendData.data && backendData.data.tagihan ? backendData.data.tagihan : [];
            const tagihan = tagihanList.find(t => t.tagihan_id == tagihan_id);

            if (!tagihan) {
                document.querySelector('.container').innerHTML = `
                    <div style="text-align: center; padding: 40px;">
                        <h2>Error</h2>
                        <p>Tagihan tidak ditemukan</p>
                        <a href="mhs_tagihan.php" class="btn btn-secondary">Kembali ke Tagihan</a>
                    </div>
                `;
                return;
            }

            // DISPLAY: Tampilkan detail dari backend data (BUKAN HARDCODE)
            const jenisPembayaran = tagihan.jenis_tagihan === 'BPP' 
                ? `BPP SEMESTER ${tagihan.semester}`
                : tagihan.jenis_tagihan.toUpperCase();
            
            const totalTagihan = tagihan.jumlah_tagihan;
            const tahunAkademik = tagihan.tahun_akademik;
            
            // VIRTUAL ACCOUNT: Ambil dari backend (VA sudah dibuat saat klik tombol)
            let vaDisplay = '-';
            let vaNumberForUpload = '';
            let nominalPembayaran = totalTagihan;
            let vaStatus = 'belum_dibuat';
            
            if (tagihan.virtual_account && tagihan.virtual_account.nomor_va) {
                // VA sudah dibuat (dari klik tombol di halaman sebelumnya)
                vaDisplay = tagihan.virtual_account.nomor_va;
                vaNumberForUpload = tagihan.virtual_account.nomor_va;
                nominalPembayaran = tagihan.virtual_account.jumlah_va || totalTagihan;
                vaStatus = tagihan.virtual_account.status_va || 'aktif';
                
                console.log('VA sudah dibuat dari halaman sebelumnya:', vaDisplay);
            } else {
                // Tidak seharusnya ada status "akan dibuat" 
                // Jika sampai sini, berarti terjadi error di halaman sebelumnya
                vaDisplay = 'ERROR: Virtual Account tidak berhasil dibuat. Silakan coba lagi.';
                vaStatus = 'error';
            }

            // UPDATE DOM dengan data backend
            document.getElementById('jenis-pembayaran').textContent = jenisPembayaran;
            document.getElementById('total-tagihan').textContent = formatRupiah(nominalPembayaran);
            document.getElementById('virtual-account').textContent = vaDisplay;
            document.getElementById('tahun-akademik').textContent = tahunAkademik;
            document.getElementById('semester-item').style.display = 'block';

            // UPLOAD BUTTON: Aktifkan hanya jika VA berhasil dibuat
            const uploadBtn = document.getElementById('upload-btn');
            if (vaStatus === 'aktif' && vaNumberForUpload) {
                const uploadParams = new URLSearchParams({
                    tagihan_id: tagihan_id,
                    va_number: vaNumberForUpload,
                    jenis_pembayaran: tagihan.jenis_tagihan,
                    total: nominalPembayaran,
                    method: method
                });
                uploadBtn.href = `mhs_upload_bukti.php?${uploadParams.toString()}`;
                uploadBtn.disabled = false;
                uploadBtn.style.opacity = '1';
            } else {
                uploadBtn.disabled = true;
                uploadBtn.style.opacity = '0.5';
                uploadBtn.textContent = '❌ Virtual Account Gagal Dibuat';
            }
        });
    </script>
</body>
</html>


