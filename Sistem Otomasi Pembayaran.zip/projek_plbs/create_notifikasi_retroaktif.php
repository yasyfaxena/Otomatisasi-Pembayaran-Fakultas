<?php
/**
 * SCRIPT: Buat Notifikasi Retroaktif untuk Cicilan yang Sudah Divalidasi
 * Jalankan: php create_notifikasi_retroaktif.php
 */

require_once __DIR__ . '/api/config/database.php';
require_once __DIR__ . '/api/helpers/notification_helper.php';

try {
    $database = new Database();
    $conn = $database->connect();
    
    echo "=== BUAT NOTIFIKASI RETROAKTIF ===\n\n";
    
    // Ambil semua pembayaran cicilan yang sudah divalidasi tapi belum punya notifikasi
    $query = "SELECT DISTINCT 
                p.mahasiswa_id, 
                t.semester, 
                t.tahun_akademik,
                m.nim,
                u.nama_lengkap
              FROM pembayaran p
              JOIN tagihan t ON p.tagihan_id = t.tagihan_id
              JOIN virtual_account va ON p.va_id = va.va_id
              JOIN mahasiswa m ON p.mahasiswa_id = m.mahasiswa_id
              JOIN users u ON m.user_id = u.user_id
              WHERE va.metode_pembayaran = 'cicilan' 
                AND p.status_validasi = 'valid'
                AND t.status_pembayaran = 'cicilan_berjalan'
                AND NOT EXISTS (
                    SELECT 1 FROM notifikasi n 
                    WHERE n.mahasiswa_id = p.mahasiswa_id 
                    AND n.judul LIKE '%Cicilan%'
                    AND n.pesan LIKE CONCAT('%Semester ', t.semester, '%')
                )";
    
    $stmt = $conn->query($query);
    $cicilan_list = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    if (count($cicilan_list) == 0) {
        echo "✓ Tidak ada cicilan yang perlu dibuatkan notifikasi.\n";
        echo "  Semua notifikasi sudah ada atau tidak ada cicilan yang divalidasi.\n\n";
    } else {
        echo "Ditemukan " . count($cicilan_list) . " cicilan yang perlu dibuatkan notifikasi:\n\n";
        
        $success = 0;
        $failed = 0;
        
        foreach ($cicilan_list as $cicilan) {
            echo "- Mahasiswa: {$cicilan['nama_lengkap']} (NIM: {$cicilan['nim']})\n";
            echo "  Semester: {$cicilan['semester']}, TA: {$cicilan['tahun_akademik']}\n";
            
            $result = createCicilanNotification(
                $conn, 
                $cicilan['mahasiswa_id'], 
                $cicilan['semester'], 
                $cicilan['tahun_akademik']
            );
            
            if ($result) {
                echo "  ✓ Notifikasi berhasil dibuat\n\n";
                $success++;
            } else {
                echo "  ✗ Gagal membuat notifikasi\n\n";
                $failed++;
            }
        }
        
        echo "=== HASIL ===\n";
        echo "Berhasil: $success\n";
        echo "Gagal: $failed\n";
        echo "Total: " . count($cicilan_list) . "\n\n";
    }
    
    // Cek total notifikasi cicilan
    $stmt = $conn->query("SELECT COUNT(*) as total FROM notifikasi WHERE judul LIKE '%Cicilan%'");
    $total = $stmt->fetch(PDO::FETCH_ASSOC);
    echo "Total notifikasi cicilan di database: {$total['total']}\n\n";
    
    echo "=== SELESAI ===\n";
    
} catch (Exception $e) {
    echo "ERROR: " . $e->getMessage() . "\n";
    echo "Stack trace:\n" . $e->getTraceAsString() . "\n";
}
