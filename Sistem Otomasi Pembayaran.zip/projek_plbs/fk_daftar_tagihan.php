<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header('Location: login_admin_fakultas.php');
    exit;
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tagihan Validasi - Tabel</title>
    <script src="va_system_module.js"></script>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.13.1/font/bootstrap-icons.min.css">
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }

        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: #f5f5f5;
            display: flex;
        }

        .sidebar {
            width: 260px;
            background-color: #1a1a1a;
            color: white;
            height: 100vh;
            position: fixed;
            left: 0;
            top: 0;
        }

        .logo {
            padding: 20px;
            text-align: center;
            border-bottom: 1px solid #333;
        }

        .logo img { width: 80px; height: auto; }

        .user-info {
            padding: 30px 20px;
            text-align: center;
            border-bottom: 1px solid #333;
        }

        .user-id { font-size: 14px; margin-bottom: 8px; color: #999; }
        .user-name { font-size: 16px; font-weight: 600; }

        .user-actions {
            display: flex;
            gap: 8px;
            justify-content: center;
            margin-top: 12px;
        }

        .user-actions a {
            padding: 8px 12px;
            background: #dc3545;
            color: white;
            text-decoration: none;
            border-radius: 5px;
            font-size: 12px;
            transition: background 0.3s;
        }

        .user-actions a:hover {
            background: #c82333;
        }

        .menu { padding: 20px 0; }

        .menu-item {
            padding: 15px 20px;
            cursor: pointer;
            display: flex;
            align-items: center;
            gap: 12px;
            transition: background-color 0.3s;
        }

        .menu-item:hover { background-color: #333; }
        .menu-item.active { background-color: #4CAF50; }

        .menu-icon {
            width: 24px; height: 24px;
            display: flex; align-items: center; justify-content: center;
        }
        .menu a {
            text-decoration: none;
            color: inherit;
        }


        .main-content { margin-left: 260px; flex: 1; padding: 20px 40px; }

        .header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 30px;
            background: white;
            padding: 15px 25px;
            border-radius: 8px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
        }

        .header-title {
            font-size: 20px;
            color: #666;
            display: flex;
            align-items: center;
            gap: 15px;
        }

        .menu-dots { font-size: 24px; cursor: pointer; color: #999; }


        .section {
            background: white;
            border-radius: 8px;
            padding: 30px;
            margin-bottom: 30px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
        }

        .section-title {
            font-size: 22px;
            margin-bottom: 25px;
            color: #333;
            font-weight: 600;
            border-bottom: 2px solid #4169E1;
            padding-bottom: 10px;
        }

        .table-container {
            overflow-x: auto;
            margin-bottom: 20px;
            border: 1px solid #e9ecef;
            border-radius: 8px;
        }

        .bills-table { width: 100%; border-collapse: collapse; }

        .bills-table th {
            background-color: #f8f9fa;
            color: #333;
            font-weight: 600;
            text-align: left;
            padding: 15px 12px;
            border-bottom: 2px solid #dee2e6;
            font-size: 14px;
            white-space: nowrap;
        }

        .bills-table td {
            padding: 15px 12px;
            border-bottom: 1px solid #e9ecef;
            vertical-align: middle;
        }

        .bills-table tbody tr:last-child td { border-bottom: none; }
        .bills-table tbody tr:hover { background-color: #f8f9fa; }

        .data-cell { font-size: 14px; color: #333; font-weight: 500; }

        .status-badge {
            display: inline-block;
            padding: 6px 12px;
            border-radius: 20px;
            font-size: 12px;
            font-weight: 600;
            min-width: 100px;
            text-align: center;
            white-space: nowrap;
        }

        .status-lunas { background-color: #d4edda; color: #155724; border: 1px solid #c3e6cb; }

        .action-cell { min-width: 120px; }

        .action-buttons {
            display: flex;
            gap: 6px;
            flex-wrap: nowrap;
            align-items: center;
        }

        .action-btn {
            padding: 6px 10px;
            border: none;
            border-radius: 4px;
            font-size: 12px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 4px;
            white-space: nowrap;
            min-width: 70px;
            height: 32px;
            flex: 1;
        }

        .btn-detail { background-color: #007bff; color: white; }
        .btn-detail:hover { background-color: #0056b3; transform: translateY(-2px); box-shadow: 0 4px 8px rgba(0, 123, 255, 0.3); }

        .btn-print { background-color: #17a2b8; color: white; }
        .btn-print:hover { background-color: #138496; transform: translateY(-2px); box-shadow: 0 4px 8px rgba(23, 162, 184, 0.3); }

        .filter-section {
            display: flex;
            gap: 15px;
            margin-bottom: 25px;
            flex-wrap: wrap;
            align-items: center;
            background-color: #f8f9fa;
            padding: 15px;
            border-radius: 6px;
        }

        .filter-group { display: flex; flex-direction: column; min-width: 180px; }
        .filter-label { font-size: 13px; font-weight: 600; margin-bottom: 5px; color: #495057; }

        .filter-select, .filter-input {
            padding: 8px 12px;
            border: 1px solid #ced4da;
            border-radius: 4px;
            font-size: 14px;
            background-color: white;
        }

        .filter-buttons { display: flex; gap: 10px; align-self: flex-end; margin-top: 10px; }

        .pagination-container {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-top: 30px;
            padding-top: 20px;
            border-top: 1px solid #e9ecef;
        }

        .pagination-info { font-size: 14px; color: #6c757d; }

        .pagination-controls { display: flex; gap: 10px; align-items: center; }

        .page-btn {
            padding: 8px 16px;
            background-color: white;
            border: 1px solid #dee2e6;
            border-radius: 4px;
            cursor: pointer;
            font-size: 14px;
            font-weight: 600;
            display: flex;
            align-items: center;
            gap: 6px;
            transition: all 0.3s;
        }

        .page-btn:hover:not(:disabled) { background-color: #007bff; color: white; border-color: #007bff; }
        .page-btn:disabled { opacity: 0.5; cursor: not-allowed; }

        .page-numbers { display: flex; gap: 5px; }

        .page-number {
            padding: 8px 12px;
            background-color: white;
            border: 1px solid #dee2e6;
            border-radius: 4px;
            cursor: pointer;
            font-size: 14px;
            min-width: 40px;
            text-align: center;
        }

        .page-number.active { background-color: #007bff; color: white; border-color: #007bff; }
        .page-number:hover:not(.active) { background-color: #e9ecef; }

        .summary-stats {
            display: flex;
            gap: 20px;
            margin-bottom: 25px;
            flex-wrap: wrap;
        }

        .stat-card {
            flex: 1;
            min-width: 200px;
            background: white;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
        }

        .stat-title { font-size: 14px; color: #6c757d; margin-bottom: 10px; }
        .stat-value { font-size: 24px; font-weight: 700; color: #333; }

        .stat-total { border-left: 4px solid #007bff; }
        .stat-lunas { border-left: 4px solid #28a745; }
        .stat-tertunggak { border-left: 4px solid #dc3545; }

        .semester-badge {
            display: inline-block;
            padding: 4px 10px;
            background-color: #007bff;
            color: white;
            border-radius: 12px;
            font-size: 11px;
            font-weight: 600;
            margin-right: 5px;
        }

        .detail-modal {
            display: none;
            position: fixed;
            z-index: 1001;
            left: 0; top: 0;
            width: 100%; height: 100%;
            background-color: rgba(0,0,0,0.5);
            animation: fadeIn 0.3s ease-out;
        }

        @keyframes fadeIn { from { opacity: 0; } to { opacity: 1; } }

        .detail-modal-content {
            background-color: white;
            margin: 30px auto;
            width: 95%;
            max-width: 900px;
            border-radius: 12px;
            box-shadow: 0 5px 20px rgba(0,0,0,0.15);
            overflow: hidden;
            animation: slideIn 0.4s ease-out;
            max-height: 85vh;
            display: flex;
            flex-direction: column;
        }

        @keyframes slideIn { from { transform: translateY(-30px); opacity: 0; } to { transform: translateY(0); opacity: 1; } }

        .detail-modal-header {
            background: #f8f9fa;
            color: #333;
            padding: 20px 25px;
            border-bottom: 1px solid #e9ecef;
            display: flex;
            justify-content: space-between;
            align-items: center;
             position: relative;
        }
       
        .detail-modal-title { 
            font-size: 18px; 
            font-weight: 600; 
            display: flex; 
            align-items: center; 
            gap: 10px; 
            position: absolute;
            left: 50%;
            transform: translateX(-50%);
            text-align: center;
        }

        .close-detail-modal {
            color: #6c757d;
            font-size: 28px;
            font-weight: bold;
            cursor: pointer;
            width: 36px; height: 36px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            transition: all 0.3s;
        }

        .close-detail-modal:hover { background: #e9ecef; color: #333; }

        .detail-modal-body { padding: 25px; flex: 1; overflow-y: auto; }

        .student-summary {
            background: #f8f9fa;
            border-radius: 8px;
            padding: 20px;
            margin-bottom: 20px;
        }

        .summary-row {
            display: flex;
            gap: 30px;
            margin-bottom: 15px;
        }

        .summary-item {
            flex: 1;
        }

        .summary-label {
            font-size: 12px;
            color: #666;
            margin-bottom: 4px;
        }

        .summary-value {
            font-size: 16px;
            font-weight: 600;
            color: #333;
        }

        .payment-history-table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }

        .payment-history-table th {
            background-color: #e9ecef;
            color: #333;
            font-weight: 600;
            text-align: left;
            padding: 12px 10px;
            border-bottom: 2px solid #dee2e6;
            font-size: 13px;
        }

        .payment-history-table td {
            padding: 12px 10px;
            border-bottom: 1px solid #e9ecef;
            font-size: 13px;
        }

        .total-row {
            background-color: #f8f9fa;
            font-weight: 600;
        }

        .detail-modal-footer {
            padding: 20px 25px;
            background-color: #f8f9fa;
            border-top: 1px solid #e9ecef;
            display: flex;
            justify-content: flex-end;
            gap: 10px;
        }

        .modal-btn {
            padding: 10px 20px;
            border: none;
            border-radius: 6px;
            font-size: 14px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 8px;
            min-width: 140px;
        }

        .modal-btn-secondary { background-color: #6c757d; color: white; }
        .modal-btn-secondary:hover { background-color: #5a6268; transform: translateY(-2px); }

        .modal-btn-info { background-color: #17a2b8; color: white; }
        .modal-btn-info:hover { background-color: #138496; transform: translateY(-2px); }

        @media (max-width: 1200px) {
            .main-content { margin-left: 0; padding: 15px; }
            .sidebar { display: none; }
            .bills-table { font-size: 13px; }
            .action-buttons { flex-direction: row; flex-wrap: wrap; }
            .action-btn { min-width: 60px; font-size: 11px; padding: 5px 8px; }
        }

        @media (max-width: 768px) {
            .pagination-container { flex-direction: column; gap: 15px; }
            .page-numbers { order: -1; }
            .filter-section { flex-direction: column; align-items: stretch; }
            .filter-buttons { align-self: stretch; justify-content: center; }
            .action-buttons { flex-direction: column; }
            .action-btn { width: 100%; }
            .detail-modal-content { width: 95%; margin: 20px auto; max-height: 90vh; }
            .summary-row { flex-direction: column; gap: 10px; }
            .detail-modal-footer { flex-direction: column; }
            .modal-btn { width: 100%; justify-content: center; }
        }
    </style>
</head>
<body>
    <div class="sidebar">
        <div class="logo">
            <img src="pictures/logo umi.png" alt="Logo">
        </div>
        <div class="user-info">
            <div class="user-name">Admin Fakultas</div>
            <div class="user-actions">
                <a href="#" onclick="logout(); return false;" style="background: #f59e0b;">Logout</a>
            </div>
        </div>
       <div class="menu">
            <a href="dashboard_admin_fakultas.php" class="menu-item">
                <div class="menu-icon"><i class="bi bi-house-door"></i></div>
                <div>Dashboard</div>
            </a>

            <a href="fk_aktivasi_KRS.php" class="menu-item">
                <div class="menu-icon"><i class="bi bi-clipboard-check"></i></div>
                <div>Aktivasi KRS</div>
            </a>

            <a href="fk_daftar_tagihan.php" class="menu-item  active">
                <div class="menu-icon"><i class="bi bi-card-checklist"></i></div>
                <div>Daftar Tagihan Mahasiswa</div>
            </a>

            <a href="fk_monitoring_cicilan.php" class="menu-item">
                <div class="menu-icon"><i class="bi bi-graph-up"></i></div>
                <div>Monitoring Cicilan</div>
            </a>
        </div>
    </div>

    <div class="main-content">
        <div class="header">
            <div class="header-title">
                <span class="menu-dots">⋮</span>
                <span>Daftar Tagihan yang Sudah Divalidasi</span>
            </div>
        </div>

        <div class="section">
            <h2 class="section-title">Tagihan yang Sudah Divalidasi (Lunas)</h2>

            <div class="summary-stats">
                <div class="stat-card stat-total">
                    <div class="stat-title">Total Tagihan Lunas</div>
                    <div class="stat-value" id="totalCount">0</div>
                </div>
                <div class="stat-card stat-lunas">
                    <div class="stat-title">Total Mahasiswa</div>
                    <div class="stat-value" id="mahasiswaCount">0</div>
                </div>
                <div class="stat-card stat-tertunggak">
                    <div class="stat-title">Total Pembayaran</div>
                    <div class="stat-value" id="totalPembayaran">Rp 0</div>
                </div>
            </div>

            <div class="filter-section">
                <div class="filter-group">
                    <label class="filter-label">NIM/Nama</label>
                    <input type="text" class="filter-input" id="searchFilter" placeholder="Cari NIM atau nama...">
                </div>

                <div class="filter-group">
                    <label class="filter-label">Semester</label>
                    <select class="filter-select" id="semesterFilter">
                        <option value="all">Semua Semester</option>
                        <option value="1">Semester 1</option>
                        <option value="2">Semester 2</option>
                        <option value="3">Semester 3</option>
                        <option value="4">Semester 4</option>
                        <option value="5">Semester 5</option>
                        <option value="6">Semester 6</option>
                        <option value="7">Semester 7</option>
                        <option value="8">Semester 8</option>
                    </select>
                </div>

                <div class="filter-group">
                    <label class="filter-label">Jurusan</label>
                    <select class="filter-select" id="jurusanFilter">
                        <option value="all">Semua Jurusan</option>
                        <option value="Teknik Informatika">Teknik Informatika</option>
                        <option value="Sistem Informasi">Sistem Informasi</option>
                        <option value="Manajemen">Manajemen</option>
                        <option value="Akuntansi">Akuntansi</option>
                    </select>
                </div>

                <div class="filter-group">
                    <label class="filter-label">Tahun Ajaran</label>
                    <select class="filter-select" id="tahunFilter">
                        <option value="all">Semua Tahun</option>
                        <option value="2023/2024">2023/2024</option>
                        <option value="2024/2025">2024/2025</option>
                        <option value="2025/2026">2025/2026</option>
                    </select>
                </div>

                <div class="filter-buttons">
                    <button class="action-btn" onclick="applyFilters()" style="background-color: #007bff; color: white;">
                        🔍 Terapkan
                    </button>
                    <button class="action-btn" onclick="resetFilters()" style="background-color: #6c757d; color: white;">
                        ↺ Reset
                    </button>
                </div>
            </div>

            <div class="table-container">
                <table class="bills-table">
                    <thead>
                        <tr>
                            <th width="5%">No</th>
                            <th width="10%">NIM</th>
                            <th width="15%">Nama Mahasiswa</th>
                            <th width="12%">Semester</th>
                            <th width="15%">Jenis Tagihan</th>
                            <th width="12%">Jumlah</th>
                            <th width="12%">Tanggal Bayar</th>
                            <th width="9%">Status</th>
                            <th width="10%" class="action-cell">Aksi</th>
                        </tr>
                    </thead>
                    <tbody id="billsTableBody"></tbody>
                </table>
            </div>

            <div class="pagination-container">
                <div class="pagination-info" id="pageInfo">Menampilkan 0-0 dari 0 data</div>
                <div class="pagination-controls">
                    <button class="page-btn" id="prevBtn" onclick="prevPage()" disabled>← Prev</button>
                    <div class="page-numbers" id="pageNumbers"></div>
                    <button class="page-btn" id="nextBtn" onclick="nextPage()">Next →</button>
                </div>
            </div>
        </div>
    </div>

    <!-- Modal untuk melihat riwayat pembayaran mahasiswa -->
    <div id="detailModal" class="detail-modal">
        <div class="detail-modal-content">
            <div class="detail-modal-header">
                <div class="detail-modal-title" style="text-align:center;">Riwayat Pembayaran Mahasiswa</div>
                <span class="close-detail-modal" onclick="closeDetailModal()">&times;</span>
            </div>
            <div class="detail-modal-body" id="detailModalBody"></div>
            <div class="detail-modal-footer" id="detailModalFooter"></div>
        </div>
    </div>

    <script src="js/auth.js"></script>
    <script>
        // Data tagihan yang sudah divalidasi - diambil dari API backend
        let billsData = [];
        let currentStudentDetail = null;
        let currentPage = 1;
        let itemsPerPage = 10;
        let filteredData = [];

        // Load tagihan data dari API
        async function loadBillingData() {
            const token = localStorage.getItem('auth_token');
            
            try {
                const response = await fetch(
                    '/projek_plbs/api/index.php/api/admin-fakultas/daftar-tagihan-validasi?page=1&limit=500',
                    {
                        method: 'GET',
                        credentials: 'include',
                        headers: {
                            'Authorization': `Bearer ${token}`,
                            'Content-Type': 'application/json'
                        }
                    }
                );

                if (!response.ok) {
                    throw new Error(`HTTP ${response.status}`);
                }

                const data = await response.json();

                if (data.status === 'success' && data.data && data.data.daftar) {
                    // Transform API response ke format yang diharapkan frontend
                    billsData = data.data.daftar.map((item) => {
                        // Extract semester number from semester field
                        const semesterMatch = item.semester ? item.semester.toString() : '1';
                        const tahunAjaranParts = item.tahun_akademik ? item.tahun_akademik.split('/') : ['2024', '2025'];
                        
                        return {
                            id: item.pembayaran_id,
                            nim: item.nim,
                            name: item.nama_mahasiswa,
                            jurusan: item.prodi_nama || 'N/A',
                            semester: `Semester ${semesterMatch}`,
                            tahun_ajaran: item.tahun_akademik,
                            jenis_tagihan: item.jenis_tagihan,
                            jumlah: item.jumlah_tagihan,
                            tanggal_tagihan: item.tanggal_tagihan || new Date().toISOString().split('T')[0],
                            tanggal_jatuh_tempo: item.tanggal_jatuh_tempo || new Date().toISOString().split('T')[0],
                            tanggal_bayar: item.tgl_pembayaran,
                            status: 'lunas',
                            catatan: `${item.jenis_tagihan} telah divalidasi`,
                            angkatan: tahunAjaranParts[0],
                            metode_bayar: item.metode_pembayaran || 'Transfer Bank',
                            validator: item.admin_validator || 'Admin Keuangan',
                            tanggal_validasi: item.tanggal_validasi || new Date().toISOString().split('T')[0]
                        };
                    });

                    filteredData = [...billsData];
                    renderTable();
                    console.log(`✓ Loaded ${billsData.length} validated billing records from API`);
                } else {
                    console.warn('Failed to load billing data:', data.message);
                    alert('Gagal mengambil data tagihan. Silakan refresh halaman.');
                }
            } catch (error) {
                console.error('Error loading billing data:', error);
                alert('Terjadi kesalahan saat mengambil data tagihan. Cek koneksi internet Anda.');
            }
        }

        function formatDate(dateString) {
            if (!dateString) return '-';
            const date = new Date(dateString);
            if (isNaN(date.getTime())) return '-';
            const day = String(date.getDate()).padStart(2, '0');
            const month = String(date.getMonth() + 1).padStart(2, '0');
            const year = date.getFullYear();
            return `${day}/${month}/${year}`;
        }

        function formatRupiah(angka) {
            const num = Number(angka);
            if (isNaN(num)) return 'Rp 0';
            return 'Rp ' + num.toLocaleString('id-ID');
        }

        // Update statistik
        function updateStats() {
            const total = filteredData.length;
            
            // Hitung jumlah mahasiswa unik
            const uniqueNims = [...new Set(filteredData.map(item => item.nim))];
            const mahasiswaCount = uniqueNims.length;
            
            // Hitung total pembayaran
            const totalPembayaran = filteredData.reduce((sum, item) => sum + item.jumlah, 0);

            document.getElementById('totalCount').textContent = total;
            document.getElementById('mahasiswaCount').textContent = mahasiswaCount;
            document.getElementById('totalPembayaran').textContent = formatRupiah(totalPembayaran);
        }

        function clampCurrentPage() {
            const totalPages = Math.ceil(filteredData.length / itemsPerPage);
            if (totalPages === 0) currentPage = 1;
            if (currentPage > totalPages) currentPage = totalPages;
            if (currentPage < 1) currentPage = 1;
        }

        function renderTable() {
            clampCurrentPage();

            const tableBody = document.getElementById('billsTableBody');
            tableBody.innerHTML = '';

            const startIndex = (currentPage - 1) * itemsPerPage;
            const endIndex = startIndex + itemsPerPage;
            const currentData = filteredData.slice(startIndex, endIndex);

            if (currentData.length === 0) {
                tableBody.innerHTML = `
                    <tr>
                        <td colspan="9" style="text-align: center; padding: 40px; color: #6c757d;">
                            Tidak ada data tagihan yang sudah divalidasi.
                        </td>
                    </tr>
                `;
                updatePagination();
                updateStats();
                return;
            }

            currentData.forEach((item, index) => {
                const row = document.createElement('tr');
                const globalIndex = startIndex + index;

                // Status badge hanya lunas
                const statusBadge = `<span class="status-badge status-lunas">LUNAS</span>`;

                // Semester badge dengan warna
                let semesterNumber = parseInt(item.semester.split(' ')[1], 10);
                let semesterColor = '#007bff';
                switch (semesterNumber) {
                    case 1: semesterColor = '#007bff'; break;
                    case 2: semesterColor = '#28a745'; break;
                    case 3: semesterColor = '#17a2b8'; break;
                    case 4: semesterColor = '#ffc107'; break;
                    case 5: semesterColor = '#fd7e14'; break;
                    case 6: semesterColor = '#6f42c1'; break;
                    case 7: semesterColor = '#e83e8c'; break;
                    case 8: semesterColor = '#dc3545'; break;
                }

                const semesterBadge = `<span class="semester-badge" style="background-color:${semesterColor};">${item.semester}</span>`;

                // Action buttons
                const actionButtons = `
                    <div class="action-buttons">
                        <button class="action-btn btn-detail" onclick="viewStudentPayments('${item.nim}')" title="Lihat riwayat pembayaran">📋 Detail</button>
                        <button class="action-btn btn-print" onclick="printInvoice(${item.id})" title="Cetak invoice">🖨 Cetak</button>
                    </div>
                `;

                row.innerHTML = `
                    <td class="data-cell">${globalIndex + 1}</td>
                    <td class="data-cell"><strong>${item.nim}</strong></td>
                    <td class="data-cell">${item.name}</td>
                    <td class="data-cell">${semesterBadge}<br><small>${item.tahun_ajaran}</small></td>
                    <td class="data-cell">${item.jenis_tagihan}</td>
                    <td class="data-cell"><strong>${formatRupiah(item.jumlah)}</strong></td>
                    <td class="data-cell">${formatDate(item.tanggal_bayar)}</td>
                    <td>${statusBadge}</td>
                    <td class="action-cell">${actionButtons}</td>
                `;

                tableBody.appendChild(row);
            });

            updatePagination();
            updateStats();
        }

        function updatePagination() {
            const totalPages = Math.ceil(filteredData.length / itemsPerPage);
            const pageNumbersContainer = document.getElementById('pageNumbers');
            const prevBtn = document.getElementById('prevBtn');
            const nextBtn = document.getElementById('nextBtn');
            const pageInfo = document.getElementById('pageInfo');

            if (filteredData.length === 0) {
                pageInfo.textContent = `Menampilkan 0-0 dari 0 data`;
                prevBtn.disabled = true;
                nextBtn.disabled = true;
                pageNumbersContainer.innerHTML = '';
                return;
            }

            const startIndex = (currentPage - 1) * itemsPerPage + 1;
            const endIndex = Math.min(currentPage * itemsPerPage, filteredData.length);
            pageInfo.textContent = `Menampilkan ${startIndex}-${endIndex} dari ${filteredData.length} data`;

            prevBtn.disabled = currentPage === 1;
            nextBtn.disabled = currentPage === totalPages;

            pageNumbersContainer.innerHTML = '';

            let startPage = Math.max(1, currentPage - 2);
            let endPage = Math.min(totalPages, startPage + 4);
            if (endPage - startPage < 4) startPage = Math.max(1, endPage - 4);

            for (let i = startPage; i <= endPage; i++) {
                const pageBtn = document.createElement('button');
                pageBtn.className = `page-number ${i === currentPage ? 'active' : ''}`;
                pageBtn.textContent = i;
                pageBtn.onclick = () => goToPage(i);
                pageNumbersContainer.appendChild(pageBtn);
            }
        }

        function goToPage(page) { currentPage = page; renderTable(); }
        function prevPage() { if (currentPage > 1) { currentPage--; renderTable(); } }
        function nextPage() {
            const totalPages = Math.ceil(filteredData.length / itemsPerPage);
            if (currentPage < totalPages) { currentPage++; renderTable(); }
        }

        // Fungsi untuk melihat seluruh pembayaran mahasiswa berdasarkan NIM
        function viewStudentPayments(nim) {
            // Ambil semua pembayaran mahasiswa dengan NIM tersebut
            const studentPayments = billsData.filter(item => item.nim === nim);
            if (studentPayments.length === 0) return;

            // Ambil data mahasiswa dari pembayaran pertama
            const firstPayment = studentPayments[0];
            currentStudentDetail = { nim, payments: studentPayments };

            // Hitung statistik
            const totalPembayaran = studentPayments.reduce((sum, item) => sum + item.jumlah, 0);
            const jumlahTagihan = studentPayments.length;
            const semesterTertinggi = Math.max(...studentPayments.map(p => parseInt(p.semester.split(' ')[1])));
            const tahunMulai = Math.min(...studentPayments.map(p => parseInt(p.tahun_ajaran.split('/')[0])));

            // Buat modal content
            const detailHTML = `
                <div class="student-summary">
                    <div class="summary-row">
                        <div class="summary-item">
                            <div class="summary-label">NIM</div>
                            <div class="summary-value">${firstPayment.nim}</div>
                        </div>
                        <div class="summary-item">
                            <div class="summary-label">Nama Mahasiswa</div>
                            <div class="summary-value">${firstPayment.name}</div>
                        </div>
                        <div class="summary-item">
                            <div class="summary-label">Jurusan</div>
                            <div class="summary-value">${firstPayment.jurusan}</div>
                        </div>
                    </div>
                    
                    <div class="summary-row">
                        <div class="summary-item">
                            <div class="summary-label">Angkatan</div>
                            <div class="summary-value">${firstPayment.angkatan}</div>
                        </div>
                        <div class="summary-item">
                            <div class="summary-label">Semester Tertinggi</div>
                            <div class="summary-value">Semester ${semesterTertinggi}</div>
                        </div>
                        <div class="summary-item">
                            <div class="summary-label">Tahun Mulai</div>
                            <div class="summary-value">${tahunMulai}</div>
                        </div>
                    </div>
                    
                    <div class="summary-row">
                        <div class="summary-item">
                            <div class="summary-label">Jumlah Tagihan Lunas</div>
                            <div class="summary-value">${jumlahTagihan} tagihan</div>
                        </div>
                        <div class="summary-item">
                            <div class="summary-label">Total Pembayaran</div>
                            <div class="summary-value">${formatRupiah(totalPembayaran)}</div>
                        </div>
                        <div class="summary-item">
                            <div class="summary-label">Status</div>
                            <div class="summary-value"><span class="status-badge status-lunas">LUNAS SEMUA</span></div>
                        </div>
                    </div>
                </div>

                <h3 style="margin: 20px 0 10px 0; font-size: 16px; color: #333;">📊 Riwayat Pembayaran Lengkap</h3>
                
                <div class="table-container">
                    <table class="payment-history-table">
                        <thead>
                            <tr>
                                <th>No</th>
                                <th>Semester</th>
                                <th>Jenis Tagihan</th>
                                <th>Jumlah</th>
                                <th>Tanggal Bayar</th>
                                <th>Metode Bayar</th>
                                <th>Validator</th>
                                <th>Tanggal Validasi</th>
                            </tr>
                        </thead>
                        <tbody>
                            ${studentPayments.map((payment, index) => `
                                <tr>
                                    <td>${index + 1}</td>
                                    <td>${payment.semester}<br><small>${payment.tahun_ajaran}</small></td>
                                    <td>${payment.jenis_tagihan}</td>
                                    <td><strong>${formatRupiah(payment.jumlah)}</strong></td>
                                    <td>${formatDate(payment.tanggal_bayar)}</td>
                                    <td>${payment.metode_bayar}</td>
                                    <td>${payment.validator}</td>
                                    <td>${formatDate(payment.tanggal_validasi)}</td>
                                </tr>
                            `).join('')}
                            <tr class="total-row">
                                <td colspan="3"><strong>TOTAL</strong></td>
                                <td><strong>${formatRupiah(totalPembayaran)}</strong></td>
                                <td colspan="4"></td>
                            </tr>
                        </tbody>
                    </table>
                </div>

                <div style="margin-top: 20px; padding: 15px; background: #f8f9fa; border-radius: 8px;">
                    <div style="font-size: 14px; font-weight: 600; color: #333; margin-bottom: 8px;">📝 Ringkasan:</div>
                    <div style="font-size: 13px; color: #666; line-height: 1.5;">
                        Mahasiswa telah melunasi semua tagihan dari Semester 1 hingga Semester ${semesterTertinggi}. 
                        Total ${jumlahTagihan} tagihan telah divalidasi dengan total pembayaran ${formatRupiah(totalPembayaran)}.
                    </div>
                </div>
            `;

            document.getElementById('detailModalBody').innerHTML = detailHTML;

            const footerHTML = `
                <button class="modal-btn modal-btn-secondary" onclick="closeDetailModal()">
                    ✕ Tutup
                </button>
                <button class="modal-btn modal-btn-info" onclick="printStudentReport('${nim}')">
                    📄 Cetak Laporan
                </button>
            `;

            document.getElementById('detailModalFooter').innerHTML = footerHTML;
            document.getElementById('detailModal').style.display = 'block';
        }

        function printStudentReport(nim) {
            const studentPayments = billsData.filter(item => item.nim === nim);
            const firstPayment = studentPayments[0];
            const totalPembayaran = studentPayments.reduce((sum, item) => sum + item.jumlah, 0);
            
            alert(`Mencetak laporan pembayaran untuk:\n\nNIM: ${firstPayment.nim}\nNama: ${firstPayment.name}\nTotal Tagihan: ${studentPayments.length}\nTotal Pembayaran: ${formatRupiah(totalPembayaran)}`);
        }

        function closeDetailModal() {
            const modal = document.getElementById('detailModal');
            if (modal) modal.style.display = 'none';
            currentStudentDetail = null;
        }

        function printInvoice(id) {
            const bill = billsData.find(p => p.id === id);
            if (!bill) return;
            alert(`Mencetak invoice untuk:\n\n${bill.nim} - ${bill.name}\n${bill.jenis_tagihan}\n${formatRupiah(bill.jumlah)}\n${bill.tahun_ajaran}`);
        }

        function applyFilters() {
            const searchFilter = document.getElementById('searchFilter').value.toLowerCase();
            const semesterFilter = document.getElementById('semesterFilter').value;
            const jurusanFilter = document.getElementById('jurusanFilter').value;
            const tahunFilter = document.getElementById('tahunFilter').value;

            filteredData = billsData.filter(bill => {
                if (searchFilter &&
                    !bill.nim.toLowerCase().includes(searchFilter) &&
                    !bill.name.toLowerCase().includes(searchFilter)) return false;

                if (semesterFilter !== 'all') {
                    const semesterNumber = bill.semester.split(' ')[1];
                    if (semesterNumber !== semesterFilter) return false;
                }

                if (jurusanFilter !== 'all' && bill.jurusan !== jurusanFilter) return false;

                if (tahunFilter !== 'all' && !bill.tahun_ajaran.includes(tahunFilter)) return false;

                return true;
            });

            currentPage = 1;
            renderTable();
        }

        function resetFilters() {
            document.getElementById('searchFilter').value = '';
            document.getElementById('semesterFilter').value = 'all';
            document.getElementById('jurusanFilter').value = 'all';
            document.getElementById('tahunFilter').value = 'all';

            filteredData = [...billsData];
            currentPage = 1;
            renderTable();
        }

        // Menu interaction
        document.querySelectorAll('.menu-item').forEach(item => {
            item.addEventListener('click', function() {
                document.querySelectorAll('.menu-item').forEach(mi => mi.classList.remove('active'));
                this.classList.add('active');
            });
        });

        document.addEventListener('keydown', function(event) {
            if (event.key === 'Escape') closeDetailModal();
        });

        const searchEl = document.getElementById('searchFilter');
        if (searchEl) {
            searchEl.addEventListener('keyup', function(event) {
                if (event.key === 'Enter') applyFilters();
            });
        }

        document.querySelectorAll('.filter-select').forEach(select => {
            select.addEventListener('change', applyFilters);
        });

        document.addEventListener('DOMContentLoaded', function() {
            // Setup authentication
            requireAuth('admin_fakultas');
            
            // Update user info in sidebar
            const user = getCurrentUser();
            if (user) {
                document.querySelector('.user-name').textContent = user.nama_lengkap || 'Admin';
            }
            
            // Load billing data from API
            loadBillingData();
            
            console.log('Sistem tagihan validasi siap digunakan.');
        });
    </script>
</body>
</html>
