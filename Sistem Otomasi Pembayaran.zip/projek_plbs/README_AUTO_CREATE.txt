# AUTO-CREATE TAGIHAN - QUICK START

## Masalah yang Diselesaikan
Sebelumnya, tagihan semester berikutnya hanya dibuat ketika:
- Mahasiswa membuka dashboard (tidak efisien)
- Admin memvalidasi pembayaran secara manual

Sekarang, tagihan dibuat OTOMATIS untuk SEMUA mahasiswa setiap hari.

## Setup Cepat (Windows)

### 1. Test Manual
Buka browser, akses:
```
http://localhost/projek_plbs/api/trigger/auto-create-tagihan
```

### 2. Setup Otomatis (Task Scheduler)
1. Tekan `Win+R`, ketik `taskschd.msc`
2. Create Basic Task → Name: `Auto Create Tagihan PLBS`
3. Trigger: Daily, 02:00 AM
4. Action: Start a program
   - Program: `powershell.exe`
   - Arguments: `-ExecutionPolicy Bypass -File "d:\laragon\www\projek_plbs\auto_create_tagihan.ps1"`
5. Finish

### 3. Cek Log
```
d:\laragon\www\projek_plbs\logs\auto_create_tagihan.log
```

## Cara Kerja
- **BPP**: Otomatis buat semester berikutnya setelah semester sebelumnya lunas (max semester 8)
- **PROPOSAL**: Otomatis buat setelah BPP semester 1-6 lunas
- **SKRIPSI**: Otomatis buat setelah BPP semester 1-7 lunas

## Files
- `auto_create_tagihan.ps1` - PowerShell script (RECOMMENDED)
- `auto_create_tagihan.bat` - Batch script (alternatif)
- `SETUP_AUTO_CREATE.txt` - Dokumentasi lengkap
- `logs/auto_create_tagihan.log` - Log file

## Troubleshooting
Lihat file `SETUP_AUTO_CREATE.txt` untuk detail lengkap.
