<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header('Location: login_admin_fakultas.php');
    exit;
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Laporan Pembayaran</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.13.1/font/bootstrap-icons.min.css">
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }

        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: #f5f5f5;
            display: flex;
        }

        .sidebar { display: none; }

        .main-content { margin-left: 0; flex: 1; padding: 20px 40px; }

        .header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 30px;
            background: white;
            padding: 15px 25px;
            border-radius: 8px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
        }

        .header-title {
            font-size: 20px;
            color: #666;
            display: flex;
            align-items: center;
            gap: 15px;
        }

        .menu-dots { font-size: 24px; cursor: pointer; color: #999; }


        .section {
            background: white;
            border-radius: 8px;
            padding: 30px;
            margin-bottom: 30px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
        }

        .section-title {
            font-size: 22px;
            margin-bottom: 25px;
            color: #333;
            font-weight: 600;
            border-bottom: 2px solid #4169E1;
            padding-bottom: 10px;
        }

        .student-info {
            background: #f8f9fa;
            border-radius: 8px;
            padding: 20px;
            margin-bottom: 30px;
        }

        .info-row {
            display: flex;
            gap: 40px;
            margin-bottom: 15px;
        }

        .info-item {
            flex: 1;
        }

        .info-label {
            font-size: 12px;
            color: #666;
            margin-bottom: 4px;
        }

        .info-value {
            font-size: 16px;
            font-weight: 600;
            color: #333;
        }

        .back-btn {
            display: inline-flex;
            align-items: center;
            gap: 8px;
            padding: 10px 20px;
            background-color: #6c757d;
            color: white;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            font-size: 14px;
            font-weight: 600;
            margin-bottom: 20px;
            transition: all 0.3s;
        }

        .back-btn:hover {
            background-color: #5a6268;
            transform: translateY(-2px);
        }

        .table-container {
            overflow-x: auto;
            margin-bottom: 20px;
            border: 1px solid #e9ecef;
            border-radius: 8px;
        }

        .report-table { width: 100%; border-collapse: collapse; }

        .report-table th {
            background-color: #f8f9fa;
            color: #333;
            font-weight: 600;
            text-align: left;
            padding: 15px 12px;
            border-bottom: 2px solid #dee2e6;
            font-size: 14px;
            white-space: nowrap;
        }

        .report-table td {
            padding: 15px 12px;
            border-bottom: 1px solid #e9ecef;
            vertical-align: middle;
        }

        .report-table tbody tr:last-child td { border-bottom: none; }
        .report-table tbody tr:hover { background-color: #f8f9fa; }

        .data-cell { font-size: 14px; color: #333; font-weight: 500; }

        .status-badge {
            display: inline-block;
            padding: 6px 12px;
            border-radius: 20px;
            font-size: 12px;
            font-weight: 600;
            min-width: 110px;
            text-align: center;
            white-space: nowrap;
        }

        .status-valid { background-color: #d4edda; color: #155724; border: 1px solid #c3e6cb; }
        .status-pending { background-color: #fff3cd; color: #856404; border: 1px solid #ffeaa7; }

        .payment-type-badge {
            display: inline-block;
            padding: 4px 10px;
            border-radius: 12px;
            font-size: 11px;
            font-weight: 600;
            white-space: nowrap;
        }

        .type-lunas { background-color: #d4edda; color: #155724; }
        .type-cicilan { background-color: #fff3cd; color: #856404; }

        .summary-stats {
            display: flex;
            gap: 20px;
            margin-bottom: 25px;
            flex-wrap: wrap;
        }

        .stat-card {
            flex: 1;
            min-width: 200px;
            background: white;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
        }

        .stat-title { font-size: 14px; color: #6c757d; margin-bottom: 10px; }
        .stat-value { font-size: 24px; font-weight: 700; color: #333; }

        .stat-total { border-left: 4px solid #007bff; }
        .stat-lunas { border-left: 4px solid #28a745; }

        .pagination-container {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-top: 30px;
            padding-top: 20px;
            border-top: 1px solid #e9ecef;
        }

        .pagination-info { font-size: 14px; color: #6c757d; }

        .pagination-controls { display: flex; gap: 10px; align-items: center; }

        .page-btn {
            padding: 8px 16px;
            background-color: white;
            border: 1px solid #dee2e6;
            border-radius: 4px;
            cursor: pointer;
            font-size: 14px;
            font-weight: 600;
            display: flex;
            align-items: center;
            gap: 6px;
            transition: all 0.3s;
        }

        .page-btn:hover:not(:disabled) { background-color: #007bff; color: white; border-color: #007bff; }
        .page-btn:disabled { opacity: 0.5; cursor: not-allowed; }

        @media (max-width: 1200px) {
            .main-content { margin-left: 0; padding: 15px; }
            .sidebar { display: none; }
            .report-table { font-size: 13px; }
        }

        @media (max-width: 768px) {
            .pagination-container { flex-direction: column; gap: 15px; }
            .info-row { flex-direction: column; gap: 15px; }
            .summary-stats { flex-direction: column; }
        }
    </style>
</head>
<body>
<div class="main-content">
        <div class="header">
            <div class="header-title">
                <span class="menu-dots">⋮</span>
                <span>Laporan Pembayaran Mahasiswa</span>
            </div>
        </div>

        <button class="back-btn" onclick="goBackToMonitoring()">
            <i class="bi bi-chevron-left"></i> Kembali ke Monitoring Cicilan
        </button>

        <div class="section">
            <div class="student-info">
                <div class="info-row">
                    <div class="info-item">
                        <div class="info-label">Nama Mahasiswa</div>
                        <div class="info-value" id="studentName">-</div>
                    </div>
                    <div class="info-item">
                        <div class="info-label">NIM</div>
                        <div class="info-value" id="studentNim">-</div>
                    </div>
                </div>
            </div>

            <div class="summary-stats">
                <div class="stat-card stat-total">
                    <div class="stat-title">Total Tagihan</div>
                    <div class="stat-value" id="totalTagihan">Rp 0</div>
                </div>
                <div class="stat-card stat-lunas">
                    <div class="stat-title">Total Pembayaran</div>
                    <div class="stat-value" id="totalPembayaran">Rp 0</div>
                </div>
            </div>

            <div class="section-title">📋 Riwayat Pembayaran</div>

            <div class="table-container">
                <table class="report-table">
                    <thead>
                        <tr>
                            <th>No</th>
                            <th>Semester</th>
                            <th>Jenis Pembayaran</th>
                            <th>Nominal</th>
                            <th>Tanggal Pembayaran</th>
                            <th>Status Validasi</th>
                        </tr>
                    </thead>
                    <tbody id="tableBody">
                        <!-- Akan diisi oleh JavaScript -->
                    </tbody>
                </table>
            </div>

            <div class="pagination-container">
                <div class="pagination-info">
                    <span id="paginationText">Menampilkan 1-10 dari 15 transaksi</span>
                </div>
                <div class="pagination-controls">
                    <button class="page-btn" onclick="previousPage()" id="prevBtn"><i class="bi bi-chevron-left"></i> Sebelumnya</button>
                    <button class="page-btn" onclick="nextPage()" id="nextBtn">Selanjutnya <i class="bi bi-chevron-right"></i></button>
                </div>
            </div>
        </div>
    </div>

    <script src="js/auth.js"></script>
    <script>
        let currentPage = 1;
        let itemsPerPage = 10;
        let currentData = [];
        let mahasiswaData = null;

        function formatCurrency(value) {
            return new Intl.NumberFormat('id-ID', { style: 'currency', currency: 'IDR', minimumFractionDigits: 0 }).format(value);
        }

        function getStatusBadge(status) {
            return status === 'valid' ? 'status-valid' : 'status-pending';
        }

        function getStatusText(status) {
            return status === 'valid' ? 'Valid' : status === 'ditolak' ? 'Ditolak' : 'Menunggu Validasi';
        }

        function getTypeClass(jenis) {
            return jenis.toLowerCase().includes('lunas') ? 'type-lunas' : 'type-cicilan';
        }

        async function loadStudentData() {
            const urlParams = new URLSearchParams(window.location.search);
            const mahasiswaId = urlParams.get('mahasiswa_id');

            if (!mahasiswaId) {
                alert('Mahasiswa ID tidak ditemukan');
                return;
            }

            const token = localStorage.getItem('auth_token');
            
            try {
                const response = await fetch(
                    `/projek_plbs/api/index.php/api/admin-fakultas/laporan-cicilan/${mahasiswaId}`,
                    {
                        method: 'GET',
                        credentials: 'include',
                        headers: {
                            'Authorization': `Bearer ${token}`,
                            'Content-Type': 'application/json'
                        }
                    }
                );

                if (!response.ok) {
                    throw new Error(`HTTP ${response.status}`);
                }

                const data = await response.json();

                if (data.status === 'success' && data.data) {
                    mahasiswaData = data.data;
                    
                    document.getElementById('studentName').textContent = mahasiswaData.mahasiswa.nama_lengkap;
                    document.getElementById('studentNim').textContent = mahasiswaData.mahasiswa.nim;

                    const totalTagihan = mahasiswaData.tagihan.reduce((sum, t) => sum + t.jumlah_tagihan, 0);
                    const totalPembayaran = mahasiswaData.tagihan.reduce((sum, t) => sum + t.total_dibayar, 0);
                    
                    document.getElementById('totalTagihan').textContent = formatCurrency(totalTagihan);
                    document.getElementById('totalPembayaran').textContent = formatCurrency(totalPembayaran);

                    currentData = mahasiswaData.pembayaran || [];
                    renderTable();
                } else {
                    alert('Gagal mengambil data laporan: ' + (data.message || 'Unknown error'));
                }
            } catch (error) {
                console.error('Error loading laporan:', error);
                alert('Terjadi kesalahan saat mengambil data laporan.');
            }
        }

        function renderTable() {
            const tableBody = document.getElementById('tableBody');
            tableBody.innerHTML = '';

            if (currentData.length === 0) {
                tableBody.innerHTML = '<tr><td colspan="6" style="text-align: center; padding: 20px; color: #666;">Belum ada riwayat pembayaran</td></tr>';
                updatePagination();
                return;
            }

            const start = (currentPage - 1) * itemsPerPage;
            const end = start + itemsPerPage;
            const pageData = currentData.slice(start, end);

            pageData.forEach((row, index) => {
                const tr = document.createElement('tr');
                tr.innerHTML = `
                    <td class="data-cell">${start + index + 1}</td>
                    <td class="data-cell">Semester ${row.semester}</td>
                    <td class="data-cell">
                        <span class="payment-type-badge ${getTypeClass(row.jenis_tagihan)}">
                            ${row.jenis_tagihan}
                        </span>
                    </td>
                    <td class="data-cell">${formatCurrency(row.jumlah_pembayaran)}</td>
                    <td class="data-cell">${new Date(row.tgl_pembayaran).toLocaleDateString('id-ID', { year: 'numeric', month: 'long', day: 'numeric' })}</td>
                    <td class="data-cell">
                        <span class="status-badge ${getStatusBadge(row.status_validasi)}">
                            ${getStatusText(row.status_validasi)}
                        </span>
                    </td>
                `;
                tableBody.appendChild(tr);
            });

            updatePagination();
        }

        function updatePagination() {
            const totalPages = currentData.length === 0 ? 1 : Math.ceil(currentData.length / itemsPerPage);
            document.getElementById('paginationText').textContent = 
                currentData.length === 0 
                    ? 'Tidak ada data' 
                    : `Menampilkan ${Math.min((currentPage - 1) * itemsPerPage + 1, currentData.length)}-${Math.min(currentPage * itemsPerPage, currentData.length)} dari ${currentData.length} transaksi`;
            
            document.getElementById('prevBtn').disabled = currentPage === 1 || currentData.length === 0;
            document.getElementById('nextBtn').disabled = currentPage === totalPages || currentData.length === 0;
        }

        function nextPage() {
            const totalPages = Math.ceil(currentData.length / itemsPerPage);
            if (currentPage < totalPages) {
                currentPage++;
                renderTable();
                window.scrollTo({ top: 0, behavior: 'smooth' });
            }
        }

        function previousPage() {
            if (currentPage > 1) {
                currentPage--;
                renderTable();
                window.scrollTo({ top: 0, behavior: 'smooth' });
            }
        }

        function goBackToMonitoring() {
            window.location.href = 'fk_monitoring_cicilan.php';
        }

        // Load data saat halaman dimuat
        document.addEventListener('DOMContentLoaded', function() {
            requireAuth('admin_fakultas');
            loadStudentData();
        });
    </script>
</body>
</html>


