@echo off
REM =============================================================================
REM AUTHENTICATION SYSTEM VERIFICATION SCRIPT (Windows)
REM =============================================================================
REM Script ini memverifikasi alur login-autentikasi-redirect untuk ketiga role
REM Run this script after database setup with TEST_DATA_INSERTION.sql
REM =============================================================================

setlocal enabledelayedexpansion
title Authentication System Verification

echo.
echo ════════════════════════════════════════════════════════════════
echo   VERIFICATION: Authentication System with Auto-Redirect
echo ════════════════════════════════════════════════════════════════
echo.

REM Configuration
set "API_URL=http://localhost/projek_plbs/api/index.php/api/auth/login"

REM =============================================================================
REM TEST 1: Database Setup Verification
REM =============================================================================
echo [TEST 1] Database Setup Verification
echo ════════════════════════════════════════════════════════════════
echo.
echo Status: Manual verification required
echo.
echo Database tables to verify:
echo   1. users table with 3 test users:
echo      - admin_universitas (role: admin_universitas)
echo      - admin_fikom (role: admin_fakultas)  
echo      - mahasiswa1 (role: mahasiswa)
echo.
echo   2. program_studi table with 8 program studi
echo      - Linked to 4 facultas
echo.
echo   3. mahasiswa table with record for mahasiswa1
echo      - NIM: 13020220001
echo      - Prodi: Teknik Informatika (prodi_id: 1)
echo.
echo Steps:
echo   1. Open your database tool (phpMyAdmin, MySQL Workbench, etc)
echo   2. Import api\TEST_DATA_INSERTION.sql
echo   3. Run verification queries (see below)
echo.
echo Verification Queries:
echo   -- Check users
echo   SELECT username, role, nama_lengkap FROM users 
echo   WHERE username IN ('admin_universitas','admin_fikom','mahasiswa1');
echo.
echo   -- Check program studi
echo   SELECT COUNT(*) as total_prodi FROM program_studi;
echo.
echo   -- Check mahasiswa
echo   SELECT u.username, m.nim, p.nama_prodi 
echo   FROM users u 
echo   LEFT JOIN mahasiswa m ON u.user_id = m.user_id 
echo   LEFT JOIN program_studi p ON m.prodi_id = p.prodi_id 
echo   WHERE u.username = 'mahasiswa1';
echo.

REM =============================================================================
REM TEST 2: Backend API Testing (Using cURL)
REM =============================================================================
echo.
echo [TEST 2] Backend API Testing
echo ════════════════════════════════════════════════════════════════
echo.
echo Checking if curl is available...

where curl >nul 2>nul
if %ERRORLEVEL% EQU 0 (
    echo ✓ curl found
    echo.
    echo Testing login endpoints...
    echo.
    
    echo --- Mahasiswa Login Test ---
    curl -s -X POST "%API_URL%" ^
        -H "Content-Type: application/json" ^
        -d "{\"username\":\"mahasiswa1\",\"password\":\"password123\"}" ^
        | find "success" >nul 2>nul && (
        echo ✓ Mahasiswa login: SUCCESS
    ) || (
        echo ✗ Mahasiswa login: FAILED
    )
    echo.
    
    echo --- Admin Fakultas Login Test ---
    curl -s -X POST "%API_URL%" ^
        -H "Content-Type: application/json" ^
        -d "{\"username\":\"admin_fikom\",\"password\":\"admin123\"}" ^
        | find "success" >nul 2>nul && (
        echo ✓ Admin Fakultas login: SUCCESS
    ) || (
        echo ✗ Admin Fakultas login: FAILED
    )
    echo.
    
    echo --- Admin Universitas Login Test ---
    curl -s -X POST "%API_URL%" ^
        -H "Content-Type: application/json" ^
        -d "{\"username\":\"admin_universitas\",\"password\":\"admin123\"}" ^
        | find "success" >nul 2>nul && (
        echo ✓ Admin Universitas login: SUCCESS
    ) || (
        echo ✗ Admin Universitas login: FAILED
    )
    echo.
    
    echo --- Wrong Password Test (Negative Test) ---
    curl -s -X POST "%API_URL%" ^
        -H "Content-Type: application/json" ^
        -d "{\"username\":\"mahasiswa1\",\"password\":\"wrongpassword\"}" ^
        | find "error" >nul 2>nul && (
        echo ✓ Wrong password: ERROR (as expected)
    ) || (
        echo ✗ Wrong password: Should return error
    )
) else (
    echo ! curl not found
    echo.
    echo To test API endpoints, you can:
    echo   1. Use Postman: https://www.postman.com/
    echo   2. Use REST Client VS Code extension
    echo   3. Use browser DevTools console
    echo.
    echo Example fetch call in browser console:
    echo   fetch('api/index.php/api/auth/login', {
    echo     method: 'POST',
    echo     headers: {'Content-Type': 'application/json'},
    echo     body: JSON.stringify({
    echo       username: 'mahasiswa1',
    echo       password: 'password123'
    echo     })
    echo   })
    echo   .then(r =^> r.json())
    echo   .then(d =^> console.log(d))
)

REM =============================================================================
REM TEST 3: Frontend Flow Verification
REM =============================================================================
echo.
echo.
echo [TEST 3] Frontend Flow Verification (Manual Testing)
echo ════════════════════════════════════════════════════════════════
echo.
echo Open your browser and test the following scenarios:
echo.
echo SCENARIO 1: Mahasiswa Login
echo ────────────────────────────────────────────────────────────────
echo   1. Access: http://localhost/projek_plbs/
echo   2. Click: "Login Mahasiswa" card
echo   3. Enter credentials:
echo      - Username: mahasiswa1
echo      - Password: password123
echo   4. Click: Login button
echo   5. Expected result: Redirect to dashboard_mahasiswa.html
echo   6. Verification:
echo      - Sidebar shows "ANDI WIJAYA"
echo      - User can access dashboard content
echo      - logout button present
echo.
echo SCENARIO 2: Admin Fakultas Login  
echo ────────────────────────────────────────────────────────────────
echo   1. Access: http://localhost/projek_plbs/
echo   2. Click: "Login Admin Fakultas" card
echo   3. Enter credentials:
echo      - Username: admin_fikom
echo      - Password: admin123
echo   4. Click: Login button
echo   5. Expected result: Redirect to dashboard_admin_fakultas.html
echo   6. Verification:
echo      - Sidebar shows "Prof. Siti Nurhaliza"
echo      - Dashboard shows admin facultas features
echo      - Logout button present
echo.
echo SCENARIO 3: Admin Universitas Login
echo ────────────────────────────────────────────────────────────────
echo   1. Access: http://localhost/projek_plbs/
echo   2. Click: "Login Admin Universitas" card
echo   3. Enter credentials:
echo      - Username: admin_universitas
echo      - Password: admin123
echo   4. Click: Login button
echo   5. Expected result: Redirect to dashboard_admin_universitas.html
echo   6. Verification:
echo      - Sidebar shows "Dr. Budi Santoso"
echo      - Dashboard shows admin universitas features
echo      - Logout button present
echo.
echo SCENARIO 4: Wrong Role on Admin Page (Negative Test)
echo ────────────────────────────────────────────────────────────────
echo   1. Access: http://localhost/projek_plbs/login_admin_fakultas.html
echo   2. Try login with mahasiswa1 credentials:
echo      - Username: mahasiswa1
echo      - Password: password123
echo   3. Expected result: ERROR message
echo      "Anda tidak memiliki akses sebagai Admin Fakultas"
echo   4. Expected: NO redirect to dashboard
echo.
echo SCENARIO 5: Protected Dashboard (No Auth)
echo ────────────────────────────────────────────────────────────────
echo   1. Open browser DevTools (F12)
echo   2. Go to Application tab
echo   3. Clear localStorage
echo   4. Direct access: http://localhost/projek_plbs/dashboard_mahasiswa.html
echo   5. Expected result: Redirect to index.html
echo.
echo SCENARIO 6: Logout Functionality
echo ────────────────────────────────────────────────────────────────
echo   1. Login as mahasiswa1
echo   2. Click "Logout" button in sidebar
echo   3. Expected result: Redirect to index.html
echo   4. Verify: Open DevTools Application tab
echo      - localStorage should be cleared
echo      - auth_token not present
echo      - role not present
echo.

REM =============================================================================
REM TEST 4: Code Review Checklist
REM =============================================================================
echo.
echo.
echo [TEST 4] Code Review Checklist
echo ════════════════════════════════════════════════════════════════
echo.
echo Backend Components:
echo   [✓] AuthController.login() queries users table from database
echo   [✓] Password verified using BCrypt password_verify()
echo   [✓] JWT token generated with user data
echo   [✓] Response includes role from database
echo   [✓] Error handling for wrong credentials
echo.
echo Frontend Components:
echo   [✓] index.html has 3 login option cards
echo   [✓] mhs_login.html AJAX POST to /api/auth/login
echo   [✓] mhs_login.html stores token+role+user_id+nama_lengkap to localStorage
echo   [✓] mhs_login.html redirects to dashboard_mahasiswa.html
echo   [✓] login_admin_fakultas.html validates role === 'admin_fakultas'
echo   [✓] login_admin_fakultas.html redirects to dashboard_admin_fakultas.html
echo   [✓] login_admin_universitas.html validates role === 'admin_universitas'
echo   [✓] login_admin_universitas.html redirects to dashboard_admin_universitas.html
echo.
echo Dashboard Protection:
echo   [✓] dashboard_mahasiswa.html includes js/auth.js
echo   [✓] dashboard_mahasiswa.html calls requireAuth('mahasiswa')
echo   [✓] dashboard_admin_fakultas.html includes js/auth.js
echo   [✓] dashboard_admin_fakultas.html calls requireAuth('admin_fakultas')
echo   [✓] dashboard_admin_universitas.html includes js/auth.js
echo   [✓] dashboard_admin_universitas.html calls requireAuth('admin_universitas')
echo.
echo Auth Helper Library (js/auth.js):
echo   [✓] isAuthenticated() checks token in localStorage
echo   [✓] getCurrentUser() returns user object from localStorage
echo   [✓] hasRole(role) validates user role
echo   [✓] requireAuth(role) redirects to index.html if not authorized
echo   [✓] logout() clears localStorage and redirects
echo.
echo Database Components:
echo   [✓] users table with username, password_hash, role columns
echo   [✓] mahasiswa table linked to users via user_id
echo   [✓] program_studi table linked to mahasiswa via prodi_id
echo   [✓] facultas table linked to program_studi via facultas_id
echo.
echo Test Data:
echo   [✓] 3 test users with hashed passwords (BCrypt)
echo   [✓] admin_universitas user with role 'admin_universitas'
echo   [✓] admin_fikom user with role 'admin_fakultas'
echo   [✓] mahasiswa1 user with role 'mahasiswa'
echo   [✓] Program studi and facultas data
echo.

REM =============================================================================
REM Summary
REM =============================================================================
echo.
echo.
echo ════════════════════════════════════════════════════════════════
echo   VERIFICATION COMPLETE
echo ════════════════════════════════════════════════════════════════
echo.
echo Key Points to Verify:
echo   1. Database setup with TEST_DATA_INSERTION.sql
echo   2. API endpoints responding with correct role
echo   3. Frontend redirecting based on role
echo   4. Role validation preventing unauthorized access
echo   5. Protected dashboards with auth checks
echo.
echo Documentation Files:
echo   - SISTEM_AUTENTIKASI_TESTING.md (Main verification guide)
echo   - QUICK_START_AUTH.md (Quick reference)
echo   - AUTHENTICATION_IMPLEMENTATION.md (Complete documentation)
echo.
echo Status: READY FOR TESTING
echo.
echo Next Steps:
echo   1. Setup database by importing TEST_DATA_INSERTION.sql
echo   2. Test each scenario above
echo   3. Verify API responses in browser DevTools
echo   4. Test all three user logins
echo   5. Test negative scenarios (wrong role, no auth)
echo.

pause
