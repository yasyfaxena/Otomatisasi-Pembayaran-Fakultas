<?php
session_start();
?>
<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Lupa Password</title>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">

<style>
/* STYLE SAMA */
:root {
    --primary: #246140;
    --primary-dark: #113120;
    --card: #ffffff;
    --muted: #777;
}

body {
    min-height: 100vh;
    background: linear-gradient(135deg, #e7efc7, #bbc2b4);
    display: flex;
    align-items: center;
    justify-content: center;
    font-family: 'Segoe UI', Tahoma, sans-serif;
}

.auth-container {
    width: 100%;
    max-width: 400px;
    background: var(--card);
    padding: 35px;
    border-radius: 14px;
    box-shadow: 0 15px 40px rgba(0,0,0,0.12);
    text-align: center;
}

.auth-container h2 {
    color: var(--primary-dark);
    margin-bottom: 10px;
}

.auth-container p {
    font-size: 14px;
    color: var(--muted);
    margin-bottom: 25px;
}

.input-wrapper {
    position: relative;
    margin-bottom: 20px;
    width: 349px;
}

.input-wrapper i {
    position: absolute;
    top: 50%;
    left: 12px;
    transform: translateY(-50%);
}

.input-wrapper input {
    width: 100%;
    padding: 12px 12px 12px 38px;
    border-radius: 8px;
    border: 1px solid #ddd;
}

.btn-primary {
    width: 100%;
    padding: 12px;
    background: linear-gradient(135deg, var(--primary), var(--primary-dark));
    border: none;
    border-radius: 10px;
    color: white;
    font-weight: 600;
    cursor: pointer;
}

.back-login {
    margin-top: 20px;
    font-size: 14px;
}

.back-login a {
    color: var(--primary);
    text-decoration: none;
    font-weight: 600;
}
</style>
</head>

<body>

<div class="auth-container">
    <h2>Lupa Password</h2>
    <p>Masukkan email untuk reset password</p>

    <form action="proses_forgot_password.php" method="POST">
        <div class="input-wrapper">
            <i class="fas fa-envelope"></i>
            <input type="email" name="email" placeholder="Email terdaftar" required>
        </div>

        <button class="btn-primary">
            <i class="fas fa-paper-plane"></i> Kirim Link Reset
        </button>
    </form>

    <div class="back-login">
        <a href="login.php">← Kembali ke Login</a>
    </div>
</div>

</body>
</html>
