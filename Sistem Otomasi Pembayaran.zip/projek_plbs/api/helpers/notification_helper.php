<?php
/**
 * Helper Functions untuk Sistem Notifikasi
 */

function createNotification($conn, $mahasiswa_id, $judul, $pesan, $tipe = 'info') {
    try {
        $query = "INSERT INTO notifikasi (mahasiswa_id, judul, pesan, tipe, status, created_at) 
                  VALUES (:mahasiswa_id, :judul, :pesan, :tipe, 'belum_dibaca', NOW())";
        $stmt = $conn->prepare($query);
        $stmt->bindParam(':mahasiswa_id', $mahasiswa_id, PDO::PARAM_INT);
        $stmt->bindParam(':judul', $judul, PDO::PARAM_STR);
        $stmt->bindParam(':pesan', $pesan, PDO::PARAM_STR);
        $stmt->bindParam(':tipe', $tipe, PDO::PARAM_STR);
        $stmt->execute();
        return true;
    } catch (Exception $e) {
        error_log('Error createNotification: ' . $e->getMessage());
        return false;
    }
}

function createCicilanNotification($conn, $mahasiswa_id, $semester, $tahun_akademik) {
    $judul = 'Pengingat Pembayaran Cicilan';
    $pesan = "Cicilan BPP Semester {$semester} telah divalidasi. Silakan lanjutkan pembayaran cicilan berikutnya sebelum jatuh tempo.";
    return createNotification($conn, $mahasiswa_id, $judul, $pesan, 'peringatan');
}

function createKRSNotification($conn, $mahasiswa_id, $semester, $tahun_akademik) {
    $judul = 'KRS Telah Diaktifkan';
    $pesan = "KRS Semester {$semester} Tahun Akademik {$tahun_akademik} telah diaktifkan dan sudah dapat diisi.";
    return createNotification($conn, $mahasiswa_id, $judul, $pesan, 'sukses');
}
