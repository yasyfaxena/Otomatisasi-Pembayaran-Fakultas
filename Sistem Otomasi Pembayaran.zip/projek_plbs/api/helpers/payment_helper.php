<?php
/**
 * Helper Functions untuk Sistem Pembayaran Cicilan
 */

function getPaymentFlags($conn, $tagihan_id, $status_pembayaran, $metode_pembayaran = null) {
    // Jika cicilan_berjalan, cek apakah ada pembayaran valid
    if ($status_pembayaran === 'cicilan_berjalan') {
        $query = "SELECT COUNT(*) as count FROM pembayaran WHERE tagihan_id = :tagihan_id AND status_validasi = 'valid'";
        $stmt = $conn->prepare($query);
        $stmt->bindParam(':tagihan_id', $tagihan_id, PDO::PARAM_INT);
        $stmt->execute();
        $result = $stmt->fetch(PDO::FETCH_ASSOC);
        $has_valid_payment = (int)$result['count'] > 0;
        
        // Jika sudah ada pembayaran valid, nonaktifkan bayar lunas (false)
        return ['can_pay_lunas' => false, 'can_pay_cicilan' => true];
    }
    if ($status_pembayaran === 'belum_bayar') {
        return ['can_pay_lunas' => true, 'can_pay_cicilan' => true];
    }
    if ($status_pembayaran === 'menunggu_verifikasi') {
        return ['can_pay_lunas' => false, 'can_pay_cicilan' => false];
    }
    if ($status_pembayaran === 'lunas') {
        return ['can_pay_lunas' => false, 'can_pay_cicilan' => false];
    }
    return ['can_pay_lunas' => false, 'can_pay_cicilan' => false];
}

function hitungSisaTagihan($conn, $tagihan_id, $jumlah_tagihan) {
    try {
        $query = "SELECT COALESCE(SUM(jumlah_pembayaran), 0) as total_dibayar
                  FROM pembayaran WHERE tagihan_id = :tagihan_id AND status_validasi = 'valid'";
        $stmt = $conn->prepare($query);
        $stmt->bindParam(':tagihan_id', $tagihan_id, PDO::PARAM_INT);
        $stmt->execute();
        $result = $stmt->fetch(PDO::FETCH_ASSOC);
        $total_dibayar = (float)($result['total_dibayar'] ?? 0);
        return max(0, $jumlah_tagihan - $total_dibayar);
    } catch (Exception $e) {
        return $jumlah_tagihan;
    }
}

function getCicilanInfo($conn, $tagihan_id, $jumlah_tagihan) {
    try {
        $query = "SELECT metode_pembayaran FROM tagihan WHERE tagihan_id = :tagihan_id";
        $stmt = $conn->prepare($query);
        $stmt->bindParam(':tagihan_id', $tagihan_id, PDO::PARAM_INT);
        $stmt->execute();
        $tagihan = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if (!$tagihan || $tagihan['metode_pembayaran'] !== 'cicilan') {
            return null;
        }
        
        $query = "SELECT COUNT(*) as total_cicilan,
                  SUM(CASE WHEN status_cicilan = 'lunas' THEN 1 ELSE 0 END) as cicilan_lunas
                  FROM cicilan_detail WHERE tagihan_id = :tagihan_id";
        $stmt = $conn->prepare($query);
        $stmt->bindParam(':tagihan_id', $tagihan_id, PDO::PARAM_INT);
        $stmt->execute();
        $result = $stmt->fetch(PDO::FETCH_ASSOC);
        
        $total_cicilan = (int)($result['total_cicilan'] ?? 2);
        $cicilan_lunas = (int)($result['cicilan_lunas'] ?? 0);
        
        // Jika belum ada cicilan_detail, return default 2 cicilan
        if ($total_cicilan === 0) {
            $total_cicilan = 2;
        }
        
        return [
            'total_cicilan' => $total_cicilan,
            'terbayar' => $cicilan_lunas,
            'sisa' => $total_cicilan - $cicilan_lunas,
            'nominal_per_cicilan' => $jumlah_tagihan / $total_cicilan
        ];
    } catch (Exception $e) {
        error_log('Error getCicilanInfo: ' . $e->getMessage());
        return null;
    }
}

function enhanceTagihanData($conn, $tagihan) {


    // Calculate sisa_tagihan first
    $sisa_tagihan = hitungSisaTagihan($conn, $tagihan['tagihan_id'], $tagihan['jumlah_tagihan']);
    
    // Check if there are valid payments
    $query = "SELECT COUNT(*) as count FROM pembayaran WHERE tagihan_id = :tagihan_id AND status_validasi = 'valid'";
    $stmt = $conn->prepare($query);
    $stmt->bindParam(':tagihan_id', $tagihan['tagihan_id'], PDO::PARAM_INT);
    $stmt->execute();
    $result = $stmt->fetch(PDO::FETCH_ASSOC);
    $has_valid_payment = (int)$result['count'] > 0;
    
    // CRITICAL: Override status_pembayaran to 'cicilan_berjalan' if:
    // 1. Has valid payment(s)
    // 2. Still has remaining balance (not fully paid)
    if ($has_valid_payment && $sisa_tagihan > 0) {
        $tagihan['status_pembayaran'] = 'cicilan_berjalan';
    }
    
    // Get payment flags based on (potentially overridden) status
    $flags = getPaymentFlags($conn, $tagihan['tagihan_id'], $tagihan['status_pembayaran'], $tagihan['metode_pembayaran'] ?? null);
    $tagihan['can_pay_lunas'] = $flags['can_pay_lunas'];
    $tagihan['can_pay_cicilan'] = $flags['can_pay_cicilan'];
    $tagihan['sisa_tagihan'] = $sisa_tagihan;
    
    if ($tagihan['metode_pembayaran'] === 'cicilan') {
        $cicilan_info = getCicilanInfo($conn, $tagihan['tagihan_id'], $tagihan['jumlah_tagihan']);
        if ($cicilan_info) {
            $tagihan['cicilan_info'] = $cicilan_info;
        }
    }
    
    return $tagihan;
}
