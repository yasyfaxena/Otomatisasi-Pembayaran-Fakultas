<?php
/**
 * Helper untuk Sistem Tagihan Berjenjang
 */

function createNextTagihan($conn, $mahasiswa_id) {
    try {
        // Ambil tagihan terakhir yang lunas
        $query = "SELECT * FROM tagihan 
                  WHERE mahasiswa_id = :mahasiswa_id 
                  AND status_pembayaran = 'lunas'
                  ORDER BY created_at DESC LIMIT 1";
        
        $stmt = $conn->prepare($query);
        $stmt->execute(['mahasiswa_id' => $mahasiswa_id]);
        $last_tagihan = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if (!$last_tagihan) {
            return false; // Belum ada tagihan lunas
        }
        
        // Cek apakah sudah ada tagihan aktif
        $check = "SELECT COUNT(*) as count FROM tagihan 
                  WHERE mahasiswa_id = :mahasiswa_id 
                  AND status_pembayaran IN ('belum_bayar','cicilan_berjalan','menunggu_verifikasi')";
        $stmt = $conn->prepare($check);
        $stmt->execute(['mahasiswa_id' => $mahasiswa_id]);
        $active = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if ($active['count'] > 0) {
            return false; // Sudah ada tagihan aktif
        }
        
        // Ambil data mahasiswa
        $stmt = $conn->prepare("SELECT * FROM mahasiswa WHERE mahasiswa_id = :id");
        $stmt->execute(['id' => $mahasiswa_id]);
        $mhs = $stmt->fetch(PDO::FETCH_ASSOC);
        
        // Tentukan tagihan berikutnya
        $next_jenis = null;
        $next_semester = null;
        
        if ($last_tagihan['jenis_tagihan'] === 'semester' || $last_tagihan['jenis_tagihan'] === 'BPP') {
            $current_semester = (int)$last_tagihan['semester'];
            
            if ($current_semester < 6) {
                // Semester 1-5 → Semester berikutnya
                $next_jenis = 'semester';
                $next_semester = $current_semester + 1;
            } elseif ($current_semester == 6) {
                // Semester 6 → Proposal
                $next_jenis = 'proposal';
                $next_semester = null;
            } elseif ($current_semester == 7) {
                // Semester 7 → Skripsi
                $next_jenis = 'skripsi';
                $next_semester = null;
            }
        } elseif ($last_tagihan['jenis_tagihan'] === 'proposal') {
            // Proposal → Semester 7
            $next_jenis = 'semester';
            $next_semester = 7;
        }
        
        if (!$next_jenis) {
            return false; // Tidak ada tagihan berikutnya
        }
        
        // Ambil tarif
        $tarif_query = "SELECT nominal FROM tarif 
                        WHERE prodi_id = :prodi_id 
                        AND jenis_tagihan = :jenis
                        AND is_active = 1
                        LIMIT 1";
        $stmt = $conn->prepare($tarif_query);
        $stmt->execute([
            'prodi_id' => $mhs['prodi_id'],
            'jenis' => $next_jenis === 'semester' ? 'BPP' : $next_jenis
        ]);
        $tarif = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if (!$tarif) {
            return false; // Tarif tidak ditemukan
        }
        
        // Buat tagihan baru
        $insert = "INSERT INTO tagihan 
                   (mahasiswa_id, jenis_tagihan, semester, tahun_akademik, 
                    jumlah_tagihan, status_pembayaran, metode_pembayaran, 
                    status_krs, tgl_jatuh_tempo, created_at)
                   VALUES 
                   (:mahasiswa_id, :jenis, :semester, :tahun_akademik, 
                    :jumlah, 'belum_bayar', 'lunas', 
                    'belum_aktif', DATE_ADD(NOW(), INTERVAL 14 DAY), NOW())";
        
        $stmt = $conn->prepare($insert);
        $result = $stmt->execute([
            'mahasiswa_id' => $mahasiswa_id,
            'jenis' => $next_jenis,
            'semester' => $next_semester,
            'tahun_akademik' => $mhs['tahun_akademik'],
            'jumlah' => $tarif['nominal']
        ]);
        
        if ($result) {
            error_log("[createNextTagihan] Created {$next_jenis}" . ($next_semester ? " semester {$next_semester}" : "") . " for mahasiswa_id={$mahasiswa_id}");
        }
        
        return $result;
        
    } catch (Exception $e) {
        error_log("[createNextTagihan] Error: " . $e->getMessage());
        return false;
    }
}
