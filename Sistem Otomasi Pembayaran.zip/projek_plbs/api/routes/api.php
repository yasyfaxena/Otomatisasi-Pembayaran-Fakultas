<?php
/**
 * API Routes
 * Define all API endpoints and map to controllers
 */

class Router {
    private $routes = [];
    private $request_method;
    private $request_uri;

    public function __construct() {
        $this->request_method = $_SERVER['REQUEST_METHOD'];
        
        // Get the API path from various possible sources
        // Priority: query parameter > PATH_INFO > REQUEST_URI
        $api_path = null;
        
        // Method 1: Check for ?path= query parameter (fallback routing method)
        if (!empty($_GET['path'])) {
            $api_path = $_GET['path'];
        }
        // Method 2: Check for PATH_INFO (from rewrite rules)
        else if (!empty($_SERVER['PATH_INFO'])) {
            $api_path = $_SERVER['PATH_INFO'];
        }
        // Method 3: Parse from REQUEST_URI (default)
        else {
            $api_path = parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH);
        }
        
        $this->request_uri = $api_path;
    }

    public function get($path, $callback) {
        $this->routes['GET'][$path] = $callback;
    }

    public function post($path, $callback) {
        $this->routes['POST'][$path] = $callback;
    }

    public function put($path, $callback) {
        $this->routes['PUT'][$path] = $callback;
    }

    public function delete($path, $callback) {
        $this->routes['DELETE'][$path] = $callback;
    }

    public function dispatch() {
        error_log("[Router] Dispatching: {$this->request_method} {$this->request_uri}");
        
        foreach ($this->routes[$this->request_method] ?? [] as $pattern => $callback) {
            if ($this->matchRoute($pattern, $this->request_uri, $matches)) {
                error_log("[Router] Matched pattern: $pattern");
                error_log("[Router] Extracted params: " . json_encode($matches));
                return call_user_func_array($callback, $matches);
            }
        }

        error_log("[Router] No route matched for: {$this->request_method} {$this->request_uri}");
        sendResponse('error', 'Endpoint not found', null, 'NOT_FOUND', 404);
    }

    private function matchRoute($pattern, $uri, &$matches) {
        // Remove /projek_plbs/api/index.php prefix if present
        $uri = preg_replace('#^/projek_plbs/api/index\.php#', '', $uri);
        
        // Remove /api prefix for comparison
        $uri = preg_replace('/^\/api/', '', $uri);
        $pattern = preg_replace('/^\/api/', '', $pattern);

        // Ensure both start with / for consistency
        if (empty($uri)) {
            $uri = '/';
        }
        if (empty($pattern)) {
            $pattern = '/';
        }

        // Convert pattern to regex - handle {param} placeholders
        $regex = preg_replace('/\{([a-zA-Z_][a-zA-Z0-9_]*)\}/', '([^/]+)', $pattern);
        $regex = '@^' . $regex . '$@';

        if (preg_match($regex, $uri, $match_result)) {
            // Extract only numeric keys (captured groups), skip index 0 (full match)
            $matches = array_slice($match_result, 1);
            return true;
        }

        return false;
    }
}

function initializeRoutes($router) {

    // ===== AUTHENTICATION ENDPOINTS =====
    $router->post('/api/auth/login', function() {
        $controller = new AuthController();
        $controller->login();
    });

    $router->post('/api/auth/register', function() {
        $controller = new AuthController();
        $controller->register();
    });

    $router->post('/api/auth/logout', function() {
        $controller = new AuthController();
        $controller->logout();
    });

    // ===== PUBLIC ENDPOINTS =====
    $router->get('/api/program-studi', function() {
        $controller = new AuthController();
        $controller->getProdiList();
    });

    // ===== MAHASISWA ENDPOINTS =====
    $router->get('/api/mahasiswa/dashboard', function() {
        $controller = new MahasiswaController();
        $controller->dashboard();
    });

    $router->get('/api/mahasiswa/dashboard-info', function() {
        $controller = new MahasiswaController();
        $controller->dashboardInfo();
    });

    $router->get('/api/mahasiswa/tagihan', function() {
        $controller = new MahasiswaController();
        $controller->tagihan();
    });

    $router->get('/api/mahasiswa/semua-tagihan', function() {
        $controller = new MahasiswaController();
        $controller->semuaTagihan();
    });

    $router->get('/api/mahasiswa/tagihan-dengan-tarif', function() {
        $controller = new MahasiswaController();
        $controller->tagihanDenganTarif();
    });

    $router->get('/api/mahasiswa/kewajiban-tarif', function() {
        $controller = new MahasiswaController();
        $controller->kewajibanTarif();
    });

    $router->get('/api/mahasiswa/tagihan-proses', function() {
        $controller = new TagihanController();
        $controller->getTagihan();
    });

    $router->get('/api/mahasiswa/tagihan/{tagihan_id}', function($tagihan_id) {
        $controller = new MahasiswaController();
        $controller->detailTagihan($tagihan_id);
    });

    // Notifikasi Endpoints
    $router->get('/api/mahasiswa/notifikasi', function() {
        $controller = new MahasiswaController();
        $controller->notifikasi();
    });

    $router->put('/api/mahasiswa/notifikasi/{notifikasi_id}/baca', function($notifikasi_id) {
        $controller = new MahasiswaController();
        $controller->bacaNotifikasi($notifikasi_id);
    });

    // KRS Status Endpoint
    $router->get('/api/mahasiswa/status-krs', function() {
        $controller = new MahasiswaController();
        $controller->statusKRS();
    });

    // Profil Mahasiswa Endpoint
    $router->get('/api/mahasiswa/profil', function() {
        $controller = new MahasiswaController();
        $controller->profil();
    });

    // ===== VIRTUAL ACCOUNT ENDPOINTS =====
    $router->post('/api/mahasiswa/tagihan/{tagihan_id}/buat-va', function($tagihan_id) {
        $controller = new VAController();
        $controller->buatVA($tagihan_id);
    });

    $router->get('/api/va/{va_id}/status', function($va_id) {
        $controller = new VAController();
        $controller->statusVA($va_id);
    });

    // ===== PEMBAYARAN ENDPOINTS =====
    $router->post('/api/mahasiswa/pembayaran/upload-bukti', function() {
        $controller = new PembayaranController();
        $controller->uploadBukti();
    });

    $router->get('/api/mahasiswa/pembayaran/riwayat', function() {
        $controller = new PembayaranController();
        $controller->riwayat();
    });

    // ===== CICILAN ENDPOINTS =====
    $router->get('/api/mahasiswa/cicilan/detail', function() {
        $controller = new CicilanController();
        $controller->detail();
    });

    $router->post('/api/cicilan/generate-cicilan-otomatis', function() {
        $controller = new CicilanController();
        $controller->generateOtomatis();
    });

    // ===== ADMIN UNIVERSITAS ENDPOINTS =====
    $router->get('/api/admin-universitas/dashboard-info', function() {
        $controller = new AdminUniversitasController();
        $controller->dashboardInfo();
    });

    $router->get('/api/admin-universitas/laporan-pembayaran', function() {
        $controller = new AdminUniversitasController();
        $controller->laporanPembayaran();
    });

    $router->get('/api/admin-universitas/monitoring-global', function() {
        $controller = new AdminUniversitasController();
        $controller->monitoringGlobal();
    });

    // Admin Universitas Pembayaran Endpoints (both paths for compatibility)
    $router->get('/api/admin-universitas/pembayaran/menunggu-validasi', function() {
        $controller = new AdminUniversitasController();
        $controller->menungguValidasi();
    });

    $router->get('/api/admin-universitas/pembayaran/{pembayaran_id}/detail', function($pembayaran_id) {
        $controller = new AdminUniversitasController();
        $controller->detailPembayaran($pembayaran_id);
    });

    $router->post('/api/admin-universitas/pembayaran/{pembayaran_id}/validasi', function($pembayaran_id) {
        $controller = new AdminUniversitasController();
        $controller->validasiPembayaran($pembayaran_id);
    });

    $router->get('/api/admin-universitas/pembayaran/riwayat', function() {
        $controller = new AdminUniversitasController();
        $controller->riwayat();
    });

    // Legacy endpoints (for backward compatibility)
    $router->get('/api/admin/pembayaran/menunggu-validasi', function() {
        $controller = new AdminUniversitasController();
        $controller->menungguValidasi();
    });

    $router->post('/api/admin/pembayaran/{pembayaran_id}/validasi', function($pembayaran_id) {
        $controller = new AdminUniversitasController();
        $controller->validasiPembayaran($pembayaran_id);
    });

    $router->get('/api/admin/pembayaran/riwayat', function() {
        $controller = new AdminUniversitasController();
        $controller->riwayat();
    });

    // ===== ADMIN FAKULTAS ENDPOINTS =====
    $router->get('/api/admin-fakultas/dashboard-info', function() {
        $controller = new AdminFakultasController();
        $controller->dashboardInfo();
    });

    $router->get('/api/admin-fakultas/daftar-pembayaran', function() {
        $controller = new AdminFakultasController();
        $controller->daftarPembayaran();
    });

    $router->get('/api/admin-fakultas/daftar-tagihan-validasi', function() {
        $controller = new AdminFakultasController();
        $controller->daftarTagihanValidasi();
    });

    $router->get('/api/admin-fakultas/monitoring-cicilan', function() {
        $controller = new AdminFakultasController();
        $controller->monitoringCicilan();
    });

    // KRS Management Endpoints
    $router->get('/api/admin-fakultas/krs/mahasiswa-layak', function() {
        $controller = new KRSController();
        $controller->mahasiswaLayakKRS();
    });

    $router->post('/api/admin-fakultas/krs/aktivasi', function() {
        $controller = new KRSController();
        $controller->aktivasiKRS();
    });

    $router->get('/api/admin-fakultas/riwayat-pembayaran', function() {
        $controller = new AdminFakultasController();
        $controller->riwayatPembayaran();
    });

    $router->get('/api/admin-fakultas/krs/mahasiswa-layak', function() {
        $controller = new AdminFakultasController();
        $controller->mahasiswaLayakKRS();
    });

    $router->post('/api/admin/krs/{mahasiswa_id}/aktivasi', function($mahasiswa_id) {
        $controller = new AdminFakultasController();
        $controller->aktivasiKRS($mahasiswa_id);
    });

    $router->post('/api/admin/krs/{mahasiswa_id}/deaktivasi', function($mahasiswa_id) {
        $controller = new AdminFakultasController();
        $controller->deaktivasiKRS($mahasiswa_id);
    });

    // Laporan Cicilan Endpoint
    $router->get('/api/admin-fakultas/laporan-cicilan/{mahasiswa_id}', function($mahasiswa_id) {
        $controller = new AdminFakultasController();
        $controller->laporanCicilan($mahasiswa_id);
    });

    // ===== TRIGGER ENDPOINTS =====
    $router->get('/api/trigger/auto-create-tagihan', function() {
        $controller = new TriggerController();
        $controller->autoCreateTagihan();
    });
}

