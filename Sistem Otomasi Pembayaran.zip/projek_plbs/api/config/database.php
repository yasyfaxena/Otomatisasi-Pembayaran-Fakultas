<?php
/**
 * Database Configuration
 * MySQL PDO Connection
 */

class Database {
    private $host = 'localhost';
    private $db_name = 'pembayaran_bpp_terpusat';
    private $username = 'root';
    private $password = '';
    private $charset = 'utf8mb4';
    
    private $pdo;

    public function connect() {
        $dsn = 'mysql:host=' . $this->host . ';dbname=' . $this->db_name . ';charset=' . $this->charset;
        
        $options = [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES => false,
        ];

        try {
            $this->pdo = new PDO($dsn, $this->username, $this->password, $options);
            return $this->pdo;
        } catch (PDOException $e) {
            http_response_code(500);
            echo json_encode([
                'status' => 'error',
                'message' => 'Database connection failed',
                'error_code' => 'DB_CONNECTION_ERROR',
                'timestamp' => date('c')
            ]);
            exit;
        }
    }

    public static function getInstance() {
        static $instance = null;
        if ($instance === null) {
            $db = new self();
            $instance = $db->connect();
        }
        return $instance;
    }
}