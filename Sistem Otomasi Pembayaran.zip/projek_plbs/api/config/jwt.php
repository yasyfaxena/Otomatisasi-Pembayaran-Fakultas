<?php
/**
 * JWT Configuration & Helper Functions
 */

class JWT {
    private static $secret_key = 'your-secret-key-change-in-production-2024-pembayaran-bpp';
    private static $algorithm = 'HS256';
    private static $token_expiration = 86400; // 24 hours

    /**
     * Generate JWT Token
     */
    public static function generate($data) {
        $header = [
            'alg' => self::$algorithm,
            'typ' => 'JWT'
        ];

        $payload = array_merge($data, [
            'iat' => time(),
            'exp' => time() + self::$token_expiration
        ]);

        $header_encoded = self::base64url_encode(json_encode($header));
        $payload_encoded = self::base64url_encode(json_encode($payload));
        
        $signature = hash_hmac(
            'sha256',
            $header_encoded . '.' . $payload_encoded,
            self::$secret_key,
            true
        );
        $signature_encoded = self::base64url_encode($signature);

        return $header_encoded . '.' . $payload_encoded . '.' . $signature_encoded;
    }

    /**
     * Verify & Decode JWT Token
     */
    public static function verify($token) {
        if (empty($token)) {
            return false;
        }

        $parts = explode('.', $token);
        if (count($parts) !== 3) {
            return false;
        }

        list($header_encoded, $payload_encoded, $signature_encoded) = $parts;

        // Verify signature
        $signature = hash_hmac(
            'sha256',
            $header_encoded . '.' . $payload_encoded,
            self::$secret_key,
            true
        );
        $signature_check = self::base64url_encode($signature);

        if ($signature_check !== $signature_encoded) {
            return false;
        }

        // Decode payload
        $payload = json_decode(self::base64url_decode($payload_encoded), true);

        // Check expiration
        if (isset($payload['exp']) && $payload['exp'] < time()) {
            return false;
        }

        return $payload;
    }

    /**
     * Base64 URL Encode
     */
    private static function base64url_encode($data) {
        return rtrim(strtr(base64_encode($data), '+/', '-_'), '=');
    }

    /**
     * Base64 URL Decode
     */
    private static function base64url_decode($data) {
        return base64_decode(strtr($data, '-_', '+/') . str_repeat('=', 4 - strlen($data) % 4));
    }

    /**
     * Get Token from Request Header
     */
    public static function getTokenFromHeader() {
        $headers = getallheaders();
        
        if (isset($headers['Authorization'])) {
            $auth_header = $headers['Authorization'];
            if (strpos($auth_header, 'Bearer ') === 0) {
                return substr($auth_header, 7);
            }
        }

        return null;
    }
}
