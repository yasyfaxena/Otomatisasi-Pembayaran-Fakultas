<?php
/**
 * Helper Functions
 */

// Clear opcache for this file
if (function_exists('opcache_invalidate')) {
    opcache_invalidate(__FILE__, true);
}

/**
 * Send JSON Response
 * ENSURES:
 * 1. Output buffering cleared
 * 2. Proper HTTP headers set
 * 3. Valid JSON always output
 * 4. No stray output before JSON
 */
function sendResponse($status, $message, $data = null, $error_code = null, $http_code = 200) {
    // STEP 1: Clear any buffered output to ensure clean response
    while (ob_get_level() > 0) {
        ob_end_clean();
    }
    
    // STEP 2: Set HTTP response code and headers
    http_response_code($http_code);
    
    // Ensure headers are set (may have been set in index.php, but set again to be safe)
    if (!headers_sent()) {
        header('Content-Type: application/json; charset=utf-8');
    }
    
    // STEP 3: Build response array
    $response = [
        'status' => $status,
        'message' => $message,
        'timestamp' => date('c')
    ];

    if ($data !== null) {
        $response['data'] = $data;
    }

    if ($error_code !== null) {
        $response['error_code'] = $error_code;
    }

    // STEP 4: Output valid JSON and terminate
    $json_output = json_encode($response, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    
    if ($json_output === false) {
        // Fallback if json_encode fails
        $json_output = json_encode([
            'status' => 'error',
            'message' => 'JSON encoding failed',
            'error_code' => 'JSON_ENCODE_FAILED',
            'timestamp' => date('c')
        ]);
    }
    
    echo $json_output;
    exit(0);
}

/**
 * Sanitize Input
 */
function sanitize($data) {
    if (is_array($data)) {
        return array_map('sanitize', $data);
    }
    return htmlspecialchars(trim($data), ENT_QUOTES, 'UTF-8');
}

/**
 * Get Input from Request
 */
function getInput($key = null, $method = 'POST') {
    $input = json_decode(file_get_contents('php://input'), true);

    if ($key === null) {
        return $input;
    }

    return $input[$key] ?? null;
}

/**
 * Validate Email
 */
function validateEmail($email) {
    return filter_var($email, FILTER_VALIDATE_EMAIL);
}

/**
 * Generate Unique VA Number
 * Format: 8805 + CUST_CODE (NIM)
 */
function generateVANumber($nim, $semester, $method) {
    $bank_code = '8805'; // BSI code
    $nim_partial = str_pad(substr($nim, -8), 8, '0', STR_PAD_LEFT);
    $random = str_pad(mt_rand(1, 99999), 5, '0', STR_PAD_LEFT);
    
    return $bank_code . ' ' . substr($nim_partial, 0, 4) . ' ' . substr($nim_partial, 4, 4) . ' ' . $random;
}

/**
 * Format Currency to Rupiah
 */
function formatRupiah($amount) {
    return 'Rp ' . number_format($amount, 0, ',', '.');
}

/**
 * Get Current Semester & Year
 */
function getCurrentSemesterInfo() {
    $month = (int) date('m');
    $year = (int) date('Y');
    
    // Semester 1: Ganjil (Jul-Dec), Semester 2: Genap (Jan-Jun)
    if ($month >= 7) {
        $semester = 1; // Ganjil
        $academic_year = $year . '/' . ($year + 1);
    } else {
        $semester = 2; // Genap
        $academic_year = ($year - 1) . '/' . $year;
    }

    return [
        'semester' => $semester,
        'tahun_akademik' => $academic_year
    ];
}

/**
 * Validate File Upload
 */
function validateFileUpload($file, $max_size = 5242880) { // 5MB
    $allowed_types = ['image/jpeg', 'image/png', 'application/pdf'];
    $file_error = null;

    if (!isset($file['tmp_name']) || !is_uploaded_file($file['tmp_name'])) {
        return ['valid' => false, 'error' => 'File not uploaded'];
    }

    if ($file['size'] > $max_size) {
        return ['valid' => false, 'error' => 'File size exceeds 5MB'];
    }

    $finfo = finfo_open(FILEINFO_MIME_TYPE);
    $mime_type = finfo_file($finfo, $file['tmp_name']);
    finfo_close($finfo);

    if (!in_array($mime_type, $allowed_types)) {
        return ['valid' => false, 'error' => 'File type not allowed. Only JPG, PNG, PDF'];
    }

    return ['valid' => true];
}

/**
 * Get Client IP Address
 */
function getClientIP() {
    if (!empty($_SERVER['HTTP_CLIENT_IP'])) {
        $ip = $_SERVER['HTTP_CLIENT_IP'];
    } elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
        $ip = $_SERVER['HTTP_X_FORWARDED_FOR'];
    } else {
        $ip = $_SERVER['REMOTE_ADDR'];
    }
    return filter_var($ip, FILTER_VALIDATE_IP);
}

/**
 * =====================================================
 * TAGIHAN MANAGEMENT FUNCTIONS (NEW)
 * =====================================================
 * Smart automatic tagihan creation based on payment history
 */

/**
 * Get Highest Paid BPP Semester for Student
 * Returns: semester number of highest paid BPP, or 0 if none paid
 * 
 * LOGIC:
 * - Query all LUNAS BPP tagihan for this mahasiswa
 * - Return MAX(semester) where status = 'lunas'
 * - If no lunas, return 0 (new student)
 */
function getHighestPaidBPPSemester($pdo, $mahasiswa_id) {
    $query = "SELECT MAX(semester) as highest_paid_semester
              FROM tagihan
              WHERE mahasiswa_id = :mahasiswa_id
                AND jenis_tagihan = 'BPP'
                AND status_pembayaran = 'lunas'";
    
    $stmt = $pdo->prepare($query);
    $stmt->execute(['mahasiswa_id' => $mahasiswa_id]);
    $result = $stmt->fetch();
    
    return (int) ($result['highest_paid_semester'] ?? 0);
}

/**
 * Get Next Unpaid BPP Semester
 * Returns: semester number of next unpaid BPP
 * 
 * LOGIC:
 * - If highest_paid_semester = 0 (new student) → return 1
 * - Else → return highest_paid_semester + 1
 */
function getNextUnpaidBPPSemester($pdo, $mahasiswa_id) {
    $highest_paid = getHighestPaidBPPSemester($pdo, $mahasiswa_id);
    return $highest_paid + 1;
}

/**
 * Check if Student is New (No Payment History)
 * Returns: TRUE if student has never paid any BPP
 */
function isNewStudent($pdo, $mahasiswa_id) {
    $query = "SELECT COUNT(*) as payment_count
              FROM tagihan
              WHERE mahasiswa_id = :mahasiswa_id
                AND status_pembayaran = 'lunas'";
    
    $stmt = $pdo->prepare($query);
    $stmt->execute(['mahasiswa_id' => $mahasiswa_id]);
    $result = $stmt->fetch();
    
    return ((int) $result['payment_count']) === 0;
}

/**
 * Auto-Create BPP Tagihan if Not Exists
 * 
 * LOGIC:
 * 1. Determine next unpaid BPP semester
 * 2. Check if tagihan already exists for this semester
 * 3. If not exists, create it (up to semester 8)
 */
function autoCreateBPPTagihan($pdo, $mahasiswa_id, $student_semester, $tahun_akademik, $prodi_id) {
    // STEP 1: Get next unpaid BPP semester
    $next_unpaid_semester = getNextUnpaidBPPSemester($pdo, $mahasiswa_id);
    error_log("[AUTO-CREATE] Mahasiswa {$mahasiswa_id}: next_unpaid_semester={$next_unpaid_semester}");
    
    // STEP 2: Don't create beyond semester 8
    if ($next_unpaid_semester > 8) {
        error_log("[AUTO-CREATE] Mahasiswa {$mahasiswa_id}: Skip, semester > 8");
        return null;
    }
    
    // STEP 3: Check if tagihan already exists for this semester (any status)
    $check_query = "SELECT tagihan_id, status_pembayaran FROM tagihan
                   WHERE mahasiswa_id = :mahasiswa_id
                     AND jenis_tagihan = 'BPP'
                     AND semester = :semester";
    
    $stmt = $pdo->prepare($check_query);
    $stmt->execute([
        'mahasiswa_id' => $mahasiswa_id,
        'semester' => $next_unpaid_semester
    ]);
    $existing = $stmt->fetch();
    
    if ($existing) {
        error_log("[AUTO-CREATE] Mahasiswa {$mahasiswa_id}: Tagihan semester {$next_unpaid_semester} exists, status={$existing['status_pembayaran']}");
    }
    
    // If exists AND not lunas, return it
    if ($existing && $existing['status_pembayaran'] !== 'lunas') {
        return $existing['tagihan_id'];
    }
    
    // If exists AND lunas, skip (already paid, don't recreate)
    if ($existing && $existing['status_pembayaran'] === 'lunas') {
        return null;
    }
    
    // STEP 4: Get tarif for this BPP semester (ignore tahun_akademik, use active tarif)
    $tarif_query = "SELECT tarif_id, nominal, tahun_akademik FROM tarif
                   WHERE prodi_id = :prodi_id
                     AND jenis_tagihan = 'BPP'
                     AND semester_dari <= :next_semester
                     AND semester_sampai >= :next_semester
                     AND is_active = TRUE
                   ORDER BY tahun_akademik DESC
                   LIMIT 1";
    
    $stmt = $pdo->prepare($tarif_query);
    $stmt->execute([
        'prodi_id' => $prodi_id,
        'next_semester' => $next_unpaid_semester
    ]);
    $tarif = $stmt->fetch();
    
    if (!$tarif) {
        error_log("[AUTO-CREATE] Mahasiswa {$mahasiswa_id}: No tarif found for prodi_id={$prodi_id}, semester={$next_unpaid_semester}");
        return null;
    }
    
    error_log("[AUTO-CREATE] Mahasiswa {$mahasiswa_id}: Found tarif, nominal={$tarif['nominal']}, tahun_akademik={$tarif['tahun_akademik']}");
    
    // STEP 5: Create tagihan automatically (use tahun_akademik from tarif)
    $insert_query = "INSERT INTO tagihan 
                    (mahasiswa_id, jenis_tagihan, semester, tahun_akademik, 
                     jumlah_tagihan, status_pembayaran, metode_pembayaran)
                    VALUES 
                    (:mahasiswa_id, 'BPP', :semester, :tahun_akademik, 
                     :jumlah_tagihan, 'belum_bayar', 'lunas')";
    
    $stmt = $pdo->prepare($insert_query);
    $stmt->execute([
        'mahasiswa_id' => $mahasiswa_id,
        'semester' => $next_unpaid_semester,
        'tahun_akademik' => $tarif['tahun_akademik'],
        'jumlah_tagihan' => $tarif['nominal']
    ]);
    
    $created_id = $pdo->lastInsertId();
    error_log("[AUTO-CREATE] Mahasiswa {$mahasiswa_id}: Created BPP tagihan_id={$created_id}, semester={$next_unpaid_semester}");
    
    return $created_id;
}

/**
 * Check if Student has Completed BPP Payment
 * Returns: TRUE if student has paid BPP up to specified semester
 * 
 * LOGIC:
 * - Check: All BPP tagihan from semester 1 to $target_semester have status = 'lunas'
 * - If YES → return TRUE (eligible for Proposal/Skripsi)
 * - If NO → return FALSE (not eligible yet)
 * - Don't filter by tahun_akademik to check all historical payments
 */
function hasPaidBPPToSemester($pdo, $mahasiswa_id, $target_semester) {
    // Count how many BPP semesters are paid (lunas)
    $query = "SELECT COUNT(DISTINCT semester) as paid_count
              FROM tagihan
              WHERE mahasiswa_id = :mahasiswa_id
                AND jenis_tagihan = 'BPP'
                AND status_pembayaran = 'lunas'
                AND semester <= :target_semester";
    
    $stmt = $pdo->prepare($query);
    $stmt->execute([
        'mahasiswa_id' => $mahasiswa_id,
        'target_semester' => $target_semester
    ]);
    $result = $stmt->fetch();

    // Should have all semesters 1 to target paid
    return ((int) $result['paid_count'] >= $target_semester);
}

/**
 * Auto-Create Proposal Tagihan if Eligible
 * 
 * CONDITIONS:
 * 1. Student must have paid BPP semester 6 (lunas)
 * 2. Proposal tagihan must not already exist
 */
function autoCreateProposalTagihan($pdo, $mahasiswa_id, $tahun_akademik, $prodi_id) {
    $check_query = "SELECT COUNT(*) as count FROM tagihan
                   WHERE mahasiswa_id = :mahasiswa_id AND jenis_tagihan = 'BPP'
                   AND semester = 6 AND status_pembayaran = 'lunas'";
    
    $stmt = $pdo->prepare($check_query);
    $stmt->execute(['mahasiswa_id' => $mahasiswa_id]);
    $result = $stmt->fetch();
    
    if ((int) $result['count'] === 0) {
        return null;
    }
    
    // STEP 2: Check if Proposal tagihan already exists (any status)
    $check_query = "SELECT tagihan_id FROM tagihan
                   WHERE mahasiswa_id = :mahasiswa_id
                     AND jenis_tagihan = 'PROPOSAL'";
    
    $stmt = $pdo->prepare($check_query);
    $stmt->execute([
        'mahasiswa_id' => $mahasiswa_id
    ]);
    $existing = $stmt->fetch();
    
    if ($existing) {
        return $existing['tagihan_id']; // Already exists
    }
    
    // STEP 3: Get Proposal tarif
    $tarif_query = "SELECT nominal FROM tarif
                   WHERE prodi_id = :prodi_id
                     AND jenis_tagihan = 'PROPOSAL'
                     AND tahun_akademik = :tahun_akademik
                     AND is_active = TRUE
                   LIMIT 1";
    
    $stmt = $pdo->prepare($tarif_query);
    $stmt->execute([
        'prodi_id' => $prodi_id,
        'tahun_akademik' => $tahun_akademik
    ]);
    $tarif = $stmt->fetch();
    
    if (!$tarif) {
        return null; // No tarif found
    }
    
    // STEP 4: Create Proposal tagihan
    $insert_query = "INSERT INTO tagihan 
                    (mahasiswa_id, jenis_tagihan, semester, tahun_akademik, 
                     jumlah_tagihan, status_pembayaran, metode_pembayaran)
                    VALUES 
                    (:mahasiswa_id, 'PROPOSAL', NULL, :tahun_akademik, 
                     :jumlah_tagihan, 'belum_bayar', 'lunas')";
    
    $stmt = $pdo->prepare($insert_query);
    $stmt->execute([
        'mahasiswa_id' => $mahasiswa_id,
        'tahun_akademik' => $tahun_akademik,
        'jumlah_tagihan' => $tarif['nominal']
    ]);
    
    return $pdo->lastInsertId();
}

/**
 * Auto-Create Skripsi Tagihan if Eligible
 * 
 * CONDITIONS:
 * 1. Student must have paid BPP semester 6 (lunas)
 * 2. Skripsi tagihan must not already exist
 */
function autoCreateSkripsiTagihan($pdo, $mahasiswa_id, $tahun_akademik, $prodi_id) {
    $check_query = "SELECT COUNT(*) as count FROM tagihan
                   WHERE mahasiswa_id = :mahasiswa_id AND jenis_tagihan = 'BPP'
                   AND semester = 6 AND status_pembayaran = 'lunas'";
    
    $stmt = $pdo->prepare($check_query);
    $stmt->execute(['mahasiswa_id' => $mahasiswa_id]);
    $result = $stmt->fetch();
    
    if ((int) $result['count'] === 0) {
        return null;
    }
    
    // STEP 2: Check if Skripsi tagihan already exists (any status)
    $check_query = "SELECT tagihan_id FROM tagihan
                   WHERE mahasiswa_id = :mahasiswa_id
                     AND jenis_tagihan = 'SKRIPSI'";
    
    $stmt = $pdo->prepare($check_query);
    $stmt->execute([
        'mahasiswa_id' => $mahasiswa_id
    ]);
    $existing = $stmt->fetch();
    
    if ($existing) {
        return $existing['tagihan_id']; // Already exists
    }
    
    // STEP 3: Get Skripsi tarif
    $tarif_query = "SELECT nominal FROM tarif
                   WHERE prodi_id = :prodi_id
                     AND jenis_tagihan = 'SKRIPSI'
                     AND tahun_akademik = :tahun_akademik
                     AND is_active = TRUE
                   LIMIT 1";
    
    $stmt = $pdo->prepare($tarif_query);
    $stmt->execute([
        'prodi_id' => $prodi_id,
        'tahun_akademik' => $tahun_akademik
    ]);
    $tarif = $stmt->fetch();
    
    if (!$tarif) {
        return null; // No tarif found
    }
    
    // STEP 4: Create Skripsi tagihan
    $insert_query = "INSERT INTO tagihan 
                    (mahasiswa_id, jenis_tagihan, semester, tahun_akademik, 
                     jumlah_tagihan, status_pembayaran, metode_pembayaran)
                    VALUES 
                    (:mahasiswa_id, 'SKRIPSI', NULL, :tahun_akademik, 
                     :jumlah_tagihan, 'belum_bayar', 'lunas')";
    
    $stmt = $pdo->prepare($insert_query);
    $stmt->execute([
        'mahasiswa_id' => $mahasiswa_id,
        'tahun_akademik' => $tahun_akademik,
        'jumlah_tagihan' => $tarif['nominal']
    ]);
    
    return $pdo->lastInsertId();
}

/**
 * Check if Student Has Any Active Unpaid Obligation
 * Returns: TRUE if student has any belum_bayar, cicilan, or cicilan_berjalan tagihan
 * 
 * CRITICAL: Must check for 'cicilan_berjalan' status which is set when first installment is paid
 * but tagihan is not yet fully paid (still has remaining balance)
 */
function hasUnpaidObligation($pdo, $mahasiswa_id) {
    $query = "SELECT COUNT(*) as unpaid_count
              FROM tagihan
              WHERE mahasiswa_id = :mahasiswa_id
                AND status_pembayaran != 'lunas'";
    
    $stmt = $pdo->prepare($query);
    $stmt->execute(['mahasiswa_id' => $mahasiswa_id]);
    $result = $stmt->fetch();
    
    return ((int) $result['unpaid_count']) > 0;
}

/**
 * ORCHESTRATOR: Proses Lengkap Penentuan dan Display Tagihan
 * 
 * Fungsi ini HARUS dijalankan PERTAMA setiap kali halaman Tagihan diakses,
 * SEBELUM query apa pun ke database dilakukan.
 * 
 * Proses:
 * 1. Ambil data mahasiswa login
 * 2. Hitung semester BPP pertama yang belum dibayar
 * 3. Query tabel tarif untuk semua jenis tagihan yang relevan
 * 4. Return complete tagihan data (dari tarif, bukan dari tabel tagihan)
 * 
 * @param PDO $pdo Database connection
 * @param int $mahasiswa_id ID mahasiswa yang login
 * 
 * @return array [
 *     'success' => bool,
 *     'message' => string,
 *     'data' => [
 *         'mahasiswa' => [...],
 *         'semester_wajib_bayar' => int,
 *         'tagihan_bpp' => [...],
 *         'tagihan_proposal' => [...] | null,
 *         'tagihan_skripsi' => [...] | null,
 *         'has_active_obligation' => bool
 *     ]
 * ]
 */
function getTagihanDataWithTarif($pdo, $mahasiswa_id) {
    try {
        // =============================================================
        // STEP 1: Ambil Data Mahasiswa yang Sedang Login
        // =============================================================
        $mahasiswa_query = "SELECT m.mahasiswa_id, m.fakultas_id, m.prodi_id, 
                                   m.semester_aktif, m.tahun_akademik_aktif, m.nama_mahasiswa
                            FROM mahasiswa m
                            WHERE m.mahasiswa_id = :mahasiswa_id
                            LIMIT 1";
        
        $stmt = $pdo->prepare($mahasiswa_query);
        $stmt->execute([':mahasiswa_id' => $mahasiswa_id]);
        $mahasiswa = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if (!$mahasiswa) {
            return [
                'success' => false,
                'message' => 'Mahasiswa tidak ditemukan',
                'data' => null
            ];
        }
        
        $fakultas_id = $mahasiswa['fakultas_id'];
        $prodi_id = $mahasiswa['prodi_id'];
        $semester_aktif = (int) $mahasiswa['semester_aktif'];
        $tahun_akademik = $mahasiswa['tahun_akademik_aktif'];
        
        // =============================================================
        // STEP 2: Hitung Semester BPP Pertama yang Belum Dibayar
        // =============================================================
        
        // 2a. Ambil Semester BPP Tertinggi yang Sudah Lunas
        $highest_paid_query = "SELECT MAX(t.semester) as max_semester
                               FROM tagihan t
                               WHERE t.mahasiswa_id = :mahasiswa_id
                                 AND t.jenis_tagihan = 'BPP'
                                 AND t.status_pembayaran = 'lunas'";
        
        $stmt = $pdo->prepare($highest_paid_query);
        $stmt->execute([':mahasiswa_id' => $mahasiswa_id]);
        $paid_result = $stmt->fetch(PDO::FETCH_ASSOC);
        $highest_paid_semester = $paid_result['max_semester'] ? (int) $paid_result['max_semester'] : 0;
        
        // 2b. Tentukan Semester Wajib Bayar
        $semester_wajib_bayar = $highest_paid_semester + 1;
        
        // 2c. Jika belum pernah bayar, set semester 1
        if ($highest_paid_semester === 0) {
            $semester_wajib_bayar = 1;
        }
        
        // 2d. Jika semester wajib bayar > semester aktif, gunakan semester aktif
        if ($semester_wajib_bayar > $semester_aktif) {
            $semester_wajib_bayar = $semester_aktif;
        }
        
        // =============================================================
        // STEP 3: Query Tabel TARIF untuk BPP Wajib Bayar (PRIORITAS TARIF)
        // =============================================================
        $tarif_bpp_query = "SELECT t.tarif_id, t.jenis_tagihan, t.semester_dari, 
                                   t.semester_sampai, t.nominal, t.tahun_akademik
                            FROM tarif t
                            WHERE t.prodi_id = :prodi_id
                              AND t.jenis_tagihan = 'BPP'
                              AND t.semester_dari <= :semester_wajib_bayar
                              AND t.semester_sampai >= :semester_wajib_bayar
                              AND t.tahun_akademik = :tahun_akademik
                              AND t.is_active = TRUE
                            LIMIT 1";
        
        $stmt = $pdo->prepare($tarif_bpp_query);
        $stmt->execute([
            ':prodi_id' => $prodi_id,
            ':semester_wajib_bayar' => $semester_wajib_bayar,
            ':tahun_akademik' => $tahun_akademik
        ]);
        $tarif_bpp = $stmt->fetch(PDO::FETCH_ASSOC);
        
        // =============================================================
        // STEP 4: Query TARIF untuk Proposal (jika syarat terpenuhi)
        // =============================================================
        $tarif_proposal = null;
        
        // Cek apakah BPP semester 6 sudah lunas
        $check_bpp6_query = "SELECT COUNT(*) as count
                             FROM tagihan t
                             WHERE t.mahasiswa_id = :mahasiswa_id
                               AND t.jenis_tagihan = 'BPP'
                               AND t.semester = 6
                               AND t.status_pembayaran = 'lunas'";
        
        $stmt = $pdo->prepare($check_bpp6_query);
        $stmt->execute([':mahasiswa_id' => $mahasiswa_id]);
        $bpp6_check = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if ((int) $bpp6_check['count'] > 0) {
            $tarif_proposal_query = "SELECT t.tarif_id, t.jenis_tagihan, t.nominal, t.tahun_akademik
                                     FROM tarif t
                                     WHERE t.prodi_id = :prodi_id
                                       AND t.jenis_tagihan = 'PROPOSAL'
                                       AND t.tahun_akademik = :tahun_akademik
                                       AND t.is_active = TRUE
                                     LIMIT 1";
            
            $stmt = $pdo->prepare($tarif_proposal_query);
            $stmt->execute([
                ':prodi_id' => $prodi_id,
                ':tahun_akademik' => $tahun_akademik
            ]);
            $tarif_proposal = $stmt->fetch(PDO::FETCH_ASSOC);
        }
        
        // =============================================================
        // STEP 5: Query TARIF untuk Skripsi (jika syarat terpenuhi)
        // =============================================================
        $tarif_skripsi = null;
        
        // Cek apakah BPP semester 7 sudah lunas
        $check_bpp7_query = "SELECT COUNT(*) as count
                             FROM tagihan t
                             WHERE t.mahasiswa_id = :mahasiswa_id
                               AND t.jenis_tagihan = 'BPP'
                               AND t.semester = 7
                               AND t.status_pembayaran = 'lunas'";
        
        $stmt = $pdo->prepare($check_bpp7_query);
        $stmt->execute([':mahasiswa_id' => $mahasiswa_id]);
        $bpp7_check = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if ((int) $bpp7_check['count'] > 0) {
            $tarif_skripsi_query = "SELECT t.tarif_id, t.jenis_tagihan, t.nominal, t.tahun_akademik
                                    FROM tarif t
                                    WHERE t.prodi_id = :prodi_id
                                      AND t.jenis_tagihan = 'SKRIPSI'
                                      AND t.tahun_akademik = :tahun_akademik
                                      AND t.is_active = TRUE
                                    LIMIT 1";
            
            $stmt = $pdo->prepare($tarif_skripsi_query);
            $stmt->execute([
                ':prodi_id' => $prodi_id,
                ':tahun_akademik' => $tahun_akademik
            ]);
            $tarif_skripsi = $stmt->fetch(PDO::FETCH_ASSOC);
        }
        
        // =============================================================
        // STEP 6: Tentukan Apakah Ada Kewajiban Aktif
        // =============================================================
        $has_active_obligation = false;
        
        if ($tarif_bpp) {
            $has_active_obligation = true;
        } elseif ($tarif_proposal) {
            $has_active_obligation = true;
        } elseif ($tarif_skripsi) {
            $has_active_obligation = true;
        }
        
        // =============================================================
        // STEP 7: Siapkan Hasil untuk Rendering
        // =============================================================
        return [
            'success' => true,
            'message' => $has_active_obligation ? 'Data tagihan berhasil diambil dari tarif' : 'Tidak ada tagihan aktif',
            'data' => [
                'mahasiswa' => [
                    'mahasiswa_id' => $mahasiswa['mahasiswa_id'],
                    'nama_mahasiswa' => $mahasiswa['nama_mahasiswa'],
                    'fakultas_id' => $mahasiswa['fakultas_id'],
                    'prodi_id' => $mahasiswa['prodi_id'],
                    'semester_aktif' => $mahasiswa['semester_aktif'],
                    'tahun_akademik_aktif' => $mahasiswa['tahun_akademik_aktif']
                ],
                'semester_wajib_bayar' => $semester_wajib_bayar,
                'highest_paid_semester' => $highest_paid_semester,
                'tagihan_bpp' => $tarif_bpp,
                'tagihan_proposal' => $tarif_proposal,
                'tagihan_skripsi' => $tarif_skripsi,
                'has_active_obligation' => $has_active_obligation
            ]
        ];
        
    } catch (Exception $e) {
        return [
            'success' => false,
            'message' => 'Error: ' . $e->getMessage(),
            'data' => null
        ];
    }
}