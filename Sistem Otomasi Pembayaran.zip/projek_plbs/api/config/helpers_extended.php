<?php
/**
 * Extended Helper Functions
 * Additional utility functions for production use
 */

/**
 * Log activity to file
 */
function logActivity($user_id, $action, $details = '', $ip_address = '') {
    $log_dir = __DIR__ . '/../logs';
    if (!is_dir($log_dir)) {
        mkdir($log_dir, 0755, true);
    }

    $log_file = $log_dir . '/activity_' . date('Y-m-d') . '.log';
    $timestamp = date('Y-m-d H:i:s');
    $log_message = sprintf(
        "[%s] User: %s | Action: %s | Details: %s | IP: %s\n",
        $timestamp,
        $user_id ?: 'GUEST',
        $action,
        $details,
        $ip_address ?: getClientIP()
    );

    file_put_contents($log_file, $log_message, FILE_APPEND);
}

/**
 * Send email notification
 */
function sendEmail($to, $subject, $body, $isHtml = true) {
    $headers = [];
    $headers[] = 'From: noreply@pembayaran-bpp.local';
    
    if ($isHtml) {
        $headers[] = 'Content-Type: text/html; charset=UTF-8';
    }

    return mail($to, $subject, $body, implode("\r\n", $headers));
}

/**
 * Generate random string
 */
function generateRandomString($length = 32) {
    return bin2hex(random_bytes($length / 2));
}

/**
 * Validate email format
 */
function validateEmail($email) {
    return filter_var($email, FILTER_VALIDATE_EMAIL) !== false;
}

/**
 * Validate phone number (Indonesia format)
 */
function validatePhoneNumber($phone) {
    $phone = preg_replace('/\D/', '', $phone);
    return (strlen($phone) >= 10 && strlen($phone) <= 13);
}

/**
 * Get HTTP client IP
 */
function getClientIP() {
    if (!empty($_SERVER['HTTP_CF_CONNECTING_IP'])) {
        return $_SERVER['HTTP_CF_CONNECTING_IP'];
    } elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
        $ips = explode(',', $_SERVER['HTTP_X_FORWARDED_FOR']);
        return trim($ips[0]);
    } elseif (!empty($_SERVER['REMOTE_ADDR'])) {
        return $_SERVER['REMOTE_ADDR'];
    }
    return '0.0.0.0';
}

/**
 * Check if API is in maintenance mode
 */
function isMaintenanceMode() {
    $maintenance_file = __DIR__ . '/../maintenance';
    return file_exists($maintenance_file);
}

/**
 * Format date to readable format
 */
function formatDate($date, $format = 'd-m-Y') {
    if ($date instanceof DateTime) {
        return $date->format($format);
    }
    return date($format, strtotime($date));
}

/**
 * Get days difference
 */
function daysDifference($date1, $date2) {
    $d1 = new DateTime($date1);
    $d2 = new DateTime($date2);
    return $d1->diff($d2)->days;
}

/**
 * Check if date is overdue
 */
function isOverdue($dueDate) {
    return strtotime($dueDate) < time();
}

/**
 * Parse pagination parameters
 */
function parsePagination() {
    $page = max(1, intval($_GET['page'] ?? 1));
    $limit = min(100, max(1, intval($_GET['limit'] ?? 10)));
    $offset = ($page - 1) * $limit;

    return [
        'page' => $page,
        'limit' => $limit,
        'offset' => $offset
    ];
}

/**
 * Build pagination response
 */
function buildPaginationResponse($total, $page, $limit) {
    $total_pages = ceil($total / $limit);

    return [
        'page' => $page,
        'limit' => $limit,
        'total' => $total,
        'total_pages' => $total_pages,
        'has_next' => $page < $total_pages,
        'has_prev' => $page > 1
    ];
}

/**
 * Sanitize input for HTML display
 */
function sanitizeOutput($data) {
    if (is_array($data)) {
        return array_map('sanitizeOutput', $data);
    }
    return htmlspecialchars($data, ENT_QUOTES, 'UTF-8');
}

/**
 * Generate invoice number
 */
function generateInvoiceNumber($prefix = 'INV') {
    return sprintf(
        '%s-%s-%s',
        $prefix,
        date('Ymd'),
        str_pad(mt_rand(1, 9999), 4, '0', STR_PAD_LEFT)
    );
}

/**
 * Generate reference number for transaction
 */
function generateReferenceNumber() {
    return sprintf(
        'REF-%s-%s',
        date('YmdHis'),
        str_pad(mt_rand(1, 999), 3, '0', STR_PAD_LEFT)
    );
}

/**
 * Check IP whitelist
 */
function isIPWhitelisted($ip = '', $whitelist = []) {
    if (empty($whitelist)) {
        return true;
    }

    $ip = $ip ?: getClientIP();

    foreach ($whitelist as $allowed) {
        if (strpos($allowed, '*') !== false) {
            $pattern = str_replace('\*', '.*', preg_quote($allowed));
            if (preg_match('/^' . $pattern . '$/', $ip)) {
                return true;
            }
        } else if ($ip === $allowed) {
            return true;
        }
    }

    return false;
}

/**
 * Rate limiting check
 */
function checkRateLimit($identifier, $limit = 100, $window = 3600) {
    $redis_key = 'ratelimit:' . $identifier;
    
    // Jika menggunakan Redis
    // $redis = new Redis();
    // $redis->connect('127.0.0.1', 6379);
    // $current = $redis->incr($redis_key);
    // if ($current === 1) {
    //     $redis->expire($redis_key, $window);
    // }
    // return $current <= $limit;

    // Fallback menggunakan file
    $cache_file = sys_get_temp_dir() . '/' . md5($redis_key);
    $now = time();

    if (file_exists($cache_file)) {
        $data = json_decode(file_get_contents($cache_file), true);
        
        if ($now - $data['time'] > $window) {
            $count = 1;
            file_put_contents($cache_file, json_encode(['count' => $count, 'time' => $now]));
            return true;
        }

        $count = $data['count'] + 1;
        file_put_contents($cache_file, json_encode(['count' => $count, 'time' => $data['time']]));
        return $count <= $limit;
    }

    file_put_contents($cache_file, json_encode(['count' => 1, 'time' => $now]));
    return true;
}

/**
 * Convert array to query string
 */
function arrayToQuery($array) {
    return http_build_query($array, '', '&', PHP_QUERY_RFC3986);
}

/**
 * Format seconds to readable time
 */
function formatSeconds($seconds) {
    $hours = floor($seconds / 3600);
    $minutes = floor(($seconds % 3600) / 60);
    $secs = $seconds % 60;

    $result = [];
    if ($hours > 0) {
        $result[] = $hours . ' jam';
    }
    if ($minutes > 0) {
        $result[] = $minutes . ' menit';
    }
    if ($secs > 0 || empty($result)) {
        $result[] = $secs . ' detik';
    }

    return implode(', ', $result);
}

/**
 * Get browser and OS info
 */
function getBrowserInfo() {
    $user_agent = $_SERVER['HTTP_USER_AGENT'];
    
    $browsers = ['Firefox', 'Chrome', 'Safari', 'Edge', 'Opera', 'MSIE', 'Trident'];
    $oss = ['Windows', 'Linux', 'Macintosh', 'Android', 'iPhone'];

    $browser = 'Unknown';
    $os = 'Unknown';

    foreach ($browsers as $b) {
        if (strpos($user_agent, $b) !== false) {
            $browser = $b;
            break;
        }
    }

    foreach ($oss as $o) {
        if (strpos($user_agent, $o) !== false) {
            $os = $o;
            break;
        }
    }

    return ['browser' => $browser, 'os' => $os];
}

/**
 * Hash string (alternative to password_hash for data)
 */
function hashData($data) {
    return hash_hmac('sha256', $data, $_ENV['JWT_SECRET'] ?? 'secret');
}

/**
 * Verify hashed data
 */
function verifyHashData($data, $hash) {
    return hash_equals(hashData($data), $hash);
}

/**
 * Deep array merge
 */
function arrayMergeDeep($base, $merge) {
    foreach ($merge as $key => $value) {
        if (is_array($value) && isset($base[$key]) && is_array($base[$key])) {
            $base[$key] = arrayMergeDeep($base[$key], $value);
        } else {
            $base[$key] = $value;
        }
    }
    return $base;
}

/**
 * Array filter by keys
 */
function arrayFilterByKeys($array, $keys) {
    return array_intersect_key($array, array_flip($keys));
}

/**
 * Convert object to array recursively
 */
function objectToArray($object) {
    if ($object instanceof stdClass || is_object($object)) {
        return json_decode(json_encode($object), true);
    }
    return $object;
}

/**
 * Generate barcode
 */
function generateBarcodeNumber() {
    return sprintf(
        '%s-%s-%s',
        date('ymd'),
        str_pad(mt_rand(1, 999), 3, '0', STR_PAD_LEFT),
        str_pad(mt_rand(1, 9999), 4, '0', STR_PAD_LEFT)
    );
}

?>
