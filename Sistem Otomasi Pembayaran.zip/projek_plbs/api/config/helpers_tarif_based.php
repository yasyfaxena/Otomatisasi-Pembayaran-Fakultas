<?php
/**
 * SISTEM PEMBAYARAN AKADEMIK - TARIF-BASED IMPLEMENTATION
 * New Helper Functions untuk Tarif-Based Approach
 * 
 * File: api/config/helpers_tarif_based.php
 * Date: 20 Desember 2025
 * 
 * PENDEKATAN BARU:
 * - Tarif adalah master data (source of truth)
 * - Tagihan hanya mencatat riwayat pembayaran
 * - Tidak ada auto-create tagihan di database
 * - Computation dilakukan runtime berdasarkan tarif
 */

// ============================================================================
// FUNCTION 1: GET ACTIVE TARIF BY PRODI
// ============================================================================

/**
 * Get all ACTIVE tarif for a specific prodi in a given year
 * These are the MASTER data of what's billable
 * 
 * @param PDO $pdo - Database connection
 * @param int $prodi_id - Program study ID
 * @param string $tahun_akademik - Academic year (format: 2024/2025)
 * @return array - All active tarif records for this prodi
 * 
 * USAGE:
 * $all_tarif = getActiveTarifByProdi($pdo, 1, '2024/2025');
 * // Result: Array of 10 items (BPP 1-8, Proposal, Skripsi)
 */
function getActiveTarifByProdi($pdo, $prodi_id, $tahun_akademik) {
    $query = "SELECT 
                tarif_id,
                jenis_tagihan,
                semester_dari,
                semester_sampai,
                nominal,
                is_active
              FROM tarif
              WHERE prodi_id = :prodi_id
                AND tahun_akademik = :tahun_akademik
                AND is_active = TRUE
              ORDER BY 
                CASE jenis_tagihan
                  WHEN 'BPP' THEN 1
                  WHEN 'Proposal' THEN 2
                  WHEN 'Skripsi' THEN 3
                  ELSE 99
                END ASC,
                semester_dari ASC";
    
    try {
        $stmt = $pdo->prepare($query);
        $stmt->execute([
            ':prodi_id' => (int) $prodi_id,
            ':tahun_akademik' => $tahun_akademik
        ]);
        
        $results = $stmt->fetchAll(PDO::FETCH_ASSOC);
        return $results ?: [];
        
    } catch (Exception $e) {
        error_log("Error in getActiveTarifByProdi: " . $e->getMessage());
        return [];
    }
}


// ============================================================================
// FUNCTION 2: FILTER TARIF BY ACADEMIC CONDITION
// ============================================================================

/**
 * Filter tarif based on mahasiswa's academic status and payment progress
 * 
 * RULES:
 * - BPP: Show only if semester <= semester_aktif
 * - Proposal: Show only if BPP 1-6 ALL paid (lunas)
 * - Skripsi: Show only if BPP 1-7 ALL paid (lunas)
 * 
 * @param PDO $pdo - Database connection
 * @param int $prodi_id - Program study
 * @param int $mahasiswa_id - Student ID
 * @param int $semester_aktif - Current semester of student
 * @param array $tarif_list - From getActiveTarifByProdi()
 * @return array - Filtered tarif (only applicable ones)
 * 
 * USAGE:
 * $filtered = filterTarifByAcademicCondition(
 *     $pdo, 1, 100, 5, $all_tarif
 * );
 * // Result: Applicable tarif for this mahasiswa
 */
function filterTarifByAcademicCondition(
    $pdo,
    $prodi_id,
    $mahasiswa_id,
    $semester_aktif,
    $tarif_list
) {
    if (empty($tarif_list)) {
        return [];
    }
    
    $filtered = [];
    
    foreach ($tarif_list as $tarif) {
        $jenis = $tarif['jenis_tagihan'];
        $semester = (int) ($tarif['semester_dari'] ?? 0);
        
        // RULE 1: BPP - Only if semester <= active semester
        if ($jenis === 'BPP') {
            if ($semester <= $semester_aktif) {
                $filtered[] = $tarif;
            }
            continue;
        }
        
        // RULE 2: Proposal - Only if paid BPP 1-6 ALL
        if ($jenis === 'Proposal') {
            if (hasPaidBPPToSemester($pdo, $mahasiswa_id, 6)) {
                $filtered[] = $tarif;
            }
            continue;
        }
        
        // RULE 3: Skripsi - Only if paid BPP 1-7 ALL
        if ($jenis === 'Skripsi') {
            if (hasPaidBPPToSemester($pdo, $mahasiswa_id, 7)) {
                $filtered[] = $tarif;
            }
            continue;
        }
        
        // Default: Include other types
        $filtered[] = $tarif;
    }
    
    return $filtered;
}


// ============================================================================
// FUNCTION 3: GET PAYMENT STATUS FOR TARIF
// ============================================================================

/**
 * Get payment status for a specific tarif item from payment history
 * 
 * Checks tabel tagihan for payment record:
 * - If found → return actual status from tagihan (belum_bayar/cicilan/lunas)
 * - If NOT found → return 'belum_bayar' (default)
 * 
 * @param PDO $pdo - Database connection
 * @param int $mahasiswa_id - Student ID
 * @param string $jenis_tagihan - Type: BPP, Proposal, Skripsi
 * @param int|null $semester - Semester (NULL for Proposal/Skripsi)
 * @param string $tahun_akademik - Academic year
 * @return string - Payment status: belum_bayar/cicilan/lunas
 * 
 * USAGE:
 * $status = getPaymentStatusForTarif($pdo, 100, 'BPP', 1, '2024/2025');
 * // Result: 'belum_bayar' or 'cicilan' or 'lunas'
 */
function getPaymentStatusForTarif(
    $pdo,
    $mahasiswa_id,
    $jenis_tagihan,
    $semester,
    $tahun_akademik
) {
    $query = "SELECT status_pembayaran
              FROM tagihan
              WHERE mahasiswa_id = :mahasiswa_id
                AND jenis_tagihan = :jenis
                AND tahun_akademik = :tahun";
    
    // For BPP: include semester in WHERE
    if ($semester !== null) {
        $query .= " AND semester = :semester";
    } else {
        // For Proposal/Skripsi: no semester filter
        $query .= " AND (semester IS NULL OR semester = 0)";
    }
    
    $query .= " LIMIT 1";
    
    try {
        $stmt = $pdo->prepare($query);
        
        $params = [
            ':mahasiswa_id' => (int) $mahasiswa_id,
            ':jenis' => $jenis_tagihan,
            ':tahun' => $tahun_akademik
        ];
        
        if ($semester !== null) {
            $params[':semester'] = (int) $semester;
        }
        
        $stmt->execute($params);
        $result = $stmt->fetch(PDO::FETCH_ASSOC);
        
        // If found in tagihan table: return actual status
        if ($result && !empty($result['status_pembayaran'])) {
            return $result['status_pembayaran'];
        }
        
        // If NOT found: default is belum_bayar
        return 'belum_bayar';
        
    } catch (Exception $e) {
        error_log("Error in getPaymentStatusForTarif: " . $e->getMessage());
        return 'belum_bayar';  // Safe default
    }
}


// ============================================================================
// FUNCTION 4: BUILD COMPLETE TAGIHAN LIST (MAIN ORCHESTRATOR)
// ============================================================================

/**
 * MAIN ORCHESTRATOR FUNCTION
 * 
 * Combine tarif (master) + payment status (riwayat)
 * Result: Complete obligation list untuk mahasiswa
 * 
 * PROCESS:
 * 1. Get master tarif data
 * 2. Filter by academic condition
 * 3. Get payment status from history
 * 4. Build complete item with all data
 * 5. Sort appropriately
 * 
 * @param PDO $pdo - Database connection
 * @param int $mahasiswa_id - Student ID
 * @param int $prodi_id - Program study
 * @param int $semester_aktif - Current semester
 * @param string $tahun_akademik - Academic year
 * @return array - Complete tagihan list ready for display
 * 
 * USAGE:
 * $tagihan_list = buildCompleteTagihanList($pdo, 100, 1, 5, '2024/2025');
 * // Result: [{jenis, semester, nominal, status}, ...]
 */
function buildCompleteTagihanList(
    $pdo,
    $mahasiswa_id,
    $prodi_id,
    $semester_aktif,
    $tahun_akademik
) {
    // STEP 1: Get master tarif data from database
    $all_tarif = getActiveTarifByProdi(
        $pdo,
        $prodi_id,
        $tahun_akademik
    );
    
    // If no tarif defined for this prodi/year: no obligations
    if (empty($all_tarif)) {
        return [];
    }
    
    // STEP 2: Filter by academic condition
    $applicable_tarif = filterTarifByAcademicCondition(
        $pdo,
        $prodi_id,
        $mahasiswa_id,
        $semester_aktif,
        $all_tarif
    );
    
    // STEP 3: Build complete list with payment status
    $complete_list = [];
    
    foreach ($applicable_tarif as $tarif) {
        
        // Get payment status from history (tabel tagihan)
        $status = getPaymentStatusForTarif(
            $pdo,
            $mahasiswa_id,
            $tarif['jenis_tagihan'],
            (int) ($tarif['semester_dari'] ?? null),
            $tahun_akademik
        );
        
        // Build item for this tarif
        $item = [
            'jenis_tagihan' => $tarif['jenis_tagihan'],
            'semester' => (int) ($tarif['semester_dari'] ?? null),
            'tahun_akademik' => $tahun_akademik,
            'nominal' => (int) $tarif['nominal'],
            'status_pembayaran' => $status,
            'tarif_id' => (int) $tarif['tarif_id'],
            // Meta: indicate this comes from tarif
            'source' => 'tarif'
        ];
        
        $complete_list[] = $item;
    }
    
    // STEP 4: Sort by type and semester
    usort($complete_list, function($a, $b) {
        // BPP first, then Proposal, then Skripsi
        $order = ['BPP' => 1, 'Proposal' => 2, 'Skripsi' => 3];
        $order_a = $order[$a['jenis_tagihan']] ?? 99;
        $order_b = $order[$b['jenis_tagihan']] ?? 99;
        
        if ($order_a !== $order_b) {
            return $order_a - $order_b;
        }
        
        // Then by semester (ascending, nulls last)
        $sem_a = $a['semester'] ?? 999;
        $sem_b = $b['semester'] ?? 999;
        
        return $sem_a - $sem_b;
    });
    
    return $complete_list;
}


// ============================================================================
// HELPER: Check if student has any applicable tarif
// ============================================================================

/**
 * Check if there are ANY applicable tarif for this student
 * Used to determine if "no active billing" message should show
 * 
 * @param PDO $pdo
 * @param int $mahasiswa_id
 * @param int $prodi_id
 * @param int $semester_aktif
 * @param string $tahun_akademik
 * @return bool - TRUE if has applicable tarif, FALSE if no tarif
 */
function hasApplicableTarif(
    $pdo,
    $mahasiswa_id,
    $prodi_id,
    $semester_aktif,
    $tahun_akademik
) {
    $tarif_list = buildCompleteTagihanList(
        $pdo,
        $mahasiswa_id,
        $prodi_id,
        $semester_aktif,
        $tahun_akademik
    );
    
    return !empty($tarif_list);
}


// ============================================================================
// FUNCTION: Check if student has unpaid obligations
// ============================================================================

/**
 * Check if student has ANY unpaid obligation from applicable tarif
 * Used for: Dashboard display logic
 * 
 * @param PDO $pdo
 * @param int $mahasiswa_id
 * @param int $prodi_id
 * @param int $semester_aktif
 * @param string $tahun_akademik
 * @return bool - TRUE if has unpaid, FALSE if all complete
 */
function hasUnpaidFromTarif(
    $pdo,
    $mahasiswa_id,
    $prodi_id,
    $semester_aktif,
    $tahun_akademik
) {
    $tarif_list = buildCompleteTagihanList(
        $pdo,
        $mahasiswa_id,
        $prodi_id,
        $semester_aktif,
        $tahun_akademik
    );
    
    // Check if ANY tarif item has status != lunas
    foreach ($tarif_list as $item) {
        if ($item['status_pembayaran'] !== 'lunas') {
            return true;  // Has unpaid
        }
    }
    
    return false;  // All lunas or no tarif
}


// ============================================================================
// MAINTENANCE: Support existing functions (deprecated but kept)
// ============================================================================

/**
 * DEPRECATED: getHighestPaidBPPSemester()
 * 
 * Note: Not used in new tarif-based approach
 * Kept for backward compatibility only
 * 
 * This function queries tagihan for highest paid BPP semester.
 * In new approach, we check tarif instead.
 */
if (!function_exists('getHighestPaidBPPSemester')) {
    function getHighestPaidBPPSemester($pdo, $mahasiswa_id) {
        $query = "SELECT MAX(semester) as highest_paid_semester
                  FROM tagihan
                  WHERE mahasiswa_id = :mahasiswa_id
                    AND jenis_tagihan = 'BPP'
                    AND status_pembayaran = 'lunas'";
        
        try {
            $stmt = $pdo->prepare($query);
            $stmt->execute([':mahasiswa_id' => (int) $mahasiswa_id]);
            $result = $stmt->fetch();
            
            return (int) ($result['highest_paid_semester'] ?? 0);
        } catch (Exception $e) {
            return 0;
        }
    }
}


/**
 * DEPRECATED: hasPaidBPPToSemester()
 * 
 * Note: Still used in filterTarifByAcademicCondition() to check
 * eligibility for Proposal and Skripsi
 * 
 * Checks if ALL BPP payments 1 to target_semester are marked lunas
 */
if (!function_exists('hasPaidBPPToSemester')) {
    function hasPaidBPPToSemester($pdo, $mahasiswa_id, $target_semester) {
        $query = "SELECT COUNT(*) as unpaid_count
                  FROM tagihan
                  WHERE mahasiswa_id = :mahasiswa_id
                    AND jenis_tagihan = 'BPP'
                    AND semester <= :target_semester
                    AND status_pembayaran != 'lunas'";
        
        try {
            $stmt = $pdo->prepare($query);
            $stmt->execute([
                ':mahasiswa_id' => (int) $mahasiswa_id,
                ':target_semester' => (int) $target_semester
            ]);
            $result = $stmt->fetch();
            
            return (int) $result['unpaid_count'] === 0;
        } catch (Exception $e) {
            return false;
        }
    }
}

?>
