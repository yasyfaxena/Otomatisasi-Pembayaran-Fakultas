<?php
/**
 * TieredBillingService
 * Handle automatic creation of tiered billing
 * 
 * CRITICAL RULES:
 * 1. Semester 1-6: After LUNAS → create Semester N+1
 * 2. Semester 6 LUNAS → Create PROPOSAL
 * 3. PROPOSAL LUNAS → Create SEMESTER 7
 * 4. SEMESTER 7 LUNAS → Create SKRIPSI
 * 5. NO JUMPS - must follow order strictly
 * 6. Only ONE active tagihan per mahasiswa at a time
 */

class TieredBillingService {
    private $pdo;
    
    public function __construct($pdo) {
        $this->pdo = $pdo;
    }
    
    /**
     * Auto-create next tagihan when current is marked LUNAS
     * Called after a tagihan is marked as LUNAS
     */
    public function createNextTagihan($mahasiswa_id) {
        try {
            error_log("[TieredBillingService] createNextTagihan for mahasiswa_id=$mahasiswa_id");
            
            // Get mahasiswa info
            $mahasiswa = $this->getMahasiswaInfo($mahasiswa_id);
            if (!$mahasiswa) {
                error_log("[TieredBillingService] Mahasiswa not found");
                return false;
            }
            
            // Get the last lunas tagihan
            $last_lunas = $this->getLastLunasTagihan($mahasiswa_id);
            error_log("[TieredBillingService] Last lunas tagihan: " . json_encode($last_lunas));
            
            if (!$last_lunas) {
                error_log("[TieredBillingService] No lunas tagihan found");
                return false;
            }
            
            // Determine what to create next
            if ($last_lunas['jenis_tagihan'] === 'BPP') {
                if ($last_lunas['semester'] < 6) {
                    // Create next BPP semester
                    return $this->createBPPTagihan($mahasiswa, $last_lunas['semester'] + 1);
                } elseif ($last_lunas['semester'] == 6) {
                    // Create PROPOSAL
                    return $this->createProposalTagihan($mahasiswa);
                }
            } elseif ($last_lunas['jenis_tagihan'] === 'Proposal') {
                // Create SEMESTER 7
                return $this->createBPPTagihan($mahasiswa, 7);
            } elseif ($last_lunas['jenis_tagihan'] === 'Skripsi') {
                // No more tagihan after skripsi
                error_log("[TieredBillingService] Skripsi is final");
                return false;
            }
            
            return false;
            
        } catch (Exception $e) {
            error_log("[TieredBillingService] ERROR: " . $e->getMessage());
            return false;
        }
    }
    
    /**
     * Create BPP tagihan for a specific semester
     */
    private function createBPPTagihan($mahasiswa, $semester) {
        try {
            error_log("[TieredBillingService] Creating BPP tagihan for semester=$semester");
            
            // Check if tagihan already exists
            $existing = $this->checkTagihanExists($mahasiswa['mahasiswa_id'], 'BPP', $semester);
            if ($existing) {
                error_log("[TieredBillingService] BPP semester $semester already exists");
                return false;
            }
            
            // Get tarif
            $tarif = $this->getTarif($mahasiswa, 'BPP', $semester);
            if (!$tarif) {
                error_log("[TieredBillingService] Tarif BPP semester $semester not found");
                return false;
            }
            
            // Create tagihan
            $stmt = $this->pdo->prepare(
                "INSERT INTO tagihan (mahasiswa_id, jenis_tagihan, semester, tahun_akademik, jumlah_tagihan, status_pembayaran, metode_pembayaran)
                 VALUES (:mahasiswa_id, 'BPP', :semester, :tahun_akademik, :jumlah, 'belum_bayar', 'lunas')"
            );
            
            $result = $stmt->execute([
                'mahasiswa_id' => $mahasiswa['mahasiswa_id'],
                'semester' => $semester,
                'tahun_akademik' => $mahasiswa['tahun_akademik'],
                'jumlah' => $tarif['nominal']
            ]);
            
            if ($result) {
                $tagihan_id = $this->pdo->lastInsertId();
                error_log("[TieredBillingService] BPP semester $semester created with ID=$tagihan_id");
                return $tagihan_id;
            }
            
            return false;
            
        } catch (Exception $e) {
            error_log("[TieredBillingService] ERROR creating BPP: " . $e->getMessage());
            return false;
        }
    }
    
    /**
     * Create PROPOSAL tagihan
     */
    private function createProposalTagihan($mahasiswa) {
        try {
            error_log("[TieredBillingService] Creating PROPOSAL tagihan");
            
            // Check if proposal already exists
            $existing = $this->checkTagihanExists($mahasiswa['mahasiswa_id'], 'Proposal', null);
            if ($existing) {
                error_log("[TieredBillingService] Proposal already exists");
                return false;
            }
            
            // Get tarif
            $tarif = $this->getTarif($mahasiswa, 'Proposal');
            if (!$tarif) {
                error_log("[TieredBillingService] Tarif Proposal not found");
                return false;
            }
            
            // Create tagihan
            $stmt = $this->pdo->prepare(
                "INSERT INTO tagihan (mahasiswa_id, jenis_tagihan, tahun_akademik, jumlah_tagihan, status_pembayaran, metode_pembayaran)
                 VALUES (:mahasiswa_id, 'Proposal', :tahun_akademik, :jumlah, 'belum_bayar', 'lunas')"
            );
            
            $result = $stmt->execute([
                'mahasiswa_id' => $mahasiswa['mahasiswa_id'],
                'tahun_akademik' => $mahasiswa['tahun_akademik'],
                'jumlah' => $tarif['nominal']
            ]);
            
            if ($result) {
                $tagihan_id = $this->pdo->lastInsertId();
                error_log("[TieredBillingService] Proposal created with ID=$tagihan_id");
                return $tagihan_id;
            }
            
            return false;
            
        } catch (Exception $e) {
            error_log("[TieredBillingService] ERROR creating Proposal: " . $e->getMessage());
            return false;
        }
    }
    
    /**
     * Create SKRIPSI tagihan
     */
    private function createSkripsiTagihan($mahasiswa) {
        try {
            error_log("[TieredBillingService] Creating SKRIPSI tagihan");
            
            // Check if skripsi already exists
            $existing = $this->checkTagihanExists($mahasiswa['mahasiswa_id'], 'Skripsi', null);
            if ($existing) {
                error_log("[TieredBillingService] Skripsi already exists");
                return false;
            }
            
            // Get tarif
            $tarif = $this->getTarif($mahasiswa, 'Skripsi');
            if (!$tarif) {
                error_log("[TieredBillingService] Tarif Skripsi not found");
                return false;
            }
            
            // Create tagihan
            $stmt = $this->pdo->prepare(
                "INSERT INTO tagihan (mahasiswa_id, jenis_tagihan, tahun_akademik, jumlah_tagihan, status_pembayaran, metode_pembayaran)
                 VALUES (:mahasiswa_id, 'Skripsi', :tahun_akademik, :jumlah, 'belum_bayar', 'lunas')"
            );
            
            $result = $stmt->execute([
                'mahasiswa_id' => $mahasiswa['mahasiswa_id'],
                'tahun_akademik' => $mahasiswa['tahun_akademik'],
                'jumlah' => $tarif['nominal']
            ]);
            
            if ($result) {
                $tagihan_id = $this->pdo->lastInsertId();
                error_log("[TieredBillingService] Skripsi created with ID=$tagihan_id");
                return $tagihan_id;
            }
            
            return false;
            
        } catch (Exception $e) {
            error_log("[TieredBillingService] ERROR creating Skripsi: " . $e->getMessage());
            return false;
        }
    }
    
    // ============================================
    // HELPER FUNCTIONS
    // ============================================
    
    private function getMahasiswaInfo($mahasiswa_id) {
        $stmt = $this->pdo->prepare(
            "SELECT m.*, u.nama_lengkap FROM mahasiswa m 
             JOIN users u ON m.user_id = u.user_id
             WHERE m.mahasiswa_id = :id LIMIT 1"
        );
        $stmt->execute(['id' => $mahasiswa_id]);
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }
    
    private function getLastLunasTagihan($mahasiswa_id) {
        // Get the latest lunas tagihan in proper order
        // Priority: Highest semester for BPP, then Proposal, then anything else
        $stmt = $this->pdo->prepare(
            "SELECT * FROM tagihan 
             WHERE mahasiswa_id = :mahasiswa_id 
             AND status_pembayaran = 'lunas'
             ORDER BY 
                CASE 
                    WHEN jenis_tagihan = 'BPP' THEN 1 
                    WHEN jenis_tagihan = 'Proposal' THEN 2 
                    WHEN jenis_tagihan = 'Skripsi' THEN 3 
                    ELSE 4 
                END DESC,
                CASE WHEN jenis_tagihan = 'BPP' THEN semester ELSE 0 END DESC,
                created_at DESC
             LIMIT 1"
        );
        $stmt->execute(['mahasiswa_id' => $mahasiswa_id]);
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }
    
    private function checkTagihanExists($mahasiswa_id, $jenis_tagihan, $semester = null) {
        if ($semester !== null) {
            $stmt = $this->pdo->prepare(
                "SELECT COUNT(*) as count FROM tagihan 
                 WHERE mahasiswa_id = :mahasiswa_id AND jenis_tagihan = :jenis AND semester = :semester"
            );
            $stmt->execute([
                'mahasiswa_id' => $mahasiswa_id,
                'jenis' => $jenis_tagihan,
                'semester' => $semester
            ]);
        } else {
            $stmt = $this->pdo->prepare(
                "SELECT COUNT(*) as count FROM tagihan 
                 WHERE mahasiswa_id = :mahasiswa_id AND jenis_tagihan = :jenis"
            );
            $stmt->execute([
                'mahasiswa_id' => $mahasiswa_id,
                'jenis' => $jenis_tagihan
            ]);
        }
        
        $result = $stmt->fetch(PDO::FETCH_ASSOC);
        return (int)$result['count'] > 0;
    }
    
    private function getTarif($mahasiswa, $jenis_tagihan, $semester = null) {
        if ($jenis_tagihan === 'BPP') {
            $stmt = $this->pdo->prepare(
                "SELECT nominal FROM tarif 
                 WHERE prodi_id = :prodi_id 
                 AND jenis_tagihan = 'BPP'
                 AND semester_dari <= :semester 
                 AND semester_sampai >= :semester
                 AND tahun_akademik = :tahun_akademik
                 AND is_active = 1
                 LIMIT 1"
            );
            $stmt->execute([
                'prodi_id' => $mahasiswa['prodi_id'],
                'semester' => $semester,
                'tahun_akademik' => $mahasiswa['tahun_akademik']
            ]);
        } else {
            $stmt = $this->pdo->prepare(
                "SELECT nominal FROM tarif 
                 WHERE prodi_id = :prodi_id 
                 AND jenis_tagihan = :jenis
                 AND tahun_akademik = :tahun_akademik
                 AND is_active = 1
                 LIMIT 1"
            );
            $stmt->execute([
                'prodi_id' => $mahasiswa['prodi_id'],
                'jenis' => $jenis_tagihan,
                'tahun_akademik' => $mahasiswa['tahun_akademik']
            ]);
        }
        
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }
}
?>
