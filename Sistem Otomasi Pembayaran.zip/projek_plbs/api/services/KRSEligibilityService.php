<?php
/**
 * KRSEligibilityService
 * Handle KRS activation eligibility and logic
 * 
 * CRITICAL RULE:
 * Mahasiswa can activate KRS if:
 * 1. tagihan.status_pembayaran = 'lunas' OR tagihan.status_pembayaran = 'cicilan_berjalan'
 * 2. krs.status_krs = 'belum_aktif' or doesn't exist
 * 3. fakultas matches admin_fakultas
 */

class KRSEligibilityService {
    private $pdo;
    
    public function __construct($pdo) {
        $this->pdo = $pdo;
    }
    
    /**
     * Get list of students eligible for KRS activation
     * (Those with cicilan_berjalan OR lunas, and no active KRS)
     */
    public function getMahasiswaLayakKRS($admin_id, $fakultas_id) {
        try {
            error_log("[KRSEligibilityService] Getting mahasiswa layak KRS for fakultas_id=$fakultas_id");
            
            // Get mahasiswa dengan active tagihan yang status = lunas OR cicilan_berjalan
            // AND belum ada KRS aktif
            $query = "
                SELECT 
                    m.mahasiswa_id, 
                    m.nim, 
                    u.nama_lengkap, 
                    ps.nama_prodi,
                    f.nama_fakultas,
                    t.tagihan_id,
                    t.semester,
                    t.status_pembayaran,
                    t.tahun_akademik,
                    k.krs_id,
                    k.status_krs
                FROM mahasiswa m
                JOIN users u ON m.user_id = u.user_id
                JOIN program_studi ps ON m.prodi_id = ps.prodi_id
                JOIN fakultas f ON ps.fakultas_id = f.fakultas_id
                JOIN tagihan t ON m.mahasiswa_id = t.mahasiswa_id
                LEFT JOIN krs k ON m.mahasiswa_id = k.mahasiswa_id 
                    AND k.semester = t.semester 
                    AND k.tahun_akademik = t.tahun_akademik
                WHERE f.fakultas_id = :fakultas_id
                AND t.status_pembayaran IN ('lunas', 'cicilan_berjalan')
                AND (k.status_krs IS NULL OR k.status_krs = 'pending')
                AND t.jenis_tagihan = 'BPP'
                AND u.role = 'mahasiswa'
                ORDER BY t.updated_at DESC
            ";
            
            $stmt = $this->pdo->prepare($query);
            $stmt->execute(['fakultas_id' => $fakultas_id]);
            $results = $stmt->fetchAll(PDO::FETCH_ASSOC);
            
            error_log("[KRSEligibilityService] Found " . count($results) . " eligible students");
            
            return [
                'status' => 'success',
                'mahasiswa' => array_map(function($m) {
                    return [
                        'mahasiswa_id' => $m['mahasiswa_id'],
                        'nim' => $m['nim'],
                        'nama_lengkap' => $m['nama_lengkap'],
                        'prodi' => $m['nama_prodi'],
                        'fakultas' => $m['nama_fakultas'],
                        'tagihan_id' => $m['tagihan_id'],
                        'semester' => (int)$m['semester'],
                        'tahun_akademik' => $m['tahun_akademik'],
                        'status_pembayaran' => $m['status_pembayaran'],
                        'krs_status' => $m['krs_id'] ? $m['status_krs'] : 'belum_buat'
                    ];
                }, $results)
            ];
            
        } catch (Exception $e) {
            error_log("[KRSEligibilityService] ERROR: " . $e->getMessage());
            return [
                'status' => 'error',
                'message' => 'Gagal mengambil daftar mahasiswa',
                'code' => 'FETCH_FAILED'
            ];
        }
    }
    
    /**
     * Check if mahasiswa is eligible for KRS activation
     */
    public function isEligible($mahasiswa_id, $semester, $tahun_akademik, $facultas_id) {
        try {
            error_log("[KRSEligibilityService] Checking eligibility for mahasiswa=$mahasiswa_id, semester=$semester");
            
            // Get active tagihan for this semester
            $query = "
                SELECT t.*, m.mahasiswa_id, ps.fakultas_id
                FROM tagihan t
                JOIN mahasiswa m ON t.mahasiswa_id = m.mahasiswa_id
                JOIN program_studi ps ON m.prodi_id = ps.prodi_id
                WHERE m.mahasiswa_id = :mahasiswa_id
                AND t.semester = :semester
                AND t.tahun_akademik = :tahun_akademik
                AND t.jenis_tagihan = 'BPP'
                LIMIT 1
            ";
            
            $stmt = $this->pdo->prepare($query);
            $stmt->execute([
                'mahasiswa_id' => $mahasiswa_id,
                'semester' => $semester,
                'tahun_akademik' => $tahun_akademik
            ]);
            $tagihan = $stmt->fetch(PDO::FETCH_ASSOC);
            
            if (!$tagihan) {
                error_log("[KRSEligibilityService] No tagihan found");
                return false;
            }
            
            // Check if fakultas matches
            if ($tagihan['fakultas_id'] != $facultas_id) {
                error_log("[KRSEligibilityService] Fakultas mismatch");
                return false;
            }
            
            // Check if status is lunas or cicilan_berjalan
            $eligible = in_array($tagihan['status_pembayaran'], ['lunas', 'cicilan_berjalan']);
            error_log("[KRSEligibilityService] Status={$tagihan['status_pembayaran']}, Eligible=$eligible");
            
            return $eligible;
            
        } catch (Exception $e) {
            error_log("[KRSEligibilityService] ERROR checking eligibility: " . $e->getMessage());
            return false;
        }
    }
    
    /**
     * Activate KRS for student
     */
    public function aktivasiKRS($mahasiswa_id, $semester, $tahun_akademik, $admin_id, $facultas_id) {
        try {
            error_log("[KRSEligibilityService] Activating KRS for mahasiswa=$mahasiswa_id, semester=$semester");
            
            // Verify eligibility
            if (!$this->isEligible($mahasiswa_id, $semester, $tahun_akademik, $facultas_id)) {
                error_log("[KRSEligibilityService] Student not eligible for KRS");
                return [
                    'status' => 'error',
                    'message' => 'Mahasiswa tidak memenuhi syarat aktivasi KRS',
                    'code' => 'NOT_ELIGIBLE'
                ];
            }
            
            $this->pdo->beginTransaction();
            
            try {
                // Check if KRS record exists
                $check_query = "
                    SELECT krs_id, status_krs FROM krs 
                    WHERE mahasiswa_id = :mahasiswa_id 
                    AND semester = :semester 
                    AND tahun_akademik = :tahun_akademik 
                    LIMIT 1
                ";
                
                $stmt = $this->pdo->prepare($check_query);
                $stmt->execute([
                    'mahasiswa_id' => $mahasiswa_id,
                    'semester' => $semester,
                    'tahun_akademik' => $tahun_akademik
                ]);
                $existing_krs = $stmt->fetch(PDO::FETCH_ASSOC);
                
                if ($existing_krs && in_array($existing_krs['status_krs'], ['aktif', 'disetujui'])) {
                    error_log("[KRSEligibilityService] KRS sudah aktif");
                    return [
                        'status' => 'error',
                        'message' => 'KRS sudah diaktifkan untuk semester ini',
                        'code' => 'ALREADY_ACTIVE'
                    ];
                }
                
                // Update or create KRS
                if ($existing_krs) {
                    $stmt = $this->pdo->prepare(
                        "UPDATE krs 
                         SET status_krs = 'aktif', tgl_persetujuan = NOW(), admin_persetujuan = :admin_id
                         WHERE krs_id = :krs_id"
                    );
                    $stmt->execute([
                        'krs_id' => $existing_krs['krs_id'],
                        'admin_id' => $admin_id
                    ]);
                    error_log("[KRSEligibilityService] KRS updated to aktif");
                } else {
                    $stmt = $this->pdo->prepare(
                        "INSERT INTO krs (mahasiswa_id, semester, tahun_akademik, status_krs, tgl_persetujuan, admin_persetujuan)
                         VALUES (:mahasiswa_id, :semester, :tahun_akademik, 'aktif', NOW(), :admin_id)"
                    );
                    $stmt->execute([
                        'mahasiswa_id' => $mahasiswa_id,
                        'semester' => $semester,
                        'tahun_akademik' => $tahun_akademik,
                        'admin_id' => $admin_id
                    ]);
                    error_log("[KRSEligibilityService] KRS created and set to aktif");
                }
                
                // Create notification for student
                $this->createKRSNotification($mahasiswa_id, $semester, $tahun_akademik);
                
                $this->pdo->commit();
                
                return [
                    'status' => 'success',
                    'message' => 'KRS berhasil diaktifkan',
                    'mahasiswa_id' => $mahasiswa_id,
                    'semester' => $semester,
                    'tahun_akademik' => $tahun_akademik,
                    'status_krs' => 'aktif'
                ];
                
            } catch (Exception $e) {
                $this->pdo->rollBack();
                error_log("[KRSEligibilityService] Transaction error: " . $e->getMessage());
                throw $e;
            }
            
        } catch (Exception $e) {
            error_log("[KRSEligibilityService] ERROR activating KRS: " . $e->getMessage());
            return [
                'status' => 'error',
                'message' => 'Gagal mengaktifkan KRS',
                'code' => 'ACTIVATION_FAILED',
                'details' => $e->getMessage()
            ];
        }
    }
    
    /**
     * Create notification for student when KRS is activated
     */
    private function createKRSNotification($mahasiswa_id, $semester, $tahun_akademik) {
        try {
            $query = "INSERT INTO notifikasi (mahasiswa_id, judul, pesan, tipe, status) 
                      VALUES (:mahasiswa_id, :judul, :pesan, 'success', 'belum_dibaca')";
            $stmt = $this->pdo->prepare($query);
            $stmt->execute([
                'mahasiswa_id' => $mahasiswa_id,
                'judul' => 'Aktivasi KRS',
                'pesan' => "KRS Semester $semester Tahun Akademik $tahun_akademik telah diaktifkan dan dapat dibelanjakan."
            ]);
            error_log("[KRSEligibilityService] KRS notification created");
            return true;
        } catch (Exception $e) {
            error_log("[KRSEligibilityService] Error creating KRS notification: " . $e->getMessage());
            return false;
        }
    }
}
?>
