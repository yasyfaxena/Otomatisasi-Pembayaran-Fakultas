<?php
/**
 * PaymentValidationService
 * Handle payment validation logic for installment and full payment
 * 
 * CRITICAL: This service implements the exact business logic as specified:
 * 1. Cicilan validation marks status as 'cicilan_berjalan' (NOT 'lunas')
 * 2. Only after BOTH cicilan are valid, tagihan becomes 'lunas'
 * 3. Notifies mahasiswa appropriately
 * 4. Marks student as eligible for KRS activation
 */

class PaymentValidationService {
    private $pdo;
    
    public function __construct($pdo) {
        $this->pdo = $pdo;
    }
    
    /**
     * MAIN VALIDATION LOGIC
     * Called by AdminUniversitas when validating a payment
     * 
     * @param int $pembayaran_id Payment ID to validate
     * @param string $status 'valid' or 'ditolak'
     * @param string $catatan Optional notes
     * @param int $admin_id Admin universitas ID
     * @return array Response with status and details
     */
    public function validasiPembayaran($pembayaran_id, $status, $catatan, $admin_id) {
        try {
            error_log("[PaymentValidationService] START validasiPembayaran: pembayaran_id=$pembayaran_id, status=$status");
            
            // Get payment details with VA info
            $payment = $this->getPembayaran($pembayaran_id);
            if (!$payment) {
                return [
                    'status' => 'error',
                    'message' => 'Pembayaran tidak ditemukan',
                    'code' => 'NOT_FOUND'
                ];
            }
            
            error_log("[PaymentValidationService] Payment found: " . json_encode($payment));
            
            if ($payment['status_validasi'] !== 'menunggu_validasi') {
                return [
                    'status' => 'error',
                    'message' => 'Pembayaran sudah di-validasi sebelumnya',
                    'code' => 'ALREADY_VALIDATED'
                ];
            }
            
            $this->pdo->beginTransaction();
            
            try {
                if ($status === 'valid') {
                    $result = $this->prosesValidPembayaran($payment, $admin_id, $catatan);
                } else {
                    $result = $this->prosesDitolakPembayaran($payment, $admin_id, $catatan);
                }
                
                $this->pdo->commit();
                
                error_log("[PaymentValidationService] Transaction committed successfully");
                return $result;
                
            } catch (Exception $e) {
                $this->pdo->rollBack();
                error_log("[PaymentValidationService] Transaction rolled back: " . $e->getMessage());
                throw $e;
            }
            
        } catch (Exception $e) {
            error_log("[PaymentValidationService] ERROR: " . $e->getMessage());
            return [
                'status' => 'error',
                'message' => 'Gagal memvalidasi pembayaran',
                'code' => 'VALIDATION_FAILED',
                'details' => $e->getMessage()
            ];
        }
    }
    
    /**
     * Handle VALID payment validation
     * This is where the cicilan vs lunas logic is implemented
     */
    private function prosesValidPembayaran($payment, $admin_id, $catatan) {
        error_log("[PaymentValidationService] Processing VALID payment");
        
        // Step 1: Update pembayaran status to valid
        $this->updatePembayaranValid($payment['pembayaran_id'], $admin_id, $catatan);
        error_log("[PaymentValidationService] Pembayaran marked as valid");
        
        // Step 2: Update VA total_diterima
        $this->updateVATotalDiterima($payment['va_id'], $payment['jumlah_pembayaran']);
        error_log("[PaymentValidationService] VA total_diterima updated");
        
        // Step 3: Get total valid payments for this tagihan
        $total_valid = $this->getTotalValidPayments($payment['tagihan_id']);
        error_log("[PaymentValidationService] Total valid payments: $total_valid, Jumlah tagihan: {$payment['jumlah_tagihan']}");
        
        // CRITICAL LOGIC: Check metode pembayaran
        if ($payment['metode_pembayaran'] === 'lunas') {
            // LUNAS: Mark as lunas only if total valid >= jumlah tagihan
            if ($total_valid >= $payment['jumlah_tagihan']) {
                $this->markTagihanLunas($payment['tagihan_id']);
                $this->markVAClosed($payment['va_id']);
                error_log("[PaymentValidationService] Tagihan marked as LUNAS (full payment)");
            } else {
                // Partial payment, still waiting
                $this->markTagihanBelumBayar($payment['tagihan_id']);
                error_log("[PaymentValidationService] Lunas payment incomplete, tagihan still belum_bayar");
            }
            
        } elseif ($payment['metode_pembayaran'] === 'cicilan') {
            // CICILAN: Update installment record with payment
            $cicilan_count = $this->getCicilanCount($payment['tagihan_id']);
            error_log("[PaymentValidationService] Total cicilan count: $cicilan_count");
            
            // Update cicilan_detail to mark installment as paid/partially paid
            $this->updateCicilanDetail($payment['tagihan_id'], $payment['jumlah_pembayaran']);
            
            // Check installment status: first cicilan paid? OR both cicilan complete?
            $cicilan_status = $this->getCicilanStatus($payment['tagihan_id']);
            error_log("[PaymentValidationService] Cicilan status: " . json_encode($cicilan_status));
            
            if ($cicilan_status['both_complete']) {
                // Both cicilan fully paid - mark tagihan as LUNAS
                $this->markTagihanLunas($payment['tagihan_id']);
                $this->markVAClosed($payment['va_id']);
                error_log("[PaymentValidationService] Both cicilan complete, tagihan marked as LUNAS");
            } else if ($cicilan_status['first_paid']) {
                // First cicilan has payment - mark tagihan as cicilan_berjalan
                $this->markTagihanCicilanBerjalan($payment['tagihan_id']);
                error_log("[PaymentValidationService] First cicilan has payment, tagihan marked as cicilan_berjalan");
                
                // Create notification for student
                $this->createCicilanValidNotification($payment['mahasiswa_id'], $payment['semester']);
            } else {
                // No payment yet - keep tagihan as belum_bayar
                $this->markTagihanBelumBayar($payment['tagihan_id']);
                error_log("[PaymentValidationService] No payment yet, tagihan still belum_bayar");
            }
        }
        
        // Step 4: Auto-create next tagihan if current is lunas
        $current_status = $this->getTagihanStatus($payment['tagihan_id']);
        if ($current_status === 'lunas') {
            try {
                error_log("[PaymentValidationService] Tagihan is LUNAS, attempting to create next tagihan");
                $this->autoCreateNextTagihan($payment['mahasiswa_id']);
            } catch (Exception $e) {
                error_log("[PaymentValidationService] Error creating next tagihan: " . $e->getMessage());
                // Don't fail the validation if next tagihan creation fails
            }
        }
        
        return [
            'status' => 'success',
            'message' => 'Pembayaran berhasil divalidasi',
            'pembayaran_id' => $payment['pembayaran_id'],
            'tagihan_id' => $payment['tagihan_id'],
            'total_valid' => $total_valid,
            'status_tagihan' => $this->getTagihanStatus($payment['tagihan_id'])
        ];
    }
    
    /**
     * Handle DITOLAK payment validation
     */
    private function prosesDitolakPembayaran($payment, $admin_id, $catatan) {
        error_log("[PaymentValidationService] Processing DITOLAK payment");
        
        // Update pembayaran status to ditolak
        $this->updatePembayaranDitolak($payment['pembayaran_id'], $admin_id, $catatan);
        
        // Tagihan remains as it was
        error_log("[PaymentValidationService] Pembayaran marked as ditolak");
        
        return [
            'status' => 'success',
            'message' => 'Pembayaran ditolak',
            'pembayaran_id' => $payment['pembayaran_id'],
            'tagihan_id' => $payment['tagihan_id']
        ];
    }
    
    // ============================================
    // HELPER FUNCTIONS
    // ============================================
    
    private function getPembayaran($pembayaran_id) {
        $query = "SELECT p.*, va.metode_pembayaran, va.va_id, t.jumlah_tagihan, t.tagihan_id, t.semester, m.mahasiswa_id
                  FROM pembayaran p
                  JOIN virtual_account va ON p.va_id = va.va_id
                  JOIN tagihan t ON p.tagihan_id = t.tagihan_id
                  JOIN mahasiswa m ON p.mahasiswa_id = m.mahasiswa_id
                  WHERE p.pembayaran_id = :id
                  LIMIT 1";
        
        $stmt = $this->pdo->prepare($query);
        $stmt->execute(['id' => $pembayaran_id]);
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }
    
    private function updatePembayaranValid($pembayaran_id, $admin_id, $catatan) {
        $stmt = $this->pdo->prepare(
            "UPDATE pembayaran 
             SET status_validasi = 'valid', tgl_validasi = NOW(), admin_validator = :admin_id, catatan_validasi = :catatan
             WHERE pembayaran_id = :id"
        );
        $stmt->execute([
            'id' => $pembayaran_id,
            'admin_id' => $admin_id,
            'catatan' => $catatan
        ]);
    }
    
    private function updatePembayaranDitolak($pembayaran_id, $admin_id, $catatan) {
        $stmt = $this->pdo->prepare(
            "UPDATE pembayaran 
             SET status_validasi = 'ditolak', tgl_validasi = NOW(), admin_validator = :admin_id, catatan_validasi = :catatan
             WHERE pembayaran_id = :id"
        );
        $stmt->execute([
            'id' => $pembayaran_id,
            'admin_id' => $admin_id,
            'catatan' => $catatan
        ]);
    }
    
    private function updateVATotalDiterima($va_id, $jumlah) {
        $stmt = $this->pdo->prepare(
            "UPDATE virtual_account SET total_diterima = total_diterima + :jumlah WHERE va_id = :id"
        );
        $stmt->execute(['id' => $va_id, 'jumlah' => $jumlah]);
    }
    
    private function getTotalValidPayments($tagihan_id) {
        $stmt = $this->pdo->prepare(
            "SELECT COALESCE(SUM(jumlah_pembayaran), 0) as total 
             FROM pembayaran 
             WHERE tagihan_id = :id AND status_validasi = 'valid'"
        );
        $stmt->execute(['id' => $tagihan_id]);
        $result = $stmt->fetch(PDO::FETCH_ASSOC);
        return (int)$result['total'];
    }
    
    private function markTagihanLunas($tagihan_id) {
        $stmt = $this->pdo->prepare(
            "UPDATE tagihan SET status_pembayaran = 'lunas', tgl_lunas = NOW() WHERE tagihan_id = :id"
        );
        $stmt->execute(['id' => $tagihan_id]);
    }
    
    private function markTagihanBelumBayar($tagihan_id) {
        $stmt = $this->pdo->prepare(
            "UPDATE tagihan SET status_pembayaran = 'belum_bayar' WHERE tagihan_id = :id"
        );
        $stmt->execute(['id' => $tagihan_id]);
    }
    
    private function markTagihanCicilanBerjalan($tagihan_id) {
        $stmt = $this->pdo->prepare(
            "UPDATE tagihan SET status_pembayaran = 'cicilan_berjalan' WHERE tagihan_id = :id"
        );
        $stmt->execute(['id' => $tagihan_id]);
    }
    
    private function markVAClosed($va_id) {
        $stmt = $this->pdo->prepare(
            "UPDATE virtual_account SET status_va = 'closed' WHERE va_id = :id"
        );
        $stmt->execute(['id' => $va_id]);
    }
    
    private function getCicilanCount($tagihan_id) {
        $stmt = $this->pdo->prepare(
            "SELECT COUNT(*) as count FROM cicilan_detail WHERE tagihan_id = :id"
        );
        $stmt->execute(['id' => $tagihan_id]);
        $result = $stmt->fetch(PDO::FETCH_ASSOC);
        return (int)$result['count'];
    }
    
    private function updateCicilanDetail($tagihan_id, $jumlah_pembayaran) {
        // Find the first non-lunas cicilan
        $stmt = $this->pdo->prepare(
            "SELECT * FROM cicilan_detail 
             WHERE tagihan_id = :id AND status_cicilan != 'lunas' 
             ORDER BY nomor_cicilan ASC LIMIT 1"
        );
        $stmt->execute(['id' => $tagihan_id]);
        $cicilan = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if ($cicilan) {
            $new_terbayar = $cicilan['jumlah_terbayar'] + $jumlah_pembayaran;
            $new_status = ($new_terbayar >= $cicilan['jumlah_cicilan']) ? 'lunas' : 'sebagian_dibayar';
            $tgl_lunas = ($new_status === 'lunas') ? date('Y-m-d') : null;
            
            $stmt = $this->pdo->prepare(
                "UPDATE cicilan_detail 
                 SET jumlah_terbayar = :terbayar, status_cicilan = :status, tgl_lunas = :tgl 
                 WHERE cicilan_id = :id"
            );
            $stmt->execute([
                'id' => $cicilan['cicilan_id'],
                'terbayar' => $new_terbayar,
                'status' => $new_status,
                'tgl' => $tgl_lunas
            ]);
        }
    }
    
    private function createCicilanValidNotification($mahasiswa_id, $semester) {
        try {
            $query = "INSERT INTO notifikasi (mahasiswa_id, judul, pesan, tipe, status) 
                      VALUES (:mahasiswa_id, :judul, :pesan, 'success', 'belum_dibaca')";
            $stmt = $this->pdo->prepare($query);
            $stmt->execute([
                'mahasiswa_id' => $mahasiswa_id,
                'judul' => 'Pembayaran Cicilan Diterima',
                'pesan' => 'Cicilan pertama telah divalidasi. Silakan menunggu aktivasi KRS dari Admin Fakultas.'
            ]);
            error_log("[PaymentValidationService] Cicilan notification created for mahasiswa_id=$mahasiswa_id");
            return true;
        } catch (Exception $e) {
            error_log("[PaymentValidationService] Error creating notification: " . $e->getMessage());
            return false;
        }
    }
    
    private function getTagihanStatus($tagihan_id) {
        $stmt = $this->pdo->prepare(
            "SELECT status_pembayaran FROM tagihan WHERE tagihan_id = :id"
        );
        $stmt->execute(['id' => $tagihan_id]);
        $result = $stmt->fetch(PDO::FETCH_ASSOC);
        return $result['status_pembayaran'] ?? 'unknown';
    }
    
    /**
     * Get comprehensive cicilan status for a tagihan
     * Returns array with keys: first_paid, both_complete
     */
    private function getCicilanStatus($tagihan_id) {
        // Check first cicilan status
        $stmt = $this->pdo->prepare(
            "SELECT COUNT(*) as count FROM cicilan_detail 
             WHERE tagihan_id = :id AND nomor_cicilan = 1 AND status_cicilan IN ('lunas', 'sebagian_dibayar')"
        );
        $stmt->execute(['id' => $tagihan_id]);
        $result = $stmt->fetch(PDO::FETCH_ASSOC);
        $first_paid = (int)$result['count'] >= 1;
        
        // Check if both cicilan are fully lunas
        $stmt = $this->pdo->prepare(
            "SELECT COUNT(*) as count FROM cicilan_detail 
             WHERE tagihan_id = :id AND status_cicilan = 'lunas'"
        );
        $stmt->execute(['id' => $tagihan_id]);
        $result = $stmt->fetch(PDO::FETCH_ASSOC);
        $both_complete = (int)$result['count'] >= 2;
        
        return [
            'first_paid' => $first_paid,
            'both_complete' => $both_complete
        ];
    }
    
    /**
     * Auto-create next tagihan when current tagihan is LUNAS
     * Logic:
     * - BPP Sem 1-5 → BPP next semester
     * - BPP Sem 6 → PROPOSAL
     * - BPP Sem 7 → SKRIPSI (if applicable)
     * - PROPOSAL → SKRIPSI
     */
    private function autoCreateNextTagihan($mahasiswa_id) {
        try {
            // Get mahasiswa info
            $mhs_query = "SELECT * FROM mahasiswa WHERE mahasiswa_id = :id LIMIT 1";
            $stmt = $this->pdo->prepare($mhs_query);
            $stmt->execute(['id' => $mahasiswa_id]);
            $mahasiswa = $stmt->fetch(PDO::FETCH_ASSOC);
            
            if (!$mahasiswa) {
                error_log("[autoCreateNextTagihan] Mahasiswa not found: $mahasiswa_id");
                return false;
            }
            
            // Get the latest LUNAS tagihan
            $last_query = "SELECT * FROM tagihan 
                          WHERE mahasiswa_id = :mahasiswa_id 
                          AND status_pembayaran = 'lunas'
                          ORDER BY created_at DESC LIMIT 1";
            $stmt = $this->pdo->prepare($last_query);
            $stmt->execute(['mahasiswa_id' => $mahasiswa_id]);
            $last_tagihan = $stmt->fetch(PDO::FETCH_ASSOC);
            
            if (!$last_tagihan) {
                error_log("[autoCreateNextTagihan] No lunas tagihan found for mahasiswa_id: $mahasiswa_id");
                return false;
            }
            
            // Check if next tagihan already exists
            $check_query = "SELECT COUNT(*) as count FROM tagihan 
                           WHERE mahasiswa_id = :mahasiswa_id 
                           AND status_pembayaran IN ('belum_bayar', 'cicilan_berjalan', 'menunggu_verifikasi')";
            $stmt = $this->pdo->prepare($check_query);
            $stmt->execute(['mahasiswa_id' => $mahasiswa_id]);
            $check = $stmt->fetch(PDO::FETCH_ASSOC);
            
            if ($check['count'] > 0) {
                error_log("[autoCreateNextTagihan] Active tagihan already exists for mahasiswa_id: $mahasiswa_id");
                return false;
            }
            
            // Determine next tagihan type and semester
            $next_jenis = null;
            $next_semester = null;
            
            $current_jenis = $last_tagihan['jenis_tagihan'];
            $current_semester = (int)($last_tagihan['semester'] ?? 0);
            
            if ($current_jenis === 'BPP') {
                if ($current_semester < 6) {
                    // BPP Sem 1-5 → BPP next semester
                    $next_jenis = 'BPP';
                    $next_semester = $current_semester + 1;
                } elseif ($current_semester === 6) {
                    // BPP Sem 6 → PROPOSAL
                    $next_jenis = 'PROPOSAL';
                    $next_semester = null;
                } elseif ($current_semester === 7) {
                    // BPP Sem 7 → SKRIPSI
                    $next_jenis = 'SKRIPSI';
                    $next_semester = null;
                } else {
                    // Semester > 7, no more tagihan
                    error_log("[autoCreateNextTagihan] Semester $current_semester, no next tagihan");
                    return false;
                }
            } elseif ($current_jenis === 'PROPOSAL') {
                // PROPOSAL → SKRIPSI
                $next_jenis = 'SKRIPSI';
                $next_semester = null;
            } else {
                // SKRIPSI or others - no next tagihan
                error_log("[autoCreateNextTagihan] Jenis $current_jenis, no next tagihan");
                return false;
            }
            
            if (!$next_jenis) {
                error_log("[autoCreateNextTagihan] Cannot determine next jenis for current: $current_jenis");
                return false;
            }
            
            // Get tarif for next tagihan
            $tarif_query = "SELECT nominal FROM tarif 
                           WHERE prodi_id = :prodi_id 
                           AND jenis_tagihan = :jenis_tagihan
                           AND is_active = 1";
            
            $params = [
                'prodi_id' => $mahasiswa['prodi_id'],
                'jenis_tagihan' => $next_jenis
            ];
            
            // For BPP, also check semester range
            if ($next_jenis === 'BPP' && $next_semester) {
                $tarif_query .= " AND :next_semester BETWEEN semester_dari AND semester_sampai";
                $params['next_semester'] = $next_semester;
            }
            
            $tarif_query .= " LIMIT 1";
            
            $stmt = $this->pdo->prepare($tarif_query);
            $stmt->execute($params);
            $tarif = $stmt->fetch(PDO::FETCH_ASSOC);
            
            if (!$tarif) {
                error_log("[autoCreateNextTagihan] Tarif not found for jenis=$next_jenis, prodi_id={$mahasiswa['prodi_id']}");
                return false;
            }
            
            // Create new tagihan
            $insert_query = "INSERT INTO tagihan 
                            (mahasiswa_id, jenis_tagihan, semester, tahun_akademik, 
                             jumlah_tagihan, status_pembayaran, metode_pembayaran, 
                             tgl_jatuh_tempo, created_at)
                            VALUES 
                            (:mahasiswa_id, :jenis_tagihan, :semester, :tahun_akademik, 
                             :jumlah_tagihan, 'belum_bayar', 'lunas', 
                             DATE_ADD(NOW(), INTERVAL 14 DAY), NOW())";
            
            $stmt = $this->pdo->prepare($insert_query);
            $result = $stmt->execute([
                'mahasiswa_id' => $mahasiswa_id,
                'jenis_tagihan' => $next_jenis,
                'semester' => $next_semester,
                'tahun_akademik' => $mahasiswa['tahun_akademik'],
                'jumlah_tagihan' => $tarif['nominal']
            ]);
            
            if ($result) {
                error_log("[autoCreateNextTagihan] SUCCESS: Created $next_jenis" . ($next_semester ? " Sem $next_semester" : "") . " for mahasiswa_id=$mahasiswa_id");
                
                // Create notification for student
                $notif_query = "INSERT INTO notifikasi (mahasiswa_id, judul, pesan, tipe, status) 
                               VALUES (:mahasiswa_id, :judul, :pesan, 'info', 'belum_dibaca')";
                $stmt = $this->pdo->prepare($notif_query);
                $stmt->execute([
                    'mahasiswa_id' => $mahasiswa_id,
                    'judul' => 'Tagihan Baru Tersedia',
                    'pesan' => "Tagihan $next_jenis" . ($next_semester ? " Semester $next_semester" : "") . " telah tersedia. Silakan lakukan pembayaran."
                ]);
                
                return true;
            } else {
                error_log("[autoCreateNextTagihan] FAILED to insert tagihan");
                return false;
            }
            
        } catch (Exception $e) {
            error_log("[autoCreateNextTagihan] ERROR: " . $e->getMessage());
            throw $e;
        }
    }
}
?>
