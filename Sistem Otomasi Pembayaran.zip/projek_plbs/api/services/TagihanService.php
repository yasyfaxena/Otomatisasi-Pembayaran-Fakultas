<?php

class TagihanService {
    private $db;
    
    public function __construct($database) {
        $this->db = $database;
    }
    
    /**
     * REQUIREMENT 1: Ambil data mahasiswa dari session
     * REQUIREMENT 2-4: Tentukan tagihan berdasarkan tarif dan progres pembayaran
     * REQUIREMENT 5: Pastikan selalu return JSON valid
     */
    public function prosesTagihanMahasiswa($mahasiswa_id) {
        try {
            // REQUIREMENT 1: Ambil data mahasiswa
            $mahasiswa = $this->getDataMahasiswa($mahasiswa_id);
            if (!$mahasiswa) {
                return [
                    'status' => 'error',
                    'message' => 'Data mahasiswa tidak ditemukan',
                    'code' => 'MAHASISWA_NOT_FOUND'
                ];
            }
            
            $tagihanData = [];
            
            // REQUIREMENT 2: Hitung semester BPP belum lunas
            $semesterBPPBelumLunas = $this->hitungSemesterBPPBelumLunas($mahasiswa_id);
            
            // REQUIREMENT 3: Ambil BPP dari tarif
            $bppTarif = $this->getTarifBPP($mahasiswa, $semesterBPPBelumLunas);
            if ($bppTarif) {
                // Tambahkan info status pembayaran
                $bppTarif['status_pembayaran'] = $this->getStatusPembayaranBPP($mahasiswa_id, $semesterBPPBelumLunas);
                $tagihanData[] = $bppTarif;
            }
            
            // REQUIREMENT 4: Proposal hanya jika BPP semester 6 lunas
            if ($this->isBPPLunas($mahasiswa_id, 6)) {
                $proposalTarif = $this->getTarifProposal($mahasiswa);
                if ($proposalTarif && !$this->isTagihanLunas($mahasiswa_id, 'Proposal')) {
                    $proposalTarif['status_pembayaran'] = $this->getStatusPembayaranProposal($mahasiswa_id);
                    $tagihanData[] = $proposalTarif;
                }
            }
            
            // REQUIREMENT 4: Skripsi hanya jika BPP semester 7 lunas
            if ($this->isBPPLunas($mahasiswa_id, 7)) {
                $skripsiTarif = $this->getTarifSkripsi($mahasiswa);
                if ($skripsiTarif && !$this->isTagihanLunas($mahasiswa_id, 'Skripsi')) {
                    $skripsiTarif['status_pembayaran'] = $this->getStatusPembayaranSkripsi($mahasiswa_id);
                    $tagihanData[] = $skripsiTarif;
                }
            }
            
            // REQUIREMENT 5: Return array tagihan (bisa kosong jika tidak ada)
            $hasActiveInstallment = $this->hasActiveInstallment($mahasiswa_id);
            
            return [
                'status' => 'success',
                'message' => empty($tagihanData) ? 'Tidak ada tagihan aktif' : 'Data tagihan ditemukan',
                'tagihan' => $tagihanData,
                'total' => count($tagihanData),
                'has_active_installment' => $hasActiveInstallment
            ];
            
        } catch (Exception $e) {
            return [
                'status' => 'error',
                'message' => 'Gagal memproses tagihan',
                'code' => 'PROCESS_ERROR',
                'details' => $e->getMessage()
            ];
        }
    }
    
    /**
     * REQUIREMENT 1: Ambil data mahasiswa dengan semua field yang diperlukan
     */
    private function getDataMahasiswa($mahasiswa_id) {
        try {
            $stmt = $this->db->prepare("
                SELECT mahasiswa_id, user_id, fakultas_id, prodi_id, semester_aktif, tahun_akademik 
                FROM mahasiswa 
                WHERE mahasiswa_id = ?
            ");
            $stmt->execute([$mahasiswa_id]);
            $result = $stmt->fetch(PDO::FETCH_ASSOC);
            return $result ?: null;
        } catch (Exception $e) {
            throw new Exception("Error fetching mahasiswa data: " . $e->getMessage());
        }
    }
    
    /**
     * REQUIREMENT 2: Hitung semester BPP belum lunas
     * Jika belum ada pembayaran = semester 1
     * Jika ada pembayaran semester X = semester X + 1
     */
    private function hitungSemesterBPPBelumLunas($mahasiswa_id) {
        try {
            $stmt = $this->db->prepare("
                SELECT MAX(semester) as semester_lunas
                FROM tagihan 
                WHERE mahasiswa_id = ? 
                AND jenis_tagihan = 'BPP' 
                AND status_pembayaran = 'lunas'
            ");
            $stmt->execute([$mahasiswa_id]);
            $result = $stmt->fetch(PDO::FETCH_ASSOC);
            
            $semester_lunas = $result['semester_lunas'] ?? 0;
            return $semester_lunas ? intval($semester_lunas) + 1 : 1;
        } catch (Exception $e) {
            throw new Exception("Error calculating BPP semester: " . $e->getMessage());
        }
    }
    
    /**
     * REQUIREMENT 3: Ambil data tarif BPP berdasarkan kriteria
     */
    private function getTarifBPP($mahasiswa, $semester) {
        try {
            $stmt = $this->db->prepare("
                SELECT 
                    tarif_id,
                    'BPP' as jenis_tagihan, 
                    ? as semester, 
                    nominal, 
                    tahun_akademik,
                    fakultas_id,
                    prodi_id
                FROM tarif 
                WHERE fakultas_id = ? 
                AND prodi_id = ? 
                AND jenis_tagihan = 'BPP'
                AND semester_dari <= ? 
                AND semester_sampai >= ?
                AND tahun_akademik = ?
                AND is_active = 1
                LIMIT 1
            ");
            $stmt->execute([
                $semester,
                $mahasiswa['fakultas_id'], 
                $mahasiswa['prodi_id'], 
                $semester,
                $semester,
                $mahasiswa['tahun_akademik']
            ]);
            return $stmt->fetch(PDO::FETCH_ASSOC) ?: null;
        } catch (Exception $e) {
            throw new Exception("Error fetching BPP tarif: " . $e->getMessage());
        }
    }
    
    /**
     * REQUIREMENT 3: Ambil data tarif Proposal
     */
    private function getTarifProposal($mahasiswa) {
        try {
            $stmt = $this->db->prepare("
                SELECT 
                    tarif_id,
                    'Proposal' as jenis_tagihan, 
                    nominal, 
                    tahun_akademik,
                    fakultas_id,
                    prodi_id
                FROM tarif 
                WHERE fakultas_id = ? 
                AND prodi_id = ? 
                AND jenis_tagihan = 'Proposal'
                AND tahun_akademik = ?
                AND is_active = 1
                LIMIT 1
            ");
            $stmt->execute([
                $mahasiswa['fakultas_id'], 
                $mahasiswa['prodi_id'], 
                $mahasiswa['tahun_akademik']
            ]);
            return $stmt->fetch(PDO::FETCH_ASSOC) ?: null;
        } catch (Exception $e) {
            throw new Exception("Error fetching Proposal tarif: " . $e->getMessage());
        }
    }
    
    /**
     * REQUIREMENT 3: Ambil data tarif Skripsi
     */
    private function getTarifSkripsi($mahasiswa) {
        try {
            $stmt = $this->db->prepare("
                SELECT 
                    tarif_id,
                    'Skripsi' as jenis_tagihan, 
                    nominal, 
                    tahun_akademik,
                    fakultas_id,
                    prodi_id
                FROM tarif 
                WHERE fakultas_id = ? 
                AND prodi_id = ? 
                AND jenis_tagihan = 'Skripsi'
                AND tahun_akademik = ?
                AND is_active = 1
                LIMIT 1
            ");
            $stmt->execute([
                $mahasiswa['fakultas_id'], 
                $mahasiswa['prodi_id'], 
                $mahasiswa['tahun_akademik']
            ]);
            return $stmt->fetch(PDO::FETCH_ASSOC) ?: null;
        } catch (Exception $e) {
            throw new Exception("Error fetching Skripsi tarif: " . $e->getMessage());
        }
    }
    
    /**
     * REQUIREMENT 4: Cek apakah BPP semester tertentu lunas
     */
    private function isBPPLunas($mahasiswa_id, $semester) {
        try {
            $stmt = $this->db->prepare("
                SELECT COUNT(*) as count
                FROM tagihan 
                WHERE mahasiswa_id = ? 
                AND jenis_tagihan = 'BPP' 
                AND semester = ?
                AND status_pembayaran = 'lunas'
            ");
            $stmt->execute([$mahasiswa_id, $semester]);
            $result = $stmt->fetch(PDO::FETCH_ASSOC);
            return intval($result['count']) > 0;
        } catch (Exception $e) {
            throw new Exception("Error checking BPP payment status: " . $e->getMessage());
        }
    }
    
    /**
     * Cek apakah tagihan jenis tertentu sudah lunas
     */
    private function isTagihanLunas($mahasiswa_id, $jenis_tagihan) {
        try {
            $stmt = $this->db->prepare("
                SELECT COUNT(*) as count
                FROM tagihan 
                WHERE mahasiswa_id = ? 
                AND jenis_tagihan = ?
                AND status_pembayaran = 'lunas'
            ");
            $stmt->execute([$mahasiswa_id, $jenis_tagihan]);
            $result = $stmt->fetch(PDO::FETCH_ASSOC);
            return intval($result['count']) > 0;
        } catch (Exception $e) {
            throw new Exception("Error checking tagihan payment status: " . $e->getMessage());
        }
    }
    
    /**
     * Get status pembayaran BPP
     */
    private function getStatusPembayaranBPP($mahasiswa_id, $semester) {
        try {
            $stmt = $this->db->prepare("
                SELECT status_pembayaran
                FROM tagihan 
                WHERE mahasiswa_id = ? 
                AND jenis_tagihan = 'BPP' 
                AND semester = ?
                ORDER BY created_at DESC
                LIMIT 1
            ");
            $stmt->execute([$mahasiswa_id, $semester]);
            $result = $stmt->fetch(PDO::FETCH_ASSOC);
            return $result['status_pembayaran'] ?? 'belum_bayar';
        } catch (Exception $e) {
            return 'belum_bayar';
        }
    }
    
    /**
     * Get status pembayaran Proposal
     */
    private function getStatusPembayaranProposal($mahasiswa_id) {
        try {
            $stmt = $this->db->prepare("
                SELECT status_pembayaran
                FROM tagihan 
                WHERE mahasiswa_id = ? 
                AND jenis_tagihan = 'Proposal'
                ORDER BY created_at DESC
                LIMIT 1
            ");
            $stmt->execute([$mahasiswa_id]);
            $result = $stmt->fetch(PDO::FETCH_ASSOC);
            return $result['status_pembayaran'] ?? 'belum_bayar';
        } catch (Exception $e) {
            return 'belum_bayar';
        }
    }
    
    /**
     * Get status pembayaran Skripsi
     */
    private function getStatusPembayaranSkripsi($mahasiswa_id) {
        try {
            $stmt = $this->db->prepare("
                SELECT status_pembayaran
                FROM tagihan 
                WHERE mahasiswa_id = ? 
                AND jenis_tagihan = 'Skripsi'
                ORDER BY created_at DESC
                LIMIT 1
            ");
            $stmt->execute([$mahasiswa_id]);
            $result = $stmt->fetch(PDO::FETCH_ASSOC);
            return $result['status_pembayaran'] ?? 'belum_bayar';
        } catch (Exception $e) {
            return 'belum_bayar';
        }
    }
    
    /**
     * Cek apakah ada cicilan aktif
     * Return boolean murni: true jika ada cicilan dengan metode_pembayaran = 'cicilan' dan status belum lunas
     */
    private function hasActiveInstallment($mahasiswa_id) {
        try {
            $stmt = $this->db->prepare("
                SELECT COUNT(*) as count
                FROM tagihan t
                JOIN cicilan_detail cd ON t.tagihan_id = cd.tagihan_id
                WHERE t.mahasiswa_id = ? 
                AND t.metode_pembayaran = 'cicilan'
                AND cd.status_pembayaran != 'lunas'
            ");
            $stmt->execute([$mahasiswa_id]);
            $result = $stmt->fetch(PDO::FETCH_ASSOC);
            return intval($result['count']) > 0;
        } catch (Exception $e) {
            return false;
        }
    }
}