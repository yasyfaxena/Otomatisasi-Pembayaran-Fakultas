<?php

class CicilanService {
    private $db;
    
    public function __construct($database) {
        $this->db = $database;
    }
    
    public function getCicilanMahasiswa($mahasiswa_id) {
        // Cicilan HANYA muncul jika ada data cicilan di database dengan status belum lunas
        $stmt = $this->db->prepare("
            SELECT c.*, t.jenis_tagihan, t.semester
            FROM cicilan c
            JOIN tagihan t ON c.tagihan_id = t.tagihan_id
            WHERE t.mahasiswa_id = ? 
            AND c.status_pembayaran != 'lunas'
            ORDER BY c.tanggal_jatuh_tempo ASC
        ");
        $stmt->execute([$mahasiswa_id]);
        $cicilan = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        // Jika tidak ada data cicilan, return empty array (TIDAK ada cicilan)
        return $cicilan;
    }
    
    public function hasCicilanAktif($mahasiswa_id) {
        $stmt = $this->db->prepare("
            SELECT COUNT(*) as count
            FROM cicilan c
            JOIN tagihan t ON c.tagihan_id = t.tagihan_id
            WHERE t.mahasiswa_id = ? 
            AND c.status_pembayaran != 'lunas'
        ");
        $stmt->execute([$mahasiswa_id]);
        $result = $stmt->fetch(PDO::FETCH_ASSOC);
        
        return $result['count'] > 0;
    }
}