<?php
/**
 * Pembayaran Controller
 * Handle payment upload and history
 */

class PembayaranController extends Controller {

    /**
     * POST /api/mahasiswa/pembayaran/upload-bukti
     * Upload payment proof
     */
    public function uploadBukti() {
        try {
            $user = $this->requireAuth();
            RoleMiddleware::mahasiswa($user);

            // Check required fields
            if (empty($_POST['va_id']) || empty($_POST['jumlah_pembayaran']) || empty($_POST['tgl_pembayaran'])) {
                $this->response('error', 'Required fields: va_id, jumlah_pembayaran, tgl_pembayaran', null, 'INVALID_REQUEST', 400);
            }

            if (!isset($_FILES['bukti_pembayaran'])) {
                $this->response('error', 'File upload required', null, 'INVALID_REQUEST', 400);
            }

            $va_id = (int) $_POST['va_id'];
            $jumlah = (float) $_POST['jumlah_pembayaran'];
            $tgl_pembayaran = $_POST['tgl_pembayaran'];
            $bank_pengirim = $_POST['bank_pengirim'] ?? 'Bank Transfer';

            // Validate date
            if (strtotime($tgl_pembayaran) === false) {
                $this->response('error', 'Invalid payment date format', null, 'INVALID_REQUEST', 400);
            }

            // Validate file
            $file_validation = validateFileUpload($_FILES['bukti_pembayaran']);
            if (!$file_validation['valid']) {
                $this->response('error', $file_validation['error'], null, 'INVALID_FILE', 400);
            }

            // Get VA and verify ownership
            $va_query = "SELECT va.*, t.mahasiswa_id, t.tagihan_id FROM virtual_account va
                        JOIN tagihan t ON va.tagihan_id = t.tagihan_id
                        JOIN mahasiswa m ON t.mahasiswa_id = m.mahasiswa_id
                        WHERE va.va_id = :va_id AND m.user_id = :user_id
                        LIMIT 1";

            $stmt = $this->pdo->prepare($va_query);
            $stmt->execute(['va_id' => $va_id, 'user_id' => $user['user_id']]);
            $va = $stmt->fetch();

            if (!$va) {
                $this->response('error', 'Virtual Account not found', null, 'NOT_FOUND', 404);
            }

            // Validate amount
            if ($jumlah <= 0 || $jumlah > $va['jumlah_va']) {
                $this->response('error', 'Payment amount invalid', null, 'INSUFFICIENT_AMOUNT', 400);
            }

            // Save file - simpan ke folder uploads/bukti_pembayaran (bukan api/uploads/bukti)
            $upload_dir = __DIR__ . '/../../uploads/bukti_pembayaran/';
            if (!is_dir($upload_dir)) {
                mkdir($upload_dir, 0755, true);
            }

            $file_name = 'bukti_' . $va['mahasiswa_id'] . '_' . time() . '.' . pathinfo($_FILES['bukti_pembayaran']['name'], PATHINFO_EXTENSION);
            $file_path = $upload_dir . $file_name;

            if (!move_uploaded_file($_FILES['bukti_pembayaran']['tmp_name'], $file_path)) {
                $this->response('error', 'File upload failed', null, 'UPLOAD_FAILED', 500);
            }

            // Start transaction
            $this->pdo->beginTransaction();

            try {
                // Create pembayaran record
                $pembayaran_data = [
                    'va_id' => $va_id,
                    'tagihan_id' => $va['tagihan_id'],
                    'mahasiswa_id' => $va['mahasiswa_id'],
                    'jumlah_pembayaran' => $jumlah,
                    'tgl_pembayaran' => $tgl_pembayaran,
                    'jam_pembayaran' => date('H:i:s'),
                    'bank_pengirim' => $bank_pengirim,
                    'bukti_pembayaran_filename' => $file_name,
                    'status_validasi' => 'menunggu_validasi',
                    'created_at' => date('Y-m-d H:i:s'),
                    'updated_at' => date('Y-m-d H:i:s')
                ];

                $insert = "INSERT INTO pembayaran (va_id, tagihan_id, mahasiswa_id, jumlah_pembayaran, tgl_pembayaran, jam_pembayaran, bank_pengirim, bukti_pembayaran_filename, status_validasi, created_at, updated_at)
                          VALUES (:va_id, :tagihan_id, :mahasiswa_id, :jumlah_pembayaran, :tgl_pembayaran, :jam_pembayaran, :bank_pengirim, :bukti_pembayaran_filename, :status_validasi, :created_at, :updated_at)";

                $stmt = $this->pdo->prepare($insert);
                $stmt->execute($pembayaran_data);
                $pembayaran_id = $this->pdo->lastInsertId();

                // Update tagihan status to waiting verification (bukan validation)
                $update_tagihan = "UPDATE tagihan SET status_pembayaran = 'menunggu_verifikasi', updated_at = NOW() WHERE tagihan_id = :tagihan_id";
                $stmt = $this->pdo->prepare($update_tagihan);
                $stmt->execute(['tagihan_id' => $va['tagihan_id']]);

                // Log activity
                $this->logActivity($va['mahasiswa_id'], 'pembayaran_upload', "Payment proof uploaded: $pembayaran_id");

                $this->pdo->commit();

                $response = [
                    'pembayaran_id' => $pembayaran_id,
                    'va_id' => $va_id,
                    'jumlah_pembayaran' => (int) $jumlah,
                    'tgl_pembayaran' => $tgl_pembayaran,
                    'status_validasi' => 'menunggu_validasi',
                    'catatan' => 'Bukti pembayaran berhasil diupload. Menunggu validasi dari admin universitas'
                ];

                $this->response('success', 'Bukti pembayaran berhasil diupload', $response, null, 201);

            } catch (Exception $e) {
                $this->pdo->rollBack();
                // Delete uploaded file on error
                if (file_exists($file_path)) {
                    unlink($file_path);
                }
                throw $e;
            }

        } catch (Exception $e) {
            $this->response('error', 'Upload failed: ' . $e->getMessage(), null, 'UPLOAD_FAILED', 500);
        }
    }

    /**
     * GET /api/mahasiswa/pembayaran/riwayat
     * Get payment history for mahasiswa (ALL statuses: menunggu_validasi, ditolak, valid)
     */
    public function riwayat() {
        try {
            $user = $this->requireAuth();
            RoleMiddleware::mahasiswa($user);

            $page = (int) ($_GET['page'] ?? 1);
            $limit = (int) ($_GET['limit'] ?? 10);
            $offset = ($page - 1) * $limit;

            // Get mahasiswa ID
            $mahasiswa_query = "SELECT mahasiswa_id FROM mahasiswa WHERE user_id = :user_id LIMIT 1";
            $stmt = $this->pdo->prepare($mahasiswa_query);
            $stmt->execute(['user_id' => $user['user_id']]);
            $mahasiswa = $stmt->fetch();

            // Get ALL payments (menunggu_validasi, ditolak, valid) - NOT just valid
            // This allows students to see their upload history and current status
            $query = "SELECT p.*, t.jenis_tagihan, t.semester, t.tahun_akademik, va.nomor_va, u.nama_lengkap as admin_validator_name
                      FROM pembayaran p
                      JOIN tagihan t ON p.tagihan_id = t.tagihan_id
                      JOIN virtual_account va ON p.va_id = va.va_id
                      LEFT JOIN users u ON p.admin_validator = u.user_id
                      WHERE p.mahasiswa_id = :mahasiswa_id
                      ORDER BY p.created_at DESC
                      LIMIT :limit OFFSET :offset";

            $stmt = $this->pdo->prepare($query);
            $stmt->bindValue(':mahasiswa_id', $mahasiswa['mahasiswa_id']);
            $stmt->bindValue(':limit', $limit, PDO::PARAM_INT);
            $stmt->bindValue(':offset', $offset, PDO::PARAM_INT);
            $stmt->execute();
            $payments = $stmt->fetchAll();

            // Get total count (ALL payments, not just valid)
            $count_query = "SELECT COUNT(*) as total FROM pembayaran WHERE mahasiswa_id = :mahasiswa_id";
            $stmt = $this->pdo->prepare($count_query);
            $stmt->execute(['mahasiswa_id' => $mahasiswa['mahasiswa_id']]);
            $count = $stmt->fetch();

            $response = [
                'pembayaran' => array_map(function($p) {
                    // Construct RELATIVE path to bukti pembayaran file
                    $bukti_path = null;
                    if (!empty($p['bukti_pembayaran_filename'])) {
                        // SIMPAN PATH RELATIF, bukan URL lengkap
                        $bukti_path = 'uploads/bukti_pembayaran/' . $p['bukti_pembayaran_filename'];
                    }
                    
                    return [
                        'pembayaran_id' => $p['pembayaran_id'],
                        'va_id' => $p['va_id'],
                        'nomor_va' => $p['nomor_va'],
                        'jenis_tagihan' => $p['jenis_tagihan'],
                        'semester' => $p['semester'],
                        'tahun_akademik' => $p['tahun_akademik'],
                        'jumlah_pembayaran' => (int) $p['jumlah_pembayaran'],
                        'tgl_pembayaran' => $p['tgl_pembayaran'],
                        'status_validasi' => $p['status_validasi'],
                        'tgl_validasi' => $p['tgl_validasi'],
                        'admin_validator' => $p['admin_validator_name'],
                        'catatan_validasi' => $p['catatan_validasi'] ?? null,
                        'bukti_pembayaran_filename' => $p['bukti_pembayaran_filename'] ?? null,
                        'bukti_pembayaran_url' => $bukti_path
                    ];
                }, $payments),
                'pagination' => [
                    'page' => $page,
                    'limit' => $limit,
                    'total' => (int) $count['total'],
                    'total_pages' => ceil($count['total'] / $limit)
                ]
            ];

            $this->response('success', 'Payment history retrieved', $response);

        } catch (Exception $e) {
            $this->response('error', 'Failed to retrieve payment history: ' . $e->getMessage(), null, 'RETRIEVE_FAILED', 500);
        }
    }

    /**
     * Log activity
     */
    private function logActivity($mahasiswa_id, $type, $description) {
        try {
            $log_data = [
                'mahasiswa_id' => $mahasiswa_id,
                'jenis_transaksi' => $type,
                'deskripsi' => $description,
                'tgl_transaksi' => date('Y-m-d H:i:s')
            ];

            $insert = "INSERT INTO riwayat_transaksi (mahasiswa_id, jenis_transaksi, deskripsi, tgl_transaksi)
                      VALUES (:mahasiswa_id, :jenis_transaksi, :deskripsi, :tgl_transaksi)";

            $stmt = $this->pdo->prepare($insert);
            $stmt->execute($log_data);
        } catch (Exception $e) {
            // Silently fail
        }
    }
}

