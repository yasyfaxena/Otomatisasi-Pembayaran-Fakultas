<?php
/**
 * Admin Fakultas Controller
 * Handle KRS activation
 */

class AdminFakultasController extends Controller {

    /**
     * GET /api/admin-fakultas/krs/mahasiswa-layak
     * Get list of students eligible for KRS activation
     * Students eligible if: status_pembayaran = 'lunas' OR 'cicilan_berjalan'
     */
    public function mahasiswaLayakKRS() {
        try {
            $user = $this->requireAuth();
            RoleMiddleware::adminFakultas($user);

            // Get admin's facultas
            $stmt = $this->pdo->prepare("SELECT fakultas_id FROM users WHERE user_id = :user_id LIMIT 1");
            $stmt->execute(['user_id' => $user['user_id']]);
            $admin_faculty = $stmt->fetch();

            if (!$admin_faculty || !$admin_faculty['facultas_id']) {
                $this->response('error', 'Admin facultas tidak ditemukan', null, 'NOT_FOUND', 404);
                return;
            }

            // Load KRSEligibilityService
            require_once __DIR__ . '/../services/KRSEligibilityService.php';
            $krsService = new KRSEligibilityService($this->pdo);

            // Get eligible students
            $result = $krsService->getMahasiswaLayakKRS($user['user_id'], $admin_faculty['facultas_id']);

            if ($result['status'] === 'error') {
                http_response_code(400);
                $this->response('error', $result['message'], null, $result['code'] ?? 'FETCH_FAILED', 400);
                return;
            }

            $this->response('success', 'Mahasiswa layak KRS retrieved', ['mahasiswa' => $result['mahasiswa']]);

        } catch (Exception $e) {
            $this->response('error', 'Failed to get mahasiswa layak KRS: ' . $e->getMessage(), null, 'FETCH_FAILED', 500);
        }
    }

    /**
     * POST /api/admin/krs/{tagihan_id}/aktivasi
     * Activate KRS for student - BASED ON TAGIHAN_ID
     */
    public function aktivasiKRS($tagihan_id) {
        try {
            $user = $this->requireAuth();
            RoleMiddleware::adminFakultas($user);

            $tagihan_id = (int) $tagihan_id;

            // Verify admin's fakultas
            $admin_fakultas_query = "SELECT fakultas_id FROM users WHERE user_id = :user_id LIMIT 1";
            $stmt = $this->pdo->prepare($admin_fakultas_query);
            $stmt->execute(['user_id' => $user['user_id']]);
            $admin_faculty = $stmt->fetch();

            if (!$admin_faculty || !$admin_faculty['fakultas_id']) {
                $this->response('error', 'Admin not assigned to any faculty', null, 'FORBIDDEN', 403);
            }

            // Get tagihan with mahasiswa info - AMBIL DARI TAGIHAN
            $tagihan_query = "SELECT t.*, m.mahasiswa_id, m.nim, ps.fakultas_id, u.nama_lengkap
                            FROM tagihan t
                            JOIN mahasiswa m ON t.mahasiswa_id = m.mahasiswa_id
                            JOIN program_studi ps ON m.prodi_id = ps.prodi_id
                            JOIN users u ON m.user_id = u.user_id
                            WHERE t.tagihan_id = :tagihan_id LIMIT 1";

            $stmt = $this->pdo->prepare($tagihan_query);
            $stmt->execute(['tagihan_id' => $tagihan_id]);
            $tagihan = $stmt->fetch();

            if (!$tagihan) {
                $this->response('error', 'Tagihan not found', null, 'NOT_FOUND', 404);
            }

            // Verify fakultas match
            if ($tagihan['fakultas_id'] != $admin_faculty['fakultas_id']) {
                $this->response('error', 'Mahasiswa is not in your faculty', null, 'FORBIDDEN', 403);
            }

            // Verify tagihan status is lunas OR cicilan_berjalan (CRITICAL: Must allow cicilan_berjalan)
            if (!in_array($tagihan['status_pembayaran'], ['lunas', 'cicilan_berjalan'])) {
                $this->response('error', 'Tagihan harus lunas atau cicilan berjalan. Status saat ini: ' . $tagihan['status_pembayaran'], null, 'INVALID_REQUEST', 400);
            }

            $mahasiswa_id = $tagihan['mahasiswa_id'];
            $semester = $tagihan['semester'];
            $tahun_akademik = $tagihan['tahun_akademik'];

            // Check if KRS already active
            $check_krs = "SELECT krs_id, status_krs FROM krs WHERE mahasiswa_id = :mahasiswa_id AND semester = :semester AND tahun_akademik = :tahun_akademik LIMIT 1";
            $stmt = $this->pdo->prepare($check_krs);
            $stmt->execute([
                'mahasiswa_id' => $mahasiswa_id,
                'semester' => $semester,
                'tahun_akademik' => $tahun_akademik
            ]);
            $existing_krs = $stmt->fetch();
            
            if ($existing_krs && in_array($existing_krs['status_krs'], ['disetujui', 'aktif'])) {
                $this->response('error', 'KRS sudah diaktifkan untuk semester ini', null, 'DUPLICATE_KRS', 400);
            }

            // Start transaction
            $this->pdo->beginTransaction();

            try {
                // Check if KRS record exists (update) or create new
                if ($existing_krs) {
                    // Update existing KRS to active
                    $krs_update = "UPDATE krs SET 
                                  status_krs = 'disetujui',
                                  tgl_persetujuan = :tgl_persetujuan,
                                  admin_persetujuan = :admin_persetujuan,
                                  updated_at = :updated_at
                                  WHERE krs_id = :krs_id";
                    
                    $stmt = $this->pdo->prepare($krs_update);
                    $stmt->execute([
                        'tgl_persetujuan' => date('Y-m-d H:i:s'),
                        'admin_persetujuan' => $user['user_id'],
                        'updated_at' => date('Y-m-d H:i:s'),
                        'krs_id' => $existing_krs['krs_id']
                    ]);
                    $krs_id = $existing_krs['krs_id'];
                } else {
                    // Create new KRS record
                    $krs_data = [
                        'mahasiswa_id' => $mahasiswa_id,
                        'semester' => $semester,
                        'tahun_akademik' => $tahun_akademik,
                        'status_krs' => 'disetujui',
                        'tgl_pengajuan' => date('Y-m-d H:i:s'),
                        'tgl_persetujuan' => date('Y-m-d H:i:s'),
                        'admin_persetujuan' => $user['user_id'],
                        'created_at' => date('Y-m-d H:i:s')
                    ];

                    $krs_insert = "INSERT INTO krs (mahasiswa_id, semester, tahun_akademik, status_krs, tgl_pengajuan, tgl_persetujuan, admin_persetujuan, created_at)
                                 VALUES (:mahasiswa_id, :semester, :tahun_akademik, :status_krs, :tgl_pengajuan, :tgl_persetujuan, :admin_persetujuan, :created_at)";

                    $stmt = $this->pdo->prepare($krs_insert);
                    $stmt->execute($krs_data);
                    $krs_id = $this->pdo->lastInsertId();
                }

                // ✅ CREATE NOTIFICATION FOR STUDENT (OPTIONAL - jika tabel notifikasi ada)
                try {
                    $notif_data = [
                        'mahasiswa_id' => $mahasiswa_id,
                        'judul' => 'Aktivasi KRS',
                        'pesan' => "KRS Semester {$semester} telah diaktifkan dan dapat diisi",
                        'status' => 'belum_dibaca',
                        'created_at' => date('Y-m-d H:i:s')
                    ];

                    $notif_insert = "INSERT INTO notifikasi (mahasiswa_id, judul, pesan, status, created_at)
                                   VALUES (:mahasiswa_id, :judul, :pesan, :status, :created_at)";

                    $stmt = $this->pdo->prepare($notif_insert);
                    $stmt->execute($notif_data);
                } catch (Exception $e) {
                    // Silently fail if notifikasi table doesn't exist
                    error_log("[aktivasiKRS] Notifikasi creation failed (table may not exist): " . $e->getMessage());
                }

                // Log activity
                $this->logActivity($mahasiswa_id, 'krs_diaktifkan', "KRS activated: KRS ID $krs_id for semester $semester");

                $this->pdo->commit();

                $response = [
                    'krs_id' => $krs_id,
                    'mahasiswa_id' => $mahasiswa_id,
                    'nim' => $tagihan['nim'],
                    'nama_lengkap' => $tagihan['nama_lengkap'],
                    'semester' => $semester,
                    'tahun_akademik' => $tahun_akademik,
                    'status_krs' => 'disetujui',
                    'tgl_persetujuan' => date('Y-m-d H:i:s'),
                    'catatan' => 'KRS berhasil diaktifkan'
                ];

                $this->response('success', 'KRS berhasil diaktifkan', $response, null, 201);

            } catch (Exception $e) {
                $this->pdo->rollBack();
                throw $e;
            }

        } catch (Exception $e) {
            $this->response('error', 'KRS activation failed: ' . $e->getMessage(), null, 'ACTIVATION_FAILED', 500);
        }
    }

    /**
     * POST /api/admin/krs/{tagihan_id}/deaktivasi
     * Deactivate KRS for student
     */
    public function deaktivasiKRS($tagihan_id) {
        try {
            $user = $this->requireAuth();
            RoleMiddleware::adminFakultas($user);

            $tagihan_id = (int) $tagihan_id;

            // Get tagihan with mahasiswa info
            $tagihan_query = "SELECT t.*, m.mahasiswa_id, m.nim, ps.fakultas_id, u.nama_lengkap
                            FROM tagihan t
                            JOIN mahasiswa m ON t.mahasiswa_id = m.mahasiswa_id
                            JOIN program_studi ps ON m.prodi_id = ps.prodi_id
                            JOIN users u ON m.user_id = u.user_id
                            WHERE t.tagihan_id = :tagihan_id LIMIT 1";

            $stmt = $this->pdo->prepare($tagihan_query);
            $stmt->execute(['tagihan_id' => $tagihan_id]);
            $tagihan = $stmt->fetch();

            if (!$tagihan) {
                $this->response('error', 'Tagihan not found', null, 'NOT_FOUND', 404);
            }

            $mahasiswa_id = $tagihan['mahasiswa_id'];
            $semester = $tagihan['semester'];
            $tahun_akademik = $tagihan['tahun_akademik'];

            // Update KRS status to inactive/ditolak
            $update_krs = "UPDATE krs SET status_krs = 'ditolak', updated_at = NOW() 
                          WHERE mahasiswa_id = :mahasiswa_id 
                          AND semester = :semester 
                          AND tahun_akademik = :tahun_akademik";
            
            $stmt = $this->pdo->prepare($update_krs);
            $stmt->execute([
                'mahasiswa_id' => $mahasiswa_id,
                'semester' => $semester,
                'tahun_akademik' => $tahun_akademik
            ]);

            $this->response('success', 'KRS berhasil dinonaktifkan', [
                'mahasiswa_id' => $mahasiswa_id,
                'nim' => $tagihan['nim'],
                'nama_lengkap' => $tagihan['nama_lengkap'],
                'semester' => $semester,
                'tahun_akademik' => $tahun_akademik
            ]);

        } catch (Exception $e) {
            $this->response('error', 'KRS deactivation failed: ' . $e->getMessage(), null, 'DEACTIVATION_FAILED', 500);
        }
    }

    /**
     * GET /api/admin-fakultas/laporan-cicilan/{mahasiswa_id}
     * Get detailed cicilan report for specific mahasiswa
     */
    public function laporanCicilan($mahasiswa_id) {
        try {
            $user = $this->requireAuth();
            RoleMiddleware::adminFakultas($user);

            $mahasiswa_id = (int) $mahasiswa_id;

            // Get mahasiswa detail with tagihan and pembayaran
            $query = "SELECT 
                     m.mahasiswa_id,
                     m.nim,
                     u.nama_lengkap,
                     ps.nama_prodi,
                     f.nama_fakultas,
                     t.tagihan_id,
                     t.semester,
                     t.tahun_akademik,
                     t.jenis_tagihan,
                     t.jumlah_tagihan,
                     t.metode_pembayaran,
                     t.status_pembayaran,
                     COALESCE(SUM(CASE WHEN p.status_validasi = 'valid' THEN p.jumlah_pembayaran ELSE 0 END), 0) as total_dibayar,
                     (t.jumlah_tagihan - COALESCE(SUM(CASE WHEN p.status_validasi = 'valid' THEN p.jumlah_pembayaran ELSE 0 END), 0)) as sisa_tagihan
                     FROM mahasiswa m
                     JOIN users u ON m.user_id = u.user_id
                     JOIN program_studi ps ON m.prodi_id = ps.prodi_id
                     JOIN fakultas f ON ps.fakultas_id = f.fakultas_id
                     JOIN tagihan t ON m.mahasiswa_id = t.mahasiswa_id
                     LEFT JOIN pembayaran p ON t.tagihan_id = p.tagihan_id
                     WHERE m.mahasiswa_id = :mahasiswa_id
                     GROUP BY t.tagihan_id
                     ORDER BY t.semester DESC, t.created_at DESC";

            $stmt = $this->pdo->prepare($query);
            $stmt->execute(['mahasiswa_id' => $mahasiswa_id]);
            $tagihan_list = $stmt->fetchAll();

            if (empty($tagihan_list)) {
                $this->response('error', 'Mahasiswa tidak ditemukan atau belum memiliki tagihan', null, 'NOT_FOUND', 404);
                return;
            }

            // Get pembayaran history for this mahasiswa
            $pembayaran_query = "SELECT 
                                p.pembayaran_id,
                                p.tagihan_id,
                                p.jumlah_pembayaran,
                                p.tgl_pembayaran,
                                p.status_validasi,
                                p.catatan_validasi,
                                t.jenis_tagihan,
                                t.semester
                                FROM pembayaran p
                                JOIN tagihan t ON p.tagihan_id = t.tagihan_id
                                WHERE p.mahasiswa_id = :mahasiswa_id
                                ORDER BY p.tgl_pembayaran DESC";

            $stmt = $this->pdo->prepare($pembayaran_query);
            $stmt->execute(['mahasiswa_id' => $mahasiswa_id]);
            $pembayaran_list = $stmt->fetchAll();

            $mahasiswa_info = $tagihan_list[0];

            $response = [
                'mahasiswa' => [
                    'mahasiswa_id' => $mahasiswa_info['mahasiswa_id'],
                    'nim' => $mahasiswa_info['nim'],
                    'nama_lengkap' => $mahasiswa_info['nama_lengkap'],
                    'prodi' => $mahasiswa_info['nama_prodi'],
                    'fakultas' => $mahasiswa_info['nama_fakultas']
                ],
                'tagihan' => array_map(function($t) {
                    return [
                        'tagihan_id' => $t['tagihan_id'],
                        'semester' => $t['semester'],
                        'tahun_akademik' => $t['tahun_akademik'],
                        'jenis_tagihan' => $t['jenis_tagihan'],
                        'jumlah_tagihan' => (float) $t['jumlah_tagihan'],
                        'total_dibayar' => (float) $t['total_dibayar'],
                        'sisa_tagihan' => (float) $t['sisa_tagihan'],
                        'metode_pembayaran' => $t['metode_pembayaran'],
                        'status_pembayaran' => $t['status_pembayaran'],
                        'persentase_dibayar' => $t['jumlah_tagihan'] > 0 
                            ? round(($t['total_dibayar'] / $t['jumlah_tagihan']) * 100, 2)
                            : 0
                    ];
                }, $tagihan_list),
                'pembayaran' => array_map(function($p) {
                    return [
                        'pembayaran_id' => $p['pembayaran_id'],
                        'tagihan_id' => $p['tagihan_id'],
                        'jenis_tagihan' => $p['jenis_tagihan'],
                        'semester' => $p['semester'],
                        'jumlah_pembayaran' => (float) $p['jumlah_pembayaran'],
                        'tgl_pembayaran' => $p['tgl_pembayaran'],
                        'status_validasi' => $p['status_validasi'],
                        'catatan_validasi' => $p['catatan_validasi']
                    ];
                }, $pembayaran_list)
            ];

            $this->response('success', 'Laporan cicilan retrieved', $response);

        } catch (Exception $e) {
            $this->response('error', 'Failed to retrieve laporan cicilan: ' . $e->getMessage(), null, 'FETCH_FAILED', 500);
        }
    }

    /**
     * Log activity
     */
    private function logActivity($mahasiswa_id, $type, $description) {
        try {
            $log_data = [
                'mahasiswa_id' => $mahasiswa_id,
                'jenis_transaksi' => $type,
                'deskripsi' => $description,
                'tgl_transaksi' => date('Y-m-d H:i:s')
            ];

            $insert = "INSERT INTO riwayat_transaksi (mahasiswa_id, jenis_transaksi, deskripsi, tgl_transaksi)
                      VALUES (:mahasiswa_id, :jenis_transaksi, :deskripsi, :tgl_transaksi)";

            $stmt = $this->pdo->prepare($insert);
            $stmt->execute($log_data);
        } catch (Exception $e) {
            // Silently fail
        }
    }

    /**
     * GET /api/admin-fakultas/dashboard-info
     * Get dashboard info for admin fakultas (KARDUS STATISTIK)
     */
    public function dashboardInfo() {
        try {
            $user = $this->requireAuth();
            RoleMiddleware::adminFakultas($user);

            // Get admin's fakultas dari users table
            $check = "SELECT * FROM users WHERE user_id = :user_id AND role = 'admin_fakultas'";
            $stmt = $this->pdo->prepare($check);
            $stmt->execute(['user_id' => $user['user_id']]);
            $admin = $stmt->fetch();
            
            if (!$admin || !$admin['fakultas_id']) {
                $this->response('error', 'Admin fakultas tidak ditemukan atau belum diassign ke fakultas', null, 'NOT_FOUND', 404);
            }

            $fakultas_id = $admin['fakultas_id'];

            // Get fakultas info
            $fak_query = "SELECT * FROM fakultas WHERE fakultas_id = :fak_id LIMIT 1";
            $stmt = $this->pdo->prepare($fak_query);
            $stmt->execute(['fak_id' => $fakultas_id]);
            $fakultas = $stmt->fetch();

            // ===== STATISTIK 1: Total Mahasiswa Aktif =====
            $total_mhs = "SELECT COUNT(DISTINCT m.mahasiswa_id) as total 
                         FROM mahasiswa m
                         JOIN program_studi ps ON m.prodi_id = ps.prodi_id
                         WHERE ps.fakultas_id = :fakultas_id AND m.status_akademik = 'aktif'";
            
            $stmt = $this->pdo->prepare($total_mhs);
            $stmt->execute(['fakultas_id' => $fakultas_id]);
            $total_result = $stmt->fetch();
            $total_mahasiswa = (int) ($total_result['total'] ?? 0);

            // ===== STATISTIK 2: Pembayaran Lunas =====
            $pembayaran_lunas = "SELECT COUNT(DISTINCT m.mahasiswa_id) as total 
                                FROM mahasiswa m
                                JOIN program_studi ps ON m.prodi_id = ps.prodi_id
                                JOIN tagihan t ON m.mahasiswa_id = t.mahasiswa_id
                                WHERE ps.fakultas_id = :fakultas_id 
                                  AND m.status_akademik = 'aktif'
                                  AND t.status_pembayaran = 'lunas'";
            
            $stmt = $this->pdo->prepare($pembayaran_lunas);
            $stmt->execute(['fakultas_id' => $fakultas_id]);
            $lunas_result = $stmt->fetch();
            $mahasiswa_lunas = (int) ($lunas_result['total'] ?? 0);

            // ===== STATISTIK 3: Status Cicilan (metode pembayaran cicilan + bukan lunas) =====
            $status_cicilan = "SELECT COUNT(DISTINCT m.mahasiswa_id) as total 
                              FROM mahasiswa m
                              JOIN program_studi ps ON m.prodi_id = ps.prodi_id
                              JOIN tagihan t ON m.mahasiswa_id = t.mahasiswa_id
                              WHERE ps.fakultas_id = :fakultas_id 
                                AND m.status_akademik = 'aktif'
                                AND t.metode_pembayaran = 'cicilan' 
                                AND t.status_pembayaran != 'lunas'";
            
            $stmt = $this->pdo->prepare($status_cicilan);
            $stmt->execute(['fakultas_id' => $fakultas_id]);
            $cicilan_result = $stmt->fetch();
            $mahasiswa_cicilan = (int) ($cicilan_result['total'] ?? 0);

            // ===== STATISTIK 4: Belum Bayar =====
            $belum_bayar = "SELECT COUNT(DISTINCT m.mahasiswa_id) as total 
                           FROM mahasiswa m
                           JOIN program_studi ps ON m.prodi_id = ps.prodi_id
                           JOIN tagihan t ON m.mahasiswa_id = t.mahasiswa_id
                           WHERE ps.fakultas_id = :fakultas_id 
                             AND m.status_akademik = 'aktif'
                             AND t.status_pembayaran = 'belum_bayar'";
            
            $stmt = $this->pdo->prepare($belum_bayar);
            $stmt->execute(['fakultas_id' => $fakultas_id]);
            $belum_result = $stmt->fetch();
            $mahasiswa_belum_bayar = (int) ($belum_result['total'] ?? 0);

            $response = [
                'admin' => [
                    'user_id' => $user['user_id'],
                    'nama_lengkap' => $user['nama_lengkap'],
                    'email' => $user['email'],
                    'role' => 'admin_fakultas'
                ],
                'fakultas' => $fakultas ? [
                    'fakultas_id' => $fakultas['fakultas_id'],
                    'nama_fakultas' => $fakultas['nama_fakultas'],
                    'kode_fakultas' => $fakultas['kode_fakultas']
                ] : null,
                'statistik' => [
                    'total_mahasiswa' => $total_mahasiswa,
                    'mahasiswa_lunas' => $mahasiswa_lunas,
                    'mahasiswa_cicilan' => $mahasiswa_cicilan,
                    'mahasiswa_belum_bayar' => $mahasiswa_belum_bayar
                ]
            ];

            $this->response('success', 'Dashboard info retrieved', $response);

        } catch (Exception $e) {
            $this->response('error', 'Failed to retrieve dashboard info: ' . $e->getMessage(), null, 'FETCH_FAILED', 500);
        }
    }

    /**
     * GET /api/admin-fakultas/daftar-tagihan-validasi
     * Get list of billing data for validation (BAGIAN 3)
     */
    public function daftarTagihanValidasi() {
        try {
            $user = $this->requireAuth();
            RoleMiddleware::adminFakultas($user);

            // Get admin's fakultas
            $admin_query = "SELECT fakultas_id FROM users WHERE user_id = :user_id AND role = 'admin_fakultas'";
            $stmt = $this->pdo->prepare($admin_query);
            $stmt->execute(['user_id' => $user['user_id']]);
            $admin = $stmt->fetch();
            
            if (!$admin || !$admin['fakultas_id']) {
                $this->response('error', 'Admin tidak ditemukan', null, 'NOT_FOUND', 404);
            }

            $fakultas_id = $admin['fakultas_id'];
            $page = (int) ($_GET['page'] ?? 1);
            $limit = (int) ($_GET['limit'] ?? 10);
            $offset = ($page - 1) * $limit;

            // Get validated/paid billing data
            $query = "SELECT 
                     p.pembayaran_id,
                     m.nim,
                     u.nama_lengkap as nama_mahasiswa,
                     t.jenis_tagihan,
                     t.semester,
                     t.tahun_akademik,
                     t.jumlah_tagihan,
                     p.tgl_pembayaran,
                     p.status_validasi,
                     t.status_pembayaran,
                     ps.nama_prodi
                     FROM pembayaran p
                     JOIN tagihan t ON p.tagihan_id = t.tagihan_id
                     JOIN mahasiswa m ON p.mahasiswa_id = m.mahasiswa_id
                     JOIN users u ON m.user_id = u.user_id
                     JOIN program_studi ps ON m.prodi_id = ps.prodi_id
                     WHERE ps.fakultas_id = :fakultas_id
                       AND p.status_validasi = 'valid'
                       AND t.status_pembayaran = 'lunas'
                     ORDER BY p.tgl_pembayaran DESC
                     LIMIT :limit OFFSET :offset";

            $stmt = $this->pdo->prepare($query);
            $stmt->bindValue(':fakultas_id', $fakultas_id, PDO::PARAM_INT);
            $stmt->bindValue(':limit', $limit, PDO::PARAM_INT);
            $stmt->bindValue(':offset', $offset, PDO::PARAM_INT);
            $stmt->execute();
            $pembayaran = $stmt->fetchAll();

            // Get count
            $count_query = "SELECT COUNT(p.pembayaran_id) as total
                           FROM pembayaran p
                           JOIN tagihan t ON p.tagihan_id = t.tagihan_id
                           JOIN mahasiswa m ON p.mahasiswa_id = m.mahasiswa_id
                           JOIN program_studi ps ON m.prodi_id = ps.prodi_id
                           WHERE ps.fakultas_id = :fakultas_id
                             AND p.status_validasi = 'valid'
                             AND t.status_pembayaran = 'lunas'";

            $stmt = $this->pdo->prepare($count_query);
            $stmt->execute(['fakultas_id' => $fakultas_id]);
            $count = $stmt->fetch();

            // Get summary cards
            $summary_query = "SELECT 
                            COUNT(DISTINCT p.pembayaran_id) as total_tagihan_lunas,
                            COUNT(DISTINCT m.mahasiswa_id) as total_mahasiswa,
                            SUM(p.jumlah_pembayaran) as total_pembayaran
                            FROM pembayaran p
                            JOIN tagihan t ON p.tagihan_id = t.tagihan_id
                            JOIN mahasiswa m ON p.mahasiswa_id = m.mahasiswa_id
                            JOIN program_studi ps ON m.prodi_id = ps.prodi_id
                            WHERE ps.fakultas_id = :fakultas_id
                              AND p.status_validasi = 'valid'
                              AND t.status_pembayaran = 'lunas'";

            $stmt = $this->pdo->prepare($summary_query);
            $stmt->execute(['fakultas_id' => $fakultas_id]);
            $summary = $stmt->fetch();

            $response = [
                'summary' => [
                    'total_tagihan_lunas' => (int) ($summary['total_tagihan_lunas'] ?? 0),
                    'total_mahasiswa' => (int) ($summary['total_mahasiswa'] ?? 0),
                    'total_pembayaran' => (float) ($summary['total_pembayaran'] ?? 0)
                ],
                'daftar' => array_map(function($item) {
                    return [
                        'pembayaran_id' => $item['pembayaran_id'],
                        'nim' => $item['nim'],
                        'nama_mahasiswa' => $item['nama_mahasiswa'],
                        'prodi' => $item['nama_prodi'],
                        'jenis_tagihan' => $item['jenis_tagihan'],
                        'semester' => $item['semester'],
                        'tahun_akademik' => $item['tahun_akademik'],
                        'jumlah' => (float) $item['jumlah_tagihan'],
                        'tgl_pembayaran' => $item['tgl_pembayaran'],
                        'status_pembayaran' => $item['status_pembayaran'],
                        'status_validasi' => $item['status_validasi']
                    ];
                }, $pembayaran),
                'pagination' => [
                    'page' => $page,
                    'limit' => $limit,
                    'total' => (int) ($count['total'] ?? 0),
                    'total_pages' => ceil(($count['total'] ?? 0) / $limit)
                ]
            ];

            $this->response('success', 'Daftar tagihan validasi retrieved', $response);

        } catch (Exception $e) {
            $this->response('error', 'Failed to retrieve tagihan: ' . $e->getMessage(), null, 'FETCH_FAILED', 500);
        }
    }

    /**
     * GET /api/admin-fakultas/monitoring-cicilan
     * Get installment monitoring data (BAGIAN 4)
     */
    public function monitoringCicilan() {
        try {
            $user = $this->requireAuth();
            RoleMiddleware::adminFakultas($user);

            // Get admin's fakultas
            $admin_query = "SELECT fakultas_id FROM users WHERE user_id = :user_id AND role = 'admin_fakultas'";
            $stmt = $this->pdo->prepare($admin_query);
            $stmt->execute(['user_id' => $user['user_id']]);
            $admin = $stmt->fetch();
            
            if (!$admin || !$admin['fakultas_id']) {
                $this->response('error', 'Admin tidak ditemukan', null, 'NOT_FOUND', 404);
            }

            $fakultas_id = $admin['fakultas_id'];
            $page = (int) ($_GET['page'] ?? 1);
            $limit = (int) ($_GET['limit'] ?? 10);
            $offset = ($page - 1) * $limit;

            // Get cicilan data
            $query = "SELECT 
                     m.mahasiswa_id,
                     m.nim,
                     u.nama_lengkap as nama_mahasiswa,
                     t.semester,
                     t.jumlah_tagihan,
                     t.jenis_tagihan,
                     t.metode_pembayaran,
                     t.status_pembayaran,
                     COALESCE(SUM(p.jumlah_pembayaran), 0) as total_dibayar,
                     (t.jumlah_tagihan - COALESCE(SUM(p.jumlah_pembayaran), 0)) as sisa_cicilan
                     FROM mahasiswa m
                     JOIN users u ON m.user_id = u.user_id
                     JOIN program_studi ps ON m.prodi_id = ps.prodi_id
                     JOIN tagihan t ON m.mahasiswa_id = t.mahasiswa_id
                     LEFT JOIN pembayaran p ON t.tagihan_id = p.tagihan_id AND p.status_validasi = 'valid'
                     WHERE ps.fakultas_id = :fakultas_id
                       AND t.metode_pembayaran = 'cicilan'
                       AND m.status_akademik = 'aktif'
                     GROUP BY m.mahasiswa_id, t.tagihan_id
                     ORDER BY m.nim ASC
                     LIMIT :limit OFFSET :offset";

            $stmt = $this->pdo->prepare($query);
            $stmt->bindValue(':fakultas_id', $fakultas_id, PDO::PARAM_INT);
            $stmt->bindValue(':limit', $limit, PDO::PARAM_INT);
            $stmt->bindValue(':offset', $offset, PDO::PARAM_INT);
            $stmt->execute();
            $cicilan_list = $stmt->fetchAll();

            // Get count
            $count_query = "SELECT COUNT(DISTINCT m.mahasiswa_id) as total
                           FROM mahasiswa m
                           JOIN program_studi ps ON m.prodi_id = ps.prodi_id
                           JOIN tagihan t ON m.mahasiswa_id = t.mahasiswa_id
                           WHERE ps.fakultas_id = :fakultas_id
                             AND t.metode_pembayaran = 'cicilan'
                             AND m.status_akademik = 'aktif'";

            $stmt = $this->pdo->prepare($count_query);
            $stmt->execute(['fakultas_id' => $fakultas_id]);
            $count = $stmt->fetch();

            $response = [
                'daftar' => array_map(function($item) {
                    return [
                        'mahasiswa_id' => $item['mahasiswa_id'],
                        'nim' => $item['nim'],
                        'nama_mahasiswa' => $item['nama_mahasiswa'],
                        'semester' => $item['semester'],
                        'jenis_tagihan' => $item['jenis_tagihan'],
                        'total_tagihan' => (float) $item['jumlah_tagihan'],
                        'total_dibayar' => (float) $item['total_dibayar'],
                        'sisa_cicilan' => (float) $item['sisa_cicilan'],
                        'status_pembayaran' => $item['status_pembayaran'],
                        'metode_pembayaran' => $item['metode_pembayaran'],
                        'persentase_dibayar' => $item['jumlah_tagihan'] > 0 
                            ? round(($item['total_dibayar'] / $item['jumlah_tagihan']) * 100, 2)
                            : 0
                    ];
                }, $cicilan_list),
                'pagination' => [
                    'page' => $page,
                    'limit' => $limit,
                    'total' => (int) ($count['total'] ?? 0),
                    'total_pages' => ceil(($count['total'] ?? 0) / $limit)
                ]
            ];

            $this->response('success', 'Monitoring cicilan retrieved', $response);

        } catch (Exception $e) {
            $this->response('error', 'Failed to retrieve monitoring cicilan: ' . $e->getMessage(), null, 'FETCH_FAILED', 500);
        }
    }

    /**
     * GET /api/admin-fakultas/daftar-pembayaran
     * Get complete billing list for validation (BAGIAN 2)
     */
    public function daftarPembayaran() {
        try {
            $user = $this->requireAuth();
            RoleMiddleware::adminFakultas($user);

            // Get admin's fakultas
            $admin_query = "SELECT fakultas_id FROM users WHERE user_id = :user_id AND role = 'admin_fakultas'";
            $stmt = $this->pdo->prepare($admin_query);
            $stmt->execute(['user_id' => $user['user_id']]);
            $admin = $stmt->fetch();
            
            if (!$admin || !$admin['fakultas_id']) {
                $this->response('error', 'Admin tidak ditemukan', null, 'NOT_FOUND', 404);
            }

            $fakultas_id = $admin['fakultas_id'];
            $page = (int) ($_GET['page'] ?? 1);
            $limit = (int) ($_GET['limit'] ?? 10);
            $offset = ($page - 1) * $limit;
            $status_filter = $_GET['status'] ?? 'valid';

            // Build query - Default show only VALID payments
            $query = "SELECT 
                     p.pembayaran_id,
                     p.tagihan_id,
                     p.mahasiswa_id,
                     m.nim,
                     u.nama_lengkap as nama_mahasiswa,
                     t.jenis_tagihan,
                     t.semester,
                     t.tahun_akademik,
                     t.jumlah_tagihan,
                     p.jumlah_pembayaran,
                     p.tgl_pembayaran,
                     p.status_validasi,
                     t.status_pembayaran,
                     p.bukti_pembayaran_filename,
                     ps.nama_prodi,
                     k.status_krs
                     FROM pembayaran p
                     JOIN tagihan t ON p.tagihan_id = t.tagihan_id
                     JOIN mahasiswa m ON p.mahasiswa_id = m.mahasiswa_id
                     JOIN users u ON m.user_id = u.user_id
                     JOIN program_studi ps ON m.prodi_id = ps.prodi_id
                     LEFT JOIN krs k ON m.mahasiswa_id = k.mahasiswa_id AND t.semester = k.semester
                     WHERE ps.fakultas_id = :fakultas_id
                     AND p.status_validasi = :status_validasi";

            $params = ['fakultas_id' => $fakultas_id, 'status_validasi' => $status_filter];

            $query .= " ORDER BY p.tgl_pembayaran DESC
                       LIMIT :limit OFFSET :offset";

            $stmt = $this->pdo->prepare($query);
            foreach ($params as $key => $value) {
                if ($key !== 'limit' && $key !== 'offset') {
                    $stmt->bindValue(":$key", $value);
                }
            }
            $stmt->bindValue(':limit', $limit, PDO::PARAM_INT);
            $stmt->bindValue(':offset', $offset, PDO::PARAM_INT);
            $stmt->execute();
            $pembayaran_list = $stmt->fetchAll();

            // Get count
            $count_query = "SELECT COUNT(p.pembayaran_id) as total
                           FROM pembayaran p
                           JOIN tagihan t ON p.tagihan_id = t.tagihan_id
                           JOIN mahasiswa m ON p.mahasiswa_id = m.mahasiswa_id
                           JOIN program_studi ps ON m.prodi_id = ps.prodi_id
                           WHERE ps.fakultas_id = :fakultas_id
                           AND p.status_validasi = :status_validasi";

            $stmt = $this->pdo->prepare($count_query);
            $stmt->execute($params);
            $count = $stmt->fetch();

            $response = [
                'daftar' => array_map(function($item) {
                    return [
                        'pembayaran_id' => $item['pembayaran_id'],
                        'tagihan_id' => $item['tagihan_id'],
                        'mahasiswa_id' => $item['mahasiswa_id'],
                        'nim' => $item['nim'],
                        'nama_mahasiswa' => $item['nama_mahasiswa'],
                        'prodi' => $item['nama_prodi'],
                        'jenis_tagihan' => $item['jenis_tagihan'],
                        'semester' => $item['semester'],
                        'tahun_akademik' => $item['tahun_akademik'],
                        'jumlah_tagihan' => (float) $item['jumlah_tagihan'],
                        'jumlah_pembayaran' => (float) $item['jumlah_pembayaran'],
                        'tgl_pembayaran' => $item['tgl_pembayaran'],
                        'status_pembayaran' => $item['status_pembayaran'],
                        'status_validasi' => $item['status_validasi'],
                        'status_krs' => $item['status_krs'] ?? 'tidak_ada',
                        'bukti_pembayaran' => $item['bukti_pembayaran_filename']
                    ];
                }, $pembayaran_list),
                'pagination' => [
                    'page' => $page,
                    'limit' => $limit,
                    'total' => (int) ($count['total'] ?? 0),
                    'total_pages' => ceil(($count['total'] ?? 0) / $limit)
                ]
            ];

            $this->response('success', 'Daftar pembayaran retrieved', $response);

        } catch (Exception $e) {
            $this->response('error', 'Failed to retrieve daftar pembayaran: ' . $e->getMessage(), null, 'FETCH_FAILED', 500);
        }
    }

    /**
     * GET /api/admin-fakultas/riwayat-pembayaran
     * Get payment history for admin facultas (BAGIAN 5)
     */
    public function riwayatPembayaran() {
        try {
            $user = $this->requireAuth();
            RoleMiddleware::adminFakultas($user);

            // Get admin's fakultas
            $admin_query = "SELECT fakultas_id FROM users WHERE user_id = :user_id AND role = 'admin_fakultas'";
            $stmt = $this->pdo->prepare($admin_query);
            $stmt->execute(['user_id' => $user['user_id']]);
            $admin = $stmt->fetch();
            
            if (!$admin || !$admin['fakultas_id']) {
                $this->response('error', 'Admin tidak ditemukan', null, 'NOT_FOUND', 404);
            }

            $fakultas_id = $admin['fakultas_id'];
            $page = (int) ($_GET['page'] ?? 1);
            $limit = (int) ($_GET['limit'] ?? 20);
            $offset = ($page - 1) * $limit;

            // Get payment history
            $query = "SELECT 
                     p.pembayaran_id,
                     m.nim,
                     u.nama_lengkap as nama_mahasiswa,
                     t.jenis_tagihan,
                     p.jumlah_pembayaran,
                     p.tgl_pembayaran,
                     p.status_validasi,
                     p.catatan_validasi,
                     ps.nama_prodi
                     FROM pembayaran p
                     JOIN tagihan t ON p.tagihan_id = t.tagihan_id
                     JOIN mahasiswa m ON p.mahasiswa_id = m.mahasiswa_id
                     JOIN users u ON m.user_id = u.user_id
                     JOIN program_studi ps ON m.prodi_id = ps.prodi_id
                     WHERE ps.fakultas_id = :fakultas_id
                     ORDER BY p.tgl_pembayaran DESC
                     LIMIT :limit OFFSET :offset";

            $stmt = $this->pdo->prepare($query);
            $stmt->bindValue(':fakultas_id', $fakultas_id, PDO::PARAM_INT);
            $stmt->bindValue(':limit', $limit, PDO::PARAM_INT);
            $stmt->bindValue(':offset', $offset, PDO::PARAM_INT);
            $stmt->execute();
            $riwayat = $stmt->fetchAll();

            // Get count
            $count_query = "SELECT COUNT(p.pembayaran_id) as total
                           FROM pembayaran p
                           JOIN tagihan t ON p.tagihan_id = t.tagihan_id
                           JOIN mahasiswa m ON p.mahasiswa_id = m.mahasiswa_id
                           JOIN program_studi ps ON m.prodi_id = ps.prodi_id
                           WHERE ps.fakultas_id = :fakultas_id";

            $stmt = $this->pdo->prepare($count_query);
            $stmt->execute(['fakultas_id' => $fakultas_id]);
            $count = $stmt->fetch();

            // Status counts
            $status_counts = "SELECT 
                             p.status_validasi,
                             COUNT(p.pembayaran_id) as total
                             FROM pembayaran p
                             JOIN tagihan t ON p.tagihan_id = t.tagihan_id
                             JOIN mahasiswa m ON p.mahasiswa_id = m.mahasiswa_id
                             JOIN program_studi ps ON m.prodi_id = ps.prodi_id
                             WHERE ps.fakultas_id = :fakultas_id
                             GROUP BY p.status_validasi";

            $stmt = $this->pdo->prepare($status_counts);
            $stmt->execute(['fakultas_id' => $fakultas_id]);
            $statuses = $stmt->fetchAll();

            $status_summary = [];
            foreach ($statuses as $s) {
                $status_summary[$s['status_validasi']] = (int) $s['total'];
            }

            $response = [
                'summary' => [
                    'menunggu_validasi' => $status_summary['menunggu_validasi'] ?? 0,
                    'valid' => $status_summary['valid'] ?? 0,
                    'ditolak' => $status_summary['ditolak'] ?? 0
                ],
                'riwayat' => array_map(function($item) {
                    return [
                        'pembayaran_id' => $item['pembayaran_id'],
                        'nim' => $item['nim'],
                        'nama_mahasiswa' => $item['nama_mahasiswa'],
                        'prodi' => $item['nama_prodi'],
                        'jenis_tagihan' => $item['jenis_tagihan'],
                        'jumlah' => (float) $item['jumlah_pembayaran'],
                        'tanggal' => $item['tgl_pembayaran'],
                        'status' => $item['status_validasi'],
                        'catatan' => $item['catatan_validasi'] ?? null
                    ];
                }, $riwayat),
                'pagination' => [
                    'page' => $page,
                    'limit' => $limit,
                    'total' => (int) ($count['total'] ?? 0),
                    'total_pages' => ceil(($count['total'] ?? 0) / $limit)
                ]
            ];

            $this->response('success', 'Riwayat pembayaran retrieved', $response);

        } catch (Exception $e) {
            $this->response('error', 'Failed to retrieve riwayat pembayaran: ' . $e->getMessage(), null, 'FETCH_FAILED', 500);
        }
    }
}

