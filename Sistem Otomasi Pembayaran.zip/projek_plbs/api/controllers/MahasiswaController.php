<?php
/**
 * Mahasiswa Controller
 * Handle student dashboard, tagihan, etc
 */

class MahasiswaController extends Controller {

    /**
     * GET /api/mahasiswa/dashboard
     * Show student dashboard with summary
     */
    public function dashboard() {
        try {
            $user = $this->requireAuth();
            RoleMiddleware::mahasiswa($user);

            // Get mahasiswa data
            $query = "SELECT m.*, ps.nama_prodi, f.nama_fakultas
                      FROM mahasiswa m
                      JOIN program_studi ps ON m.prodi_id = ps.prodi_id
                      JOIN fakultas f ON ps.fakultas_id = f.fakultas_id
                      WHERE m.user_id = :user_id
                      LIMIT 1";

            $stmt = $this->pdo->prepare($query);
            $stmt->execute(['user_id' => $user['user_id']]);
            $mahasiswa = $stmt->fetch();

            if (!$mahasiswa) {
                $this->response('error', 'Mahasiswa data not found', null, 'NOT_FOUND', 404);
            }

            // Get tagihan summary
            $query_summary = "SELECT 
                            SUM(CASE WHEN status_pembayaran = 'belum_bayar' THEN jumlah_tagihan ELSE 0 END) as total_belum_bayar,
                            SUM(CASE WHEN status_pembayaran = 'cicilan' THEN jumlah_tagihan ELSE 0 END) as total_cicilan,
                            SUM(CASE WHEN status_pembayaran = 'lunas' THEN jumlah_tagihan ELSE 0 END) as total_lunas
                            FROM tagihan
                            WHERE mahasiswa_id = :mahasiswa_id";

            $stmt = $this->pdo->prepare($query_summary);
            $stmt->execute(['mahasiswa_id' => $mahasiswa['mahasiswa_id']]);
            $summary = $stmt->fetch();

            $response = [
                'mahasiswa_id' => $mahasiswa['mahasiswa_id'],
                'nim' => $mahasiswa['nim'],
                'nama_lengkap' => $user['nama_lengkap'],
                'semester_aktif' => $mahasiswa['semester_aktif'],
                'tahun_akademik' => $mahasiswa['tahun_akademik'],
                'nama_prodi' => $mahasiswa['nama_prodi'],
                'nama_fakultas' => $mahasiswa['nama_fakultas'],
                'status_akademik' => $mahasiswa['status_akademik'],
                'ringkasan_tagihan' => [
                    'total_belum_bayar' => (int) ($summary['total_belum_bayar'] ?? 0),
                    'total_cicilan' => (int) ($summary['total_cicilan'] ?? 0),
                    'total_lunas' => (int) ($summary['total_lunas'] ?? 0)
                ]
            ];

            $this->response('success', 'Dashboard loaded successfully', $response);

        } catch (Exception $e) {
            $this->response('error', 'Failed to load dashboard: ' . $e->getMessage(), null, 'LOAD_FAILED', 500);
        }
    }

    /**
     * GET /api/mahasiswa/tagihan
     * Show active BPP billing for current semester
     * 
     * RESTRICTION: HANYA untuk Fakultas Ilmu Komputer (Teknik Informatika & Sistem Informasi)
     * 
     * ALUR:
     * 1. Validasi: Mahasiswa dari FK Ilmu Komputer?
     * 2. Validasi: Prodi = Teknik Informatika / Sistem Informasi?
     * 3. Ambil semester_aktif mahasiswa
     * 4. Cek tagihan BPP semester aktif
     * 5. Jika belum ada → ambil tarif & buat otomatis
     * 6. Jika sudah ada → tampilkan
     * 
     * Business Rules:
     * - Tagihan hanya untuk FK Ilmu Komputer
     * - Prodi hanya: Teknik Informatika (TI) & Sistem Informasi (SI)
     * - Nominal dari tarif table (by prodi)
     * - Backend check duplikasi sebelum insert
     */
    public function tagihan() {
        try {
            $user = $this->requireAuth();
            RoleMiddleware::mahasiswa($user);

            // STEP 1: VALIDASI FAKULTAS & PROGRAM STUDI
            // Only Fakultas Ilmu Komputer + Teknik Informatika/Sistem Informasi
            $validation_query = "SELECT m.mahasiswa_id, m.semester_aktif, m.tahun_akademik, m.prodi_id, 
                                        f.fakultas_id, f.nama_fakultas, ps.nama_prodi
                                 FROM mahasiswa m
                                 JOIN program_studi ps ON m.prodi_id = ps.prodi_id
                                 JOIN fakultas f ON ps.fakultas_id = f.fakultas_id
                                 WHERE m.user_id = :user_id 
                                   AND f.nama_fakultas = 'Fakultas Ilmu Komputer'
                                   AND ps.nama_prodi IN ('Teknik Informatika', 'Sistem Informasi')
                                 LIMIT 1";
            
            $stmt = $this->pdo->prepare($validation_query);
            $stmt->execute(['user_id' => $user['user_id']]);
            $mahasiswa = $stmt->fetch();

            // REJECTION: Jika bukan FK Ilmu Komputer atau bukan TI/SI
            if (!$mahasiswa) {
                $this->response(
                    'error', 
                    'Sistem tagihan BPP hanya berlaku untuk Fakultas Ilmu Komputer (Teknik Informatika & Sistem Informasi)', 
                    null, 
                    'INVALID_FACULTY', 
                    403
                );
            }

            // STEP 2: CEK TAGIHAN BPP SUDAH ADA
            $check_query = "SELECT tagihan_id, jumlah_tagihan, status_pembayaran
                            FROM tagihan
                            WHERE mahasiswa_id = :mahasiswa_id 
                              AND jenis_tagihan = 'BPP'
                              AND semester = :semester
                              AND tahun_akademik = :tahun_akademik
                              AND status_pembayaran != 'lunas'
                            LIMIT 1";
            
            $stmt = $this->pdo->prepare($check_query);
            $stmt->execute([
                'mahasiswa_id' => $mahasiswa['mahasiswa_id'],
                'semester' => $mahasiswa['semester_aktif'],
                'tahun_akademik' => $mahasiswa['tahun_akademik']
            ]);
            $tagihan = $stmt->fetch();

            // STEP 3: JIKA TIDAK ADA → BUAT OTOMATIS DARI TARIF
            if (!$tagihan) {
                // Lookup tarif spesifik untuk prodi FK Ilmu Komputer
                $tarif_query = "SELECT nominal FROM tarif
                                WHERE prodi_id = :prodi_id
                                  AND jenis_tagihan = 'BPP'
                                  AND :semester BETWEEN semester_dari AND semester_sampai
                                  AND tahun_akademik = :tahun_akademik
                                  AND is_active = TRUE
                                LIMIT 1";
                
                $stmt = $this->pdo->prepare($tarif_query);
                $stmt->execute([
                    'prodi_id' => $mahasiswa['prodi_id'],
                    'semester' => $mahasiswa['semester_aktif'],
                    'tahun_akademik' => $mahasiswa['tahun_akademik']
                ]);
                $tarif = $stmt->fetch();

                // Jika tidak ada tarif spesifik prodi, gunakan default FK
                if (!$tarif) {
                    $default_tarif_query = "SELECT nominal FROM tarif
                                           WHERE fakultas_id = :fakultas_id
                                             AND prodi_id IS NULL
                                             AND jenis_tagihan = 'BPP'
                                             AND tahun_akademik = :tahun_akademik
                                             AND is_active = TRUE
                                           LIMIT 1";
                    
                    $stmt = $this->pdo->prepare($default_tarif_query);
                    $stmt->execute([
                        'fakultas_id' => $mahasiswa['fakultas_id'],
                        'tahun_akademik' => $mahasiswa['tahun_akademik']
                    ]);
                    $tarif = $stmt->fetch();
                }

                if (!$tarif || empty($tarif['nominal'])) {
                    $this->response(
                        'error', 
                        'Tarif BPP tidak dikonfigurasi untuk program studi Anda', 
                        null, 
                        'TARIF_NOT_FOUND', 
                        400
                    );
                }

                // INSERT tagihan baru dengan jumlah dari tarif FK IK
                $jumlah = $tarif['nominal'];
                $tgl_jatuh_tempo = date('Y-12-31', strtotime($mahasiswa['tahun_akademik'] . '-01-01'));

                $insert_query = "INSERT INTO tagihan (mahasiswa_id, jenis_tagihan, semester, tahun_akademik, jumlah_tagihan, status_pembayaran, metode_pembayaran, tgl_jatuh_tempo, created_at, updated_at)
                                 VALUES (:mahasiswa_id, 'BPP', :semester, :tahun_akademik, :jumlah_tagihan, 'belum_bayar', 'lunas', :tgl_jatuh_tempo, NOW(), NOW())";
                
                $stmt = $this->pdo->prepare($insert_query);
                $result = $stmt->execute([
                    'mahasiswa_id' => $mahasiswa['mahasiswa_id'],
                    'semester' => $mahasiswa['semester_aktif'],
                    'tahun_akademik' => $mahasiswa['tahun_akademik'],
                    'jumlah_tagihan' => $jumlah,
                    'tgl_jatuh_tempo' => $tgl_jatuh_tempo
                ]);

                if (!$result) {
                    $this->response('error', 'Gagal membuat tagihan BPP', null, 'INSERT_FAILED', 500);
                }

                // Ambil tagihan yang baru dibuat
                $check_query = "SELECT tagihan_id, jumlah_tagihan, status_pembayaran
                                FROM tagihan
                                WHERE mahasiswa_id = :mahasiswa_id 
                                  AND jenis_tagihan = 'BPP'
                                  AND semester = :semester
                                  AND tahun_akademik = :tahun_akademik
                                LIMIT 1";
                
                $stmt = $this->pdo->prepare($check_query);
                $stmt->execute([
                    'mahasiswa_id' => $mahasiswa['mahasiswa_id'],
                    'semester' => $mahasiswa['semester_aktif'],
                    'tahun_akademik' => $mahasiswa['tahun_akademik']
                ]);
                $tagihan = $stmt->fetch();
            }

            // STEP 4: FORMAT DAN RETURN RESPONSE (dengan info fakultas & prodi)
            $response = [
                'fakultas' => $mahasiswa['nama_fakultas'],  // "Fakultas Ilmu Komputer"
                'program_studi' => $mahasiswa['nama_prodi'],  // "Teknik Informatika" atau "Sistem Informasi"
                'tagihan_id' => $tagihan['tagihan_id'],
                'jenis_tagihan' => 'BPP',
                'semester' => $mahasiswa['semester_aktif'],
                'tahun_akademik' => $mahasiswa['tahun_akademik'],
                'jumlah_tagihan' => (int) $tagihan['jumlah_tagihan'],
                'status_pembayaran' => $tagihan['status_pembayaran']
            ];

            $this->response('success', 'Tagihan BPP Fakultas Ilmu Komputer berhasil dimuat', $response);

        } catch (Exception $e) {
            $this->response('error', 'Gagal memproses tagihan: ' . $e->getMessage(), null, 'PROCESS_FAILED', 500);
        }
    }

    /**
     * GET /api/mahasiswa/tagihan/{tagihan_id}
     * Show detail of specific tagihan with payment history
     */
    public function detailTagihan($tagihan_id) {
        try {
            $user = $this->requireAuth();
            RoleMiddleware::mahasiswa($user);

            $tagihan_id = (int) $tagihan_id;

            // Get tagihan and verify ownership
            $query = "SELECT t.* FROM tagihan t
                      JOIN mahasiswa m ON t.mahasiswa_id = m.mahasiswa_id
                      WHERE t.tagihan_id = :tagihan_id AND m.user_id = :user_id
                      LIMIT 1";

            $stmt = $this->pdo->prepare($query);
            $stmt->execute(['tagihan_id' => $tagihan_id, 'user_id' => $user['user_id']]);
            $tagihan = $stmt->fetch();

            if (!$tagihan) {
                $this->response('error', 'Tagihan not found', null, 'NOT_FOUND', 404);
            }

            // Get virtual accounts
            $va_query = "SELECT * FROM virtual_account WHERE tagihan_id = :tagihan_id ORDER BY tgl_pembuatan DESC";
            $va_stmt = $this->pdo->prepare($va_query);
            $va_stmt->execute(['tagihan_id' => $tagihan_id]);
            $vas = $va_stmt->fetchAll();

            // Get payments
            $payment_query = "SELECT * FROM pembayaran WHERE tagihan_id = :tagihan_id ORDER BY tgl_pembayaran DESC";
            $payment_stmt = $this->pdo->prepare($payment_query);
            $payment_stmt->execute(['tagihan_id' => $tagihan_id]);
            $payments = $payment_stmt->fetchAll();

            $response = [
                'tagihan' => [
                    'tagihan_id' => $tagihan['tagihan_id'],
                    'jenis_tagihan' => $tagihan['jenis_tagihan'],
                    'semester' => $tagihan['semester'],
                    'tahun_akademik' => $tagihan['tahun_akademik'],
                    'jumlah_tagihan' => (int) $tagihan['jumlah_tagihan'],
                    'status_pembayaran' => $tagihan['status_pembayaran'],
                    'metode_pembayaran' => $tagihan['metode_pembayaran'],
                    'tgl_jatuh_tempo' => $tagihan['tgl_jatuh_tempo']
                ],
                'virtual_accounts' => array_map(function($va) {
                    return [
                        'va_id' => $va['va_id'],
                        'nomor_va' => $va['nomor_va'],
                        'metode_pembayaran' => $va['metode_pembayaran'],
                        'jumlah_va' => (int) $va['jumlah_va'],
                        'total_diterima' => (int) $va['total_diterima'],
                        'status_va' => $va['status_va'],
                        'tgl_kadaluarsa' => $va['tgl_kadaluarsa']
                    ];
                }, $vas),
                'payments' => array_map(function($p) {
                    return [
                        'pembayaran_id' => $p['pembayaran_id'],
                        'jumlah_pembayaran' => (int) $p['jumlah_pembayaran'],
                        'tgl_pembayaran' => $p['tgl_pembayaran'],
                        'status_validasi' => $p['status_validasi'],
                        'tgl_validasi' => $p['tgl_validasi']
                    ];
                }, $payments)
            ];

            $this->response('success', 'Tagihan detail loaded', $response);

        } catch (Exception $e) {
            $this->response('error', 'Failed to load tagihan detail: ' . $e->getMessage(), null, 'LOAD_FAILED', 500);
        }
    }

    /**
     * GET /api/mahasiswa/semua-tagihan
     * Get all tagihan for current mahasiswa for dashboard filtering
     * Frontend will filter berdasarkan semester_aktif dan rules bisnis
     */
    public function semuaTagihan() {
        try {
            $user = $this->requireAuth();
            RoleMiddleware::mahasiswa($user);

            // STEP 1: Get mahasiswa complete info including user data
            $mhs_query = "SELECT m.mahasiswa_id, m.semester_aktif, m.prodi_id, m.tahun_akademik, u.nim_or_id
                         FROM mahasiswa m
                         JOIN users u ON m.user_id = u.user_id
                         WHERE m.user_id = :user_id LIMIT 1";
            
            $stmt = $this->pdo->prepare($mhs_query);
            $stmt->execute(['user_id' => $user['user_id']]);
            $mahasiswa = $stmt->fetch();

            if (!$mahasiswa) {
                $this->response('error', 'Mahasiswa not found', null, 'NOT_FOUND', 404);
                return;
            }

            // STEP 2: Auto-create BPP tagihan if needed
            // For new students or students with gap in payment
            autoCreateBPPTagihan(
                $this->pdo,
                $mahasiswa['mahasiswa_id'],
                (int) $mahasiswa['semester_aktif'],
                $mahasiswa['tahun_akademik'],
                (int) $mahasiswa['prodi_id']
            );

            // STEP 3: Auto-create Proposal tagihan if student qualified
            // Only if completed BPP payment up to semester 6
            autoCreateProposalTagihan(
                $this->pdo,
                $mahasiswa['mahasiswa_id'],
                $mahasiswa['tahun_akademik'],
                (int) $mahasiswa['prodi_id']
            );

            // STEP 4: Auto-create Skripsi tagihan if student qualified
            // Only if completed BPP payment up to semester 7
            autoCreateSkripsiTagihan(
                $this->pdo,
                $mahasiswa['mahasiswa_id'],
                $mahasiswa['tahun_akademik'],
                (int) $mahasiswa['prodi_id']
            );

            // STEP 5: Get all non-lunas tagihan untuk mahasiswa ini
            $tagihan_query = "SELECT 
                             tagihan_id,
                             jenis_tagihan,
                             semester,
                             tahun_akademik,
                             jumlah_tagihan,
                             status_pembayaran
                         FROM tagihan 
                         WHERE mahasiswa_id = :mahasiswa_id
                           AND status_pembayaran != 'lunas'
                         ORDER BY jenis_tagihan = 'BPP' DESC, semester ASC, jenis_tagihan ASC";
            
            $stmt = $this->pdo->prepare($tagihan_query);
            $stmt->execute(['mahasiswa_id' => $mahasiswa['mahasiswa_id']]);
            $tagihan_list = $stmt->fetchAll();

            $response = [
                'semester_aktif' => (int) $mahasiswa['semester_aktif'],
                'nim' => $mahasiswa['nim_or_id'],
                'tagihan' => array_map(function($t) {
                    return [
                        'tagihan_id' => $t['tagihan_id'],
                        'jenis_tagihan' => $t['jenis_tagihan'],
                        'semester' => $t['semester'] ? (int) $t['semester'] : null,
                        'tahun_akademik' => $t['tahun_akademik'],
                        'jumlah_tagihan' => (int) $t['jumlah_tagihan'],
                        'status_pembayaran' => $t['status_pembayaran']
                    ];
                }, $tagihan_list)
            ];

            $this->response('success', 'All tagihan retrieved', $response);

        } catch (Exception $e) {
            $this->response('error', 'Failed to retrieve tagihan: ' . $e->getMessage(), null, 'FETCH_FAILED', 500);
        }
    }

    /**
     * GET /api/mahasiswa/dashboard-info
     * Get complete dashboard data with smart tagihan management
     * 
     * LOGIC:
     * 1. Auto-create BPP tagihan if student has unpaid semester
     * 2. Auto-create Proposal if BPP up to sem 6 completed
     * 3. Auto-create Skripsi if BPP up to sem 7 completed
     * 4. Show "no active billing" ONLY if ALL BPP paid (student completed)
     * 5. Use nim_or_id from users table as academic identity
     */
    public function dashboardInfo() {
        try {
            $user = $this->requireAuth();
            RoleMiddleware::mahasiswa($user);

            // STEP 1: Get mahasiswa info dengan user data (untuk nim_or_id)
            $mhs_query = "SELECT m.*, ps.nama_prodi, f.nama_fakultas, u.nim_or_id
                         FROM mahasiswa m
                         JOIN program_studi ps ON m.prodi_id = ps.prodi_id
                         JOIN fakultas f ON ps.fakultas_id = f.fakultas_id
                         JOIN users u ON m.user_id = u.user_id
                         WHERE m.user_id = :user_id LIMIT 1";
            
            $stmt = $this->pdo->prepare($mhs_query);
            $stmt->execute(['user_id' => $user['user_id']]);
            $mahasiswa = $stmt->fetch();

            if (!$mahasiswa) {
                $this->response('error', 'Mahasiswa not found', null, 'NOT_FOUND', 404);
                return;
            }

            // STEP 2: Get current semester info
            $sem_info = getCurrentSemesterInfo();

            // STEP 3: Auto-create BPP tagihan if needed
            autoCreateBPPTagihan(
                $this->pdo,
                $mahasiswa['mahasiswa_id'],
                (int) $mahasiswa['semester_aktif'],
                $mahasiswa['tahun_akademik'],
                (int) $mahasiswa['prodi_id']
            );

            // STEP 4: Auto-create Proposal if eligible
            autoCreateProposalTagihan(
                $this->pdo,
                $mahasiswa['mahasiswa_id'],
                $mahasiswa['tahun_akademik'],
                (int) $mahasiswa['prodi_id']
            );

            // STEP 5: Auto-create Skripsi if eligible
            autoCreateSkripsiTagihan(
                $this->pdo,
                $mahasiswa['mahasiswa_id'],
                $mahasiswa['tahun_akademik'],
                (int) $mahasiswa['prodi_id']
            );

            // STEP 6: Get current unpaid tagihan (prioritize BPP, then Proposal, then Skripsi)
            // Return ALL unpaid tagihan, not just one
            $tagihan_query = "SELECT * FROM tagihan 
                             WHERE mahasiswa_id = :mahasiswa_id
                               AND status_pembayaran != 'lunas'
                             ORDER BY 
                               CASE UPPER(jenis_tagihan)
                                 WHEN 'BPP' THEN 1 
                                 WHEN 'PROPOSAL' THEN 2 
                                 WHEN 'SKRIPSI' THEN 3 
                                 ELSE 4 
                               END,
                               semester ASC";
            
            $stmt = $this->pdo->prepare($tagihan_query);
            $stmt->execute(['mahasiswa_id' => $mahasiswa['mahasiswa_id']]);
            $tagihan_list = $stmt->fetchAll();
            
            // Get first tagihan for backward compatibility
            $tagihan = !empty($tagihan_list) ? $tagihan_list[0] : null;

            // STEP 7: Check if student has any unpaid obligation
            // Show "no active billing" ONLY if NO unpaid obligations remain
            $has_unpaid = hasUnpaidObligation($this->pdo, $mahasiswa['mahasiswa_id']);

            // STEP 8: Enhance tagihan data with payment status and flags
            if ($tagihan) {
                $tagihan = enhanceTagihanData($this->pdo, $tagihan);
            }

            // STEP 9: Get KRS status from krs table for current semester
            // Check based on mahasiswa's semester_aktif, not tagihan semester
            $krs_status = 'belum_aktif';
            $krs_query = "SELECT status_krs FROM krs 
                         WHERE mahasiswa_id = :mahasiswa_id 
                           AND semester = :semester 
                           AND tahun_akademik = :tahun_akademik 
                         LIMIT 1";
            
            $stmt = $this->pdo->prepare($krs_query);
            $stmt->execute([
                'mahasiswa_id' => $mahasiswa['mahasiswa_id'],
                'semester' => $mahasiswa['semester_aktif'],
                'tahun_akademik' => $mahasiswa['tahun_akademik']
            ]);
            $krs = $stmt->fetch();
            
            if ($krs && in_array($krs['status_krs'], ['disetujui', 'aktif'])) {
                $krs_status = 'aktif';
            }

            // Get cicilan data - check from cicilan_detail and tagihan
            // Cicilan exists if: tagihan.metode_pembayaran = 'cicilan' AND status_pembayaran != 'lunas'
            $cicilan_query = "SELECT 
                                t.tagihan_id,
                                t.semester,
                                t.tahun_akademik,
                                COUNT(cd.cicilan_id) as cicilan_count,
                                SUM(CASE WHEN cd.status_cicilan = 'lunas' THEN 1 ELSE 0 END) as terbayar_count,
                                SUM(cd.jumlah_cicilan - cd.jumlah_terbayar) as sisa_cicilan
                            FROM tagihan t
                            LEFT JOIN cicilan_detail cd ON t.tagihan_id = cd.tagihan_id
                            WHERE t.mahasiswa_id = :mahasiswa_id 
                              AND t.metode_pembayaran = 'cicilan'
                              AND t.status_pembayaran != 'lunas'
                            GROUP BY t.tagihan_id, t.semester, t.tahun_akademik
                            ORDER BY t.tahun_akademik DESC, t.semester ASC";
            
            $stmt = $this->pdo->prepare($cicilan_query);
            $stmt->execute(['mahasiswa_id' => $mahasiswa['mahasiswa_id']]);
            $cicilan_list = $stmt->fetchAll();

            // Calculate cicilan statistics
            $cicilan_terbayar = 0;
            $cicilan_belum_bayar = 0;
            $total_sisa_cicilan = 0;
            $has_active_installment = false;

            foreach ($cicilan_list as $c) {
                $cicilan_terbayar += (int)($c['terbayar_count'] ?? 0);
                $cicilan_belum_bayar += ((int)($c['cicilan_count'] ?? 0) - (int)($c['terbayar_count'] ?? 0));
                $total_sisa_cicilan += (int)($c['sisa_cicilan'] ?? 0);
                
                // TRUE if any cicilan not fully lunas
                if ((int)($c['terbayar_count'] ?? 0) < (int)($c['cicilan_count'] ?? 0)) {
                    $has_active_installment = true;
                }
            }

            $response = [
                'user' => [
                    'user_id' => $user['user_id'],
                    'nama_lengkap' => $user['nama_lengkap'],
                    'email' => $user['email'],
                    'nim' => $mahasiswa['nim_or_id'],
                    'program_studi' => $mahasiswa['nama_prodi'],
                    'fakultas' => $mahasiswa['nama_fakultas']
                ],
                'semester' => [
                    'tahun_akademik' => $sem_info['tahun_akademik'],
                    'semester_aktif' => $mahasiswa['semester_aktif'],
                    'status_akademik' => $mahasiswa['status_akademik']
                ],
                'has_unpaid_obligation' => $has_unpaid,
                'tagihan_aktif' => $tagihan ? [
                    'tagihan_id' => $tagihan['tagihan_id'],
                    'jenis_tagihan' => $tagihan['jenis_tagihan'],
                    'semester' => $tagihan['semester'] ? (int) $tagihan['semester'] : null,
                    'total_tagihan' => (int) $tagihan['jumlah_tagihan'],
                    'sisa_tagihan' => (int) ($tagihan['sisa_tagihan'] ?? $tagihan['jumlah_tagihan']),
                    'status_pembayaran' => $tagihan['status_pembayaran'],
                    'tahun_akademik' => $tagihan['tahun_akademik'],
                    'can_pay_lunas' => $tagihan['can_pay_lunas'] ?? true,
                    'can_pay_cicilan' => $tagihan['can_pay_cicilan'] ?? true,
                    'status_krs' => $krs_status
                ] : null,
                'all_tagihan' => array_map(function($t) {
                    $enhanced = enhanceTagihanData($this->pdo, $t);
                    return [
                        'tagihan_id' => $enhanced['tagihan_id'],
                        'jenis_tagihan' => $enhanced['jenis_tagihan'],
                        'semester' => $enhanced['semester'] ? (int) $enhanced['semester'] : null,
                        'total_tagihan' => (int) $enhanced['jumlah_tagihan'],
                        'sisa_tagihan' => (int) ($enhanced['sisa_tagihan'] ?? $enhanced['jumlah_tagihan']),
                        'status_pembayaran' => $enhanced['status_pembayaran'],
                        'tahun_akademik' => $enhanced['tahun_akademik']
                    ];
                }, $tagihan_list),
                'info' => [
                    'has_active_installment' => (bool) $has_active_installment
                ],
                'cicilan_summary' => [
                    'total_cicilan' => count($cicilan_list),
                    'cicilan_terbayar' => $cicilan_terbayar,
                    'cicilan_belum_bayar' => $cicilan_belum_bayar,
                    'total_sisa_cicilan' => (int) $total_sisa_cicilan,
                    'list' => array_map(function($c) {
                        return [
                            'tagihan_id' => $c['tagihan_id'],
                            'semester' => (int) $c['semester'],
                            'tahun_akademik' => $c['tahun_akademik'],
                            'cicilan_count' => (int) $c['cicilan_count'],
                            'terbayar_count' => (int) ($c['terbayar_count'] ?? 0),
                            'sisa_cicilan' => (int) ($c['sisa_cicilan'] ?? 0)
                        ];
                    }, $cicilan_list)
                ]
            ];

            $this->response('success', 'Dashboard info retrieved', $response);

        } catch (Exception $e) {
            $this->response('error', 'Failed to retrieve dashboard info: ' . $e->getMessage(), null, 'FETCH_FAILED', 500);
        }
    }

    /**
     * GET /api/mahasiswa/kewajiban-tarif
     * Get student CURRENT ACTIVE payment obligation based on TARIF table
     * 
     * LOGIC:
     * 1. Get mahasiswa academic progress
     * 2. Determine NEXT UNPAID BPP semester (main obligation)
     * 3. Check if Proposal is applicable (BPP 1-6 completed)
     * 4. Check if Skripsi is applicable (BPP 1-7 completed)
     * 5. Return ONLY THE ACTIVE OBLIGATION (not all)
     * 
     * For fresh student with no history:
     * - Returns BPP semester 1 from tarif
     * 
     * For student with payment history:
     * - Returns next unpaid BPP semester from tarif
     * 
     * For student with BPP >= 6:
     * - Returns Proposal if not paid
     * 
     * For student with BPP >= 7:
     * - Returns Skripsi if not paid
     */
    public function kewajibanTarif() {
        try {
            $user = $this->requireAuth();
            RoleMiddleware::mahasiswa($user);

            // STEP 1: Get mahasiswa complete info
            $mhs_query = "SELECT m.mahasiswa_id, m.semester_aktif, m.prodi_id, m.tahun_akademik, 
                                 m.status_akademik, u.nim_or_id, ps.nama_prodi, f.nama_fakultas
                         FROM mahasiswa m
                         JOIN users u ON m.user_id = u.user_id
                         JOIN program_studi ps ON m.prodi_id = ps.prodi_id
                         JOIN fakultas f ON ps.fakultas_id = f.fakultas_id
                         WHERE m.user_id = :user_id LIMIT 1";
            
            $stmt = $this->pdo->prepare($mhs_query);
            $stmt->execute(['user_id' => $user['user_id']]);
            $mahasiswa = $stmt->fetch();

            if (!$mahasiswa) {
                $this->response('error', 'Mahasiswa not found', null, 'NOT_FOUND', 404);
                return;
            }

            // STEP 2: Determine which payment obligation to show
            $active_obligation = $this->determineActiveObligation(
                $mahasiswa['mahasiswa_id'],
                $mahasiswa['prodi_id'],
                $mahasiswa['semester_aktif'],
                $mahasiswa['tahun_akademik'],
                $mahasiswa['status_akademik']
            );

            if (!$active_obligation) {
                // No obligation - all paid
                $this->response('success', 'No active payment obligations', [
                    'mahasiswa_id' => $mahasiswa['mahasiswa_id'],
                    'nim' => $mahasiswa['nim_or_id'],
                    'kewajiban' => [],
                    'total_kewajiban' => 0,
                    'message' => 'Semua kewajiban pembayaran telah terpenuhi'
                ]);
                return;
            }

            // STEP 3: Build response
            $response = [
                'mahasiswa_id' => $mahasiswa['mahasiswa_id'],
                'nim' => $mahasiswa['nim_or_id'],
                'nama_prodi' => $mahasiswa['nama_prodi'],
                'semester_aktif' => (int) $mahasiswa['semester_aktif'],
                'tahun_akademik' => $mahasiswa['tahun_akademik'],
                'status_akademik' => $mahasiswa['status_akademik'],
                'kewajiban' => [$active_obligation],
                'total_kewajiban' => 1
            ];

            $this->response('success', 'Active payment obligation retrieved from tarif', $response);

        } catch (Exception $e) {
            $this->response('error', 'Failed to retrieve payment obligation: ' . $e->getMessage(), null, 'FETCH_FAILED', 500);
        }
    }

    /**
     * Determine which payment obligation is CURRENTLY ACTIVE for student
     * 
     * Priority:
     * 1. Next unpaid BPP semester (primary obligation)
     * 2. If all BPP paid, check Proposal
     * 3. If BPP 1-7 paid, check Skripsi
     * 4. If all paid, return null
     * 
     * @return array|null - Single active obligation or null
     */
    private function determineActiveObligation(
        $mahasiswa_id,
        $prodi_id,
        $semester_aktif,
        $tahun_akademik,
        $status_akademik
    ) {
        // STEP 1: Determine next unpaid BPP semester
        $next_bpp_semester = $this->getNextUnpaidBPPSemester(
            $mahasiswa_id,
            $semester_aktif,
            $tahun_akademik
        );

        // If next BPP found, return it (highest priority)
        if ($next_bpp_semester) {
            return $next_bpp_semester;
        }

        // STEP 2: Check if all BPP paid - can show Proposal?
        if ($this->isBPPFullyPaidUpToSemester($mahasiswa_id, 6, $tahun_akademik)) {
            $proposal = $this->getProposalObligation($mahasiswa_id, $prodi_id, $tahun_akademik);
            if ($proposal) {
                return $proposal;
            }
        }

        // STEP 3: Check if BPP 1-7 paid - can show Skripsi?
        if ($this->isBPPFullyPaidUpToSemester($mahasiswa_id, 7, $tahun_akademik)) {
            $skripsi = $this->getSkripsiObligation($mahasiswa_id, $prodi_id, $tahun_akademik);
            if ($skripsi) {
                return $skripsi;
            }
        }

        // All obligations paid
        return null;
    }

    /**
     * Get next UNPAID BPP semester for mahasiswa
     * 
     * Logic:
     * - Find highest PAID BPP semester from tabel tagihan
     * - Next semester = highest_paid + 1
     * - If no history, next = 1 (fresh student)
     * - Return tarif data for next semester if available
     * 
     * @return array|null - Tarif data for next BPP semester or null
     */
    private function getNextUnpaidBPPSemester(
        $mahasiswa_id,
        $semester_aktif,
        $tahun_akademik
    ) {
        // Find highest paid BPP semester
        $query = "SELECT MAX(semester) as max_paid_semester
                 FROM tagihan
                 WHERE mahasiswa_id = :mahasiswa_id
                   AND jenis_tagihan = 'BPP'
                   AND status_pembayaran = 'lunas'
                   AND tahun_akademik = :tahun_akademik";
        
        $stmt = $this->pdo->prepare($query);
        $stmt->execute([
            'mahasiswa_id' => $mahasiswa_id,
            'tahun_akademik' => $tahun_akademik
        ]);
        $result = $stmt->fetch();
        
        // Determine next semester to pay
        $highest_paid = (int) ($result['max_paid_semester'] ?? 0);
        $next_semester = $highest_paid + 1;

        // Check if next semester is valid (not beyond current semester)
        if ($next_semester > $semester_aktif || $next_semester > 8) {
            return null;
        }

        // Get tarif for next BPP semester
        $tarif_query = "SELECT tarif_id, jenis_tagihan, nominal, semester_dari, semester_sampai
                       FROM tarif
                       WHERE jenis_tagihan = 'BPP'
                         AND semester_dari = :next_semester
                         AND prodi_id = :prodi_id
                         AND tahun_akademik = :tahun_akademik
                         AND is_active = TRUE
                       LIMIT 1";
        
        $stmt = $this->pdo->prepare($tarif_query);
        $stmt->execute([
            'next_semester' => $next_semester,
            'prodi_id' => $this->getMahasiswaProdiId($mahasiswa_id),
            'tahun_akademik' => $tahun_akademik
        ]);
        $tarif = $stmt->fetch();

        if (!$tarif) {
            return null;
        }

        return [
            'jenis_tagihan' => 'BPP',
            'semester' => $next_semester,
            'nominal' => (int) $tarif['nominal'],
            'tahun_akademik' => $tahun_akademik,
            'status' => 'belum_lunas',
            'source' => 'tarif',
            'tarif_id' => $tarif['tarif_id']
        ];
    }

    /**
     * Check if BPP is paid UP TO target semester (all semesters 1 to target)
     */
    private function isBPPFullyPaidUpToSemester(
        $mahasiswa_id,
        $target_semester,
        $tahun_akademik
    ) {
        $query = "SELECT COUNT(DISTINCT semester) as paid_count
                 FROM tagihan
                 WHERE mahasiswa_id = :mahasiswa_id
                   AND jenis_tagihan = 'BPP'
                   AND status_pembayaran = 'lunas'
                   AND semester <= :target_semester
                   AND tahun_akademik = :tahun_akademik";
        
        $stmt = $this->pdo->prepare($query);
        $stmt->execute([
            'mahasiswa_id' => $mahasiswa_id,
            'target_semester' => $target_semester,
            'tahun_akademik' => $tahun_akademik
        ]);
        $result = $stmt->fetch();

        // Should have all semesters 1 to target paid
        return ((int) $result['paid_count'] >= $target_semester);
    }

    /**
     * Get Proposal obligation if applicable and not yet paid
     */
    private function getProposalObligation(
        $mahasiswa_id,
        $prodi_id,
        $tahun_akademik
    ) {
        // Check if already paid Proposal
        $check_query = "SELECT COUNT(*) as count
                       FROM tagihan
                       WHERE mahasiswa_id = :mahasiswa_id
                         AND jenis_tagihan = 'Proposal'
                         AND status_pembayaran = 'lunas'
                         AND tahun_akademik = :tahun_akademik";
        
        $stmt = $this->pdo->prepare($check_query);
        $stmt->execute([
            'mahasiswa_id' => $mahasiswa_id,
            'tahun_akademik' => $tahun_akademik
        ]);
        $result = $stmt->fetch();

        if ((int) $result['count'] > 0) {
            // Already paid
            return null;
        }

        // Get Proposal tarif
        $tarif_query = "SELECT tarif_id, nominal
                       FROM tarif
                       WHERE jenis_tagihan = 'Proposal'
                         AND prodi_id = :prodi_id
                         AND tahun_akademik = :tahun_akademik
                         AND is_active = TRUE
                       LIMIT 1";
        
        $stmt = $this->pdo->prepare($tarif_query);
        $stmt->execute([
            'prodi_id' => $prodi_id,
            'tahun_akademik' => $tahun_akademik
        ]);
        $tarif = $stmt->fetch();

        if (!$tarif) {
            return null;
        }

        return [
            'jenis_tagihan' => 'Proposal',
            'semester' => null,
            'nominal' => (int) $tarif['nominal'],
            'tahun_akademik' => $tahun_akademik,
            'status' => 'belum_lunas',
            'source' => 'tarif',
            'tarif_id' => $tarif['tarif_id']
        ];
    }

    /**
     * Get Skripsi obligation if applicable and not yet paid
     */
    private function getSkripsiObligation(
        $mahasiswa_id,
        $prodi_id,
        $tahun_akademik
    ) {
        // Check if already paid Skripsi
        $check_query = "SELECT COUNT(*) as count
                       FROM tagihan
                       WHERE mahasiswa_id = :mahasiswa_id
                         AND jenis_tagihan = 'Skripsi'
                         AND status_pembayaran = 'lunas'
                         AND tahun_akademik = :tahun_akademik";
        
        $stmt = $this->pdo->prepare($check_query);
        $stmt->execute([
            'mahasiswa_id' => $mahasiswa_id,
            'tahun_akademik' => $tahun_akademik
        ]);
        $result = $stmt->fetch();

        if ((int) $result['count'] > 0) {
            // Already paid
            return null;
        }

        // Get Skripsi tarif
        $tarif_query = "SELECT tarif_id, nominal
                       FROM tarif
                       WHERE jenis_tagihan = 'Skripsi'
                         AND prodi_id = :prodi_id
                         AND tahun_akademik = :tahun_akademik
                         AND is_active = TRUE
                       LIMIT 1";
        
        $stmt = $this->pdo->prepare($tarif_query);
        $stmt->execute([
            'prodi_id' => $prodi_id,
            'tahun_akademik' => $tahun_akademik
        ]);
        $tarif = $stmt->fetch();

        if (!$tarif) {
            return null;
        }

        return [
            'jenis_tagihan' => 'Skripsi',
            'semester' => null,
            'nominal' => (int) $tarif['nominal'],
            'tahun_akademik' => $tahun_akademik,
            'status' => 'belum_lunas',
            'source' => 'tarif',
            'tarif_id' => $tarif['tarif_id']
        ];
    }

    /**
     * Helper: Get prodi_id for mahasiswa
     */
    private function getMahasiswaProdiId($mahasiswa_id) {
        $query = "SELECT prodi_id FROM mahasiswa WHERE mahasiswa_id = :mahasiswa_id LIMIT 1";
        $stmt = $this->pdo->prepare($query);
        $stmt->execute(['mahasiswa_id' => $mahasiswa_id]);
        $result = $stmt->fetch();
        return $result ? (int) $result['prodi_id'] : null;
    }

    /**
     * GET /api/mahasiswa/notifikasi
     * Get notifications for mahasiswa (cicilan reminders & KRS activation)
     */
    public function notifikasi() {
        try {
            $user = $this->requireAuth();
            RoleMiddleware::mahasiswa($user);

            // Get mahasiswa ID
            $mahasiswa_query = "SELECT mahasiswa_id FROM mahasiswa WHERE user_id = :user_id LIMIT 1";
            $stmt = $this->pdo->prepare($mahasiswa_query);
            $stmt->execute(['user_id' => $user['user_id']]);
            $mahasiswa = $stmt->fetch();

            if (!$mahasiswa) {
                $this->response('error', 'Mahasiswa not found', null, 'NOT_FOUND', 404);
                return;
            }

            $page = (int) ($_GET['page'] ?? 1);
            $limit = (int) ($_GET['limit'] ?? 20);
            $offset = ($page - 1) * $limit;
            $status_filter = $_GET['status'] ?? null;

            // Get notifications
            $query = "SELECT * FROM notifikasi WHERE mahasiswa_id = :mahasiswa_id";
            $params = ['mahasiswa_id' => $mahasiswa['mahasiswa_id']];

            if ($status_filter && in_array($status_filter, ['belum_dibaca', 'sudah_dibaca'])) {
                $query .= " AND status = :status";
                $params['status'] = $status_filter;
            }

            $query .= " ORDER BY created_at DESC LIMIT :limit OFFSET :offset";

            $stmt = $this->pdo->prepare($query);
            foreach ($params as $key => $value) {
                $stmt->bindValue(":$key", $value);
            }
            $stmt->bindValue(':limit', $limit, PDO::PARAM_INT);
            $stmt->bindValue(':offset', $offset, PDO::PARAM_INT);
            $stmt->execute();
            $notifikasi_list = $stmt->fetchAll();

            // Get count
            $count_query = "SELECT COUNT(*) as total FROM notifikasi WHERE mahasiswa_id = :mahasiswa_id";
            if ($status_filter && in_array($status_filter, ['belum_dibaca', 'sudah_dibaca'])) {
                $count_query .= " AND status = :status";
            }
            $stmt = $this->pdo->prepare($count_query);
            $stmt->execute($params);
            $count = $stmt->fetch();

            // Get unread count
            $unread_query = "SELECT COUNT(*) as unread FROM notifikasi WHERE mahasiswa_id = :mahasiswa_id AND status = 'belum_dibaca'";
            $stmt = $this->pdo->prepare($unread_query);
            $stmt->execute(['mahasiswa_id' => $mahasiswa['mahasiswa_id']]);
            $unread = $stmt->fetch();

            $response = [
                'notifikasi' => array_map(function($n) {
                    return [
                        'notifikasi_id' => $n['notifikasi_id'],
                        'judul' => $n['judul'],
                        'pesan' => $n['pesan'],
                        'status' => $n['status'],
                        'created_at' => $n['created_at'],
                        'read_at' => $n['read_at']
                    ];
                }, $notifikasi_list),
                'unread_count' => (int) ($unread['unread'] ?? 0),
                'pagination' => [
                    'page' => $page,
                    'limit' => $limit,
                    'total' => (int) ($count['total'] ?? 0),
                    'total_pages' => ceil(($count['total'] ?? 0) / $limit)
                ]
            ];

            $this->response('success', 'Notifikasi retrieved', $response);

        } catch (Exception $e) {
            // If notifikasi table doesn't exist, return empty
            if (strpos($e->getMessage(), 'notifikasi') !== false) {
                $this->response('success', 'No notifications available', [
                    'notifikasi' => [],
                    'unread_count' => 0,
                    'pagination' => ['page' => 1, 'limit' => 20, 'total' => 0, 'total_pages' => 0]
                ]);
            } else {
                $this->response('error', 'Failed to retrieve notifikasi: ' . $e->getMessage(), null, 'FETCH_FAILED', 500);
            }
        }
    }

    /**
     * PUT /api/mahasiswa/notifikasi/{notifikasi_id}/baca
     * Mark notification as read
     */
    public function bacaNotifikasi($notifikasi_id) {
        try {
            $user = $this->requireAuth();
            RoleMiddleware::mahasiswa($user);

            $notifikasi_id = (int) $notifikasi_id;

            // Get mahasiswa ID
            $mahasiswa_query = "SELECT mahasiswa_id FROM mahasiswa WHERE user_id = :user_id LIMIT 1";
            $stmt = $this->pdo->prepare($mahasiswa_query);
            $stmt->execute(['user_id' => $user['user_id']]);
            $mahasiswa = $stmt->fetch();

            // Update notification status
            $update = "UPDATE notifikasi SET status = 'sudah_dibaca', read_at = NOW() 
                      WHERE notifikasi_id = :notifikasi_id AND mahasiswa_id = :mahasiswa_id";
            
            $stmt = $this->pdo->prepare($update);
            $stmt->execute([
                'notifikasi_id' => $notifikasi_id,
                'mahasiswa_id' => $mahasiswa['mahasiswa_id']
            ]);

            $this->response('success', 'Notifikasi marked as read', ['notifikasi_id' => $notifikasi_id]);

        } catch (Exception $e) {
            $this->response('error', 'Failed to update notifikasi: ' . $e->getMessage(), null, 'UPDATE_FAILED', 500);
        }
    }

    /**
     * GET /api/mahasiswa/status-krs
     * Check KRS status for current semester
     */
    public function statusKRS() {
        try {
            $user = $this->requireAuth();
            RoleMiddleware::mahasiswa($user);

            // Get mahasiswa data
            $mahasiswa_query = "SELECT m.mahasiswa_id, m.semester_aktif, m.tahun_akademik 
                               FROM mahasiswa m
                               WHERE m.user_id = :user_id LIMIT 1";
            
            $stmt = $this->pdo->prepare($mahasiswa_query);
            $stmt->execute(['user_id' => $user['user_id']]);
            $mahasiswa = $stmt->fetch();

            if (!$mahasiswa) {
                $this->response('error', 'Mahasiswa not found', null, 'NOT_FOUND', 404);
                return;
            }

            // Check KRS status for current semester
            $krs_query = "SELECT krs_id, status_krs, tgl_pengajuan, tgl_persetujuan 
                         FROM krs 
                         WHERE mahasiswa_id = :mahasiswa_id 
                           AND semester = :semester 
                           AND tahun_akademik = :tahun_akademik 
                         LIMIT 1";
            
            $stmt = $this->pdo->prepare($krs_query);
            $stmt->execute([
                'mahasiswa_id' => $mahasiswa['mahasiswa_id'],
                'semester' => $mahasiswa['semester_aktif'],
                'tahun_akademik' => $mahasiswa['tahun_akademik']
            ]);
            $krs = $stmt->fetch();

            // Check tagihan status (must be lunas for KRS activation)
            $tagihan_query = "SELECT status_pembayaran FROM tagihan 
                             WHERE mahasiswa_id = :mahasiswa_id 
                               AND semester = :semester 
                               AND tahun_akademik = :tahun_akademik 
                               AND jenis_tagihan = 'BPP'
                             LIMIT 1";
            
            $stmt = $this->pdo->prepare($tagihan_query);
            $stmt->execute([
                'mahasiswa_id' => $mahasiswa['mahasiswa_id'],
                'semester' => $mahasiswa['semester_aktif'],
                'tahun_akademik' => $mahasiswa['tahun_akademik']
            ]);
            $tagihan = $stmt->fetch();

            $krs_aktif = $krs && in_array($krs['status_krs'], ['disetujui', 'aktif']);
            $pembayaran_lunas = $tagihan && $tagihan['status_pembayaran'] === 'lunas';

            $response = [
                'mahasiswa_id' => $mahasiswa['mahasiswa_id'],
                'semester' => $mahasiswa['semester_aktif'],
                'tahun_akademik' => $mahasiswa['tahun_akademik'],
                'krs_aktif' => $krs_aktif,
                'pembayaran_lunas' => $pembayaran_lunas,
                'dapat_isi_krs' => $krs_aktif && $pembayaran_lunas,
                'krs_detail' => $krs ? [
                    'krs_id' => $krs['krs_id'],
                    'status_krs' => $krs['status_krs'],
                    'tgl_pengajuan' => $krs['tgl_pengajuan'],
                    'tgl_persetujuan' => $krs['tgl_persetujuan']
                ] : null,
                'pesan' => $this->getKRSStatusMessage($krs_aktif, $pembayaran_lunas)
            ];

            $this->response('success', 'KRS status retrieved', $response);

        } catch (Exception $e) {
            $this->response('error', 'Failed to check KRS status: ' . $e->getMessage(), null, 'CHECK_FAILED', 500);
        }
    }

    /**
     * Helper: Get KRS status message
     */
    private function getKRSStatusMessage($krs_aktif, $pembayaran_lunas) {
        if (!$pembayaran_lunas) {
            return 'Pembayaran BPP belum lunas. KRS tidak dapat diisi.';
        }
        if (!$krs_aktif) {
            return 'Menunggu aktivasi KRS oleh Admin Fakultas.';
        }
        return 'KRS telah diaktifkan. Anda dapat mengisi KRS.';
    }

    /**
     * GET /api/mahasiswa/profil
     * Get complete student profile for modal display
     * SECURITY: Only accessible by the student themselves
     */
    public function profil() {
        try {
            $user = $this->requireAuth();
            RoleMiddleware::mahasiswa($user);

            // Get complete mahasiswa profile from database
            $query = "SELECT 
                        m.mahasiswa_id,
                        u.nim_or_id as nim,
                        m.semester_aktif,
                        m.tahun_akademik,
                        m.status_akademik,
                        u.nama_lengkap,
                        u.email,
                        ps.nama_prodi as jurusan,
                        f.nama_fakultas as fakultas
                      FROM mahasiswa m
                      JOIN users u ON m.user_id = u.user_id
                      JOIN program_studi ps ON m.prodi_id = ps.prodi_id
                      JOIN fakultas f ON ps.fakultas_id = f.fakultas_id
                      WHERE m.user_id = :user_id
                      LIMIT 1";

            $stmt = $this->pdo->prepare($query);
            $stmt->execute(['user_id' => $user['user_id']]);
            $profil = $stmt->fetch();

            if (!$profil) {
                $this->response('error', 'Profil mahasiswa tidak ditemukan', null, 'NOT_FOUND', 404);
                return;
            }

            // Build response with all profile data
            $response = [
                'nim' => $profil['nim'] ?: '-',
                'nama_lengkap' => $profil['nama_lengkap'] ?: '-',
                'email' => $profil['email'] ?: '-',
                'fakultas' => $profil['fakultas'] ?: '-',
                'jurusan' => $profil['jurusan'] ?: '-',
                'angkatan' => '-',
                'semester_aktif' => $profil['semester_aktif'] ? (int) $profil['semester_aktif'] : 1,
                'tahun_akademik' => $profil['tahun_akademik'] ?: '-',
                'status_mahasiswa' => $profil['status_akademik'] ?: 'aktif'
            ];

            $this->response('success', 'Profil mahasiswa berhasil dimuat', $response);

        } catch (Exception $e) {
            $this->response('error', 'Gagal memuat profil: ' . $e->getMessage(), null, 'LOAD_FAILED', 500);
        }
    }

    /**
     * GET /api/mahasiswa/tagihan-dengan-tarif
     * 
     * Endpoint ORCHESTRATOR untuk halaman Tagihan
     * 
     * Proses:
     * 1. Ambil data mahasiswa login
     * 2. Hitung semester BPP pertama yang belum dibayar
     * 3. Query ke tabel TARIF (BUKAN tabel tagihan)
     * 4. Return semua data tagihan dari tarif
     * 5. Render data meskipun tabel tagihan kosong
     * 
     * Response tidak pernah menampilkan "Tidak ada tagihan" hanya karena
     * tabel tagihan kosong. Pesan ini hanya muncul jika TIDAK ADA TARIF AKTIF
     * yang sesuai setelah seluruh perhitungan.
     */
    public function tagihanDenganTarif() {
        try {
            $user = $this->requireAuth();
            RoleMiddleware::mahasiswa($user);

            // Get mahasiswa_id dari user yang login
            $query = "SELECT mahasiswa_id FROM mahasiswa WHERE user_id = :user_id LIMIT 1";
            $stmt = $this->pdo->prepare($query);
            $stmt->execute(['user_id' => $user['user_id']]);
            $mahasiswa_row = $stmt->fetch();

            if (!$mahasiswa_row) {
                $this->response('error', 'Mahasiswa tidak ditemukan', null, 'NOT_FOUND', 404);
                return;
            }

            $mahasiswa_id = $mahasiswa_row['mahasiswa_id'];

            // =============================================================
            // PROSES ORCHESTRATOR: Ambil data tagihan dari TARIF
            // =============================================================
            $result = getTagihanDataWithTarif($this->pdo, $mahasiswa_id);

            if (!$result['success']) {
                $this->response('error', $result['message'], null, 'ERROR', 500);
                return;
            }

            // =============================================================
            // Persiapan Response
            // =============================================================
            $data = $result['data'];
            $response_data = [
                'mahasiswa' => $data['mahasiswa'],
                'semester_wajib_bayar' => $data['semester_wajib_bayar'],
                'highest_paid_semester' => $data['highest_paid_semester'],
                'tagihan' => [],
                'has_active_obligation' => $data['has_active_obligation']
            ];

            // Tambahkan BPP ke array tagihan
            if ($data['tagihan_bpp']) {
                $response_data['tagihan'][] = array_merge(
                    $data['tagihan_bpp'],
                    [
                        'semester' => $data['semester_wajib_bayar'],
                        'status_pembayaran' => 'belum_bayar',
                        'source' => 'tarif'
                    ]
                );
            }

            // Tambahkan Proposal ke array tagihan (jika ada dan syarat terpenuhi)
            if ($data['tagihan_proposal']) {
                $response_data['tagihan'][] = array_merge(
                    $data['tagihan_proposal'],
                    [
                        'status_pembayaran' => 'belum_bayar',
                        'source' => 'tarif'
                    ]
                );
            }

            // Tambahkan Skripsi ke array tagihan (jika ada dan syarat terpenuhi)
            if ($data['tagihan_skripsi']) {
                $response_data['tagihan'][] = array_merge(
                    $data['tagihan_skripsi'],
                    [
                        'status_pembayaran' => 'belum_bayar',
                        'source' => 'tarif'
                    ]
                );
            }

            // =============================================================
            // Response Message
            // =============================================================
            $message = $data['has_active_obligation'] 
                ? 'Data tagihan berhasil diambil dari tabel tarif' 
                : 'Tidak ada tagihan aktif';

            $this->response('success', $message, $response_data, 'OK', 200);

        } catch (Exception $e) {
            $this->response('error', 'Error: ' . $e->getMessage(), null, 'ERROR', 500);
        }
    }
}
