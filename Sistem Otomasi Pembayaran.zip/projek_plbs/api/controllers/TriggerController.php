<?php
/**
 * Trigger Controller
 * Handle manual trigger for auto-create tagihan
 */

class TriggerController extends Controller {

    /**
     * GET /api/trigger/auto-create-tagihan
     * Auto-create tagihan untuk semua mahasiswa (bypass opcache dengan inline SQL)
     */
    public function autoCreateTagihan() {
        try {
            $query = "SELECT mahasiswa_id, prodi_id, semester_aktif, tahun_akademik FROM mahasiswa";
            $stmt = $this->pdo->query($query);
            $mahasiswa_list = $stmt->fetchAll();
            
            $results = [];
            $total_created = 0;
            
            foreach ($mahasiswa_list as $mhs) {
                $mahasiswa_id = $mhs['mahasiswa_id'];
                $prodi_id = $mhs['prodi_id'];
                $tahun_akademik = $mhs['tahun_akademik'];
                
                // === AUTO-CREATE BPP (INLINE SQL) ===
                $highest_paid = $this->pdo->prepare("SELECT MAX(semester) as max_sem FROM tagihan WHERE mahasiswa_id = ? AND jenis_tagihan = 'BPP' AND status_pembayaran = 'lunas'");
                $highest_paid->execute([$mahasiswa_id]);
                $max_result = $highest_paid->fetch();
                $next_semester = ((int)($max_result['max_sem'] ?? 0)) + 1;
                
                if ($next_semester <= 8) {
                    $check = $this->pdo->prepare("SELECT tagihan_id FROM tagihan WHERE mahasiswa_id = ? AND jenis_tagihan = 'BPP' AND semester = ?");
                    $check->execute([$mahasiswa_id, $next_semester]);
                    
                    if (!$check->fetch()) {
                        $tarif = $this->pdo->prepare("SELECT nominal, tahun_akademik FROM tarif WHERE prodi_id = ? AND jenis_tagihan = 'BPP' AND semester_dari <= ? AND semester_sampai >= ? AND is_active = TRUE ORDER BY tahun_akademik DESC LIMIT 1");
                        $tarif->execute([$prodi_id, $next_semester, $next_semester]);
                        $tarif_data = $tarif->fetch();
                        
                        if ($tarif_data) {
                            $insert = $this->pdo->prepare("INSERT INTO tagihan (mahasiswa_id, jenis_tagihan, semester, tahun_akademik, jumlah_tagihan, status_pembayaran, metode_pembayaran) VALUES (?, 'BPP', ?, ?, ?, 'belum_bayar', 'lunas')");
                            $insert->execute([$mahasiswa_id, $next_semester, $tarif_data['tahun_akademik'], $tarif_data['nominal']]);
                            $results[] = "Mahasiswa {$mahasiswa_id}: BPP semester {$next_semester} created";
                            $total_created++;
                        }
                    }
                }
                
                // === AUTO-CREATE PROPOSAL (INLINE SQL) ===
                // Proposal dibuat jika semester 6 lunas
                $check_sem6 = $this->pdo->prepare("SELECT COUNT(*) as cnt FROM tagihan WHERE mahasiswa_id = ? AND jenis_tagihan = 'BPP' AND status_pembayaran = 'lunas' AND semester = 6");
                $check_sem6->execute([$mahasiswa_id]);
                $sem6_result = $check_sem6->fetch();
                
                if ((int)$sem6_result['cnt'] > 0) {
                    $check_proposal = $this->pdo->prepare("SELECT tagihan_id FROM tagihan WHERE mahasiswa_id = ? AND jenis_tagihan = 'PROPOSAL'");
                    $check_proposal->execute([$mahasiswa_id]);
                    
                    if (!$check_proposal->fetch()) {
                        $tarif_proposal = $this->pdo->prepare("SELECT nominal FROM tarif WHERE prodi_id = ? AND jenis_tagihan = 'PROPOSAL' AND is_active = TRUE ORDER BY tahun_akademik DESC LIMIT 1");
                        $tarif_proposal->execute([$prodi_id]);
                        $proposal_data = $tarif_proposal->fetch();
                        
                        if ($proposal_data) {
                            $insert_proposal = $this->pdo->prepare("INSERT INTO tagihan (mahasiswa_id, jenis_tagihan, semester, tahun_akademik, jumlah_tagihan, status_pembayaran, metode_pembayaran) VALUES (?, 'PROPOSAL', NULL, ?, ?, 'belum_bayar', 'lunas')");
                            $insert_proposal->execute([$mahasiswa_id, $tahun_akademik, $proposal_data['nominal']]);
                            $results[] = "Mahasiswa {$mahasiswa_id}: PROPOSAL created";
                            $total_created++;
                        }
                    }
                }
                
                // === AUTO-CREATE SKRIPSI (INLINE SQL) ===
                // Skripsi dibuat jika semester 6 lunas (bersamaan dengan Proposal)
                $check_sem6_skripsi = $this->pdo->prepare("SELECT COUNT(*) as cnt FROM tagihan WHERE mahasiswa_id = ? AND jenis_tagihan = 'BPP' AND status_pembayaran = 'lunas' AND semester = 6");
                $check_sem6_skripsi->execute([$mahasiswa_id]);
                $sem6_skripsi_result = $check_sem6_skripsi->fetch();
                
                if ((int)$sem6_skripsi_result['cnt'] > 0) {
                    $check_skripsi = $this->pdo->prepare("SELECT tagihan_id FROM tagihan WHERE mahasiswa_id = ? AND jenis_tagihan = 'SKRIPSI'");
                    $check_skripsi->execute([$mahasiswa_id]);
                    
                    if (!$check_skripsi->fetch()) {
                        $tarif_skripsi = $this->pdo->prepare("SELECT nominal FROM tarif WHERE prodi_id = ? AND jenis_tagihan = 'SKRIPSI' AND is_active = TRUE ORDER BY tahun_akademik DESC LIMIT 1");
                        $tarif_skripsi->execute([$prodi_id]);
                        $skripsi_data = $tarif_skripsi->fetch();
                        
                        if ($skripsi_data) {
                            $insert_skripsi = $this->pdo->prepare("INSERT INTO tagihan (mahasiswa_id, jenis_tagihan, semester, tahun_akademik, jumlah_tagihan, status_pembayaran, metode_pembayaran) VALUES (?, 'SKRIPSI', NULL, ?, ?, 'belum_bayar', 'lunas')");
                            $insert_skripsi->execute([$mahasiswa_id, $tahun_akademik, $skripsi_data['nominal']]);
                            $results[] = "Mahasiswa {$mahasiswa_id}: SKRIPSI created";
                            $total_created++;
                        }
                    }
                }
            }
            
            $this->response('success', "Auto-create selesai: {$total_created} tagihan dibuat", [
                'total_mahasiswa' => count($mahasiswa_list),
                'total_created' => $total_created,
                'details' => $results
            ]);
            
        } catch (Exception $e) {
            $this->response('error', 'Failed: ' . $e->getMessage(), null, 'TRIGGER_FAILED', 500);
        }
    }
}
