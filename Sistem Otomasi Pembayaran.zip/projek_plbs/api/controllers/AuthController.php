<?php
/**
 * Authentication Controller
 * Handle login, logout, register
 */

class AuthController extends Controller {

    /**
     * POST /api/auth/login
     * Authenticate user and return JWT token + complete identity data
     * 
     * IMPORTANT: This endpoint returns complete user identity data including:
     * - For mahasiswa: nim, mahasiswa_id, semester_aktif, tahun_akademik
     * 
     * Frontend MUST store this data to session/localStorage for use in dashboard:
     * - Display welcome greeting with nama_lengkap
     * - Display NIM in sidebar
     * - Use semester_aktif for tagihan filtering
     * 
     * Backend MUST use this data to:
     * - Filter all queries by user_id extracted from JWT token
     * - Ensure user can only access their own data
     */
    public function login() {
        try {
            // STEP 0: Validate input is provided
            $input = getInput();
            if (!is_array($input)) {
                $this->response('error', 'Invalid request body, expected JSON', null, 'INVALID_INPUT', 400);
                return;
            }

            // STEP 1: Validate required fields
            if (empty($input['username']) || empty($input['password'])) {
                $this->response('error', 'Username and password are required', null, 'INVALID_REQUEST', 400);
                return;
            }

            $username = $this->sanitizeInput($input['username']);
            $password = $input['password'];

            // STEP 2: Find user by username - including mahasiswa data
            $query = "SELECT u.*, m.mahasiswa_id, m.nim, m.semester_aktif, m.tahun_akademik
                      FROM users u
                      LEFT JOIN mahasiswa m ON u.user_id = m.user_id
                      WHERE u.username = :username AND u.is_active = 1
                      LIMIT 1";

            $stmt = $this->pdo->prepare($query);
            if (!$stmt) {
                $this->response('error', 'Database query preparation failed', null, 'DB_ERROR', 500);
                return;
            }
            
            $execute_result = $stmt->execute(['username' => $username]);
            if (!$execute_result) {
                $this->response('error', 'Database query execution failed', null, 'DB_ERROR', 500);
                return;
            }
            
            $user = $stmt->fetch();

            // STEP 3: Verify user exists and password matches
            if (!$user || !password_verify($password, $user['password_hash'])) {
                $this->response('error', 'Invalid username or password', null, 'INVALID_CREDENTIALS', 401);
                return;
            }

            // STEP 4: Generate JWT Token with complete identity data
            $token_data = [
                'user_id' => $user['user_id'],
                'username' => $user['username'],
                'email' => $user['email'],
                'role' => $user['role'],
                'nama_lengkap' => $user['nama_lengkap'],
                'nim_or_id' => $user['nim_or_id']
            ];

            // Add mahasiswa-specific data to token if student
            if ($user['role'] === 'mahasiswa' && !empty($user['mahasiswa_id'])) {
                $token_data['mahasiswa_id'] = $user['mahasiswa_id'];
                $token_data['nim'] = $user['nim'];
                $token_data['semester_aktif'] = $user['semester_aktif'];
                $token_data['tahun_akademik'] = $user['tahun_akademik'];
            }

            $token = JWT::generate($token_data);
            if (!$token) {
                $this->response('error', 'Token generation failed', null, 'TOKEN_FAILED', 500);
                return;
            }

            // STEP 4.5: SAVE SESSION DATA - Store user credentials in PHP session
            // This is required for API endpoints to verify user is logged in
            $_SESSION['user_id'] = $user['user_id'];
            $_SESSION['username'] = $user['username'];
            $_SESSION['role'] = $user['role'];
            $_SESSION['nama_lengkap'] = $user['nama_lengkap'];
            
            // Store mahasiswa-specific data in session if student
            if ($user['role'] === 'mahasiswa' && !empty($user['mahasiswa_id'])) {
                $_SESSION['mahasiswa_id'] = $user['mahasiswa_id'];
                $_SESSION['nim'] = $user['nim'];
                $_SESSION['semester_aktif'] = $user['semester_aktif'];
                $_SESSION['tahun_akademik'] = $user['tahun_akademik'];
            }

            // STEP 5: Log login activity (non-blocking)
            $this->logActivity($user['user_id'], 'login', 'User login successful');

            // STEP 6: Prepare complete response data
            $response_data = [
                'token' => $token,
                'user_id' => (int) $user['user_id'],
                'username' => (string) $user['username'],
                'role' => (string) $user['role'],
                'nama_lengkap' => (string) $user['nama_lengkap']
            ];

            // STEP 7: Add mahasiswa-specific data to response
            if ($user['role'] === 'mahasiswa' && !empty($user['mahasiswa_id'])) {
                $response_data['nim'] = (string) $user['nim'];
                $response_data['mahasiswa_id'] = (int) $user['mahasiswa_id'];
                $response_data['semester_aktif'] = (int) $user['semester_aktif'];
                $response_data['tahun_akademik'] = (string) $user['tahun_akademik'];
            }

            // STEP 8: Send success response with complete JSON
            $this->response('success', 'Login berhasil', $response_data, null, 200);
            return;

        } catch (Exception $e) {
            // Always return JSON on error
            $this->response('error', 'Login gagal: ' . $e->getMessage(), null, 'LOGIN_FAILED', 500);
            return;
        }
    }

    /**
     * POST /api/auth/register
     * Register new student user
     */
    public function register() {
        try {
            // STEP 0: Validate input is provided
            $input = getInput();
            if (!is_array($input)) {
                $this->response('error', 'Invalid request body, expected JSON', null, 'INVALID_INPUT', 400);
                return;
            }

            // STEP 1: Validate required fields
            $required = ['username', 'password', 'email', 'nim', 'nama_lengkap', 'prodi_id'];
            foreach ($required as $field) {
                if (empty($input[$field])) {
                    $this->response('error', ucfirst($field) . ' tidak boleh kosong', null, 'INVALID_REQUEST', 400);
                    return;
                }
            }

            $username = $this->sanitizeInput($input['username']);
            $email = filter_var($input['email'], FILTER_VALIDATE_EMAIL);
            $nim = $this->sanitizeInput($input['nim']);
            $nama_lengkap = $this->sanitizeInput($input['nama_lengkap']);
            $prodi_id = (int) $input['prodi_id'];

            if (!$email) {
                $this->response('error', 'Format email tidak valid', null, 'INVALID_REQUEST', 400);
                return;
            }

            // STEP 2: Check duplicate username
            $check = $this->pdo->prepare("SELECT user_id FROM users WHERE username = :username");
            if (!$check || !$check->execute(['username' => $username])) {
                $this->response('error', 'Database error during username validation', null, 'DB_ERROR', 500);
                return;
            }
            if ($check->fetch()) {
                $this->response('error', 'Username sudah terdaftar', null, 'DUPLICATE_USER', 400);
                return;
            }

            // STEP 3: Check duplicate email
            $check = $this->pdo->prepare("SELECT user_id FROM users WHERE email = :email");
            if (!$check || !$check->execute(['email' => $email])) {
                $this->response('error', 'Database error during email validation', null, 'DB_ERROR', 500);
                return;
            }
            if ($check->fetch()) {
                $this->response('error', 'Email sudah terdaftar', null, 'DUPLICATE_EMAIL', 400);
                return;
            }

            // STEP 4: Check duplicate NIM
            $check = $this->pdo->prepare("SELECT user_id FROM users WHERE nim_or_id = :nim");
            if (!$check || !$check->execute(['nim' => $nim])) {
                $this->response('error', 'Database error during NIM validation', null, 'DB_ERROR', 500);
                return;
            }
            if ($check->fetch()) {
                $this->response('error', 'NIM sudah terdaftar', null, 'DUPLICATE_NIM', 400);
                return;
            }

            // Get current semester info
            $sem_info = getCurrentSemesterInfo();

            // Start transaction
            $this->pdo->beginTransaction();

            try {
                // Create users record
                $password_hash = password_hash($input['password'], PASSWORD_BCRYPT);
                
                $user_data = [
                    'username' => $username,
                    'password_hash' => $password_hash,
                    'email' => $email,
                    'role' => 'mahasiswa',
                    'nim_or_id' => $nim,
                    'nama_lengkap' => $nama_lengkap,
                    'is_active' => 1,
                    'created_at' => date('Y-m-d H:i:s'),
                    'updated_at' => date('Y-m-d H:i:s')
                ];

                $user_insert = "INSERT INTO users (username, password_hash, email, role, nim_or_id, nama_lengkap, is_active, created_at, updated_at)
                               VALUES (:username, :password_hash, :email, :role, :nim_or_id, :nama_lengkap, :is_active, :created_at, :updated_at)";
                
                $stmt = $this->pdo->prepare($user_insert);
                $stmt->execute($user_data);
                $user_id = $this->pdo->lastInsertId();

                // Create mahasiswa record
                $mahasiswa_data = [
                    'user_id' => $user_id,
                    'nim' => $nim,
                    'prodi_id' => $prodi_id,
                    'semester_aktif' => 1,
                    'tahun_akademik' => $sem_info['tahun_akademik'],
                    'status_akademik' => 'aktif',
                    'created_at' => date('Y-m-d H:i:s')
                ];

                $mahasiswa_insert = "INSERT INTO mahasiswa (user_id, nim, prodi_id, semester_aktif, tahun_akademik, status_akademik, created_at)
                                   VALUES (:user_id, :nim, :prodi_id, :semester_aktif, :tahun_akademik, :status_akademik, :created_at)";
                
                $stmt = $this->pdo->prepare($mahasiswa_insert);
                $stmt->execute($mahasiswa_data);

                $this->pdo->commit();

                $this->logActivity($user_id, 'registration', 'User registration successful');

                $this->response('success', 'Registrasi berhasil, silakan login', [
                    'user_id' => $user_id,
                    'username' => $username,
                    'email' => $email
                ], null, 201);

            } catch (Exception $e) {
                $this->pdo->rollBack();
                throw $e;
            }

        } catch (Exception $e) {
            // Always return JSON on error
            $this->response('error', 'Registrasi gagal: ' . $e->getMessage(), null, 'REGISTRATION_FAILED', 500);
            return;
        }
    }

    /**
     * POST /api/auth/logout
     * Logout user
     */
    public function logout() {
        try {
            $user = $this->requireAuth();
            if (!$user) {
                $this->response('error', 'User not authenticated', null, 'UNAUTHORIZED', 401);
                return;
            }
            
            // Log logout activity (non-blocking)
            $this->logActivity($user['user_id'], 'logout', 'User logout successful');
            
            // DESTROY SESSION DATA
            // Clear all session variables
            $_SESSION = [];
            
            // Destroy the session
            if (session_id() != '') {
                setcookie(session_name(), '', time() - 2592000, '/');
            }
            session_destroy();
            
            // Send success response
            $this->response('success', 'Logout berhasil', null, null, 200);
            return;

        } catch (Exception $e) {
            // Always return JSON on error
            $this->response('error', 'Logout gagal: ' . $e->getMessage(), null, 'LOGOUT_FAILED', 500);
            return;
        }
    }

    /**
     * Log activity to audit trail
     */
    private function logActivity($user_id, $type, $description) {
        try {
            $log_data = [
                'user_id' => $user_id,
                'jenis_aktivitas' => $type,
                'deskripsi' => $description,
                'ip_address' => getClientIP(),
                'created_at' => date('Y-m-d H:i:s')
            ];

            $insert = "INSERT INTO audit_log (user_id, jenis_aktivitas, deskripsi, ip_address, created_at)
                      VALUES (:user_id, :jenis_aktivitas, :deskripsi, :ip_address, :created_at)";
            
            $stmt = $this->pdo->prepare($insert);
            $stmt->execute($log_data);
        } catch (Exception $e) {
            // Silently fail - don't disrupt main flow
        }
    }

    /**
     * GET /api/program-studi
     * Get list of program studi for registration
     */
    public function getProdiList() {
        try {
            $query = "SELECT prodi_id, nama_prodi, kode_prodi 
                      FROM program_studi 
                      ORDER BY nama_prodi ASC";

            $stmt = $this->pdo->prepare($query);
            if (!$stmt) {
                $this->response('error', 'Database query preparation failed', null, 'DB_ERROR', 500);
                return;
            }
            
            $execute_result = $stmt->execute();
            if (!$execute_result) {
                $this->response('error', 'Database query execution failed', null, 'DB_ERROR', 500);
                return;
            }
            
            $prodi_list = $stmt->fetchAll();

            // Return success response
            $this->response('success', 'Program studi retrieved', $prodi_list, null, 200);
            return;

        } catch (Exception $e) {
            // Always return JSON on error
            $this->response('error', 'Failed to retrieve program studi: ' . $e->getMessage(), null, 'FETCH_FAILED', 500);
            return;
        }
    }
}

