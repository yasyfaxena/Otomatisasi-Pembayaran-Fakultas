<?php
/**
 * Cicilan Controller
 * Handle installment tracking
 */

class CicilanController extends Controller {

    /**
     * GET /api/mahasiswa/cicilan/detail
     * Get installment details
     */
    public function detail() {
        try {
            $user = $this->requireAuth();
            RoleMiddleware::mahasiswa($user);

            if (empty($_GET['tagihan_id'])) {
                $this->response('error', 'tagihan_id required', null, 'INVALID_REQUEST', 400);
            }

            $tagihan_id = (int) $_GET['tagihan_id'];

            // Get tagihan and verify ownership
            $tagihan_query = "SELECT t.* FROM tagihan t
                            JOIN mahasiswa m ON t.mahasiswa_id = m.mahasiswa_id
                            WHERE t.tagihan_id = :tagihan_id AND m.user_id = :user_id
                            LIMIT 1";

            $stmt = $this->pdo->prepare($tagihan_query);
            $stmt->execute(['tagihan_id' => $tagihan_id, 'user_id' => $user['user_id']]);
            $tagihan = $stmt->fetch();

            if (!$tagihan) {
                $this->response('error', 'Tagihan not found', null, 'NOT_FOUND', 404);
            }

            if ($tagihan['metode_pembayaran'] !== 'cicilan') {
                $this->response('error', 'This is not installment payment', null, 'INVALID_REQUEST', 400);
            }

            // Get cicilan details
            $cicilan_query = "SELECT * FROM cicilan_detail WHERE tagihan_id = :tagihan_id ORDER BY nomor_cicilan ASC";
            $stmt = $this->pdo->prepare($cicilan_query);
            $stmt->execute(['tagihan_id' => $tagihan_id]);
            $cicilans = $stmt->fetchAll();

            // Calculate totals
            $total_terbayar = 0;
            foreach ($cicilans as $c) {
                $total_terbayar += $c['jumlah_terbayar'];
            }
            $sisa_cicilan = $tagihan['jumlah_tagihan'] - $total_terbayar;
            $persentase = ($total_terbayar / $tagihan['jumlah_tagihan']) * 100;

            $response = [
                'tagihan_id' => $tagihan['tagihan_id'],
                'jumlah_tagihan' => (int) $tagihan['jumlah_tagihan'],
                'metode_pembayaran' => $tagihan['metode_pembayaran'],
                'status_pembayaran' => $tagihan['status_pembayaran'],
                'cicilan_list' => array_map(function($c) {
                    return [
                        'cicilan_id' => $c['cicilan_id'],
                        'nomor_cicilan' => $c['nomor_cicilan'],
                        'jumlah_cicilan' => (int) $c['jumlah_cicilan'],
                        'jumlah_terbayar' => (int) $c['jumlah_terbayar'],
                        'status_cicilan' => $c['status_cicilan'],
                        'tgl_jatuh_tempo' => $c['tgl_jatuh_tempo'],
                        'tgl_lunas' => $c['tgl_lunas']
                    ];
                }, $cicilans),
                'total_terbayar' => (int) $total_terbayar,
                'sisa_cicilan' => (int) $sisa_cicilan,
                'persentase_pembayaran' => round($persentase, 2)
            ];

            $this->response('success', 'Installment details retrieved', $response);

        } catch (Exception $e) {
            $this->response('error', 'Failed to get installment detail: ' . $e->getMessage(), null, 'RETRIEVE_FAILED', 500);
        }
    }

    /**
     * POST /api/cicilan/generate-cicilan-otomatis
     * Generate installment automatically (Internal - for admin use)
     */
    public function generateOtomatis() {
        try {
            $user = $this->requireAuth();
            RoleMiddleware::checkRole($user, ['admin_universitas', 'admin_fakultas']);

            $input = getInput();

            if (empty($input['tagihan_id']) || empty($input['jumlah_cicilan'])) {
                $this->response('error', 'tagihan_id and jumlah_cicilan required', null, 'INVALID_REQUEST', 400);
            }

            $tagihan_id = (int) $input['tagihan_id'];
            $jumlah_cicilan = (int) $input['jumlah_cicilan'];
            $mulai_bulan = $input['mulai_bulan'] ?? date('Y-m');

            if ($jumlah_cicilan < 2 || $jumlah_cicilan > 12) {
                $this->response('error', 'Jumlah cicilan harus antara 2-12', null, 'INVALID_REQUEST', 400);
            }

            // Get tagihan
            $tagihan_query = "SELECT * FROM tagihan WHERE tagihan_id = :tagihan_id LIMIT 1";
            $stmt = $this->pdo->prepare($tagihan_query);
            $stmt->execute(['tagihan_id' => $tagihan_id]);
            $tagihan = $stmt->fetch();

            if (!$tagihan) {
                $this->response('error', 'Tagihan not found', null, 'NOT_FOUND', 404);
            }

            $nominal_cicilan = $tagihan['jumlah_tagihan'] / $jumlah_cicilan;
            $start_date = new DateTime($mulai_bulan . '-01');

            // Start transaction
            $this->pdo->beginTransaction();

            try {
                for ($i = 1; $i <= $jumlah_cicilan; $i++) {
                    $due_date = clone $start_date;
                    $due_date->add(new DateInterval('P' . (30 * ($i - 1)) . 'D'));

                    $cicilan_data = [
                        'tagihan_id' => $tagihan_id,
                        'nomor_cicilan' => $i,
                        'jumlah_cicilan' => $nominal_cicilan,
                        'jumlah_terbayar' => 0,
                        'status_cicilan' => 'belum_dibayar',
                        'tgl_jatuh_tempo' => $due_date->format('Y-m-d'),
                        'created_at' => date('Y-m-d H:i:s')
                    ];

                    $insert = "INSERT INTO cicilan_detail (tagihan_id, nomor_cicilan, jumlah_cicilan, jumlah_terbayar, status_cicilan, tgl_jatuh_tempo, created_at)
                              VALUES (:tagihan_id, :nomor_cicilan, :jumlah_cicilan, :jumlah_terbayar, :status_cicilan, :tgl_jatuh_tempo, :created_at)";

                    $stmt = $this->pdo->prepare($insert);
                    $stmt->execute($cicilan_data);
                }

                $this->pdo->commit();

                $response = [
                    'tagihan_id' => $tagihan_id,
                    'jumlah_cicilan' => $jumlah_cicilan,
                    'nominal_per_cicilan' => (float) $nominal_cicilan,
                    'total_tagihan' => (int) $tagihan['jumlah_tagihan'],
                    'catatan' => 'Cicilan berhasil dibuat otomatis'
                ];

                $this->response('success', 'Cicilan otomatis dibuat', $response, null, 201);

            } catch (Exception $e) {
                $this->pdo->rollBack();
                throw $e;
            }

        } catch (Exception $e) {
            $this->response('error', 'Failed to generate installment: ' . $e->getMessage(), null, 'CREATE_FAILED', 500);
        }
    }
}

