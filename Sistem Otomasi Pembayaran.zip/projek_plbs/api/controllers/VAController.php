<?php
/**
 * Virtual Account Controller
 * Handle VA generation and management
 */

class VAController extends Controller {

    /**
     * POST /api/mahasiswa/tagihan/{tagihan_id}/buat-va
     * Create Virtual Account for payment
     */
    public function buatVA($tagihan_id) {
        try {
            $user = $this->requireAuth();
            RoleMiddleware::mahasiswa($user);

            $input = getInput();
            $tagihan_id = (int) $tagihan_id;

            if (empty($input['metode_pembayaran']) || !in_array($input['metode_pembayaran'], ['lunas', 'cicilan'])) {
                $this->response('error', 'Invalid payment method', null, 'INVALID_REQUEST', 400);
            }

            $metode = $input['metode_pembayaran'];

            // Get tagihan and verify ownership
            $query = "SELECT t.*, m.mahasiswa_id, m.nim, m.user_id FROM tagihan t
                      JOIN mahasiswa m ON t.mahasiswa_id = m.mahasiswa_id
                      WHERE t.tagihan_id = :tagihan_id AND m.user_id = :user_id
                      LIMIT 1";

            $stmt = $this->pdo->prepare($query);
            $stmt->execute(['tagihan_id' => $tagihan_id, 'user_id' => $user['user_id']]);
            $tagihan = $stmt->fetch();

            if (!$tagihan) {
                $this->response('error', 'Tagihan not found', null, 'NOT_FOUND', 404);
            }

            if (empty($tagihan['nim'])) {
                $this->response('error', 'Data NIM mahasiswa tidak valid. Hubungi administrator untuk mengecek data akademik Anda.', null, 'INVALID_NIM', 400);
            }

            // CEK VA EXISTING - cek semua VA (aktif atau inactive)
            $check_va = "SELECT va.* FROM virtual_account va
                         WHERE va.tagihan_id = :tagihan_id AND va.metode_pembayaran = :metode
                         LIMIT 1";
            $stmt = $this->pdo->prepare($check_va);
            $stmt->execute(['tagihan_id' => $tagihan_id, 'metode' => $metode]);
            $existing_va = $stmt->fetch();
            
            // Jika VA sudah ada (aktif atau inactive), GUNAKAN/REAKTIVASI VA tersebut
            if ($existing_va) {
                error_log("Found existing VA: va_id={$existing_va['va_id']}, status={$existing_va['status_va']}, tagihan_id={$tagihan_id}");
                
                // Jika VA inactive, reaktivasi dengan expiry date baru
                if ($existing_va['status_va'] === 'inactive') {
                    $new_expiration = date('Y-m-d H:i:s', strtotime('+30 days'));
                    $update_va = "UPDATE virtual_account SET status_va = 'aktif', tgl_kadaluarsa = :expiry WHERE va_id = :va_id";
                    $stmt = $this->pdo->prepare($update_va);
                    $stmt->execute(['expiry' => $new_expiration, 'va_id' => $existing_va['va_id']]);
                    $existing_va['tgl_kadaluarsa'] = $new_expiration;
                    error_log("VA reactivated: va_id={$existing_va['va_id']}");
                }
                
                // Return VA existing
                $this->response('success', 'Virtual Account berhasil diambil', [
                    'va_id' => $existing_va['va_id'],
                    'nomor_va' => $existing_va['nomor_va'],
                    'metode_pembayaran' => $existing_va['metode_pembayaran'],
                    'jumlah_va' => (int) $existing_va['jumlah_va'],
                    'tgl_kadaluarsa' => $existing_va['tgl_kadaluarsa'],
                    'bank_tujuan' => 'Bank Syariah Indonesia (BSI)',
                    'catatan' => 'Gunakan nomor VA ini pada kolom berita transfer'
                ], null, 200);
                return; // Explicit return untuk keamanan
            }

            // Generate VA Number
            $va_number = generateVANumber($tagihan['nim'], $tagihan['semester'], $metode);

            // Check uniqueness
            $check_unique = "SELECT va_id FROM virtual_account WHERE nomor_va = :nomor_va";
            $stmt = $this->pdo->prepare($check_unique);
            $stmt->execute(['nomor_va' => $va_number]);
            if ($stmt->fetch()) {
                // Regenerate if duplicate
                $va_number = generateVANumber($tagihan['nim'], $tagihan['semester'], $metode . '_' . time());
            }

            $va_code = 'VA_BPP_S' . $tagihan['semester'] . '_' . strtoupper($metode);
            $expiration_date = date('Y-m-d H:i:s', strtotime('+30 days'));

            // Jika cicilan, nominal VA = setengah dari tagihan
            $jumlah_va = ($metode === 'cicilan') ? ($tagihan['jumlah_tagihan'] / 2) : $tagihan['jumlah_tagihan'];

            // HANYA buat VA baru jika BELUM ADA VA untuk tagihan+metode ini
            // Start transaction
            $this->pdo->beginTransaction();

            try {
                // Create VA record (HANYA jika belum ada)
                $va_data = [
                    'tagihan_id' => $tagihan_id,
                    'nomor_va' => $va_number,
                    'va_code' => $va_code,
                    'metode_pembayaran' => $metode,
                    'status_va' => 'aktif',
                    'jumlah_va' => $jumlah_va,
                    'total_diterima' => 0,
                    'tgl_pembuatan' => date('Y-m-d H:i:s'),
                    'tgl_kadaluarsa' => $expiration_date
                ];

                $va_insert = "INSERT INTO virtual_account (tagihan_id, nomor_va, va_code, metode_pembayaran, status_va, jumlah_va, total_diterima, tgl_pembuatan, tgl_kadaluarsa)
                             VALUES (:tagihan_id, :nomor_va, :va_code, :metode_pembayaran, :status_va, :jumlah_va, :total_diterima, :tgl_pembuatan, :tgl_kadaluarsa)";

                $stmt = $this->pdo->prepare($va_insert);
                $stmt->execute($va_data);
                $va_id = $this->pdo->lastInsertId();

                // Update tagihan status
                $update_tagihan = "UPDATE tagihan SET status_pembayaran = 'belum_bayar', metode_pembayaran = :metode, updated_at = NOW() WHERE tagihan_id = :tagihan_id";
                $stmt = $this->pdo->prepare($update_tagihan);
                $stmt->execute(['metode' => $metode, 'tagihan_id' => $tagihan_id]);

                // If cicilan, generate cicilan details (hanya jika belum ada)
                if ($metode === 'cicilan') {
                    // Cek apakah cicilan detail sudah ada
                    $check_cicilan = "SELECT COUNT(*) as count FROM cicilan_detail WHERE tagihan_id = :tagihan_id";
                    $stmt = $this->pdo->prepare($check_cicilan);
                    $stmt->execute(['tagihan_id' => $tagihan_id]);
                    $cicilan_count = $stmt->fetch();
                    
                    if ($cicilan_count['count'] == 0) {
                        $this->generateCicilanDetails($tagihan_id, $jumlah_va, $va_id);
                    }
                }

                // Log activity
                $this->logActivity($tagihan['mahasiswa_id'], 'va_dibuat', "VA created: $va_number for tagihan $tagihan_id");

                $this->pdo->commit();

                $response = [
                    'va_id' => $va_id,
                    'nomor_va' => $va_number,
                    'metode_pembayaran' => $metode,
                    'jumlah_va' => (int) $jumlah_va,
                    'tgl_kadaluarsa' => $expiration_date,
                    'bank_tujuan' => 'Bank Syariah Indonesia (BSI)',
                    'catatan' => 'Gunakan nomor VA ini pada kolom berita transfer'
                ];

                $this->response('success', 'Virtual Account berhasil dibuat', $response, null, 201);

            } catch (Exception $e) {
                $this->pdo->rollBack();
                throw $e;
            }

        } catch (Exception $e) {
            $this->response('error', 'Failed to create VA: ' . $e->getMessage(), null, 'CREATE_VA_FAILED', 500);
        }
    }

    /**
     * GET /api/va/{va_id}/status
     * Get VA status and payment history
     */
    public function statusVA($va_id) {
        try {
            $user = $this->requireAuth();
            $va_id = (int) $va_id;

            // Get VA and verify
            $va_query = "SELECT va.*, t.mahasiswa_id FROM virtual_account va
                        JOIN tagihan t ON va.tagihan_id = t.tagihan_id
                        WHERE va.va_id = :va_id";

            $stmt = $this->pdo->prepare($va_query);
            $stmt->execute(['va_id' => $va_id]);
            $va = $stmt->fetch();

            if (!$va) {
                $this->response('error', 'Virtual Account not found', null, 'NOT_FOUND', 404);
            }

            // Verify ownership if mahasiswa
            if ($user['role'] === 'mahasiswa') {
                $mahasiswa_check = "SELECT mahasiswa_id FROM mahasiswa WHERE user_id = :user_id LIMIT 1";
                $stmt = $this->pdo->prepare($mahasiswa_check);
                $stmt->execute(['user_id' => $user['user_id']]);
                $mahasiswa = $stmt->fetch();

                if ($mahasiswa['mahasiswa_id'] != $va['mahasiswa_id']) {
                    $this->response('error', 'Access denied', null, 'FORBIDDEN', 403);
                }
            }

            // Get payment history
            $payment_query = "SELECT * FROM pembayaran WHERE va_id = :va_id ORDER BY tgl_pembayaran DESC";
            $stmt = $this->pdo->prepare($payment_query);
            $stmt->execute(['va_id' => $va_id]);
            $payments = $stmt->fetchAll();

            $response = [
                'va_id' => $va['va_id'],
                'nomor_va' => $va['nomor_va'],
                'metode_pembayaran' => $va['metode_pembayaran'],
                'jumlah_va' => (int) $va['jumlah_va'],
                'total_diterima' => (int) $va['total_diterima'],
                'sisa_pembayaran' => (int) ($va['jumlah_va'] - $va['total_diterima']),
                'status_va' => $va['status_va'],
                'tgl_pembuatan' => $va['tgl_pembuatan'],
                'tgl_kadaluarsa' => $va['tgl_kadaluarsa'],
                'pembayaran' => array_map(function($p) {
                    return [
                        'pembayaran_id' => $p['pembayaran_id'],
                        'jumlah' => (int) $p['jumlah_pembayaran'],
                        'tgl_pembayaran' => $p['tgl_pembayaran'],
                        'status_validasi' => $p['status_validasi']
                    ];
                }, $payments)
            ];

            $this->response('success', 'VA status retrieved', $response);

        } catch (Exception $e) {
            $this->response('error', 'Failed to get VA status: ' . $e->getMessage(), null, 'GET_FAILED', 500);
        }
    }

    /**
     * Generate cicilan details
     */
    private function generateCicilanDetails($tagihan_id, $total_amount, $va_id) {
        $jumlah_cicilan = 5;
        
        $nominal_cicilan = $total_amount / $jumlah_cicilan;
        $start_date = new DateTime();

        for ($i = 1; $i <= $jumlah_cicilan; $i++) {
            $due_date = clone $start_date;
            $due_date->add(new DateInterval('P' . (30 * $i) . 'D'));

            $cicilan_data = [
                'tagihan_id' => $tagihan_id,
                'va_id' => $va_id,
                'nomor_cicilan' => $i,
                'jumlah_cicilan' => $nominal_cicilan,
                'jumlah_terbayar' => 0,
                'status_cicilan' => 'belum_dibayar',
                'tgl_jatuh_tempo' => $due_date->format('Y-m-d'),
                'created_at' => date('Y-m-d H:i:s')
            ];

            $insert = "INSERT INTO cicilan_detail (tagihan_id, va_id, nomor_cicilan, jumlah_cicilan, jumlah_terbayar, status_cicilan, tgl_jatuh_tempo, created_at)
                      VALUES (:tagihan_id, :va_id, :nomor_cicilan, :jumlah_cicilan, :jumlah_terbayar, :status_cicilan, :tgl_jatuh_tempo, :created_at)";

            $stmt = $this->pdo->prepare($insert);
            $stmt->execute($cicilan_data);
        }
    }

    /**
     * Log activity
     */
    private function logActivity($mahasiswa_id, $type, $description) {
        try {
            $log_data = [
                'mahasiswa_id' => $mahasiswa_id,
                'jenis_transaksi' => $type,
                'deskripsi' => $description,
                'tgl_transaksi' => date('Y-m-d H:i:s')
            ];

            $insert = "INSERT INTO riwayat_transaksi (mahasiswa_id, jenis_transaksi, deskripsi, tgl_transaksi)
                      VALUES (:mahasiswa_id, :jenis_transaksi, :deskripsi, :tgl_transaksi)";

            $stmt = $this->pdo->prepare($insert);
            $stmt->execute($log_data);
        } catch (Exception $e) {
            // Silently fail
        }
    }
}

