<?php
/**
 * Base Controller Class
 */

class Controller {
    protected $pdo;
    protected $user;

    public function __construct() {
        $this->pdo = Database::getInstance();
        $this->user = null;
    }

    protected function requireAuth() {
        $this->user = AuthMiddleware::verify();
        return $this->user;
    }

    protected function requireRole($roles) {
        if (!is_array($roles)) {
            $roles = [$roles];
        }
        RoleMiddleware::checkRole($this->user, $roles);
    }

    protected function response($status, $message, $data = null, $error_code = null, $http_code = 200) {
        sendResponse($status, $message, $data, $error_code, $http_code);
    }

    protected function sanitizeInput($input) {
        return sanitize($input);
    }
}

