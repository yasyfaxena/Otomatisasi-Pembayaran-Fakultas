<?php

require_once __DIR__ . '/../services/TagihanService.php';
require_once __DIR__ . '/../services/CicilanService.php';
require_once __DIR__ . '/../config/database.php';

class TagihanController {
    private $tagihanService;
    private $cicilanService;
    private $db;
    
    public function __construct() {
        // Start session if not started
        if (session_status() == PHP_SESSION_NONE) {
            session_start();
        }
        
        // Initialize database connection
        $database = new Database();
        $this->db = $database->connect();
        
        $this->tagihanService = new TagihanService($this->db);
        $this->cicilanService = new CicilanService($this->db);
    }
    
    public function getTagihan() {
        // Set response header
        header('Content-Type: application/json');
        
        // STEP 1: Validasi Session - Pastikan user telah login
        if (!isset($_SESSION['mahasiswa_id'])) {
            http_response_code(401);
            echo json_encode([
                'status' => 'error',
                'message' => 'Unauthorized - Please login first',
                'code' => 'UNAUTHORIZED'
            ]);
            return;
        }
        
        $mahasiswa_id = $_SESSION['mahasiswa_id'];
        
        try {
            // STEP 2-4: Ambil data tagihan dengan logika tarif
            $tagihanResult = $this->tagihanService->prosesTagihanMahasiswa($mahasiswa_id);
            
            // Check if error occurred
            if (isset($tagihanResult['status']) && $tagihanResult['status'] === 'error') {
                http_response_code(400);
                echo json_encode($tagihanResult);
                return;
            }
            
            // Get cicilan data
            $cicilanAktif = $this->cicilanService->getCicilanMahasiswa($mahasiswa_id);
            
            // Combine responses
            $response = $tagihanResult;
            $response['cicilan'] = $cicilanAktif;
            
            // Pastikan has_active_installment selalu ada dengan default false
            if (!isset($response['has_active_installment'])) {
                $response['has_active_installment'] = false;
            }
            
            echo json_encode($response);
            
        } catch (Exception $e) {
            // STEP 5: Return valid JSON error
            http_response_code(500);
            echo json_encode([
                'status' => 'error',
                'message' => 'Internal server error',
                'code' => 'INTERNAL_ERROR',
                'details' => $e->getMessage()
            ]);
        }
    }
}