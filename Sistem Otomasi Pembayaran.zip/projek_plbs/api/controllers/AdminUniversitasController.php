<?php
/**
 * Admin Universitas Controller
 * Handle payment validation and global reporting
 */

class AdminUniversitasController extends Controller {

    /**
     * GET /api/admin/pembayaran/menunggu-validasi
     * Get pending payments for validation
     */
    public function menungguValidasi() {
        try {
            $user = $this->requireAuth();
            RoleMiddleware::adminUniversitas($user);

            $page = (int) ($_GET['page'] ?? 1);
            $limit = (int) ($_GET['limit'] ?? 10);
            $offset = ($page - 1) * $limit;
            $status = $_GET['status'] ?? 'menunggu_validasi';

            // Get pending payments
            $query = "SELECT p.*, m.nim, u.nama_lengkap as mahasiswa_nama, t.jenis_tagihan, t.jumlah_tagihan, t.semester, 
                             t.metode_pembayaran, va.nomor_va,
                             ps.nama_prodi, f.nama_fakultas
                      FROM pembayaran p
                      JOIN tagihan t ON p.tagihan_id = t.tagihan_id
                      JOIN virtual_account va ON p.va_id = va.va_id
                      JOIN mahasiswa m ON p.mahasiswa_id = m.mahasiswa_id
                      JOIN users u ON m.user_id = u.user_id
                      JOIN program_studi ps ON m.prodi_id = ps.prodi_id
                      JOIN fakultas f ON ps.fakultas_id = f.fakultas_id
                      WHERE p.status_validasi = :status
                      ORDER BY p.created_at ASC
                      LIMIT :limit OFFSET :offset";

            $stmt = $this->pdo->prepare($query);
            $stmt->bindValue(':status', $status);
            $stmt->bindValue(':limit', $limit, PDO::PARAM_INT);
            $stmt->bindValue(':offset', $offset, PDO::PARAM_INT);
            $stmt->execute();
            $payments = $stmt->fetchAll();

            // Get total count
            $count_query = "SELECT COUNT(*) as total FROM pembayaran WHERE status_validasi = :status";
            $stmt = $this->pdo->prepare($count_query);
            $stmt->execute(['status' => $status]);
            $count = $stmt->fetch();

            $response = [
                'pembayaran' => array_map(function($p) {
                    return [
                        'pembayaran_id' => $p['pembayaran_id'],
                        'metode_pembayaran' => $p['metode_pembayaran'],
                        'mahasiswa' => [
                            'nim' => $p['nim'],
                            'nama_lengkap' => $p['mahasiswa_nama'],
                            'prodi' => $p['nama_prodi'],
                            'fakultas' => $p['nama_fakultas']
                        ],
                        'tagihan' => [
                            'jenis_tagihan' => $p['jenis_tagihan'],
                            'jumlah_tagihan' => (int) $p['jumlah_tagihan'],
                            'semester' => $p['semester']
                        ],
                        'pembayaran_detail' => [
                            'nomor_va' => $p['nomor_va'],
                            'jumlah_pembayaran' => (int) $p['jumlah_pembayaran'],
                            'tgl_pembayaran' => $p['tgl_pembayaran'],
                            'bank_pengirim' => $p['bank_pengirim']
                        ],
                        'bukti_pembayaran' => [
                            'filename' => $p['bukti_pembayaran_filename'],
                            'url' => $p['bukti_pembayaran_filename'] ? 'uploads/bukti_pembayaran/' . $p['bukti_pembayaran_filename'] : null
                        ],
                        'status_validasi' => $p['status_validasi'],
                        'created_at' => $p['created_at']
                    ];
                }, $payments),
                'pagination' => [
                    'page' => $page,
                    'limit' => $limit,
                    'total' => (int) $count['total'],
                    'total_pages' => ceil($count['total'] / $limit)
                ]
            ];

            $this->response('success', 'Pending payments retrieved', $response);

        } catch (Exception $e) {
            $this->response('error', 'Failed to get pending payments: ' . $e->getMessage(), null, 'RETRIEVE_FAILED', 500);
        }
    }

    /**
     * GET /api/admin-universitas/pembayaran/{pembayaran_id}/detail
     * Get detail of a specific payment with CORRECT calculation (ONLY VALID)
     */
    public function detailPembayaran($pembayaran_id) {
        try {
            $user = $this->requireAuth();
            RoleMiddleware::adminUniversitas($user);

            $pembayaran_id = (int) $pembayaran_id;

            // Get payment detail
            $query = "SELECT p.*, m.nim, m.mahasiswa_id, u.nama_lengkap as mahasiswa_nama, t.jenis_tagihan, t.jumlah_tagihan, t.semester, t.tagihan_id,
                             va.metode_pembayaran, va.nomor_va,
                             ps.nama_prodi, f.nama_fakultas
                      FROM pembayaran p
                      JOIN tagihan t ON p.tagihan_id = t.tagihan_id
                      JOIN virtual_account va ON p.va_id = va.va_id
                      JOIN mahasiswa m ON p.mahasiswa_id = m.mahasiswa_id
                      JOIN users u ON m.user_id = u.user_id
                      JOIN program_studi ps ON m.prodi_id = ps.prodi_id
                      JOIN fakultas f ON ps.fakultas_id = f.fakultas_id
                      WHERE p.pembayaran_id = :pembayaran_id
                      LIMIT 1";

            $stmt = $this->pdo->prepare($query);
            $stmt->execute(['pembayaran_id' => $pembayaran_id]);
            $payment = $stmt->fetch();

            if (!$payment) {
                $this->response('error', 'Payment not found', null, 'NOT_FOUND', 404);
                return;
            }

            // Calculate total VALID payments ONLY
            $total_query = "SELECT COALESCE(SUM(jumlah_pembayaran), 0) as total_valid
                           FROM pembayaran
                           WHERE tagihan_id = :tagihan_id AND status_validasi = 'valid'";
            $stmt = $this->pdo->prepare($total_query);
            $stmt->execute(['tagihan_id' => $payment['tagihan_id']]);
            $total_result = $stmt->fetch();
            $total_valid = (int) $total_result['total_valid'];

            // Determine status based on VALID payments only
            $status_lunas = ($total_valid >= $payment['jumlah_tagihan']) ? 'LUNAS' : 'BELUM LUNAS';

            $response = [
                'pembayaran_id' => $payment['pembayaran_id'],
                'metode_pembayaran' => $payment['metode_pembayaran'],
                'mahasiswa' => [
                    'nim' => $payment['nim'],
                    'nama_lengkap' => $payment['mahasiswa_nama'],
                    'prodi' => $payment['nama_prodi'],
                    'fakultas' => $payment['nama_fakultas']
                ],
                'tagihan' => [
                    'jenis_tagihan' => $payment['jenis_tagihan'],
                    'jumlah_tagihan' => (int) $payment['jumlah_tagihan'],
                    'semester' => $payment['semester'],
                    'total_dibayar_valid' => $total_valid,
                    'status_lunas' => $status_lunas
                ],
                'pembayaran_detail' => [
                    'nomor_va' => $payment['nomor_va'],
                    'jumlah_pembayaran' => (int) $payment['jumlah_pembayaran'],
                    'tgl_pembayaran' => $payment['tgl_pembayaran'],
                    'bank_pengirim' => $payment['bank_pengirim']
                ],
                'bukti_pembayaran' => [
                    'filename' => $payment['bukti_pembayaran_filename'],
                    'url' => $payment['bukti_pembayaran_filename'] ? 'uploads/bukti_pembayaran/' . $payment['bukti_pembayaran_filename'] : null
                ],
                'status_validasi' => $payment['status_validasi'],
                'created_at' => $payment['created_at']
            ];

            $this->response('success', 'Payment detail retrieved', $response);

        } catch (Exception $e) {
            $this->response('error', 'Failed to get payment detail: ' . $e->getMessage(), null, 'RETRIEVE_FAILED', 500);
        }
    }

    public function validasiPembayaran($pembayaran_id) {
        try {
            error_log("[AdminUniversitasController::validasiPembayaran] START - pembayaran_id: $pembayaran_id");
            
            $user = $this->requireAuth();
            RoleMiddleware::adminUniversitas($user);
            
            $input = getInput();
            $pembayaran_id = (int) $pembayaran_id;
            
            if (empty($input['status_validasi']) || !in_array($input['status_validasi'], ['valid', 'ditolak'])) {
                $this->response('error', 'Status validasi harus valid atau ditolak', null, 'INVALID_REQUEST', 400);
                return;
            }

            $status = $input['status_validasi'];
            $catatan = $input['catatan_validasi'] ?? '';

            // Load PaymentValidationService
            require_once __DIR__ . '/../services/PaymentValidationService.php';
            require_once __DIR__ . '/../services/TieredBillingService.php';
            
            $validationService = new PaymentValidationService($this->pdo);
            $tieredBillingService = new TieredBillingService($this->pdo);
            
            // Use service to validate payment
            $result = $validationService->validasiPembayaran($pembayaran_id, $status, $catatan, $user['user_id']);
            
            if ($result['status'] === 'error') {
                http_response_code(400);
                $this->response('error', $result['message'], null, $result['code'] ?? 'VALIDATION_FAILED', 400);
                return;
            }
            
            // If valid and lunas, try to create next tagihan
            if ($status === 'valid' && isset($result['status_tagihan']) && $result['status_tagihan'] === 'lunas') {
                // Get mahasiswa info from tagihan
                $stmt = $this->pdo->prepare("SELECT t.mahasiswa_id, t.jenis_tagihan, t.semester, m.prodi_id, t.tahun_akademik 
                                             FROM tagihan t 
                                             JOIN mahasiswa m ON t.mahasiswa_id = m.mahasiswa_id 
                                             WHERE t.tagihan_id = :id LIMIT 1");
                $stmt->execute(['id' => $result['tagihan_id']]);
                $tagihan = $stmt->fetch(PDO::FETCH_ASSOC);
                
                if ($tagihan && $tagihan['jenis_tagihan'] === 'BPP') {
                    $mahasiswa_id = $tagihan['mahasiswa_id'];
                    $current_semester = (int)$tagihan['semester'];
                    $prodi_id = $tagihan['prodi_id'];
                    $tahun_akademik = $tagihan['tahun_akademik'];
                    
                    // Auto-create next BPP semester (direct query, bypass opcache)
                    try {
                        $next_semester = $current_semester + 1;
                        
                        if ($next_semester <= 8) {
                            // Check if next semester tagihan already exists
                            $check = $this->pdo->prepare("SELECT tagihan_id FROM tagihan 
                                                         WHERE mahasiswa_id = ? AND jenis_tagihan = 'BPP' AND semester = ?");
                            $check->execute([$mahasiswa_id, $next_semester]);
                            
                            if (!$check->fetch()) {
                                // Get tarif for next semester
                                $tarif_query = $this->pdo->prepare("SELECT nominal, tahun_akademik FROM tarif 
                                                                    WHERE prodi_id = ? AND jenis_tagihan = 'BPP' 
                                                                    AND semester_dari <= ? AND semester_sampai >= ? 
                                                                    AND is_active = TRUE 
                                                                    ORDER BY tahun_akademik DESC LIMIT 1");
                                $tarif_query->execute([$prodi_id, $next_semester, $next_semester]);
                                $tarif = $tarif_query->fetch(PDO::FETCH_ASSOC);
                                
                                if ($tarif) {
                                    // Create next semester tagihan
                                    $insert = $this->pdo->prepare("INSERT INTO tagihan 
                                                                  (mahasiswa_id, jenis_tagihan, semester, tahun_akademik, jumlah_tagihan, status_pembayaran, metode_pembayaran) 
                                                                  VALUES (?, 'BPP', ?, ?, ?, 'belum_bayar', 'lunas')");
                                    $insert->execute([$mahasiswa_id, $next_semester, $tarif['tahun_akademik'], $tarif['nominal']]);
                                    error_log("[AUTO-CREATE] Created BPP semester {$next_semester} for mahasiswa {$mahasiswa_id}");
                                }
                            }
                        }
                        
                        // Auto-create PROPOSAL if semester 6 lunas
                        if ($current_semester == 6) {
                            // Check if all semesters 1-6 are lunas
                            $check_all = $this->pdo->prepare("SELECT COUNT(DISTINCT semester) as paid_count 
                                                              FROM tagihan 
                                                              WHERE mahasiswa_id = ? AND jenis_tagihan = 'BPP' 
                                                              AND status_pembayaran = 'lunas' AND semester <= 6");
                            $check_all->execute([$mahasiswa_id]);
                            $paid = $check_all->fetch(PDO::FETCH_ASSOC);
                            
                            if ((int)$paid['paid_count'] >= 6) {
                                // Check if Proposal already exists
                                $check_proposal = $this->pdo->prepare("SELECT tagihan_id FROM tagihan 
                                                                      WHERE mahasiswa_id = ? AND jenis_tagihan = 'PROPOSAL'");
                                $check_proposal->execute([$mahasiswa_id]);
                                
                                if (!$check_proposal->fetch()) {
                                    // Get Proposal tarif
                                    $tarif_proposal = $this->pdo->prepare("SELECT nominal FROM tarif 
                                                                           WHERE prodi_id = ? AND jenis_tagihan = 'PROPOSAL' 
                                                                           AND is_active = TRUE 
                                                                           ORDER BY tahun_akademik DESC LIMIT 1");
                                    $tarif_proposal->execute([$prodi_id]);
                                    $tarif_p = $tarif_proposal->fetch(PDO::FETCH_ASSOC);
                                    
                                    if ($tarif_p) {
                                        $insert_proposal = $this->pdo->prepare("INSERT INTO tagihan 
                                                                               (mahasiswa_id, jenis_tagihan, semester, tahun_akademik, jumlah_tagihan, status_pembayaran, metode_pembayaran) 
                                                                               VALUES (?, 'PROPOSAL', NULL, ?, ?, 'belum_bayar', 'lunas')");
                                        $insert_proposal->execute([$mahasiswa_id, $tahun_akademik, $tarif_p['nominal']]);
                                        error_log("[AUTO-CREATE] Created PROPOSAL for mahasiswa {$mahasiswa_id}");
                                    }
                                }
                            }
                        }
                        
                        // Auto-create SKRIPSI if semester 7 lunas
                        if ($current_semester == 7) {
                            // Check if all semesters 1-7 are lunas
                            $check_all = $this->pdo->prepare("SELECT COUNT(DISTINCT semester) as paid_count 
                                                              FROM tagihan 
                                                              WHERE mahasiswa_id = ? AND jenis_tagihan = 'BPP' 
                                                              AND status_pembayaran = 'lunas' AND semester <= 7");
                            $check_all->execute([$mahasiswa_id]);
                            $paid = $check_all->fetch(PDO::FETCH_ASSOC);
                            
                            if ((int)$paid['paid_count'] >= 7) {
                                // Check if Skripsi already exists
                                $check_skripsi = $this->pdo->prepare("SELECT tagihan_id FROM tagihan 
                                                                     WHERE mahasiswa_id = ? AND jenis_tagihan = 'SKRIPSI'");
                                $check_skripsi->execute([$mahasiswa_id]);
                                
                                if (!$check_skripsi->fetch()) {
                                    // Get Skripsi tarif
                                    $tarif_skripsi = $this->pdo->prepare("SELECT nominal FROM tarif 
                                                                          WHERE prodi_id = ? AND jenis_tagihan = 'SKRIPSI' 
                                                                          AND is_active = TRUE 
                                                                          ORDER BY tahun_akademik DESC LIMIT 1");
                                    $tarif_skripsi->execute([$prodi_id]);
                                    $tarif_s = $tarif_skripsi->fetch(PDO::FETCH_ASSOC);
                                    
                                    if ($tarif_s) {
                                        $insert_skripsi = $this->pdo->prepare("INSERT INTO tagihan 
                                                                              (mahasiswa_id, jenis_tagihan, semester, tahun_akademik, jumlah_tagihan, status_pembayaran, metode_pembayaran) 
                                                                              VALUES (?, 'SKRIPSI', NULL, ?, ?, 'belum_bayar', 'lunas')");
                                        $insert_skripsi->execute([$mahasiswa_id, $tahun_akademik, $tarif_s['nominal']]);
                                        error_log("[AUTO-CREATE] Created SKRIPSI for mahasiswa {$mahasiswa_id}");
                                    }
                                }
                            }
                        }
                    } catch (Exception $e) {
                        error_log("[AUTO-CREATE] Failed: " . $e->getMessage());
                    }
                }
                
                // Also try TieredBillingService (backup)
                if (isset($tagihan['mahasiswa_id'])) {
                    $tieredBillingService->createNextTagihan($tagihan['mahasiswa_id']);
                }
            }
            
            $message = ($status === 'valid') ? 'Pembayaran berhasil divalidasi' : 'Pembayaran ditolak';
            $this->response('success', $message, $result, null, 200);

        } catch (Exception $e) {
            error_log("[AdminUniversitasController::validasiPembayaran] ERROR: " . $e->getMessage());
            error_log("[AdminUniversitasController::validasiPembayaran] Stack trace: " . $e->getTraceAsString());
            $this->response('error', 'Gagal memvalidasi pembayaran: ' . $e->getMessage(), null, 'VALIDATION_FAILED', 500);
        }
    }

    /**
     * GET /api/admin/pembayaran/riwayat
     * Get payment history - valid AND ditolak
     */
    public function riwayat() {
        try {
            $user = $this->requireAuth();
            RoleMiddleware::adminUniversitas($user);

            $page = (int) ($_GET['page'] ?? 1);
            $limit = (int) ($_GET['limit'] ?? 20);
            $offset = ($page - 1) * $limit;
            $tahun_akademik = $_GET['tahun_akademik'] ?? null;

            $query = "SELECT p.*, m.nim, u.nama_lengkap, t.jenis_tagihan, t.jumlah_tagihan, f.nama_fakultas, 
                             va.nomor_va, admin_u.nama_lengkap as admin_validator_name
                      FROM pembayaran p
                      JOIN mahasiswa m ON p.mahasiswa_id = m.mahasiswa_id
                      JOIN users u ON m.user_id = u.user_id
                      JOIN tagihan t ON p.tagihan_id = t.tagihan_id
                      JOIN virtual_account va ON p.va_id = va.va_id
                      JOIN program_studi ps ON m.prodi_id = ps.prodi_id
                      JOIN fakultas f ON ps.fakultas_id = f.fakultas_id
                      LEFT JOIN users admin_u ON p.admin_validator = admin_u.user_id
                      WHERE p.status_validasi IN ('valid', 'ditolak')";

            $params = [];

            if ($tahun_akademik) {
                $query .= " AND t.tahun_akademik = :tahun_akademik";
                $params['tahun_akademik'] = $tahun_akademik;
            }

            $query .= " ORDER BY p.tgl_validasi DESC LIMIT :limit OFFSET :offset";

            $stmt = $this->pdo->prepare($query);
            foreach ($params as $key => $value) {
                $stmt->bindValue(":$key", $value);
            }
            $stmt->bindValue(':limit', $limit, PDO::PARAM_INT);
            $stmt->bindValue(':offset', $offset, PDO::PARAM_INT);
            $stmt->execute();
            $payments = $stmt->fetchAll();

            // Get total - valid AND ditolak
            $count_query = "SELECT COUNT(*) as total FROM pembayaran p 
                           JOIN tagihan t ON p.tagihan_id = t.tagihan_id 
                           WHERE p.status_validasi IN ('valid', 'ditolak')";
            if ($tahun_akademik) {
                $count_query .= " AND t.tahun_akademik = :tahun_akademik";
            }
            $stmt = $this->pdo->prepare($count_query);
            $stmt->execute($params);
            $count = $stmt->fetch();

            $response = [
                'pembayaran' => array_map(function($p) {
                    return [
                        'pembayaran_id' => $p['pembayaran_id'],
                        'mahasiswa_nim' => $p['nim'],
                        'mahasiswa_nama' => $p['nama_lengkap'],
                        'fakultas' => $p['nama_fakultas'],
                        'jenis_tagihan' => $p['jenis_tagihan'],
                        'nomor_va' => $p['nomor_va'],
                        'jumlah_pembayaran' => (int) $p['jumlah_pembayaran'],
                        'tgl_pembayaran' => $p['tgl_pembayaran'],
                        'status_validasi' => $p['status_validasi'],
                        'tgl_validasi' => $p['tgl_validasi'],
                        'admin_validator' => $p['admin_validator_name'],
                        'catatan_validasi' => $p['catatan_validasi']
                    ];
                }, $payments),
                'pagination' => [
                    'page' => $page,
                    'limit' => $limit,
                    'total' => (int) $count['total'],
                    'total_pages' => ceil($count['total'] / $limit)
                ]
            ];

            $this->response('success', 'Payment history retrieved', $response);

        } catch (Exception $e) {
            $this->response('error', 'Failed to retrieve payment history: ' . $e->getMessage(), null, 'RETRIEVE_FAILED', 500);
        }
    }

    /**
     * Update cicilan progress
     */
    private function updateCicilanProgress($tagihan_id, $jumlah) {
        $cicilan_query = "SELECT * FROM cicilan_detail WHERE tagihan_id = :tagihan_id AND status_cicilan != 'lunas' ORDER BY nomor_cicilan ASC LIMIT 1";
        $stmt = $this->pdo->prepare($cicilan_query);
        $stmt->execute(['tagihan_id' => $tagihan_id]);
        $cicilan = $stmt->fetch();

        if ($cicilan) {
            $new_terbayar = $cicilan['jumlah_terbayar'] + $jumlah;
            $new_status = ($new_terbayar >= $cicilan['jumlah_cicilan']) ? 'lunas' : 'sebagian_dibayar';
            $tgl_lunas = ($new_status === 'lunas') ? date('Y-m-d') : null;

            $update = "UPDATE cicilan_detail SET jumlah_terbayar = :jumlah_terbayar, status_cicilan = :status, tgl_lunas = :tgl_lunas 
                      WHERE cicilan_id = :cicilan_id";

            $stmt = $this->pdo->prepare($update);
            $stmt->execute([
                'jumlah_terbayar' => $new_terbayar,
                'status' => $new_status,
                'tgl_lunas' => $tgl_lunas,
                'cicilan_id' => $cicilan['cicilan_id']
            ]);
        }
    }

    /**
     * Log activity
     */
    private function logActivity($mahasiswa_id, $type, $description) {
        try {
            $log_data = [
                'mahasiswa_id' => $mahasiswa_id,
                'jenis_transaksi' => $type,
                'deskripsi' => $description,
                'tgl_transaksi' => date('Y-m-d H:i:s')
            ];

            $insert = "INSERT INTO riwayat_transaksi (mahasiswa_id, jenis_transaksi, deskripsi, tgl_transaksi)
                      VALUES (:mahasiswa_id, :jenis_transaksi, :deskripsi, :tgl_transaksi)";

            $stmt = $this->pdo->prepare($insert);
            $stmt->execute($log_data);
        } catch (Exception $e) {
            // Silently fail
        }
    }

    /**
     * GET /api/admin-universitas/dashboard-info
     * Get dashboard info for admin universitas
     */
    public function dashboardInfo() {
        try {
            $user = $this->requireAuth();
            RoleMiddleware::adminUniversitas($user);

            // Get global statistics
            $stats_query = "SELECT 
                           COUNT(DISTINCT m.mahasiswa_id) as total_mahasiswa,
                           COUNT(DISTINCT t.tagihan_id) as total_tagihan,
                           SUM(CASE WHEN t.status_pembayaran = 'lunas' THEN 1 ELSE 0 END) as total_lunas,
                           SUM(CASE WHEN t.status_pembayaran = 'cicilan' THEN 1 ELSE 0 END) as total_cicilan,
                           SUM(CASE WHEN t.status_pembayaran = 'belum_bayar' THEN 1 ELSE 0 END) as total_belum_bayar
                           FROM mahasiswa m
                           LEFT JOIN tagihan t ON m.mahasiswa_id = t.mahasiswa_id";

            $stmt = $this->pdo->prepare($stats_query);
            $stmt->execute();
            $stats = $stmt->fetch();

            // Get payment validation statistics
            $payment_stats = "SELECT 
                             COUNT(CASE WHEN status_validasi = 'menunggu_validasi' THEN 1 END) as pending,
                             COUNT(CASE WHEN status_validasi = 'valid' THEN 1 END) as approved,
                             COUNT(CASE WHEN status_validasi = 'ditolak' THEN 1 END) as rejected
                             FROM pembayaran";

            $stmt = $this->pdo->prepare($payment_stats);
            $stmt->execute();
            $payments = $stmt->fetch();

            // Get total payment amount
            $payment_total = "SELECT 
                             SUM(jumlah_pembayaran) as total_amount
                             FROM pembayaran
                             WHERE status_validasi = 'valid'";

            $stmt = $this->pdo->prepare($payment_total);
            $stmt->execute();
            $total_amount = $stmt->fetch();

            $response = [
                'admin' => [
                    'nama_lengkap' => $user['nama_lengkap'],
                    'email' => $user['email'],
                    'role' => 'admin_universitas'
                ],
                'statistik_mahasiswa' => [
                    'total_mahasiswa' => (int) ($stats['total_mahasiswa'] ?? 0),
                    'total_tagihan' => (int) ($stats['total_tagihan'] ?? 0),
                    'tagihan_lunas' => (int) ($stats['total_lunas'] ?? 0),
                    'tagihan_cicilan' => (int) ($stats['total_cicilan'] ?? 0),
                    'tagihan_belum_bayar' => (int) ($stats['total_belum_bayar'] ?? 0)
                ],
                'statistik_pembayaran' => [
                    'menunggu_validasi' => (int) ($payments['pending'] ?? 0),
                    'valid' => (int) ($payments['approved'] ?? 0),
                    'ditolak' => (int) ($payments['rejected'] ?? 0),
                    'total_amount_tervalidasi' => (float) ($total_amount['total_amount'] ?? 0)
                ]
            ];

            $this->response('success', 'Dashboard info retrieved', $response);

        } catch (Exception $e) {
            $this->response('error', 'Failed to retrieve dashboard info: ' . $e->getMessage(), null, 'FETCH_FAILED', 500);
        }
    }

    /**
     * GET /api/admin-universitas/laporan-pembayaran
     * Get payment report (global reporting) - valid AND ditolak
     */
    public function laporanPembayaran() {
        try {
            $user = $this->requireAuth();
            RoleMiddleware::adminUniversitas($user);

            $page = (int) ($_GET['page'] ?? 1);
            $limit = (int) ($_GET['limit'] ?? 20);
            $offset = ($page - 1) * $limit;
            $tahun_akademik = $_GET['tahun_akademik'] ?? null;
            $fakultas_id = $_GET['fakultas_id'] ?? null;

            // Get payment reports with full details
            $query = "SELECT 
                     p.pembayaran_id,
                     m.nim,
                     u.nama_lengkap as nama_mahasiswa,
                     f.nama_fakultas,
                     ps.nama_prodi,
                     t.jenis_tagihan,
                     t.metode_pembayaran,
                     t.semester,
                     t.tahun_akademik,
                     t.jumlah_tagihan,
                     p.jumlah_pembayaran,
                     p.tgl_pembayaran,
                     p.status_validasi,
                     p.tgl_validasi,
                     p.catatan_validasi,
                     t.status_pembayaran,
                     va.nomor_va,
                     admin_u.nama_lengkap as admin_validator_name
                     FROM pembayaran p
                     JOIN tagihan t ON p.tagihan_id = t.tagihan_id
                     JOIN mahasiswa m ON p.mahasiswa_id = m.mahasiswa_id
                     JOIN users u ON m.user_id = u.user_id
                     JOIN program_studi ps ON m.prodi_id = ps.prodi_id
                     JOIN fakultas f ON ps.fakultas_id = f.fakultas_id
                     JOIN virtual_account va ON p.va_id = va.va_id
                     LEFT JOIN users admin_u ON p.admin_validator = admin_u.user_id
                     WHERE p.status_validasi IN ('valid', 'ditolak')";

            $params = [];

            if ($tahun_akademik) {
                $query .= " AND t.tahun_akademik = :tahun_akademik";
                $params['tahun_akademik'] = $tahun_akademik;
            }

            if ($fakultas_id) {
                $query .= " AND f.fakultas_id = :fakultas_id";
                $params['fakultas_id'] = $fakultas_id;
            }

            $query .= " ORDER BY p.tgl_validasi DESC LIMIT :limit OFFSET :offset";

            $stmt = $this->pdo->prepare($query);
            foreach ($params as $key => $value) {
                $stmt->bindValue(":$key", $value);
            }
            $stmt->bindValue(':limit', $limit, PDO::PARAM_INT);
            $stmt->bindValue(':offset', $offset, PDO::PARAM_INT);
            $stmt->execute();
            $pembayaran = $stmt->fetchAll();

            // Get count for pagination
            $count_query = "SELECT COUNT(p.pembayaran_id) as total
                           FROM pembayaran p
                           JOIN tagihan t ON p.tagihan_id = t.tagihan_id
                           JOIN mahasiswa m ON p.mahasiswa_id = m.mahasiswa_id
                           JOIN program_studi ps ON m.prodi_id = ps.prodi_id
                           JOIN fakultas f ON ps.fakultas_id = f.fakultas_id
                           WHERE p.status_validasi IN ('valid', 'ditolak')";

            if ($tahun_akademik) {
                $count_query .= " AND t.tahun_akademik = :tahun_akademik";
            }
            if ($fakultas_id) {
                $count_query .= " AND f.fakultas_id = :fakultas_id";
            }

            $stmt = $this->pdo->prepare($count_query);
            foreach ($params as $key => $value) {
                $stmt->bindValue(":$key", $value);
            }
            $stmt->execute();
            $count = $stmt->fetch();

            // Get summary statistics - ONLY VALID for totals
            $summary_query = "SELECT 
                             COUNT(DISTINCT t.tahun_akademik) as total_tahun,
                             COUNT(DISTINCT f.fakultas_id) as total_fakultas,
                             SUM(CASE WHEN p.status_validasi = 'valid' THEN p.jumlah_pembayaran ELSE 0 END) as total_pembayaran,
                             COUNT(CASE WHEN p.status_validasi = 'valid' THEN p.pembayaran_id END) as total_valid
                             FROM pembayaran p
                             JOIN tagihan t ON p.tagihan_id = t.tagihan_id
                             JOIN mahasiswa m ON p.mahasiswa_id = m.mahasiswa_id
                             JOIN program_studi ps ON m.prodi_id = ps.prodi_id
                             JOIN fakultas f ON ps.fakultas_id = f.fakultas_id
                             WHERE p.status_validasi = 'valid'";

            if ($tahun_akademik) {
                $summary_query .= " AND t.tahun_akademik = :tahun_akademik";
            }
            if ($fakultas_id) {
                $summary_query .= " AND f.fakultas_id = :fakultas_id";
            }

            $stmt = $this->pdo->prepare($summary_query);
            foreach ($params as $key => $value) {
                $stmt->bindValue(":$key", $value);
            }
            $stmt->execute();
            $summary = $stmt->fetch();

            $response = [
                'summary' => [
                    'total_pembayaran' => (float) ($summary['total_pembayaran'] ?? 0),
                    'total_transaksi' => (int) $count['total'],
                    'total_tahun_akademik' => (int) ($summary['total_tahun'] ?? 0),
                    'total_fakultas' => (int) ($summary['total_fakultas'] ?? 0)
                ],
                'laporan' => array_map(function($item) {
                    return [
                        'pembayaran_id' => $item['pembayaran_id'],
                        'nim' => $item['nim'],
                        'nama_mahasiswa' => $item['nama_mahasiswa'],
                        'fakultas_nama' => $item['nama_fakultas'],
                        'prodi_nama' => $item['nama_prodi'],
                        'jenis_tagihan' => $item['jenis_tagihan'],
                        'semester' => $item['semester'],
                        'tahun_akademik' => $item['tahun_akademik'],
                        'jumlah_tagihan' => (float) $item['jumlah_tagihan'],
                        'jumlah_pembayaran' => (float) $item['jumlah_pembayaran'],
                        'nomor_va' => $item['nomor_va'],
                        'tgl_pembayaran' => $item['tgl_pembayaran'],
                        'tgl_validasi' => $item['tgl_validasi'],
                        'status_validasi' => $item['status_validasi'],
                        'status_pembayaran' => $item['status_pembayaran'],
                        'metode_pembayaran' => $item['metode_pembayaran'],
                        'tanggal_validasi' => $item['tgl_validasi'],
                        'admin_validator' => $item['admin_validator_name'],
                        'catatan_validasi' => $item['catatan_validasi']
                    ];
                }, $pembayaran),
                'pagination' => [
                    'page' => $page,
                    'limit' => $limit,
                    'total' => (int) $count['total'],
                    'total_pages' => ceil($count['total'] / $limit)
                ]
            ];

            $this->response('success', 'Laporan pembayaran retrieved', $response);

        } catch (Exception $e) {
            $this->response('error', 'Failed to retrieve laporan pembayaran: ' . $e->getMessage(), null, 'FETCH_FAILED', 500);
        }
    }

    /**
     * GET /api/admin-universitas/monitoring-global
     * Get global monitoring data (payment status across all faculties)
     */
    public function monitoringGlobal() {
        try {
            $user = $this->requireAuth();
            RoleMiddleware::adminUniversitas($user);

            $page = (int) ($_GET['page'] ?? 1);
            $limit = (int) ($_GET['limit'] ?? 20);
            $offset = ($page - 1) * $limit;
            $tahun_akademik = $_GET['tahun_akademik'] ?? null;

            // Get monitoring data per faculty
            $query = "SELECT 
                     f.fakultas_id,
                     f.nama_fakultas,
                     COUNT(DISTINCT m.mahasiswa_id) as total_mahasiswa,
                     COUNT(DISTINCT t.tagihan_id) as total_tagihan,
                     SUM(CASE WHEN t.status_pembayaran = 'lunas' THEN 1 ELSE 0 END) as total_lunas,
                     SUM(CASE WHEN t.status_pembayaran = 'cicilan' THEN 1 ELSE 0 END) as total_cicilan,
                     SUM(CASE WHEN t.status_pembayaran = 'belum_bayar' THEN 1 ELSE 0 END) as total_belum_bayar,
                     SUM(t.jumlah_tagihan) as total_nominal,
                     SUM(CASE WHEN p.status_validasi = 'valid' THEN p.jumlah_pembayaran ELSE 0 END) as total_terbayar,
                     COUNT(DISTINCT CASE WHEN p.status_validasi = 'menunggu_validasi' THEN p.pembayaran_id END) as pending_validation
                     FROM fakultas f
                     LEFT JOIN program_studi ps ON f.fakultas_id = ps.fakultas_id
                     LEFT JOIN mahasiswa m ON ps.prodi_id = m.prodi_id
                     LEFT JOIN tagihan t ON m.mahasiswa_id = t.mahasiswa_id
                     LEFT JOIN pembayaran p ON t.tagihan_id = p.tagihan_id
                     WHERE 1=1";

            $params = [];

            if ($tahun_akademik) {
                $query .= " AND (t.tahun_akademik = :tahun_akademik OR t.tahun_akademik IS NULL)";
                $params['tahun_akademik'] = $tahun_akademik;
            }

            $query .= " GROUP BY f.fakultas_id, f.nama_fakultas
                       ORDER BY f.nama_fakultas ASC
                       LIMIT :limit OFFSET :offset";

            $stmt = $this->pdo->prepare($query);
            foreach ($params as $key => $value) {
                $stmt->bindValue(":$key", $value);
            }
            $stmt->bindValue(':limit', $limit, PDO::PARAM_INT);
            $stmt->bindValue(':offset', $offset, PDO::PARAM_INT);
            $stmt->execute();
            $monitoring = $stmt->fetchAll();

            // Get count
            $count_query = "SELECT COUNT(DISTINCT f.fakultas_id) as total
                           FROM fakultas f";

            $stmt = $this->pdo->prepare($count_query);
            $stmt->execute();
            $count = $stmt->fetch();

            // Get global summary
            $global_summary = "SELECT 
                              COUNT(DISTINCT m.mahasiswa_id) as total_mahasiswa,
                              COUNT(DISTINCT t.tagihan_id) as total_tagihan,
                              SUM(CASE WHEN t.status_pembayaran = 'lunas' THEN 1 ELSE 0 END) as total_lunas,
                              SUM(CASE WHEN t.status_pembayaran = 'cicilan' THEN 1 ELSE 0 END) as total_cicilan,
                              SUM(CASE WHEN t.status_pembayaran = 'belum_bayar' THEN 1 ELSE 0 END) as total_belum_bayar,
                              SUM(t.jumlah_tagihan) as total_nominal,
                              SUM(CASE WHEN p.status_validasi = 'valid' THEN p.jumlah_pembayaran ELSE 0 END) as total_terbayar
                              FROM mahasiswa m
                              LEFT JOIN tagihan t ON m.mahasiswa_id = t.mahasiswa_id
                              LEFT JOIN pembayaran p ON t.tagihan_id = p.tagihan_id
                              WHERE 1=1";

            if ($tahun_akademik) {
                $global_summary .= " AND (t.tahun_akademik = :tahun_akademik OR t.tahun_akademik IS NULL)";
            }

            $stmt = $this->pdo->prepare($global_summary);
            foreach ($params as $key => $value) {
                $stmt->bindValue(":$key", $value);
            }
            $stmt->execute();
            $summary = $stmt->fetch();

            $response = [
                'global_summary' => [
                    'total_mahasiswa' => (int) ($summary['total_mahasiswa'] ?? 0),
                    'total_tagihan' => (int) ($summary['total_tagihan'] ?? 0),
                    'total_lunas' => (int) ($summary['total_lunas'] ?? 0),
                    'total_cicilan' => (int) ($summary['total_cicilan'] ?? 0),
                    'total_belum_bayar' => (int) ($summary['total_belum_bayar'] ?? 0),
                    'total_nominal' => (float) ($summary['total_nominal'] ?? 0),
                    'total_terbayar' => (float) ($summary['total_terbayar'] ?? 0),
                    'persentase_terbayar' => ($summary['total_nominal'] > 0) 
                        ? round(($summary['total_terbayar'] / $summary['total_nominal']) * 100, 2)
                        : 0
                ],
                'monitoring_per_fakultas' => array_map(function($item) {
                    $total_tagihan = (float) ($item['total_nominal'] ?? 0);
                    $total_terbayar = (float) ($item['total_terbayar'] ?? 0);
                    return [
                        'fakultas_id' => $item['fakultas_id'],
                        'nama_fakultas' => $item['nama_fakultas'],
                        'total_mahasiswa' => (int) ($item['total_mahasiswa'] ?? 0),
                        'total_tagihan' => (int) ($item['total_tagihan'] ?? 0),
                        'tagihan_lunas' => (int) ($item['total_lunas'] ?? 0),
                        'tagihan_cicilan' => (int) ($item['total_cicilan'] ?? 0),
                        'tagihan_belum_bayar' => (int) ($item['total_belum_bayar'] ?? 0),
                        'total_nominal' => $total_tagihan,
                        'total_terbayar' => $total_terbayar,
                        'pending_validation' => (int) ($item['pending_validation'] ?? 0),
                        'persentase_terbayar' => $total_tagihan > 0 
                            ? round(($total_terbayar / $total_tagihan) * 100, 2)
                            : 0
                    ];
                }, $monitoring),
                'pagination' => [
                    'page' => $page,
                    'limit' => $limit,
                    'total' => (int) $count['total'],
                    'total_pages' => ceil($count['total'] / $limit)
                ]
            ];

            $this->response('success', 'Monitoring global retrieved', $response);

        } catch (Exception $e) {
            $this->response('error', 'Failed to retrieve monitoring global: ' . $e->getMessage(), null, 'FETCH_FAILED', 500);
        }
    }
}

