<?php
/**
 * KRS Controller for Admin Fakultas
 * Handle KRS activation and management
 */

class KRSController extends Controller {

    /**
     * GET /api/admin-fakultas/krs/mahasiswa-layak
     * Get list of students eligible for KRS activation
     * CRITICAL: Students eligible if status_pembayaran = 'lunas' OR 'cicilan_berjalan'
     */
    public function mahasiswaLayakKRS() {
        try {
            $user = $this->requireAuth();
            RoleMiddleware::adminFakultas($user);

            // Get fakultas_id from users table (admin_fakultas assignment)
            $stmt = $this->pdo->prepare("SELECT fakultas_id FROM users WHERE user_id = :user_id AND role = 'admin_fakultas' LIMIT 1");
            $stmt->execute(['user_id' => $user['user_id']]);
            $admin = $stmt->fetch();

            if (!$admin || !$admin['facultas_id']) {
                $this->response('error', 'Admin fakultas tidak ditemukan atau tidak assign ke fakultas', null, 'NOT_FOUND', 404);
                return;
            }

            $facultas_id = $admin['facultas_id'];

            // Load KRSEligibilityService
            require_once __DIR__ . '/../services/KRSEligibilityService.php';
            $krsService = new KRSEligibilityService($this->pdo);

            // Get eligible students using service
            $result = $krsService->getMahasiswaLayakKRS($user['user_id'], $facultas_id);

            if ($result['status'] === 'error') {
                http_response_code(400);
                $this->response('error', $result['message'], null, $result['code'] ?? 'FETCH_FAILED', 400);
                return;
            }

            $this->response('success', 'Mahasiswa layak KRS retrieved', ['mahasiswa' => $result['mahasiswa']]);

        } catch (Exception $e) {
            $this->response('error', 'Failed to get mahasiswa layak KRS: ' . $e->getMessage(), null, 'FETCH_FAILED', 500);
        }
    }

    /**
     * POST /api/admin-fakultas/krs/aktivasi
     * Activate KRS for student
     * CRITICAL: Only admin_fakultas can activate
     * CRITICAL: Student must have cicilan_berjalan OR lunas status
     */
    public function aktivasiKRS() {
        try {
            $user = $this->requireAuth();
            RoleMiddleware::adminFakultas($user);

            $input = getInput();

            if (empty($input['mahasiswa_id']) || empty($input['semester']) || empty($input['tahun_akademik'])) {
                $this->response('error', 'mahasiswa_id, semester, dan tahun_akademik wajib diisi', null, 'INVALID_REQUEST', 400);
                return;
            }

            $mahasiswa_id = (int) $input['mahasiswa_id'];
            $semester = (int) $input['semester'];
            $tahun_akademik = $input['tahun_akademik'];

            // Get admin's facultas
            $stmt = $this->pdo->prepare("SELECT facultas_id FROM users WHERE user_id = :user_id AND role = 'admin_fakultas' LIMIT 1");
            $stmt->execute(['user_id' => $user['user_id']]);
            $admin = $stmt->fetch();

            if (!$admin || !$admin['facultas_id']) {
                $this->response('error', 'Admin tidak assign ke fakultas manapun', null, 'FORBIDDEN', 403);
                return;
            }

            // Load KRSEligibilityService
            require_once __DIR__ . '/../services/KRSEligibilityService.php';
            $krsService = new KRSEligibilityService($this->pdo);

            // Use service to activate KRS
            $result = $krsService->aktivasiKRS($mahasiswa_id, $semester, $tahun_akademik, $user['user_id'], $admin['facultas_id']);

            if ($result['status'] === 'error') {
                http_response_code(400);
                $this->response('error', $result['message'], null, $result['code'] ?? 'ACTIVATION_FAILED', 400);
                return;
            }

            $this->response('success', 'KRS berhasil diaktifkan', $result);

        } catch (Exception $e) {
            error_log("[KRSController::aktivasiKRS] ERROR: " . $e->getMessage());
            $this->response('error', 'Failed to activate KRS: ' . $e->getMessage(), null, 'ACTIVATION_FAILED', 500);
        }
    }
}
