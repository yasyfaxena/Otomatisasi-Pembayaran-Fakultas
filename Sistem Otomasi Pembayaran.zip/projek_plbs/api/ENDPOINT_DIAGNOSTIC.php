<?php
/**
 * API ENDPOINT DIAGNOSTIC
 * Diagnose API routing issues and endpoint availability
 */

echo "╔════════════════════════════════════════════════════════════╗\n";
echo "║      API ENDPOINT DIAGNOSTIC                               ║\n";
echo "║      Diagnose 404/401 errors pada login endpoint           ║\n";
echo "╚════════════════════════════════════════════════════════════╝\n\n";

// Check 1: api/index.php exists
echo "✓ Checking api/index.php...\n";
if (file_exists(__DIR__ . '/index.php')) {
    echo "  ✅ File exists\n";
} else {
    echo "  ❌ File NOT found\n";
}

// Check 2: routes/api.php exists
echo "\n✓ Checking routes/api.php...\n";
if (file_exists(__DIR__ . '/routes/api.php')) {
    echo "  ✅ File exists\n";
    
    // Check for login route
    $routes_content = file_get_contents(__DIR__ . '/routes/api.php');
    if (strpos($routes_content, '/api/auth/login') !== false) {
        echo "  ✅ Login route defined\n";
    } else {
        echo "  ❌ Login route NOT defined\n";
    }
} else {
    echo "  ❌ File NOT found\n";
}

// Check 3: AuthController exists
echo "\n✓ Checking AuthController...\n";
if (file_exists(__DIR__ . '/controllers/AuthController.php')) {
    echo "  ✅ File exists\n";
    
    $auth_content = file_get_contents(__DIR__ . '/controllers/AuthController.php');
    if (strpos($auth_content, 'function login') !== false) {
        echo "  ✅ login() method exists\n";
    } else {
        echo "  ❌ login() method NOT found\n";
    }
} else {
    echo "  ❌ File NOT found\n";
}

// Check 4: Controller base class
echo "\n✓ Checking Controller base class...\n";
if (file_exists(__DIR__ . '/controllers/Controller.php')) {
    echo "  ✅ File exists\n";
} else {
    echo "  ❌ File NOT found\n";
}

// Check 5: Config files
echo "\n✓ Checking config files...\n";
$config_files = ['database.php', 'jwt.php', 'helpers.php'];
foreach ($config_files as $file) {
    if (file_exists(__DIR__ . '/config/' . $file)) {
        echo "  ✅ config/$file exists\n";
    } else {
        echo "  ❌ config/$file NOT found\n";
    }
}

// Check 6: Middleware files
echo "\n✓ Checking middleware files...\n";
$middleware_files = ['auth.php', 'role.php'];
foreach ($middleware_files as $file) {
    if (file_exists(__DIR__ . '/middleware/' . $file)) {
        echo "  ✅ middleware/$file exists\n";
    } else {
        echo "  ❌ middleware/$file NOT found\n";
    }
}

// Check 7: Router class
echo "\n✓ Checking Router class...\n";
if (file_exists(__DIR__ . '/routes/api.php')) {
    $router_content = file_get_contents(__DIR__ . '/routes/api.php');
    if (strpos($router_content, 'class Router') !== false) {
        echo "  ✅ Router class defined\n";
    } else {
        echo "  ❌ Router class NOT found\n";
    }
}

// Check 8: TEST: Direct call to login endpoint
echo "\n╔════════════════════════════════════════════════════════════╗\n";
echo "║      TESTING LOGIN ENDPOINT                                ║\n";
echo "╚════════════════════════════════════════════════════════════╝\n\n";

echo "✓ Testing endpoint accessibility...\n\n";
echo "Expected endpoint URL:\n";
echo "  http://localhost:8000/api/index.php/api/auth/login\n\n";

echo "OR (simplified):\n";
echo "  http://localhost:8000/api/index.php?path=/api/auth/login\n\n";

echo "Frontend calling:\n";
echo "  /projek_plbs/api/index.php/api/auth/login\n\n";

echo "Which translates to:\n";
echo "  http://localhost:8000/projek_plbs/api/index.php/api/auth/login\n\n";

// Check routing logic
echo "╔════════════════════════════════════════════════════════════╗\n";
echo "║      ROUTING ANALYSIS                                      ║\n";
echo "╚════════════════════════════════════════════════════════════╝\n\n";

echo "Router matchRoute logic:\n";
echo "1. Input URI: /projek_plbs/api/index.php/api/auth/login\n";
echo "2. Strip /projek_plbs/api/index.php → /api/auth/login\n";
echo "3. Strip /api → /auth/login\n";
echo "4. Match pattern /api/auth/login against /auth/login\n";
echo "5. Pattern after strip → /auth/login\n";
echo "6. Should MATCH ✅\n\n";

echo "OR if pattern not stripped:\n";
echo "1. Pattern /api/auth/login\n";
echo "2. After strip → /auth/login\n";
echo "3. Match /auth/login against /auth/login\n";
echo "4. Should MATCH ✅\n\n";

// Check 9: Possible issues
echo "╔════════════════════════════════════════════════════════════╗\n";
echo "║      POSSIBLE ISSUES                                       ║\n";
echo "╚════════════════════════════════════════════════════════════╝\n\n";

echo "Issue 1: 404 Not Found\n";
echo "  Cause: Routing pattern mismatch\n";
echo "  Check: Is /api/auth/login registered in routes?\n";
echo "  Fix: Verify routes/api.php has the correct pattern\n\n";

echo "Issue 2: 401 Unauthorized\n";
echo "  Cause: Session/Authentication check failed\n";
echo "  Check: Is AuthController->login() checking session?\n";
echo "  Fix: Debug authentication logic\n\n";

echo "Issue 3: Wrong URL format\n";
echo "  Cause: Frontend using wrong API URL\n";
echo "  Check: Frontend fetch call URL\n";
echo "  Fix: Use correct API endpoint URL\n\n";

// Recommendation
echo "╔════════════════════════════════════════════════════════════╗\n";
echo "║      NEXT STEPS                                            ║\n";
echo "╚════════════════════════════════════════════════════════════╝\n\n";

echo "1. Check Network tab in browser DevTools\n";
echo "   - See actual URL being called\n";
echo "   - Check response headers\n\n";

echo "2. Test endpoint directly:\n";
echo "   curl -X POST http://localhost:8000/api/index.php/api/auth/login \\\n";
echo "     -H 'Content-Type: application/json' \\\n";
echo "     -d '{\"username\":\"admin_univ\",\"password\":\"admin123\"}'\n\n";

echo "3. Check api/index.php error log:\n";
echo "   logs/api_errors.log\n\n";

echo "4. Verify routing pattern:\n";
echo "   Is it /api/auth/login or /auth/login?\n\n";

echo "\n";
