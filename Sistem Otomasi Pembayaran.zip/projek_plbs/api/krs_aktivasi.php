<?php
/**
 * API Endpoint untuk Aktivasi KRS
 * POST /api/admin/krs/{tagihan_id}/aktivasi
 */

header('Content-Type: application/json');
require_once __DIR__ . '/config/database.php';
require_once __DIR__ . '/helpers/notification_helper.php';

session_start();

if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin_fakultas') {
    http_response_code(401);
    echo json_encode(['status' => 'error', 'message' => 'Unauthorized']);
    exit;
}

try {
    $database = new Database();
    $conn = $database->connect();
    
    // Get tagihan_id from URL
    $tagihan_id = $_GET['tagihan_id'] ?? null;
    
    if (!$tagihan_id) {
        http_response_code(400);
        echo json_encode(['status' => 'error', 'message' => 'Tagihan ID required']);
        exit;
    }
    
    // Get tagihan info
    $stmt = $conn->prepare("SELECT t.*, m.mahasiswa_id FROM tagihan t JOIN mahasiswa m ON t.mahasiswa_id = m.mahasiswa_id WHERE t.tagihan_id = :id");
    $stmt->execute(['id' => $tagihan_id]);
    $tagihan = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$tagihan) {
        http_response_code(404);
        echo json_encode(['status' => 'error', 'message' => 'Tagihan not found']);
        exit;
    }
    
    // Update status KRS
    $stmt = $conn->prepare("UPDATE tagihan SET status_krs = 'aktif' WHERE tagihan_id = :id");
    $stmt->execute(['id' => $tagihan_id]);
    
    // CREATE NOTIFICATION untuk aktivasi KRS
    createKRSNotification(
        $conn,
        $tagihan['mahasiswa_id'],
        $tagihan['semester'],
        $tagihan['tahun_akademik']
    );
    
    echo json_encode([
        'status' => 'success',
        'message' => 'KRS berhasil diaktifkan dan notifikasi telah dikirim'
    ]);
    
} catch (Exception $e) {
    http_response_code(500);
    echo json_encode([
        'status' => 'error',
        'message' => $e->getMessage()
    ]);
}
