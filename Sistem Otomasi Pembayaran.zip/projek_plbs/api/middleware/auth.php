<?php
/**
 * Authentication Middleware
 * Verify JWT Token
 */

class AuthMiddleware {
    public static function verify() {
        $token = JWT::getTokenFromHeader();

        if (empty($token)) {
            sendResponse('error', 'Token not provided', null, 'UNAUTHORIZED', 401);
        }

        $decoded = JWT::verify($token);

        if (!$decoded) {
            sendResponse('error', 'Invalid or expired token', null, 'UNAUTHORIZED', 401);
        }

        return $decoded;
    }

    /**
     * Get authenticated user info
     */
    public static function getUser() {
        return self::verify();
    }
}