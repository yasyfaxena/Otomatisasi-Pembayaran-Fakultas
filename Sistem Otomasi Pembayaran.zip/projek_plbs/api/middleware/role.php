<?php
/**
 * Role-Based Access Control (RBAC) Middleware
 */

class RoleMiddleware {
    private static $allowed_roles = [];

    public static function checkRole($user, $required_roles = []) {
        if (empty($required_roles)) {
            return true;
        }

        if (!is_array($required_roles)) {
            $required_roles = [$required_roles];
        }

        if (!isset($user['role'])) {
            sendResponse('error', 'User role not found', null, 'FORBIDDEN', 403);
        }

        if (!in_array($user['role'], $required_roles)) {
            sendResponse('error', 'Access denied. Insufficient permissions', null, 'FORBIDDEN', 403);
        }

        return true;
    }

    public static function mahasiswa($user) {
        return self::checkRole($user, 'mahasiswa');
    }

    public static function adminFakultas($user) {
        return self::checkRole($user, 'admin_fakultas');
    }

    public static function adminUniversitas($user) {
        return self::checkRole($user, 'admin_universitas');
    }

    public static function adminOnly($user) {
        return self::checkRole($user, ['admin_fakultas', 'admin_universitas']);
    }
}