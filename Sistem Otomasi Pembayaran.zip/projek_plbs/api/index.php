<?php
/**
 * Main Entry Point - API Index
 * Handles all API requests and returns JSON responses
 */

// Start PHP session FIRST before any other output
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

// Set error handling - suppress all error output and log to file instead
error_reporting(E_ALL);
ini_set('display_errors', 0);
ini_set('log_errors', 1);
ini_set('error_log', __DIR__ . '/../logs/api_errors.log');

// Set output buffering to catch any stray output
ob_start();

// Set response header FIRST before any other output
header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization');

// Handle preflight
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit;
}

// Wrap everything in try-catch for ultimate safety
try {
    // Include config & helpers
    require_once __DIR__ . '/config/database.php';
    require_once __DIR__ . '/config/jwt.php';
    require_once __DIR__ . '/config/helpers.php';
    require_once __DIR__ . '/helpers/payment_helper.php';

    // Include middleware
    require_once __DIR__ . '/middleware/auth.php';
    require_once __DIR__ . '/middleware/role.php';

    // Include base classes
    require_once __DIR__ . '/controllers/Controller.php';
    require_once __DIR__ . '/models/Model.php';

    // Include controllers
    require_once __DIR__ . '/controllers/AuthController.php';
    require_once __DIR__ . '/controllers/MahasiswaController.php';
    require_once __DIR__ . '/controllers/VAController.php';
    require_once __DIR__ . '/controllers/PembayaranController.php';
    require_once __DIR__ . '/controllers/CicilanController.php';
    require_once __DIR__ . '/controllers/AdminUniversitasController.php';
    require_once __DIR__ . '/controllers/AdminFakultasController.php';
    require_once __DIR__ . '/controllers/TagihanController.php';
    require_once __DIR__ . '/controllers/KRSController.php';
    require_once __DIR__ . '/controllers/TriggerController.php';

    // Include router
    require_once __DIR__ . '/routes/api.php';

    // Clear any buffered output
    ob_clean();

    // Initialize router
    $router = new Router();
    initializeRoutes($router);

    // Dispatch request
    $router->dispatch();

} catch (Exception $e) {
    // Clear any buffered output
    ob_clean();
    
    // Log error
    error_log($e->getMessage() . "\n" . $e->getTraceAsString());
    
    // Send error response
    http_response_code(500);
    echo json_encode([
        'status' => 'error',
        'message' => 'Internal server error',
        'error_code' => 'INTERNAL_ERROR',
        'timestamp' => date('c')
    ]);
    exit;
}