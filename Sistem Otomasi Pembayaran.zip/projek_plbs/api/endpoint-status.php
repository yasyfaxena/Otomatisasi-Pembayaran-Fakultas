<?php
/**
 * Endpoint Status Check
 * Access: http://localhost/projek_plbs/api/endpoint-status.php
 */

header('Content-Type: application/json; charset=utf-8');

$endpoints = [
    [
        'name' => 'Login Mahasiswa',
        'method' => 'POST',
        'url' => '/projek_plbs/api/index.php/api/auth/login',
        'requires_auth' => false,
        'required_fields' => ['username', 'password']
    ],
    [
        'name' => 'Register Mahasiswa',
        'method' => 'POST',
        'url' => '/projek_plbs/api/index.php/api/auth/register',
        'requires_auth' => false,
        'required_fields' => ['username', 'password', 'email', 'nim', 'nama_lengkap', 'prodi_id']
    ],
    [
        'name' => 'Get Program Studi',
        'method' => 'GET',
        'url' => '/projek_plbs/api/index.php/api/program-studi',
        'requires_auth' => false,
        'required_fields' => []
    ],
    [
        'name' => 'Logout',
        'method' => 'POST',
        'url' => '/projek_plbs/api/index.php/api/auth/logout',
        'requires_auth' => true,
        'required_fields' => []
    ],
    [
        'name' => 'Dashboard Mahasiswa',
        'method' => 'GET',
        'url' => '/projek_plbs/api/index.php/api/mahasiswa/dashboard',
        'requires_auth' => true,
        'required_fields' => []
    ]
];

// Test each endpoint
$results = [];
foreach ($endpoints as $endpoint) {
    $ch = curl_init('http://localhost' . $endpoint['url']);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_CUSTOMREQUEST, $endpoint['method']);
    curl_setopt($ch, CURLOPT_TIMEOUT, 5);
    
    if ($endpoint['method'] === 'POST' && !$endpoint['requires_auth']) {
        curl_setopt($ch, CURLOPT_HTTPHEADER, ['Content-Type: application/json']);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode([]));
    }
    
    $response = curl_exec($ch);
    $http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);
    
    $response_data = json_decode($response, true);
    
    // Determine status
    $status = 'OK';
    if ($http_code === 404 || (isset($response_data['status']) && $response_data['status'] === 'error' && isset($response_data['error_code']) && $response_data['error_code'] === 'NOT_FOUND')) {
        $status = 'NOT_FOUND';
    } elseif ($http_code >= 500) {
        $status = 'ERROR';
    } elseif ($http_code === 400) {
        $status = 'BAD_REQUEST';
    } elseif ($http_code === 401) {
        $status = 'UNAUTHORIZED';
    }
    
    $results[] = array_merge($endpoint, [
        'status' => $status,
        'http_code' => $http_code,
        'response_status' => $response_data['status'] ?? null,
        'response_message' => $response_data['message'] ?? null
    ]);
}

echo json_encode([
    'timestamp' => date('c'),
    'server_info' => [
        'php_version' => phpversion(),
        'server' => $_SERVER['SERVER_SOFTWARE'] ?? 'Unknown'
    ],
    'endpoints' => $results
], JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES);
?>
