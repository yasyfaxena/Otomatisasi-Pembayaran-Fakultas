<?php
/**
 * API Endpoint untuk Notifikasi Mahasiswa
 * GET /api/mahasiswa/notifikasi
 */

header('Content-Type: application/json');
require_once __DIR__ . '/config/database.php';

session_start();

if (!isset($_SESSION['user_id'])) {
    http_response_code(401);
    echo json_encode(['status' => 'error', 'message' => 'Unauthorized']);
    exit;
}

try {
    $database = new Database();
    $conn = $database->connect();
    $user_id = $_SESSION['user_id'];
    
    // Get mahasiswa_id
    $stmt = $conn->prepare("SELECT mahasiswa_id FROM mahasiswa WHERE user_id = :user_id");
    $stmt->execute(['user_id' => $user_id]);
    $mahasiswa = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$mahasiswa) {
        http_response_code(404);
        echo json_encode(['status' => 'error', 'message' => 'Mahasiswa not found']);
        exit;
    }
    
    $mahasiswa_id = $mahasiswa['mahasiswa_id'];
    
    // Get notifications
    $query = "SELECT * FROM notifikasi 
              WHERE mahasiswa_id = :mahasiswa_id 
              ORDER BY created_at DESC 
              LIMIT 10";
    
    $stmt = $conn->prepare($query);
    $stmt->execute(['mahasiswa_id' => $mahasiswa_id]);
    $notifikasi = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    // Count unread
    $stmt = $conn->prepare("SELECT COUNT(*) as unread FROM notifikasi WHERE mahasiswa_id = :mahasiswa_id AND status = 'belum_dibaca'");
    $stmt->execute(['mahasiswa_id' => $mahasiswa_id]);
    $unread = $stmt->fetch(PDO::FETCH_ASSOC);
    
    echo json_encode([
        'status' => 'success',
        'data' => [
            'notifikasi' => $notifikasi,
            'unread_count' => (int)$unread['unread']
        ]
    ]);
    
} catch (Exception $e) {
    http_response_code(500);
    echo json_encode([
        'status' => 'error',
        'message' => $e->getMessage()
    ]);
}
