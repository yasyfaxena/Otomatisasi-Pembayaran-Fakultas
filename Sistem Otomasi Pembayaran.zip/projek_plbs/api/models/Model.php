<?php
/**
 * Base Model Class
 */

class Model {
    protected $pdo;
    protected $table;

    public function __construct() {
        $this->pdo = Database::getInstance();
    }

    /**
     * Find by ID
     */
    protected function findById($id) {
        $query = "SELECT * FROM {$this->table} WHERE id = :id LIMIT 1";
        $stmt = $this->pdo->prepare($query);
        $stmt->execute(['id' => $id]);
        return $stmt->fetch();
    }

    /**
     * Find all with pagination
     */
    protected function findAll($limit = 10, $offset = 0, $where = [], $order = 'id DESC') {
        $query = "SELECT * FROM {$this->table}";

        if (!empty($where)) {
            $conditions = [];
            foreach ($where as $key => $value) {
                $conditions[] = "$key = :$key";
            }
            $query .= " WHERE " . implode(' AND ', $conditions);
        }

        $query .= " ORDER BY $order LIMIT $limit OFFSET $offset";

        $stmt = $this->pdo->prepare($query);
        
        if (!empty($where)) {
            foreach ($where as $key => $value) {
                $stmt->bindValue(":$key", $value);
            }
        }

        $stmt->execute();
        return $stmt->fetchAll();
    }

    /**
     * Create new record
     */
    protected function create($data) {
        $columns = array_keys($data);
        $placeholders = array_map(function($col) { return ":$col"; }, $columns);

        $query = "INSERT INTO {$this->table} (" . implode(',', $columns) . ") 
                  VALUES (" . implode(',', $placeholders) . ")";

        $stmt = $this->pdo->prepare($query);
        
        foreach ($data as $key => $value) {
            $stmt->bindValue(":$key", $value);
        }

        if ($stmt->execute()) {
            return $this->pdo->lastInsertId();
        }
        return false;
    }

    /**
     * Update record
     */
    protected function update($id, $data) {
        $set_clauses = [];
        foreach ($data as $key => $value) {
            $set_clauses[] = "$key = :$key";
        }

        $query = "UPDATE {$this->table} SET " . implode(', ', $set_clauses) . " WHERE id = :id";

        $stmt = $this->pdo->prepare($query);
        $stmt->bindValue(':id', $id);

        foreach ($data as $key => $value) {
            $stmt->bindValue(":$key", $value);
        }

        return $stmt->execute();
    }

    /**
     * Delete record
     */
    protected function delete($id) {
        $query = "DELETE FROM {$this->table} WHERE id = :id";
        $stmt = $this->pdo->prepare($query);
        return $stmt->execute(['id' => $id]);
    }

    /**
     * Execute custom query
     */
    protected function query($sql, $params = []) {
        $stmt = $this->pdo->prepare($sql);
        $stmt->execute($params);
        return $stmt;
    }

    /**
     * Count records
     */
    protected function count($where = []) {
        $query = "SELECT COUNT(*) as total FROM {$this->table}";

        if (!empty($where)) {
            $conditions = [];
            foreach ($where as $key => $value) {
                $conditions[] = "$key = :$key";
            }
            $query .= " WHERE " . implode(' AND ', $conditions);
        }

        $stmt = $this->pdo->prepare($query);
        
        if (!empty($where)) {
            foreach ($where as $key => $value) {
                $stmt->bindValue(":$key", $value);
            }
        }

        $stmt->execute();
        $result = $stmt->fetch();
        return $result['total'] ?? 0;
    }
}

