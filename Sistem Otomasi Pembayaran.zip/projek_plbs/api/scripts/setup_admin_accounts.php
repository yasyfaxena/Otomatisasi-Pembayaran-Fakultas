<?php
/**
 * ADMIN ACCOUNT SETUP SCRIPT
 * 
 * Script untuk membuat akun Admin Universitas dan Admin Fakultas dengan password yang sudah di-hash
 * 
 * REQUIREMENTS:
 * - Database harus sudah dibuat dengan schema yang ada
 * - Koneksi PDO ke database harus valid
 * 
 * USAGE:
 * Dari CLI:
 *   php api/scripts/setup_admin_accounts.php
 * 
 * Script ini akan:
 * 1. Meminta input username, password, email untuk masing-masing admin
 * 2. Hash password menggunakan password_hash() dengan BCRYPT
 * 3. Insert record ke database dengan is_active = 1
 * 4. Verifikasi insert berhasil
 * 
 * SECURITY:
 * ✅ Password di-hash dengan BCRYPT (PHP standard)
 * ✅ Password tidak disimpan plain text
 * ✅ Query menggunakan prepared statement (prevent SQL injection)
 * ✅ Session check di login (verifikasi dengan password_verify)
 */

// Cek apakah running dari CLI
if (php_sapi_name() !== 'cli') {
    die("❌ This script harus dijalankan dari CLI (command line), bukan dari browser.\n");
}

echo "\n";
echo "╔════════════════════════════════════════════════════════════╗\n";
echo "║      ADMIN ACCOUNT SETUP SCRIPT                            ║\n";
echo "║      Membuat akun Admin Universitas & Admin Fakultas       ║\n";
echo "╚════════════════════════════════════════════════════════════╝\n";
echo "\n";

// Load database configuration
$config_file = __DIR__ . '/../config/database.php';
if (!file_exists($config_file)) {
    die("❌ Error: Database config file tidak ditemukan di: $config_file\n");
}

require_once $config_file;

// Cek koneksi PDO
try {
    if (!isset($pdo) || !($pdo instanceof PDO)) {
        die("❌ Error: PDO connection tidak tersedia\n");
    }
    echo "✅ Database connected successfully\n\n";
} catch (Exception $e) {
    die("❌ Database connection error: " . $e->getMessage() . "\n");
}

// ============================================
// STEP 1: Create Admin Universitas
// ============================================

echo "┌─────────────────────────────────────────────────────────┐\n";
echo "│ STEP 1: ADMIN UNIVERSITAS                               │\n";
echo "└─────────────────────────────────────────────────────────┘\n";
echo "\n";

// Input data Admin Universitas
echo "Masukkan data Admin Universitas:\n";
echo "Username [admin_univ]: ";
$admin_univ_username = trim(fgets(STDIN)) ?: 'admin_univ';

echo "Password [admin123]: ";
// Hide password input
system('stty -echo');
$admin_univ_password = trim(fgets(STDIN)) ?: 'admin123';
system('stty echo');
echo "\n";

echo "Email [admin.universitas@kampus.ac.id]: ";
$admin_univ_email = trim(fgets(STDIN)) ?: 'admin.universitas@kampus.ac.id';

echo "ID/NIM [ADMUNIV001]: ";
$admin_univ_nim = trim(fgets(STDIN)) ?: 'ADMUNIV001';

echo "Nama Lengkap [Admin Universitas]: ";
$admin_univ_nama = trim(fgets(STDIN)) ?: 'Admin Universitas';

// Hash password
$admin_univ_password_hash = password_hash($admin_univ_password, PASSWORD_DEFAULT);

// Insert Admin Universitas
try {
    $query = "INSERT INTO users (
        username, 
        password_hash, 
        email, 
        role, 
        nim_or_id, 
        nama_lengkap, 
        fakultas_id, 
        is_active,
        created_at,
        updated_at
    ) VALUES (
        :username,
        :password_hash,
        :email,
        :role,
        :nim_or_id,
        :nama_lengkap,
        :fakultas_id,
        :is_active,
        :created_at,
        :updated_at
    )";

    $stmt = $pdo->prepare($query);
    $stmt->execute([
        'username' => $admin_univ_username,
        'password_hash' => $admin_univ_password_hash,
        'email' => $admin_univ_email,
        'role' => 'admin_universitas',
        'nim_or_id' => $admin_univ_nim,
        'nama_lengkap' => $admin_univ_nama,
        'fakultas_id' => null,  // NULL untuk admin universitas
        'is_active' => 1,
        'created_at' => date('Y-m-d H:i:s'),
        'updated_at' => date('Y-m-d H:i:s')
    ]);

    $admin_univ_id = $pdo->lastInsertId();
    echo "✅ Admin Universitas berhasil dibuat!\n";
    echo "   ID: $admin_univ_id\n";
    echo "   Username: $admin_univ_username\n";
    echo "   Email: $admin_univ_email\n\n";

} catch (Exception $e) {
    echo "❌ Error creating Admin Universitas: " . $e->getMessage() . "\n";
    exit(1);
}

// ============================================
// STEP 2: Create Admin Fakultas
// ============================================

echo "┌─────────────────────────────────────────────────────────┐\n";
echo "│ STEP 2: ADMIN FAKULTAS                                  │\n";
echo "└─────────────────────────────────────────────────────────┘\n";
echo "\n";

// Get list of fakultas
try {
    $fak_stmt = $pdo->query("SELECT fakultas_id, nama_fakultas FROM fakultas ORDER BY nama_fakultas");
    $fakultas_list = $fak_stmt->fetchAll(PDO::FETCH_ASSOC);

    if (empty($fakultas_list)) {
        echo "⚠️  Tidak ada data Fakultas di database\n";
        echo "   Silakan setup Fakultas terlebih dahulu\n\n";
    } else {
        echo "Daftar Fakultas yang tersedia:\n";
        foreach ($fakultas_list as $fak) {
            echo "  {$fak['fakultas_id']}. {$fak['nama_fakultas']}\n";
        }
        echo "\n";

        // Input data Admin Fakultas
        echo "Masukkan data Admin Fakultas:\n";
        echo "Username [admin_fakultas_ti]: ";
        $admin_fak_username = trim(fgets(STDIN)) ?: 'admin_fakultas_ti';

        echo "Password [admin123]: ";
        system('stty -echo');
        $admin_fak_password = trim(fgets(STDIN)) ?: 'admin123';
        system('stty echo');
        echo "\n";

        echo "Email [admin.ti@kampus.ac.id]: ";
        $admin_fak_email = trim(fgets(STDIN)) ?: 'admin.ti@kampus.ac.id';

        echo "ID/NIM [ADMTI001]: ";
        $admin_fak_nim = trim(fgets(STDIN)) ?: 'ADMTI001';

        echo "Nama Lengkap [Admin Fakultas TI]: ";
        $admin_fak_nama = trim(fgets(STDIN)) ?: 'Admin Fakultas Teknik Informatika';

        echo "Fakultas ID [{$fakultas_list[0]['fakultas_id']}]: ";
        $admin_fak_fakultas_id = (int)(trim(fgets(STDIN)) ?: $fakultas_list[0]['fakultas_id']);

        // Hash password
        $admin_fak_password_hash = password_hash($admin_fak_password, PASSWORD_DEFAULT);

        // Insert Admin Fakultas
        try {
            $query = "INSERT INTO users (
                username, 
                password_hash, 
                email, 
                role, 
                nim_or_id, 
                nama_lengkap, 
                fakultas_id, 
                is_active,
                created_at,
                updated_at
            ) VALUES (
                :username,
                :password_hash,
                :email,
                :role,
                :nim_or_id,
                :nama_lengkap,
                :fakultas_id,
                :is_active,
                :created_at,
                :updated_at
            )";

            $stmt = $pdo->prepare($query);
            $stmt->execute([
                'username' => $admin_fak_username,
                'password_hash' => $admin_fak_password_hash,
                'email' => $admin_fak_email,
                'role' => 'admin_fakultas',
                'nim_or_id' => $admin_fak_nim,
                'nama_lengkap' => $admin_fak_nama,
                'fakultas_id' => $admin_fak_fakultas_id,
                'is_active' => 1,
                'created_at' => date('Y-m-d H:i:s'),
                'updated_at' => date('Y-m-d H:i:s')
            ]);

            $admin_fak_id = $pdo->lastInsertId();
            echo "✅ Admin Fakultas berhasil dibuat!\n";
            echo "   ID: $admin_fak_id\n";
            echo "   Username: $admin_fak_username\n";
            echo "   Email: $admin_fak_email\n";
            echo "   Fakultas ID: $admin_fak_fakultas_id\n\n";

        } catch (Exception $e) {
            echo "❌ Error creating Admin Fakultas: " . $e->getMessage() . "\n";
            exit(1);
        }
    }
} catch (Exception $e) {
    echo "⚠️  Warning: Tidak bisa load daftar fakultas: " . $e->getMessage() . "\n\n";
}

// ============================================
// VERIFICATION
// ============================================

echo "╔════════════════════════════════════════════════════════════╗\n";
echo "║      SETUP COMPLETE                                       ║\n";
echo "╚════════════════════════════════════════════════════════════╝\n";
echo "\n";

echo "✅ Admin accounts berhasil dibuat!\n";
echo "\n";

echo "📋 Summary:\n";
echo "├─ Admin Universitas\n";
echo "│  ├─ Username: $admin_univ_username\n";
echo "│  ├─ Email: $admin_univ_email\n";
echo "│  └─ Password: ••••••••••\n";

if (!empty($admin_fak_id)) {
    echo "├─ Admin Fakultas\n";
    echo "│  ├─ Username: $admin_fak_username\n";
    echo "│  ├─ Email: $admin_fak_email\n";
    echo "│  └─ Password: ••••••••••\n";
}

echo "\n";
echo "🔐 Security Notes:\n";
echo "├─ Password di-hash dengan BCRYPT (PASSWORD_DEFAULT)\n";
echo "├─ Password tidak disimpan plain text di database\n";
echo "├─ Login akan menggunakan password_verify() untuk validasi\n";
echo "└─ Hash akan berbeda untuk password yang sama (salt random)\n";
echo "\n";

echo "🚀 Next steps:\n";
echo "├─ Login dengan username & password yang sudah dibuat\n";
echo "├─ Akses dashboard masing-masing admin\n";
echo "└─ Setup data fakultas, prodi, tarif, dsb\n";
echo "\n";

echo "✅ Setup selesai!\n\n";
