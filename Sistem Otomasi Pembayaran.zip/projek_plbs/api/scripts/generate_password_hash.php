<?php
/**
 * PASSWORD HASH GENERATOR UTILITY
 * 
 * Script ini digunakan untuk generate password hash yang aman menggunakan PHP password_hash()
 * Password hash hasil script ini siap untuk disimpan langsung ke database
 * 
 * USAGE:
 * 1. Jalankan dari terminal/command line:
 *    php api/scripts/generate_password_hash.php "password_anda"
 * 
 * 2. Atau akses via browser (tidak recommended untuk production):
 *    http://localhost:8000/api/scripts/generate_password_hash.php?password=admin123
 * 
 * OUTPUT:
 * Password hash (gunakan untuk INSERT ke database column password_hash)
 * 
 * SECURITY NOTES:
 * - password_hash() menggunakan BCRYPT dengan cost=10 (default PASSWORD_DEFAULT)
 * - Hash akan selalu BERBEDA meski password sama (salt otomatis random)
 * - Keamanan: tidak perlu simpan password plaintext
 */

// Only allow CLI and direct PHP execution
// Prevent accidental access via web request
if (php_sapi_name() !== 'cli' && empty($_GET['password'])) {
    die("This script should be run from CLI. Usage: php generate_password_hash.php PASSWORD\n");
}

// Get password from CLI argument or GET parameter
$password = null;

if (php_sapi_name() === 'cli') {
    // From command line
    if ($argc < 2) {
        echo "=== PASSWORD HASH GENERATOR ===\n";
        echo "Usage: php generate_password_hash.php \"your_password\"\n";
        echo "Example: php generate_password_hash.php \"admin123\"\n";
        echo "\n";
        echo "This will output a secure password hash suitable for database storage.\n";
        exit(1);
    }
    $password = $argv[1];
} else {
    // From GET parameter (development only)
    $password = $_GET['password'] ?? null;
    if (empty($password)) {
        ?>
        <!DOCTYPE html>
        <html>
        <head>
            <title>Password Hash Generator</title>
            <style>
                body { font-family: Arial, sans-serif; max-width: 600px; margin: 50px auto; }
                .container { background: #f5f5f5; padding: 20px; border-radius: 8px; }
                input, button { padding: 10px; margin: 5px 0; width: 100%; }
                .output { 
                    background: #fff; 
                    padding: 15px; 
                    margin: 15px 0; 
                    border: 1px solid #ddd; 
                    border-radius: 4px;
                    word-break: break-all;
                    font-family: monospace;
                }
                .warning { color: #c33; font-weight: bold; }
            </style>
        </head>
        <body>
            <div class="container">
                <h1>🔐 Password Hash Generator</h1>
                <p class="warning">⚠️ WARNING: Hanya gunakan untuk development/testing. Jangan di-expose di production!</p>
                
                <form method="GET">
                    <label>Masukkan Password:</label>
                    <input type="password" name="password" placeholder="Contoh: admin123" required>
                    <button type="submit">Generate Hash</button>
                </form>
            </div>
        </body>
        </html>
        <?php
        exit;
    }
}

// Generate hash menggunakan PASSWORD_DEFAULT (BCRYPT)
$password_hash = password_hash($password, PASSWORD_DEFAULT);

// Output result
if (php_sapi_name() === 'cli') {
    // CLI Output - formatnya text
    echo "=== PASSWORD HASH GENERATED ===\n";
    echo "Password: " . str_repeat('*', strlen($password)) . "\n";
    echo "Hash: " . $password_hash . "\n";
    echo "\n";
    echo "Gunakan hash di atas untuk INSERT ke database:\n";
    echo "INSERT INTO users (username, password_hash, ...) \n";
    echo "VALUES ('admin', '" . $password_hash . "', ...);\n";
    echo "\n";
    echo "Verifikasi password dengan: password_verify('" . $password . "', '" . $password_hash . "');\n";
} else {
    // Web output - display HTML
    ?>
    <!DOCTYPE html>
    <html>
    <head>
        <title>Password Hash Generator</title>
        <style>
            body { font-family: Arial, sans-serif; max-width: 600px; margin: 50px auto; }
            .container { background: #f5f5f5; padding: 20px; border-radius: 8px; }
            input, button { padding: 10px; margin: 5px 0; width: 100%; }
            .output { 
                background: #fff; 
                padding: 15px; 
                margin: 15px 0; 
                border: 1px solid #2d5a2d; 
                border-radius: 4px;
                word-break: break-all;
                font-family: monospace;
                font-size: 12px;
            }
            .warning { color: #c33; font-weight: bold; }
            .success { color: #2d5a2d; font-weight: bold; }
            button { background: #2d5a2d; color: white; cursor: pointer; }
            button:hover { background: #1a3a1a; }
            .copy-btn { 
                background: #666; 
                padding: 8px; 
                cursor: pointer; 
                margin: 5px 0;
            }
        </style>
    </head>
    <body>
        <div class="container">
            <h1>🔐 Password Hash Generator</h1>
            <p class="warning">⚠️ WARNING: Hanya gunakan untuk development/testing. Jangan di-expose di production!</p>
            
            <form method="GET">
                <label>Masukkan Password:</label>
                <input type="password" name="password" placeholder="Contoh: admin123" required>
                <button type="submit">Generate Hash</button>
            </form>

            <h2 class="success">✅ Hash Generated</h2>
            
            <h3>Password:</h3>
            <div class="output">
                <?php echo str_repeat('*', strlen($password)); ?>
            </div>

            <h3>Password Hash (untuk database):</h3>
            <div class="output" id="hashOutput">
                <?php echo htmlspecialchars($password_hash); ?>
            </div>
            <button class="copy-btn" onclick="copyToClipboard()">📋 Copy Hash</button>

            <h3>SQL Query Sample:</h3>
            <div class="output">
                INSERT INTO users (username, password_hash, email, role, nim_or_id, nama_lengkap, is_active)<br>
                VALUES ('admin_univ', '<?php echo htmlspecialchars($password_hash); ?>', 'admin@kampus.ac.id', 'admin_universitas', 'ADMUNIV001', 'Admin Universitas', 1);
            </div>

            <h3>Verifikasi:</h3>
            <p>Gunakan password_verify() untuk verifikasi saat login:</p>
            <div class="output">
                password_verify('<?php echo htmlspecialchars($password); ?>', '<?php echo htmlspecialchars($password_hash); ?>');<br>
                // Returns: true
            </div>

            <h3>Kembali ke Input</h3>
            <form method="GET">
                <button type="submit">Generate Password Lain</button>
            </form>
        </div>

        <script>
        function copyToClipboard() {
            const hashOutput = document.getElementById('hashOutput');
            const text = hashOutput.textContent;
            
            navigator.clipboard.writeText(text).then(() => {
                alert('Hash berhasil dicopy!');
            }).catch(() => {
                alert('Gagal copy, silakan copy manual');
            });
        }
        </script>
    </body>
    </html>
    <?php
}
