<?php
/**
 * AUTHENTICATION VERIFICATION SCRIPT
 * 
 * Script untuk memverifikasi sistem autentikasi bekerja dengan benar
 * Melakukan test pada:
 * 1. Password hashing dengan password_hash()
 * 2. Password verification dengan password_verify()
 * 3. Database connection
 * 4. Admin account dalam database
 * 5. Login logic di AuthController
 * 
 * USAGE:
 * php api/scripts/verify_authentication.php
 */

echo "\n";
echo "╔════════════════════════════════════════════════════════════╗\n";
echo "║      AUTHENTICATION VERIFICATION SCRIPT                    ║\n";
echo "║      Verifikasi sistem login Admin dengan standar keamanan ║\n";
echo "╚════════════════════════════════════════════════════════════╝\n";
echo "\n";

// Counter untuk results
$tests_passed = 0;
$tests_failed = 0;

// ============================================
// TEST 1: PHP password_hash() & password_verify()
// ============================================

echo "┌─────────────────────────────────────────────────────────┐\n";
echo "│ TEST 1: PHP Password Hashing Functions                  │\n";
echo "└─────────────────────────────────────────────────────────┘\n";

$test_password = 'admin123';
$test_hash = password_hash($test_password, PASSWORD_DEFAULT);

echo "\n1.1 Testing password_hash()...\n";
if (!empty($test_hash) && strlen($test_hash) == 60 && strpos($test_hash, '$2y$') === 0) {
    echo "    ✅ PASS: password_hash() works correctly\n";
    echo "       - Hash: " . substr($test_hash, 0, 30) . "...\n";
    echo "       - Length: " . strlen($test_hash) . " characters\n";
    echo "       - Algorithm: BCRYPT (\$2y$)\n";
    $tests_passed++;
} else {
    echo "    ❌ FAIL: password_hash() output invalid\n";
    $tests_failed++;
}

echo "\n1.2 Testing password_verify()...\n";
$verify_correct = password_verify($test_password, $test_hash);
$verify_wrong = password_verify('wrongpassword', $test_hash);

if ($verify_correct === true && $verify_wrong === false) {
    echo "    ✅ PASS: password_verify() works correctly\n";
    echo "       - Correct password: " . ($verify_correct ? 'TRUE' : 'FALSE') . "\n";
    echo "       - Wrong password: " . ($verify_wrong ? 'TRUE' : 'FALSE') . "\n";
    $tests_passed++;
} else {
    echo "    ❌ FAIL: password_verify() result incorrect\n";
    echo "       - Expected: correct=true, wrong=false\n";
    echo "       - Got: correct=$verify_correct, wrong=$verify_wrong\n";
    $tests_failed++;
}

// ============================================
// TEST 2: Database Connection
// ============================================

echo "\n┌─────────────────────────────────────────────────────────┐\n";
echo "│ TEST 2: Database Connection                             │\n";
echo "└─────────────────────────────────────────────────────────┘\n";

$config_file = __DIR__ . '/../config/database.php';

echo "\n2.1 Checking database config file...\n";
if (file_exists($config_file)) {
    echo "    ✅ PASS: Config file exists at $config_file\n";
    $tests_passed++;
} else {
    echo "    ❌ FAIL: Config file not found at $config_file\n";
    $tests_failed++;
    echo "    (Cannot continue without database connection)\n";
    exit(1);
}

echo "\n2.2 Loading database connection...\n";
try {
    require_once $config_file;
    if (isset($pdo) && $pdo instanceof PDO) {
        echo "    ✅ PASS: PDO connection established\n";
        $tests_passed++;
    } else {
        echo "    ❌ FAIL: PDO not available\n";
        $tests_failed++;
        exit(1);
    }
} catch (Exception $e) {
    echo "    ❌ FAIL: Database connection error: " . $e->getMessage() . "\n";
    $tests_failed++;
    exit(1);
}

// ============================================
// TEST 3: Users Table Structure
// ============================================

echo "\n┌─────────────────────────────────────────────────────────┐\n";
echo "│ TEST 3: Users Table Structure                           │\n";
echo "└─────────────────────────────────────────────────────────┘\n";

echo "\n3.1 Checking users table exists...\n";
try {
    $check = $pdo->query("SHOW TABLES LIKE 'users'");
    if ($check->rowCount() > 0) {
        echo "    ✅ PASS: users table exists\n";
        $tests_passed++;
    } else {
        echo "    ❌ FAIL: users table not found\n";
        $tests_failed++;
    }
} catch (Exception $e) {
    echo "    ❌ FAIL: Error checking table: " . $e->getMessage() . "\n";
    $tests_failed++;
}

echo "\n3.2 Checking password_hash column...\n";
try {
    $columns = $pdo->query("DESCRIBE users");
    $column_names = [];
    while ($col = $columns->fetch(PDO::FETCH_ASSOC)) {
        $column_names[] = $col['Field'];
    }
    
    if (in_array('password_hash', $column_names)) {
        echo "    ✅ PASS: password_hash column exists\n";
        echo "       Columns in users table:\n";
        foreach (array_chunk($column_names, 3) as $chunk) {
            echo "       - " . implode(", ", $chunk) . "\n";
        }
        $tests_passed++;
    } else {
        echo "    ❌ FAIL: password_hash column not found\n";
        echo "       Columns: " . implode(", ", $column_names) . "\n";
        $tests_failed++;
    }
} catch (Exception $e) {
    echo "    ❌ FAIL: Error checking columns: " . $e->getMessage() . "\n";
    $tests_failed++;
}

// ============================================
// TEST 4: Admin Accounts in Database
// ============================================

echo "\n┌─────────────────────────────────────────────────────────┐\n";
echo "│ TEST 4: Admin Accounts in Database                      │\n";
echo "└─────────────────────────────────────────────────────────┘\n";

echo "\n4.1 Checking for Admin Universitas...\n";
try {
    $stmt = $pdo->prepare("SELECT user_id, username, email, role, is_active FROM users WHERE role = 'admin_universitas'");
    $stmt->execute();
    $admin_univ = $stmt->fetch();
    
    if ($admin_univ) {
        echo "    ✅ PASS: Admin Universitas found\n";
        echo "       - Username: " . $admin_univ['username'] . "\n";
        echo "       - Email: " . $admin_univ['email'] . "\n";
        echo "       - Active: " . ($admin_univ['is_active'] ? 'YES' : 'NO') . "\n";
        $tests_passed++;
    } else {
        echo "    ⚠️  WARNING: No Admin Universitas found in database\n";
        echo "       Run: php api/scripts/setup_admin_accounts.php\n";
    }
} catch (Exception $e) {
    echo "    ❌ FAIL: Error querying admin_universitas: " . $e->getMessage() . "\n";
    $tests_failed++;
}

echo "\n4.2 Checking for Admin Fakultas...\n";
try {
    $stmt = $pdo->prepare("SELECT user_id, username, email, role, is_active FROM users WHERE role = 'admin_fakultas'");
    $stmt->execute();
    $admin_fak = $stmt->fetch();
    
    if ($admin_fak) {
        echo "    ✅ PASS: Admin Fakultas found\n";
        echo "       - Username: " . $admin_fak['username'] . "\n";
        echo "       - Email: " . $admin_fak['email'] . "\n";
        echo "       - Active: " . ($admin_fak['is_active'] ? 'YES' : 'NO') . "\n";
        $tests_passed++;
    } else {
        echo "    ⚠️  WARNING: No Admin Fakultas found in database\n";
        echo "       Run: php api/scripts/setup_admin_accounts.php\n";
    }
} catch (Exception $e) {
    echo "    ❌ FAIL: Error querying admin_fakultas: " . $e->getMessage() . "\n";
    $tests_failed++;
}

echo "\n4.3 Checking password_hash values...\n";
try {
    $stmt = $pdo->prepare("SELECT user_id, username, password_hash FROM users WHERE role IN ('admin_universitas', 'admin_fakultas') LIMIT 1");
    $stmt->execute();
    $user = $stmt->fetch();
    
    if ($user) {
        $hash = $user['password_hash'];
        if (strlen($hash) == 60 && strpos($hash, '$2y$') === 0) {
            echo "    ✅ PASS: Password hash is properly stored\n";
            echo "       - Username: " . $user['username'] . "\n";
            echo "       - Hash preview: " . substr($hash, 0, 30) . "...\n";
            echo "       - Hash length: " . strlen($hash) . " characters\n";
            echo "       - Algorithm: BCRYPT (\$2y$)\n";
            $tests_passed++;
        } else {
            echo "    ❌ FAIL: Password hash format invalid!\n";
            echo "       - Expected: BCRYPT hash (60 chars, \$2y\$...)\n";
            echo "       - Got: " . substr($hash, 0, 20) . "... (length: " . strlen($hash) . ")\n";
            echo "       - This password may be stored as plain text!\n";
            $tests_failed++;
        }
    } else {
        echo "    ⚠️  WARNING: No admin accounts to check\n";
    }
} catch (Exception $e) {
    echo "    ❌ FAIL: Error checking password hash: " . $e->getMessage() . "\n";
    $tests_failed++;
}

// ============================================
// TEST 5: Login Logic Simulation
// ============================================

echo "\n┌─────────────────────────────────────────────────────────┐\n";
echo "│ TEST 5: Login Logic Simulation                          │\n";
echo "└─────────────────────────────────────────────────────────┘\n";

echo "\n5.1 Simulating login with correct password...\n";
try {
    // Buat test user dengan hash yang diketahui
    $test_user_pass = 'testpassword123';
    $test_user_hash = password_hash($test_user_pass, PASSWORD_DEFAULT);
    
    // Simulasi query login
    // Query hanya ngambil user, jangan bandingkan password di SQL!
    // (Simulasi database query):
    // SELECT * FROM users WHERE username = ? AND is_active = 1
    
    // Kemudian verify password dengan password_verify()
    if (password_verify($test_user_pass, $test_user_hash)) {
        echo "    ✅ PASS: Login logic correct (correct password verified)\n";
        $tests_passed++;
    } else {
        echo "    ❌ FAIL: Login logic failed\n";
        $tests_failed++;
    }
} catch (Exception $e) {
    echo "    ❌ FAIL: Error in login simulation: " . $e->getMessage() . "\n";
    $tests_failed++;
}

echo "\n5.2 Simulating login with wrong password...\n";
try {
    $test_user_pass = 'testpassword123';
    $test_user_hash = password_hash($test_user_pass, PASSWORD_DEFAULT);
    
    // Coba dengan password salah
    if (!password_verify('wrongpassword', $test_user_hash)) {
        echo "    ✅ PASS: Login logic correct (wrong password rejected)\n";
        $tests_passed++;
    } else {
        echo "    ❌ FAIL: Login logic failed - wrong password was accepted!\n";
        $tests_failed++;
    }
} catch (Exception $e) {
    echo "    ❌ FAIL: Error in login simulation: " . $e->getMessage() . "\n";
    $tests_failed++;
}

// ============================================
// TEST 6: AuthController File
// ============================================

echo "\n┌─────────────────────────────────────────────────────────┐\n";
echo "│ TEST 6: AuthController Implementation                   │\n";
echo "└─────────────────────────────────────────────────────────┘\n";

$auth_controller_file = __DIR__ . '/../controllers/AuthController.php';

echo "\n6.1 Checking AuthController file...\n";
if (file_exists($auth_controller_file)) {
    echo "    ✅ PASS: AuthController.php exists\n";
    $tests_passed++;
    
    // Check for password_verify usage
    echo "\n6.2 Checking for password_verify() usage...\n";
    $auth_content = file_get_contents($auth_controller_file);
    
    if (strpos($auth_content, 'password_verify') !== false) {
        echo "    ✅ PASS: password_verify() is used in login\n";
        $tests_passed++;
    } else {
        echo "    ❌ FAIL: password_verify() not found in AuthController\n";
        $tests_failed++;
    }
    
    // Check for password_hash usage
    echo "\n6.3 Checking for password_hash() usage...\n";
    if (strpos($auth_content, 'password_hash') !== false) {
        echo "    ✅ PASS: password_hash() is used for password creation\n";
        $tests_passed++;
    } else {
        echo "    ❌ FAIL: password_hash() not found in AuthController\n";
        $tests_failed++;
    }
    
    // Check for prepared statements
    echo "\n6.4 Checking for prepared statements...\n";
    if (preg_match('/prepare\s*\(/', $auth_content) && preg_match('/execute\s*\(/', $auth_content)) {
        echo "    ✅ PASS: Prepared statements are used (prevent SQL injection)\n";
        $tests_passed++;
    } else {
        echo "    ❌ FAIL: Prepared statements not found\n";
        $tests_failed++;
    }
} else {
    echo "    ❌ FAIL: AuthController.php not found\n";
    $tests_failed++;
}

// ============================================
// FINAL RESULTS
// ============================================

echo "\n╔════════════════════════════════════════════════════════════╗\n";
echo "║      VERIFICATION RESULTS                                 ║\n";
echo "╚════════════════════════════════════════════════════════════╝\n";
echo "\n";

$total_tests = $tests_passed + $tests_failed;
$pass_rate = $total_tests > 0 ? round(($tests_passed / $total_tests) * 100) : 0;

echo "Total Tests: $total_tests\n";
echo "Passed: ✅ $tests_passed\n";
echo "Failed: ❌ $tests_failed\n";
echo "Pass Rate: $pass_rate%\n\n";

if ($tests_failed == 0) {
    echo "╔════════════════════════════════════════════════════════════╗\n";
    echo "║  ✅ ALL TESTS PASSED - SYSTEM AUTHENTICATION READY!       ║\n";
    echo "║                                                            ║\n";
    echo "║  Sistem login Admin sudah AMAN dan SESUAI standar:        ║\n";
    echo "║  ✅ Password di-hash dengan BCRYPT (password_hash)         ║\n";
    echo "║  ✅ Verifikasi dengan password_verify                     ║\n";
    echo "║  ✅ Query aman dari SQL injection (prepared statements)   ║\n";
    echo "║  ✅ Database schema correct (password_hash column)        ║\n";
    echo "║  ✅ Admin accounts sudah ada dengan hash yang benar       ║\n";
    echo "║                                                            ║\n";
    echo "║  READY FOR PRODUCTION DEPLOYMENT! 🚀                     ║\n";
    echo "╚════════════════════════════════════════════════════════════╝\n";
} else {
    echo "╔════════════════════════════════════════════════════════════╗\n";
    echo "║  ⚠️  SOME TESTS FAILED - PLEASE REVIEW                   ║\n";
    echo "║                                                            ║\n";
    echo "║  Actions:                                                  ║\n";
    echo "║  1. Review failed tests above                              ║\n";
    echo "║  2. Run setup script if needed:                            ║\n";
    echo "║     php api/scripts/setup_admin_accounts.php              ║\n";
    echo "║  3. Check database credentials in database.php            ║\n";
    echo "║  4. Verify password hashing with:                         ║\n";
    echo "║     php api/scripts/generate_password_hash.php            ║\n";
    echo "╚════════════════════════════════════════════════════════════╝\n";
}

echo "\n";
