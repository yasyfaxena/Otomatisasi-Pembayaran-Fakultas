<?php
/**
 * API Endpoint untuk Mark Notifikasi sebagai Dibaca
 * POST /api/mahasiswa/notifikasi/{id}/read
 */

header('Content-Type: application/json');
require_once __DIR__ . '/config/database.php';

session_start();

if (!isset($_SESSION['user_id'])) {
    http_response_code(401);
    echo json_encode(['status' => 'error', 'message' => 'Unauthorized']);
    exit;
}

try {
    $database = new Database();
    $conn = $database->connect();
    $user_id = $_SESSION['user_id'];
    
    // Get mahasiswa_id
    $stmt = $conn->prepare("SELECT mahasiswa_id FROM mahasiswa WHERE user_id = :user_id");
    $stmt->execute(['user_id' => $user_id]);
    $mahasiswa = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$mahasiswa) {
        http_response_code(404);
        echo json_encode(['status' => 'error', 'message' => 'Mahasiswa not found']);
        exit;
    }
    
    $mahasiswa_id = $mahasiswa['mahasiswa_id'];
    $notif_id = $_GET['id'] ?? null;
    
    if (!$notif_id) {
        http_response_code(400);
        echo json_encode(['status' => 'error', 'message' => 'Notification ID required']);
        exit;
    }
    
    // Update notification status
    $stmt = $conn->prepare("UPDATE notifikasi SET status = 'dibaca' WHERE id = :id AND mahasiswa_id = :mahasiswa_id");
    $stmt->execute(['id' => $notif_id, 'mahasiswa_id' => $mahasiswa_id]);
    
    echo json_encode([
        'status' => 'success',
        'message' => 'Notification marked as read'
    ]);
    
} catch (Exception $e) {
    http_response_code(500);
    echo json_encode([
        'status' => 'error',
        'message' => $e->getMessage()
    ]);
}
