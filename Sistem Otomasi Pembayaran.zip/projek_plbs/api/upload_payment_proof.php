<?php
/**
 * API: Upload Payment Proof / Bukti Pembayaran
 * 
 * WAJIB: Hanya menggunakan kolom yang benar-benar ada di database
 * - tagihan table: status_pembayaran (bukan status_tagihan)
 * - pembayaran table: bukti_pembayaran_filename, status_validasi
 * 
 * DILARANG: Menggunakan kolom fiktif atau asumsi struktur
 * 
 * Method: POST
 * Parameters:
 * - bukti_file (FILE): File bukti pembayaran (JPG, PNG, PDF)
 * - tagihan_id (INT): ID tagihan
 * - va_number (STRING): Nomor Virtual Account
 * - tanggal_transfer (DATE): Tanggal transfer pembayaran
 * 
 * Response:
 * {
 *   "status": "success|error",
 *   "message": "...",
 *   "pembayaran_id": 123  // if success
 * }
 */

header('Content-Type: application/json');
error_reporting(E_ALL);
ini_set('display_errors', 0);  // DILARANG menampilkan error mentah ke frontend
ini_set('log_errors', 1);

// Log all requests for debugging
error_log('UPLOAD PROOF: Request received - Method=' . $_SERVER['REQUEST_METHOD'] . ', Has session=' . (isset($_SESSION['user_id']) ? 'yes' : 'no'));

session_start();

try {
    // ========================================
    // STEP 1: VALIDATE SESSION & USER
    // ========================================
    if (!isset($_SESSION['user_id'])) {
        http_response_code(401);
        echo json_encode([
            'status' => 'error',
            'message' => 'Anda harus login terlebih dahulu'
        ]);
        exit;
    }

    $user_id = $_SESSION['user_id'];
    $mahasiswa_id = $_SESSION['mahasiswa_id'] ?? null;

    if (!$mahasiswa_id) {
        http_response_code(403);
        echo json_encode([
            'status' => 'error',
            'message' => 'Akses ditolak'
        ]);
        exit;
    }

    // ========================================
    // STEP 2: VALIDATE PARAMETERS
    // ========================================
    $tagihan_id = isset($_POST['tagihan_id']) ? intval($_POST['tagihan_id']) : null;
    $va_number = isset($_POST['va_number']) ? trim($_POST['va_number']) : null;
    $tanggal_transfer = isset($_POST['tanggal_transfer']) ? trim($_POST['tanggal_transfer']) : null;

    if (!$tagihan_id || !$va_number || !$tanggal_transfer) {
        http_response_code(400);
        echo json_encode([
            'status' => 'error',
            'message' => 'Parameter tidak lengkap'
        ]);
        exit;
    }

    // Validate tanggal_transfer format
    $transfer_date = DateTime::createFromFormat('Y-m-d', $tanggal_transfer);
    if (!$transfer_date) {
        http_response_code(400);
        echo json_encode([
            'status' => 'error',
            'message' => 'Format tanggal tidak valid'
        ]);
        exit;
    }

    // ========================================
    // STEP 3: VALIDATE FILE
    // ========================================
    if (!isset($_FILES['bukti_file'])) {
        http_response_code(400);
        echo json_encode([
            'status' => 'error',
            'message' => 'File tidak ditemukan'
        ]);
        exit;
    }

    $file = $_FILES['bukti_file'];
    $max_size = 5 * 1024 * 1024; // 5MB

    // Check for upload errors
    if ($file['error'] !== UPLOAD_ERR_OK) {
        $error_messages = [
            UPLOAD_ERR_INI_SIZE => 'File terlalu besar (melebihi upload_max_filesize)',
            UPLOAD_ERR_FORM_SIZE => 'File terlalu besar (melebihi MAX_FILE_SIZE)',
            UPLOAD_ERR_PARTIAL => 'File hanya terupload sebagian',
            UPLOAD_ERR_NO_FILE => 'File tidak dipilih',
            UPLOAD_ERR_NO_TMP_DIR => 'Folder temporary tidak ditemukan',
            UPLOAD_ERR_CANT_WRITE => 'Gagal menulis file',
            UPLOAD_ERR_EXTENSION => 'Upload tidak diizinkan oleh PHP extension'
        ];
        
        http_response_code(400);
        echo json_encode([
            'status' => 'error',
            'message' => 'Upload error: ' . ($error_messages[$file['error']] ?? 'Unknown error')
        ]);
        exit;
    }

    // Validate file size
    if ($file['size'] > $max_size) {
        http_response_code(400);
        echo json_encode([
            'status' => 'error',
            'message' => 'Ukuran file terlalu besar. Maksimal 5MB.'
        ]);
        exit;
    }

    // Validate MIME type
    $finfo = finfo_open(FILEINFO_MIME_TYPE);
    $mime_type = finfo_file($finfo, $file['tmp_name']);
    finfo_close($finfo);

    $allowed_types = ['image/jpeg', 'image/png', 'application/pdf'];
    if (!in_array($mime_type, $allowed_types)) {
        http_response_code(400);
        echo json_encode([
            'status' => 'error',
            'message' => 'Tipe file tidak didukung. Hanya JPG, PNG, atau PDF.'
        ]);
        exit;
    }

    // ========================================
    // STEP 4: LOAD DATABASE & VALIDATE SCHEMA
    // ========================================
    require_once __DIR__ . '/config/database.php';
    
    $db = new Database();
    $conn = $db->connect();

    // VALIDASI WAJIB: Pastikan kolom yang digunakan benar-benar ada
    error_log('UPLOAD PROOF: STEP 4A - Validating database schema');
    
    // Cek struktur tabel tagihan (WAJIB ada kolom status pembayaran)
    $check_columns = "SELECT COLUMN_NAME FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'tagihan' AND COLUMN_NAME IN ('status_pembayaran', 'status_tagihan', 'status')";
    $stmt_cols = $conn->query($check_columns);
    $available_columns = $stmt_cols->fetchAll(PDO::FETCH_COLUMN);
    
    if (empty($available_columns)) {
        error_log('UPLOAD PROOF: ERROR - No valid status column found in tagihan table');
        http_response_code(500);
        echo json_encode([
            'status' => 'error',
            'message' => 'Konfigurasi database tidak sesuai. Hubungi administrator.'
        ]);
        exit;
    }
    
    // Gunakan kolom yang tersedia (prioritas: status_pembayaran > status > status_tagihan)
    $status_column = null;
    if (in_array('status_pembayaran', $available_columns)) {
        $status_column = 'status_pembayaran';
    } elseif (in_array('status', $available_columns)) {
        $status_column = 'status';
    } elseif (in_array('status_tagihan', $available_columns)) {
        $status_column = 'status_tagihan';
    }
    
    if (!$status_column) {
        error_log('UPLOAD PROOF: ERROR - Could not determine correct status column');
        http_response_code(500);
        echo json_encode([
            'status' => 'error',
            'message' => 'Konfigurasi database tidak sesuai. Hubungi administrator.'
        ]);
        exit;
    }
    
    error_log('UPLOAD PROOF: Using status column: ' . $status_column);

    // ========================================
    // STEP 4B: VALIDATE PAYMENT STATUS & METHOD (CRITICAL for locking)
    // ========================================
    // Check current status to prevent double upload & verify method is locked
    error_log('UPLOAD PROOF: STEP 4B - Validating payment status & method');
    
    $check_status_query = "
        SELECT t.tagihan_id, t.jumlah_tagihan, t.`" . $status_column . "` as status_pembayaran, t.metode_pembayaran, t.semester, t.tahun_akademik, t.jenis_tagihan
        FROM tagihan t
        WHERE t.tagihan_id = :tagihan_id 
        AND t.mahasiswa_id = :mahasiswa_id
        LIMIT 1
    ";
    
    $stmt_status = $conn->prepare($check_status_query);
    $stmt_status->execute([
        ':tagihan_id' => $tagihan_id,
        ':mahasiswa_id' => $mahasiswa_id
    ]);
    $status_check = $stmt_status->fetch();
    
    if (!$status_check) {
        error_log('UPLOAD PROOF: Tagihan not found - tagihan_id=' . $tagihan_id . ', mahasiswa_id=' . $mahasiswa_id);
        http_response_code(404);
        echo json_encode([
            'status' => 'error',
            'message' => 'Tagihan tidak ditemukan.'
        ]);
        exit;
    }
    
    $current_status = $status_check['status_pembayaran'];
    $metode_pembayaran = $status_check['metode_pembayaran'];
    $semester = $status_check['semester'];
    $tahun_akademik = $status_check['tahun_akademik'];
    $jenis_tagihan = $status_check['jenis_tagihan'];
    
    // CRITICAL: Validate current status allows upload
    // PRINCIPLE: Upload is ONLY blocked if status = menunggu_verifikasi OR lunas
    // ALLOWED statuses: belum_bayar, ditolak
    // NOTE: Validation is ONLY done by admin, NOT during upload
    error_log('UPLOAD PROOF: Current status=' . $current_status . ', metode=' . $metode_pembayaran);
    
    if ($current_status === 'menunggu_verifikasi') {
        error_log('UPLOAD PROOF: BLOCKED - Bukti pembayaran sudah diunggah sebelumnya, sedang menunggu verifikasi admin - tagihan_id=' . $tagihan_id);
        http_response_code(409);  // Conflict
        echo json_encode([
            'status' => 'error',
            'code' => 'PAYMENT_ALREADY_PROCESSING',
            'message' => 'Bukti pembayaran sudah diunggah dan sedang menunggu verifikasi admin. Silakan tunggu keputusan admin universitas.'
        ]);
        exit;
    }
    
    if ($current_status === 'lunas') {
        error_log('UPLOAD PROOF: BLOCKED - Tagihan already paid in full - tagihan_id=' . $tagihan_id);
        http_response_code(409);  // Conflict
        echo json_encode([
            'status' => 'error',
            'code' => 'PAYMENT_ALREADY_COMPLETED',
            'message' => 'Tagihan ini sudah lunas. Tidak perlu upload bukti pembayaran lagi.'
        ]);
        exit;
    }
    
    // PRINCIPLE: Only belum_bayar, ditolak, and cicilan_berjalan are allowed for upload
    if (!in_array($current_status, ['belum_bayar', 'ditolak', 'cicilan_berjalan'])) {
        error_log('UPLOAD PROOF: BLOCKED - Status not in allowed list [belum_bayar, ditolak, cicilan_berjalan] - status=' . $current_status . ', tagihan_id=' . $tagihan_id);
        http_response_code(400);
        echo json_encode([
            'status' => 'error',
            'code' => 'UPLOAD_NOT_ALLOWED',
            'message' => 'Upload bukti pembayaran tidak dapat dilakukan pada status tagihan saat ini. Hubungi admin universitas untuk bantuan.'
        ]);
        exit;
    }
    
    // CRITICAL: Validate method is selected
    if (empty($metode_pembayaran)) {
        error_log('UPLOAD PROOF: BLOCKED - Payment method not selected - tagihan_id=' . $tagihan_id);
        http_response_code(400);
        echo json_encode([
            'status' => 'error',
            'code' => 'METHOD_NOT_SELECTED',
            'message' => 'Metode pembayaran belum dipilih. Pilih Lunas atau Cicilan terlebih dahulu.'
        ]);
        exit;
    }
    
    // CRITICAL: Validate method is valid ENUM value
    if (!in_array($metode_pembayaran, ['lunas', 'cicilan'])) {
        error_log('UPLOAD PROOF: BLOCKED - Invalid payment method - method=' . $metode_pembayaran . ', tagihan_id=' . $tagihan_id);
        http_response_code(400);
        echo json_encode([
            'status' => 'error',
            'code' => 'INVALID_METHOD',
            'message' => 'Metode pembayaran tidak valid.'
        ]);
        exit;
    }

    // Check if tagihan exists and belongs to this student (gunakan kolom yang valid)
    $check_tagihan = "
        SELECT t.tagihan_id, t.jumlah_tagihan, t.`" . $status_column . "` as status_pembayaran
        FROM tagihan t
        WHERE t.tagihan_id = :tagihan_id 
        AND t.mahasiswa_id = :mahasiswa_id
    ";
    
    $stmt = $conn->prepare($check_tagihan);
    $stmt->bindParam(':tagihan_id', $tagihan_id, PDO::PARAM_INT);
    $stmt->bindParam(':mahasiswa_id', $mahasiswa_id, PDO::PARAM_INT);
    $stmt->execute();
    $tagihan = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$tagihan) {
        error_log('UPLOAD PROOF: Tagihan not found - tagihan_id=' . $tagihan_id . ', mahasiswa_id=' . $mahasiswa_id);
        http_response_code(404);
        echo json_encode([
            'status' => 'error',
            'message' => 'Tagihan tidak ditemukan'
        ]);
        exit;
    }

    // Check if VA exists and is active
    $check_va = "
        SELECT va_id, nomor_va, jumlah_va, status_va
        FROM virtual_account
        WHERE nomor_va = :nomor_va
        AND tagihan_id = :tagihan_id
        AND status_va = 'aktif'
    ";

    $stmt = $conn->prepare($check_va);
    $stmt->bindParam(':nomor_va', $va_number, PDO::PARAM_STR);
    $stmt->bindParam(':tagihan_id', $tagihan_id, PDO::PARAM_INT);
    $stmt->execute();
    $va = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$va) {
        error_log('UPLOAD PROOF: VA not found or inactive - nomor_va=' . $va_number . ', tagihan_id=' . $tagihan_id);
        http_response_code(404);
        echo json_encode([
            'status' => 'error',
            'message' => 'Virtual Account tidak ditemukan atau sudah tidak aktif'
        ]);
        exit;
    }

    // ========================================
    // STEP 5: CREATE UPLOADS DIRECTORY
    // ========================================
    $upload_dir = __DIR__ . '/../uploads/bukti_pembayaran';
    $upload_dir = realpath(__DIR__ . '/..') . DIRECTORY_SEPARATOR . 'uploads' . DIRECTORY_SEPARATOR . 'bukti_pembayaran';
    
    if (!is_dir($upload_dir)) {
        if (!@mkdir($upload_dir, 0755, true)) {
            error_log('UPLOAD PROOF: Failed to create upload directory - ' . $upload_dir);
            http_response_code(500);
            echo json_encode([
                'status' => 'error',
                'message' => 'Gagal membuat direktori upload'
            ]);
            exit;
        }
    }

    // ========================================
    // STEP 6: SAVE FILE
    // ========================================
    // Generate unique filename
    $file_extension = pathinfo($file['name'], PATHINFO_EXTENSION);
    $filename = 'bukti_' . $tagihan_id . '_' . time() . '.' . $file_extension;
    $filepath = $upload_dir . '/' . $filename;

    if (!move_uploaded_file($file['tmp_name'], $filepath)) {
        error_log('UPLOAD PROOF: Failed to move uploaded file - ' . $file['tmp_name']);
        http_response_code(500);
        echo json_encode([
            'status' => 'error',
            'message' => 'Gagal menyimpan file'
        ]);
        exit;
    }

    error_log('UPLOAD PROOF: File saved - filename=' . $filename . ', size=' . $file['size']);

    // ========================================
    // STEP 7: BEGIN DATABASE TRANSACTION
    // ========================================
    // All database operations must succeed together or rollback
    try {
        $conn->beginTransaction();
        error_log('UPLOAD PROOF: Transaction started');

        // ========================================
        // STEP 7A: INSERT INTO PEMBAYARAN TABLE
        // ========================================
        $insert_pembayaran = "
            INSERT INTO pembayaran 
            (tagihan_id, va_id, mahasiswa_id, jumlah_pembayaran, tgl_pembayaran, bukti_pembayaran_filename, status_validasi)
            VALUES 
            (:tagihan_id, :va_id, :mahasiswa_id, :jumlah_pembayaran, :tgl_pembayaran, :bukti_pembayaran_filename, 'menunggu_validasi')
        ";

        $stmt = $conn->prepare($insert_pembayaran);
        $stmt->bindParam(':tagihan_id', $tagihan_id, PDO::PARAM_INT);
        $stmt->bindParam(':va_id', $va['va_id'], PDO::PARAM_INT);
        $stmt->bindParam(':mahasiswa_id', $mahasiswa_id, PDO::PARAM_INT);
        $stmt->bindParam(':jumlah_pembayaran', $va['jumlah_va'], PDO::PARAM_STR);
        $stmt->bindParam(':tgl_pembayaran', $tanggal_transfer, PDO::PARAM_STR);
        $stmt->bindParam(':bukti_pembayaran_filename', $filename, PDO::PARAM_STR);

        if (!$stmt->execute()) {
            throw new Exception('Gagal INSERT ke pembayaran: ' . json_encode($conn->errorInfo()));
        }

        $pembayaran_id = $conn->lastInsertId();
        error_log('UPLOAD PROOF: pembayaran INSERT success - pembayaran_id=' . $pembayaran_id);

        // ========================================
        // STEP 7B: INSERT INTO RIWAYAT_TRANSAKSI (WAJIB)
        // ========================================
        // SETIAP upload bukti pembayaran HARUS menciptakan record riwayat transaksi
        // Riwayat transaksi adalah bukti bahwa transaksi benar-benar terjadi di sistem
        $deskripsi_riwayat = 'Upload bukti pembayaran untuk tagihan #' . $tagihan_id . 
                            ' (VA: ' . $va_number . ') sebesar Rp ' . 
                            number_format($va['jumlah_va'], 2, ',', '.') . 
                            ' pada tanggal ' . $tanggal_transfer;

        $insert_riwayat = "
            INSERT INTO riwayat_transaksi 
            (mahasiswa_id, jenis_transaksi, deskripsi, referensi_id, tgl_transaksi)
            VALUES 
            (:mahasiswa_id, 'upload_bukti_pembayaran', :deskripsi, :referensi_id, NOW())
        ";

        $stmt_riwayat = $conn->prepare($insert_riwayat);
        $stmt_riwayat->bindParam(':mahasiswa_id', $mahasiswa_id, PDO::PARAM_INT);
        $stmt_riwayat->bindParam(':deskripsi', $deskripsi_riwayat, PDO::PARAM_STR);
        $stmt_riwayat->bindParam(':referensi_id', $pembayaran_id, PDO::PARAM_INT);

        if (!$stmt_riwayat->execute()) {
            throw new Exception('Gagal INSERT ke riwayat_transaksi: ' . json_encode($conn->errorInfo()));
        }

        $riwayat_id = $conn->lastInsertId();
        error_log('UPLOAD PROOF: riwayat_transaksi INSERT success - riwayat_id=' . $riwayat_id . ', referensi_id=' . $pembayaran_id);

        // ========================================
        // STEP 7C: UPDATE TAGIHAN STATUS (CRITICAL - LOCK PAYMENT METHOD)
        // ========================================
        // WAJIB: Change status to 'menunggu_verifikasi' & lock metode_pembayaran
        error_log('UPLOAD PROOF: STEP 7C - Updating tagihan status to menunggu_verifikasi');
        
        $update_status = "
            UPDATE tagihan 
            SET `" . $status_column . "` = 'menunggu_verifikasi'
            WHERE tagihan_id = :tagihan_id
            AND mahasiswa_id = :mahasiswa_id
        ";
        
        $stmt_update = $conn->prepare($update_status);
        if (!$stmt_update->execute([
            ':tagihan_id' => $tagihan_id,
            ':mahasiswa_id' => $mahasiswa_id
        ])) {
            throw new Exception('Gagal UPDATE status tagihan ke menunggu_verifikasi: ' . json_encode($conn->errorInfo()));
        }
        
        error_log('UPLOAD PROOF: Tagihan status updated to menunggu_verifikasi - tagihan_id=' . $tagihan_id);

        // ========================================
        // STEP 7D: COMMIT TRANSACTION
        // ========================================
        $conn->commit();
        error_log('UPLOAD PROOF: Transaction committed successfully - pembayaran_id=' . $pembayaran_id . ', riwayat_id=' . $riwayat_id);

    } catch (Exception $e) {
        // ========================================
        // ROLLBACK ON ANY FAILURE
        // ========================================
        if ($conn->inTransaction()) {
            $conn->rollBack();
            error_log('UPLOAD PROOF: Transaction rolled back - Reason: ' . $e->getMessage());
        }

        // Delete uploaded file if transaction failed
        if (file_exists($filepath)) {
            unlink($filepath);
            error_log('UPLOAD PROOF: Uploaded file deleted after rollback - ' . $filepath);
        }

        http_response_code(500);
        echo json_encode([
            'status' => 'error',
            'message' => 'Gagal menyimpan data pembayaran. Silakan coba lagi.'
        ]);
        exit;
    }

    error_log('UPLOAD PROOF: SUCCESS - pembayaran_id=' . $pembayaran_id . ', riwayat_id=' . $riwayat_id . ', tagihan_id=' . $tagihan_id . ', mahasiswa_id=' . $mahasiswa_id);

    // ========================================
    // STEP 8: RETURN SUCCESS RESPONSE
    // ========================================
    // File saved, pembayaran created, riwayat created, status set to menunggu_verifikasi
    // NOTE: Upload is NOT validation. Validation is done ONLY by admin universitas.
    http_response_code(200);
    echo json_encode([
        'status' => 'success',
        'message' => 'Bukti pembayaran berhasil diunggah. Status sedang menunggu verifikasi admin universitas. Anda akan diberitahu ketika admin universitas menentukan keputusan.',
        'pembayaran_id' => intval($pembayaran_id),
        'riwayat_id' => intval($riwayat_id),
        'payment_status' => 'menunggu_verifikasi',
        'data' => [
            'filename' => $filename,
            'uploaded_at' => date('Y-m-d H:i:s'),
            'va_number' => $va_number,
            'jumlah' => floatval($va['jumlah_va']),
            'semester' => $semester,
            'tahun_akademik' => $tahun_akademik,
            'jenis_tagihan' => $jenis_tagihan,
            'riwayat_recorded' => true,
            'status_locked' => true
        ]
    ]);

} catch (PDOException $e) {
    error_log('UPLOAD PROOF: PDOException - Code=' . $e->getCode() . ', Message=' . $e->getMessage() . ', File=' . $e->getFile() . ', Line=' . $e->getLine());
    
    http_response_code(500);
    echo json_encode([
        'status' => 'error',
        'message' => 'Gagal memproses bukti pembayaran. Silakan hubungi admin.'
    ]);
} catch (Exception $e) {
    error_log('UPLOAD PROOF: Exception - Message=' . $e->getMessage() . ', File=' . $e->getFile() . ', Line=' . $e->getLine());
    
    http_response_code(500);
    echo json_encode([
        'status' => 'error',
        'message' => 'Gagal memproses bukti pembayaran. Silakan hubungi admin.'
    ]);
}

// Fallback error handler for any uncaught errors or fatal errors
register_shutdown_function(function() {
    $error = error_get_last();
    if ($error !== null && ($error['type'] === E_ERROR || $error['type'] === E_PARSE || $error['type'] === E_COMPILE_ERROR)) {
        error_log('UPLOAD PROOF: Fatal error - ' . $error['message'] . ' in ' . $error['file'] . ':' . $error['line']);
        http_response_code(500);
        echo json_encode([
            'status' => 'error',
            'message' => 'Fatal error: ' . $error['message']
        ]);
    }
});
