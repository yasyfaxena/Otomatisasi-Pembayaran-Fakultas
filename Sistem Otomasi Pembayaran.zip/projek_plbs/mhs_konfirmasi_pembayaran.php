<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header('Location: mhs_login.php');
    exit;
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Konfirmasi Pembayaran</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: #f5f5f5;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }

        .confirmation-container {
            width: 100%;
            max-width: 550px;
            background: white;
            border-radius: 12px;
            padding: 30px 40px;
            box-shadow: 0 6px 20px rgba(0,0,0,0.1);
            border: 1px solid #e0e0e0;
            text-align: center;
        }

        .page-header {
            margin-bottom: 25px;
            padding-bottom: 15px;
            border-bottom: 1px solid #eee;
        }
        .page-title {
            font-size: 24px;
            font-weight: 700;
            color: #333;
        }

        .tagihan-details {
            text-align: left;
            margin-bottom: 30px;
        }
        .tagihan-row {
            display: grid;
            grid-template-columns: 180px 1fr;
            align-items: center;
            margin-bottom: 15px;
            font-size: 16px;
        }
        .tagihan-label { color: #555; font-weight: 600; }
        .tagihan-value { color: #333; font-weight: 600; }
        
        .action-buttons {
            display: flex;
            justify-content: center;
            gap: 15px;
            margin-top: 20px;
        }

        .btn {
            border: none;
            padding: 12px 25px;
            border-radius: 8px;
            cursor: pointer;
            font-weight: 700;
            font-size: 15px;
            transition: all 0.3s;
            text-decoration: none;
            display: inline-block;
        }
        .btn-green { background-color: #4CAF50; color: white; }
        .btn-green:hover { background-color: #45a049; }
        .btn-secondary { background-color: #f1f1f1; color: #333; border: 1px solid #ddd; }
        .btn-secondary:hover { background-color: #e0e0e0; }

    </style>
</head>
<body>
    <div class="confirmation-container">
        <header class="page-header">
            <h1 class="page-title">KONFIRMASI PEMBAYARAN</h1>
        </header>

        <div class="tagihan-details">
            <div class="tagihan-row">
                <span class="tagihan-label">Jenis Pembayaran</span>
                <span class="tagihan-value" id="jenis-pembayaran">-</span>
            </div>
            <div class="tagihan-row">
                <span class="tagihan-label">Total Tagihan</span>
                <span class="tagihan-value" id="total-tagihan">-</span>
            </div>
            <div class="tagihan-row" id="semester-row" style="display: none;">
                <span class="tagihan-label">Tahun Akademik</span>
                <span class="tagihan-value" id="tahun-akademik">-</span>
            </div>
        </div>

        <div class="action-buttons">
            <a href="mhs_tagihan.php" class="btn btn-secondary">Batal</a>
            <a href="#" id="lanjutkan-pembayaran" class="btn btn-green">Lanjutkan Pembayaran</a>
        </div>
    </div>

    <script>
        document.addEventListener('DOMContentLoaded', function() {
            const params = new URLSearchParams(window.location.search);
            const type = params.get('type');
            const total = params.get('total');
            const semester = params.get('semester');

            function formatRupiah(angka) {
                return 'Rp ' + parseInt(angka).toLocaleString('id-ID');
            }

            let displayType = type;
            if (type === 'BPP Cicilan') {
                displayType = `BPP Semester 5 (Cicilan)`;
            } else if (type === 'BPP Lunas') {
                displayType = `BPP Semester 5 (Lunas)`;
            }

            document.getElementById('jenis-pembayaran').textContent = displayType;
            document.getElementById('total-tagihan').textContent = formatRupiah(total);

            if (semester) {
                document.getElementById('tahun-akademik').textContent = semester;
                document.getElementById('semester-row').style.display = 'grid';
            }

            // Prepare the link for the next page
            const LanjutkanBtn = document.getElementById('lanjutkan-pembayaran');
            const nextParams = new URLSearchParams({
                type: type,
                total: total,
                semester: semester || ''
            });
            LanjutkanBtn.href = `mhs_instruksi_pembayaran.php?${nextParams.toString()}`;
        });
    </script>
</body>
</html>


