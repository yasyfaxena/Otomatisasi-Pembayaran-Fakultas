# Script untuk menghapus semua bulatan avatar dari halaman admin
# Dan mengubah avatar mahasiswa menjadi icon baju toga

# Hapus avatar dari semua halaman admin fakultas dan universitas
$files = @(
    "fk_daftar_tagihan.php",
    "fk_laporan_pembayaran.php", 
    "fk_monitoring_cicilan.php",
    "univ_riwayat_pembayaran.php",
    "univ_validasi.php"
)

foreach ($file in $files) {
    $path = "d:\laragon\www\projek_plbs\$file"
    if (Test-Path $path) {
        $content = Get-Content $path -Raw
        # Hapus div user-avatar
        $content = $content -replace '<div class="user-avatar"></div>', ''
        # Hapus CSS user-avatar
        $content = $content -replace '\.user-avatar \{[^}]+\}', ''
        Set-Content $path $content -NoNewline
        Write-Host "✓ Removed avatar from $file"
    }
}

Write-Host ""
Write-Host "All admin avatars removed!"
