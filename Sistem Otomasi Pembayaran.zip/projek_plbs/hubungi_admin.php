<?php
session_start();
?>
<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Hubungi Admin Fakultas</title>

<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">

<style>
:root {
    --primary: #246140;
    --primary-dark: #113120;
    --bg: #f5f7fa;
    --card: #ffffff;
    --text: #333;
    --muted: #777;
}

* {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
    font-family: 'Segoe UI', Tahoma, sans-serif;
}

body {
    min-height: 100vh;
    background:
        linear-gradient(rgba(0,0,0,0.45), rgba(0,0,0,0.45)),
        url("img/bg-campus.jpg");
    background-size: cover;
    background-position: center;
    display: flex;
    align-items: center;
    justify-content: center;
}

.card {
    background: var(--card);
    padding: 40px 35px;
    border-radius: 14px;
    max-width: 420px;
    width: 100%;
    text-align: center;
    box-shadow: 0 15px 40px rgba(0,0,0,0.25);
}

.icon {
    font-size: 48px;
    color: var(--primary);
    margin-bottom: 15px;
}

.card h2 {
    font-size: 22px;
    color: var(--primary-dark);
    margin-bottom: 10px;
}

.card p {
    font-size: 14px;
    color: var(--muted);
    margin-bottom: 25px;
    line-height: 1.6;
}

.btn {
    display: inline-block;
    padding: 12px 22px;
    background: linear-gradient(135deg, var(--primary), var(--primary-dark));
    color: white;
    border-radius: 10px;
    text-decoration: none;
    font-weight: 600;
    transition: 0.3s;
}

.btn:hover {
    opacity: 0.9;
    transform: translateY(-2px);
}

.footer {
    margin-top: 20px;
    font-size: 13px;
    color: var(--muted);
}
</style>
</head>

<body>

<div class="card">
    <div class="icon">
        <i class="fas fa-circle-info"></i>
    </div>

    <h2>Akses Dibatasi</h2>
    <p>
        <br>
        <strong>Silakan hubungi admin fakultas</strong>
        <br> untuk mendapatkan bantuan lebih lanjut.
    </p>

    <a href="mailto:admin@fakultas.ac.id" class="btn">
        <i class="fas fa-envelope"></i> Hubungi Admin
    </a>

    <div class="footer">
        © 2025 Sistem Informasi Fakultas
    </div>
</div>

</body>
</html>
