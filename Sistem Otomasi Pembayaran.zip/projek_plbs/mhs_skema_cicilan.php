<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header('Location: mhs_login.php');
    exit;
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Skema Cicilan BPP</title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; background-color: #f5f5f5; display: flex; justify-content: center; align-items: center; height: 100vh; padding: 20px; }
        .container { width: 100%; max-width: 600px; background: white; border-radius: 12px; padding: 30px 40px; box-shadow: 0 6px 20px rgba(0,0,0,0.1); text-align: center; }
        .page-header { margin-bottom: 25px; }
        .page-title { font-size: 24px; font-weight: 700; color: #333; }
        .detail-item { background-color: #f8f9fa; padding: 15px; border-radius: 8px; margin-bottom: 15px; text-align: left; }
        .detail-label { font-size: 14px; color: #666; }
        .detail-value { font-size: 18px; font-weight: 600; color: #333; }
        .action-area { display: flex; justify-content: center; gap: 15px; margin-top: 30px; }
        .btn { border: none; padding: 12px 25px; border-radius: 8px; cursor: pointer; font-weight: 700; font-size: 15px; text-decoration: none; display: inline-flex; align-items: center; gap: 8px; }
        .btn-primary { background-color: #2196F3; color: white; }
        .btn-secondary { background-color: #6c757d; color: white; }
    </style>
</head>
<body>
    <div class="container">
        <header class="page-header">
            <h1 class="page-title">SKEMA CICILAN BPP</h1>
        </header>

        <div class="detail-item">
            <div class="detail-label">Total Tagihan</div>
            <div class="detail-value" id="total-tagihan">-</div>
        </div>
        <div class="detail-item">
            <div class="detail-label">Jumlah Cicilan</div>
            <div class="detail-value" id="jumlah-cicilan">2x</div>
        </div>
        <div class="detail-item">
            <div class="detail-label">Nominal per Cicilan</div>
            <div class="detail-value" id="nominal-cicilan">-</div>
        </div>
        
        <div class="action-area">
            <a href="mhs_tagihan.php" class="btn btn-secondary">Kembali</a>
            <button id="lanjutkan-btn" class="btn btn-primary">Lanjutkan Pembayaran</button>
        </div>
    </div>

    <script>
        document.addEventListener('DOMContentLoaded', function() {
            const params = new URLSearchParams(window.location.search);
            const total = parseInt(params.get('total'));
            const semester = params.get('semester');
            const nim = "13020220029"; // Hardcoded for simulation

            const formatRupiah = (angka) => 'Rp ' + angka.toLocaleString('id-ID');
            const jumlahCicilan = 2;
            const nominalCicilan = total / jumlahCicilan;

            document.getElementById('total-tagihan').textContent = formatRupiah(total);
            document.getElementById('nominal-cicilan').textContent = formatRupiah(nominalCicilan);

            const lanjutkanBtn = document.getElementById('lanjutkan-btn');
            lanjutkanBtn.addEventListener('click', function() {
                // Generate the persistent VA for this BPP
                const vaNumber = `8805 ${nim.slice(0, 4)} ${nim.slice(4, 8)} ${nim.slice(8)}`;

                // Get existing payments from localStorage
                const payments = JSON.parse(localStorage.getItem('payments')) || {};
                
                // Create or update the payment record for this VA
                if (!payments[vaNumber]) {
                    payments[vaNumber] = {
                        va: vaNumber,
                        type: 'BPP Cicilan',
                        total: total,
                        semester: semester,
                        status: 'CICILAN BERJALAN',
                        installments: jumlahCicilan,
                        installments_paid: 0,
                        amount_paid: 0
                    };
                    localStorage.setItem('payments', JSON.stringify(payments));
                }
                
                // Redirect to the installment detail page
                window.location.href = `mhs_detail_cicilan.php?va=${vaNumber}`;
            });
        });
    </script>
</body>
</html>


