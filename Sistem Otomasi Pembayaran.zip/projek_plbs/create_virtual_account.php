<?php
/**
 * CREATE VIRTUAL ACCOUNT - On-Demand VA Generation with COMPREHENSIVE VALIDATION
 * 
 * PRINSIP DASAR (WAJIB):
 * 1. Virtual Account HANYA dibuat setelah mahasiswa memilih metode pembayaran
 * 2. Proses pembuatan VA HARUS gagal dengan pesan jelas jika data tidak lengkap
 * 3. Backend TIDAK BOLEH mencoba insert VA jika data tidak valid
 * 4. SEMUA error handling dilakukan dengan try-catch (no raw SQL errors)
 * 5. Frontend HANYA menampilkan VA jika backend berhasil membuatnya
 * 
 * VALIDASI WAJIB SEBELUM INSERT:
 * ✓ tagihan_id ADA dan VALID
 * ✓ metode_pembayaran SUDAH DISET ('lunas' atau 'cicilan')
 * ✓ jumlah_tagihan > 0 (diambil dari tagihan.jumlah_tagihan)
 * ✓ Belum ada VA aktif untuk tagihan tersebut (cegah duplicate)
 * ✓ Semua kolom WAJIB di tabel virtual_account terpenuhi
 */

session_start();

header('Content-Type: application/json; charset=utf-8');
ini_set('display_errors', 0);
error_reporting(E_ALL);

// ==========================================
// FUNCTION: Validasi & Return Error JSON
// ==========================================

function sendError($code, $message, $http_code = 400) {
    http_response_code($http_code);
    echo json_encode([
        'status' => 'error',
        'message' => $message,
        'code' => $code
    ]);
    exit;
}

function sendSuccess($data, $message = 'Success', $http_code = 201) {
    http_response_code($http_code);
    echo json_encode([
        'status' => 'success',
        'message' => $message,
        'data' => $data
    ]);
    exit;
}

// ==========================================
// STEP 1: VALIDASI SESSION
// ==========================================

if (!isset($_SESSION['user_id']) || empty($_SESSION['user_id'])) {
    sendError('UNAUTHORIZED', 'User tidak terautentikasi. Silakan login terlebih dahulu.', 401);
}

try {
    // ==========================================
    // STEP 2: KONEKSI DATABASE
    // ==========================================
    
    $db_path = __DIR__ . '/api/config/database.php';
    if (!file_exists($db_path)) {
        error_log('Database config not found: ' . $db_path);
        sendError('CONFIG_ERROR', 'Konfigurasi database tidak ditemukan. Hubungi administrator.', 500);
    }
    
    require_once $db_path;
    
    if (!class_exists('Database')) {
        error_log('Database class not found in config');
        sendError('CONFIG_ERROR', 'Konfigurasi database tidak valid. Hubungi administrator.', 500);
    }
    
    $database = new Database();
    $conn = $database->connect();
    
    if (!$conn instanceof PDO) {
        error_log('Database connection failed - not PDO instance');
        sendError('DB_CONNECTION_ERROR', 'Gagal terhubung ke database. Silakan coba beberapa saat lagi.', 500);
    }
    
    // Set error mode untuk PDO
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    
    $user_id = $_SESSION['user_id'];
    
    // ==========================================
    // STEP 3: VALIDASI INPUT DARI FRONTEND
    // ==========================================
    
    // Validasi tagihan_id
    if (!isset($_POST['tagihan_id']) || empty($_POST['tagihan_id'])) {
        sendError('INVALID_INPUT', 'ID Tagihan tidak diberikan. Silakan refresh halaman dan coba lagi.', 400);
    }
    
    $tagihan_id = (int)$_POST['tagihan_id'];
    if ($tagihan_id <= 0) {
        sendError('INVALID_INPUT', 'ID Tagihan tidak valid. Silakan refresh halaman dan coba lagi.', 400);
    }
    
    // Validasi method
    if (!isset($_POST['method']) || empty($_POST['method'])) {
        sendError('INVALID_INPUT', 'Metode pembayaran tidak diberikan. Silakan pilih metode pembayaran.', 400);
    }
    
    $method = strtolower(trim($_POST['method']));
    if (!in_array($method, ['lunas', 'cicilan'])) {
        sendError('INVALID_INPUT', 'Metode pembayaran tidak valid. Gunakan "lunas" atau "cicilan".', 400);
    }
    
    // ==========================================
    // STEP 4: AMBIL & VALIDASI DATA TAGIHAN
    // ==========================================
    
    $query = "
        SELECT 
            t.tagihan_id,
            t.mahasiswa_id,
            t.jumlah_tagihan,
            t.jenis_tagihan,
            t.semester,
            t.tahun_akademik,
            t.metode_pembayaran,
            t.status_pembayaran,
            m.nim,
            m.user_id as mahasiswa_user_id,
            ps.nama_prodi
        FROM tagihan t
        INNER JOIN mahasiswa m ON t.mahasiswa_id = m.mahasiswa_id
        INNER JOIN program_studi ps ON m.prodi_id = ps.prodi_id
        WHERE t.tagihan_id = :tagihan_id
        LIMIT 1
    ";
    
    $stmt = $conn->prepare($query);
    if (!$stmt) {
        error_log('SQL prepare error: ' . implode(' ', $conn->errorInfo()));
        sendError('DB_PREPARE_ERROR', 'Gagal mempersiapkan query database. Silakan coba beberapa saat lagi.', 500);
    }
    
    $stmt->bindParam(':tagihan_id', $tagihan_id, PDO::PARAM_INT);
    
    if (!$stmt->execute()) {
        error_log('SQL execute error: ' . implode(' ', $stmt->errorInfo()));
        sendError('DB_EXECUTE_ERROR', 'Gagal mengambil data tagihan dari database. Silakan coba beberapa saat lagi.', 500);
    }
    
    $tagihan = $stmt->fetch(PDO::FETCH_ASSOC);
    
    // Validasi: Tagihan ditemukan
    if (!$tagihan) {
        sendError('TAGIHAN_NOT_FOUND', 'Tagihan tidak ditemukan atau Anda tidak memiliki akses. Silakan refresh halaman.', 404);
    }
    
    // Validasi: User ownership (mahasiswa_user_id MUST match session user_id)
    if ((int)$tagihan['mahasiswa_user_id'] !== (int)$user_id) {
        error_log('Authorization check failed: User ' . $user_id . ' tried to access tagihan of user ' . $tagihan['mahasiswa_user_id']);
        sendError('UNAUTHORIZED', 'Anda tidak memiliki akses ke tagihan ini. Silakan hubungi administrator.', 403);
    }
    
    $mahasiswa_id = (int)$tagihan['mahasiswa_id'];
    $jumlah_tagihan = (float)$tagihan['jumlah_tagihan'];
    $nim = trim($tagihan['nim']);
    
    // Validasi: Jumlah tagihan HARUS > 0
    if ($jumlah_tagihan <= 0) {
        error_log('Invalid tagihan amount: ' . $jumlah_tagihan . ' for tagihan_id: ' . $tagihan_id);
        sendError('INVALID_AMOUNT', 'Jumlah tagihan tidak valid (harus lebih dari 0). Hubungi administrator.', 400);
    }
    
    // Validasi: NIM tidak boleh kosong
    if (empty($nim) || strlen($nim) < 8) {
        error_log('Invalid NIM for mahasiswa_id: ' . $mahasiswa_id . ', NIM: ' . $nim);
        sendError('INVALID_NIM', 'Data NIM mahasiswa tidak valid. Hubungi administrator untuk mengecek data akademik Anda.', 400);
    }
    
    // ==========================================
    // STEP 5: CEK DUPLICATE VA
    // ==========================================
    
    // Check: Apakah sudah ada VA aktif untuk tagihan ini?
    $va_check_query = "
        SELECT 
            va_id,
            nomor_va,
            status_va,
            metode_pembayaran,
            jumlah_va
        FROM virtual_account 
        WHERE tagihan_id = :tagihan_id
        LIMIT 1
    ";
    
    $stmt = $conn->prepare($va_check_query);
    if (!$stmt) {
        error_log('SQL prepare error for VA check: ' . implode(' ', $conn->errorInfo()));
        sendError('DB_PREPARE_ERROR', 'Gagal mengecek status Virtual Account. Silakan coba beberapa saat lagi.', 500);
    }
    
    $stmt->bindParam(':tagihan_id', $tagihan_id, PDO::PARAM_INT);
    
    if (!$stmt->execute()) {
        error_log('SQL execute error for VA check: ' . implode(' ', $stmt->errorInfo()));
        sendError('DB_EXECUTE_ERROR', 'Gagal mengecek status Virtual Account. Silakan coba beberapa saat lagi.', 500);
    }
    
    $va_exists = $stmt->fetch(PDO::FETCH_ASSOC);
    
    // Jika VA sudah ada, kembalikan VA yang sudah ada (jangan buat duplicate)
    if ($va_exists) {
        error_log('VA already exists for tagihan_id: ' . $tagihan_id . ', returning existing VA');
        sendSuccess([
            'va_id' => (int)$va_exists['va_id'],
            'nomor_va' => $va_exists['nomor_va'],
            'status_va' => $va_exists['status_va'],
            'metode_pembayaran' => $va_exists['metode_pembayaran'],
            'jumlah_va' => (float)$va_exists['jumlah_va'],
            'nominal_pembayaran' => (float)$va_exists['jumlah_va']
        ], 'Virtual Account sudah ada sebelumnya', 200);
    }
    
    // ==========================================
    // STEP 6: GENERATE NOMOR VA UNIK
    // ==========================================
    
    // Format: 8805 + NIM (12 digit) + Tagihan ID (4 digit)
    // Contoh: 880512345678120001
    $formatted_nim = substr($nim, 0, 12);  // Ambil 12 digit pertama NIM
    $nomor_va = '8805' . $formatted_nim . str_pad($tagihan_id, 4, '0', STR_PAD_LEFT);
    
    // Validasi: nomor_va panjang
    if (strlen($nomor_va) < 16) {
        error_log('Generated VA number too short: ' . $nomor_va . ' for NIM: ' . $nim . ', tagihan_id: ' . $tagihan_id);
        sendError('VA_GENERATION_ERROR', 'Gagal menghasilkan nomor Virtual Account. Hubungi administrator.', 500);
    }
    
    // ==========================================
    // STEP 7: TENTUKAN NOMINAL VA & METHOD
    // ==========================================
    
    $jumlah_va = $jumlah_tagihan;
    $metode_va = $method;  // 'lunas' atau 'cicilan'
    
    if ($method === 'cicilan') {
        // Untuk cicilan: hitung nominal per cicilan
        $jumlah_cicilan = 2;  // Default 2x cicilan
        $nominal_per_cicilan = round($jumlah_tagihan / $jumlah_cicilan, 2);
        
        // Validasi: nominal per cicilan harus > 0
        if ($nominal_per_cicilan <= 0) {
            error_log('Invalid nominal per cicilan: ' . $nominal_per_cicilan . ' for tagihan amount: ' . $jumlah_tagihan);
            sendError('INVALID_AMOUNT', 'Gagal menghitung nominal cicilan. Hubungi administrator.', 400);
        }
        
        $jumlah_va = $nominal_per_cicilan;
    }
    
    // Final validation: jumlah_va harus > 0
    if ($jumlah_va <= 0) {
        error_log('Invalid VA amount: ' . $jumlah_va . ' after calculation');
        sendError('INVALID_AMOUNT', 'Jumlah Virtual Account tidak valid (harus lebih dari 0). Hubungi administrator.', 400);
    }
    
    // ==========================================
    // STEP 8: START DATABASE TRANSACTION
    // ==========================================
    
    // Gunakan transaction untuk memastikan konsistensi data
    if (!$conn->beginTransaction()) {
        error_log('Failed to begin transaction');
        sendError('DB_TRANSACTION_ERROR', 'Gagal memulai transaksi database. Silakan coba beberapa saat lagi.', 500);
    }
    
    // ==========================================
    // STEP 9: INSERT CICILAN_DETAIL (JIKA CICILAN)
    // ==========================================
    
    if ($method === 'cicilan') {
        $jumlah_cicilan = 2;  // Default 2x cicilan
        $nominal_per_cicilan = round($jumlah_tagihan / $jumlah_cicilan, 2);
        
        for ($i = 1; $i <= $jumlah_cicilan; $i++) {
            try {
                // Hitung tanggal jatuh tempo (30 hari, 60 hari)
                $jatuh_tempo = date('Y-m-d', strtotime("+{$i}0 days"));
                
                $insert_cicilan = "
                    INSERT INTO cicilan_detail 
                    (tagihan_id, nomor_cicilan, jumlah_cicilan, tgl_jatuh_tempo, status_cicilan, jumlah_terbayar, created_at)
                    VALUES 
                    (:tagihan_id, :nomor_cicilan, :jumlah_cicilan, :tgl_jatuh_tempo, 'belum_dibayar', 0, NOW())
                ";
                
                $stmt = $conn->prepare($insert_cicilan);
                if (!$stmt) {
                    throw new Exception('Gagal mempersiapkan query cicilan_detail: ' . implode(' ', $conn->errorInfo()));
                }
                
                $stmt->bindParam(':tagihan_id', $tagihan_id, PDO::PARAM_INT);
                $stmt->bindParam(':nomor_cicilan', $i, PDO::PARAM_INT);
                $stmt->bindParam(':jumlah_cicilan', $nominal_per_cicilan, PDO::PARAM_STR);
                $stmt->bindParam(':tgl_jatuh_tempo', $jatuh_tempo, PDO::PARAM_STR);
                
                if (!$stmt->execute()) {
                    throw new Exception('Gagal insert cicilan_detail ke database: ' . implode(' ', $stmt->errorInfo()));
                }
            } catch (PDOException $e) {
                $conn->rollBack();
                error_log('PDOException while inserting cicilan_detail: ' . $e->getMessage());
                sendError('CICILAN_INSERT_ERROR', 'Gagal membuat data cicilan. Silakan coba beberapa saat lagi atau hubungi administrator.', 500);
            } catch (Exception $e) {
                $conn->rollBack();
                error_log('Exception while inserting cicilan_detail: ' . $e->getMessage());
                sendError('CICILAN_INSERT_ERROR', 'Gagal membuat data cicilan. Silakan coba beberapa saat lagi atau hubungi administrator.', 500);
            }
        }
    }
    
    // ==========================================
    // STEP 10: GENERATE VA_CODE
    // ==========================================
    
    // va_code adalah kode unik untuk VA (digunakan oleh payment gateway)
    // Format: Random 20 chars atau bisa juga kombinasi dari nomor_va
    $va_code = substr($nomor_va, 0, 20);  // Ambil 20 karakter pertama dari nomor_va
    
    // ==========================================
    // STEP 11: INSERT VIRTUAL ACCOUNT
    // ==========================================
    
    try {
        $insert_va = "
            INSERT INTO virtual_account 
            (tagihan_id, nomor_va, va_code, status_va, metode_pembayaran, jumlah_va, tgl_pembuatan, tgl_kadaluarsa)
            VALUES 
            (:tagihan_id, :nomor_va, :va_code, 'aktif', :metode_pembayaran, :jumlah_va, NOW(), DATE_ADD(NOW(), INTERVAL 7 DAY))
        ";
        
        $stmt = $conn->prepare($insert_va);
        if (!$stmt) {
            $error_info = $conn->errorInfo();
            error_log('VA INSERT PREPARE ERROR - Code: ' . $error_info[0] . ', Error: ' . $error_info[2]);
            throw new Exception('Gagal mempersiapkan query virtual_account (Error ' . $error_info[0] . '): ' . $error_info[2]);
        }
        
        $stmt->bindParam(':tagihan_id', $tagihan_id, PDO::PARAM_INT);
        $stmt->bindParam(':nomor_va', $nomor_va, PDO::PARAM_STR);
        $stmt->bindParam(':va_code', $va_code, PDO::PARAM_STR);
        $stmt->bindParam(':metode_pembayaran', $metode_va, PDO::PARAM_STR);
        $stmt->bindParam(':jumlah_va', $jumlah_va, PDO::PARAM_STR);
        
        if (!$stmt->execute()) {
            $error_info = $stmt->errorInfo();
            error_log('VA INSERT EXECUTE ERROR - Code: ' . $error_info[0] . ', Error: ' . $error_info[2]);
            error_log('VA INSERT VALUES: tagihan_id=' . $tagihan_id . ', nomor_va=' . $nomor_va . ', va_code=' . $va_code . ', metode=' . $metode_va . ', jumlah=' . $jumlah_va);
            throw new Exception('Gagal insert virtual_account ke database (Error ' . $error_info[0] . '): ' . $error_info[2]);
        }
        
        $va_id = $conn->lastInsertId();
        if (!$va_id) {
            error_log('VA INSERT SUCCESS but no lastInsertId');
            throw new Exception('Gagal mendapatkan ID virtual_account yang baru dibuat');
        }
        
        error_log('VA INSERT SUCCESS: va_id=' . $va_id . ', nomor_va=' . $nomor_va . ', tagihan_id=' . $tagihan_id);
        
    } catch (PDOException $e) {
        $conn->rollBack();
        error_log('PDOException while inserting virtual_account: Code=' . $e->getCode() . ', Message=' . $e->getMessage());
        sendError('VA_INSERT_ERROR', 'Gagal membuat Virtual Account di database. Silakan coba beberapa saat lagi atau hubungi administrator.', 500);
    } catch (Exception $e) {
        $conn->rollBack();
        error_log('Exception while inserting virtual_account: ' . $e->getMessage());
        sendError('VA_INSERT_ERROR', 'Gagal membuat Virtual Account. Silakan coba beberapa saat lagi atau hubungi administrator.', 500);
    }
    
    // ==========================================
    // STEP 12: LOCK TAGIHAN METODE PEMBAYARAN
    // =========================================
    // CATATAN: STATUS TIDAK BERUBAH saat VA dibuat
    // STATUS hanya berubah saat upload bukti pembayaran
    
    try {
        // Update metode_pembayaran - same for both cicilan and lunas
        $update_tagihan = "
            UPDATE tagihan 
            SET 
                metode_pembayaran = :metode
            WHERE tagihan_id = :tagihan_id
        ";
        
        $stmt = $conn->prepare($update_tagihan);
        if (!$stmt) {
            $error_info = $conn->errorInfo();
            error_log('TAGIHAN UPDATE PREPARE ERROR - Code: ' . $error_info[0] . ', Error: ' . $error_info[2]);
            throw new Exception('Gagal mempersiapkan query update tagihan: ' . $error_info[2]);
        }
        
        $stmt->bindParam(':metode', $method, PDO::PARAM_STR);
        $stmt->bindParam(':tagihan_id', $tagihan_id, PDO::PARAM_INT);
        
        if (!$stmt->execute()) {
            $error_info = $stmt->errorInfo();
            error_log('TAGIHAN UPDATE EXECUTE ERROR - Code: ' . $error_info[0] . ', Error: ' . $error_info[2]);
            throw new Exception('Gagal update status tagihan: ' . $error_info[2]);
        }
        
        error_log('TAGIHAN UPDATE SUCCESS: tagihan_id=' . $tagihan_id . ', method=' . $method);
        
    } catch (PDOException $e) {
        $conn->rollBack();
        error_log('PDOException while updating tagihan: ' . $e->getMessage());
        sendError('TAGIHAN_UPDATE_ERROR', 'Gagal mengupdate status tagihan. Virtual Account sudah dibuat, silakan hubungi administrator.', 500);
    } catch (Exception $e) {
        $conn->rollBack();
        error_log('Exception while updating tagihan: ' . $e->getMessage());
        sendError('TAGIHAN_UPDATE_ERROR', 'Gagal mengupdate status tagihan. Virtual Account sudah dibuat, silakan hubungi administrator.', 500);
    }
    
    // ==========================================
    // STEP 13: COMMIT TRANSACTION
    // ==========================================
    
    if (!$conn->commit()) {
        error_log('DB COMMIT ERROR - Failed to commit transaction');
        sendError('DB_COMMIT_ERROR', 'Gagal menyimpan perubahan ke database. Silakan coba beberapa saat lagi atau hubungi administrator.', 500);
    }
    
    error_log('TRANSACTION COMMITTED SUCCESSFULLY for tagihan_id=' . $tagihan_id);
    
    // ==========================================
    // STEP 14: RETURN SUCCESS RESPONSE
    // ==========================================
    
    error_log('VA successfully created: VA ID ' . $va_id . ', tagihan_id: ' . $tagihan_id . ', method: ' . $method);
    
    sendSuccess([
        'va_id' => (int)$va_id,
        'nomor_va' => $nomor_va,
        'status_va' => 'aktif',
        'metode_pembayaran' => $metode_va,
        'jumlah_va' => (float)$jumlah_va,
        'nominal_pembayaran' => (float)$jumlah_va,
        'method' => $method
    ], 'Virtual Account berhasil dibuat', 201);

} catch (PDOException $e) {
    // PDO Exception dari database
    error_log('Unhandled PDOException in create_virtual_account.php: Code=' . $e->getCode() . ', Message=' . $e->getMessage());
    error_log('PDOException Full Stack: ' . $e->getTraceAsString());
    sendError('DB_ERROR', 'Gagal membuat Virtual Account. Silakan coba beberapa saat lagi atau hubungi administrator.', 500);
    
} catch (Exception $e) {
    // Generic exception
    error_log('Unhandled Exception in create_virtual_account.php: ' . $e->getMessage());
    sendError('SYSTEM_ERROR', 'Terjadi kesalahan sistem. Silakan coba beberapa saat lagi atau hubungi administrator.', 500);
}
?>
