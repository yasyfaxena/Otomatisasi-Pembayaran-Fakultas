<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header('Location: mhs_login.php');
    exit;
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Upload Bukti Cicilan</title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; background-color: #f5f5f5; display: flex; }
        .sidebar { width: 260px; background-color: #1a1a1a; color: white; height: 100vh; position: fixed; left: 0; top: 0; }
        .logo { padding: 20px; text-align: center; border-bottom: 1px solid #333; }
        .logo img { width: 80px; }
        .user-info { padding: 30px 20px; text-align: center; border-bottom: 1px solid #333; }
        .user-id { font-size: 14px; margin-bottom: 8px; color: #999; }
        .user-name { font-size: 16px; font-weight: 600; }
        .menu { padding: 20px 0; }
        .menu-item { padding: 15px 20px; cursor: pointer; display: flex; align-items: center; gap: 12px; text-decoration: none; color: inherit; }
        .menu-item.active { background-color: #4CAF50; }
        .main-content { margin-left: 260px; flex: 1; padding: 30px 40px; }
        .header { margin-bottom: 30px; }
        .header-title { font-size: 28px; font-weight: 700; color: #333; }
        .section { background: white; padding: 30px; border-radius: 12px; margin-bottom: 25px; box-shadow: 0 4px 12px rgba(0,0,0,0.08); }
        .section-title { font-size: 20px; font-weight: 700; color: #333; margin-bottom: 20px; padding-bottom: 15px; border-bottom: 1px solid #eee; }
        .payment-info-box { background: #e3f2fd; padding: 20px; border-radius: 8px; margin-bottom: 20px; border-left: 5px solid #2196F3; }
        .info-item { display: grid; grid-template-columns: 180px 1fr; font-size: 15px; margin-bottom: 12px; }
        .info-label { color: #555; }
        .info-value { color: #333; font-weight: 600; }
        .info-value.highlight { font-family: 'Courier New', monospace; color: #0d47a1; }
        .form-group { margin-bottom: 20px; }
        .form-label { display: block; font-weight: 600; color: #555; margin-bottom: 8px; }
        .form-control { width: 100%; padding: 12px; border: 1px solid #ddd; border-radius: 8px; font-size: 15px; }
        .file-upload-box { border: 2px dashed #4CAF50; border-radius: 8px; padding: 40px; text-align: center; background: #f9f9f9; cursor: pointer; }
        .file-preview { margin-top: 15px; }
        .file-name { font-weight: 600; }
        .button-group { display: flex; gap: 12px; justify-content: flex-end; margin-top: 30px; }
        .btn { padding: 12px 25px; border: none; border-radius: 8px; font-weight: 700; cursor: pointer; text-decoration: none; font-size: 15px; }
        .btn-primary { background-color: #4CAF50; color: white; }
        .btn-primary:disabled { background-color: #ccc; cursor: not-allowed; }
        .btn-secondary { background-color: #6c757d; color: white; }
    </style>
</head>
<body>
    <aside class="sidebar">
        <!-- Sidebar content remains the same -->
    </aside>

    <main class="main-content">
        <header class="header"><h1 class="header-title" id="main-title">Upload Bukti Pembayaran</h1></header>

        <div class="section">
            <h2 class="section-title">Detail Pembayaran</h2>
            <div class="payment-info-box">
                <div class="info-item">
                    <span class="info-label">Virtual Account</span>
                    <span class="info-value highlight" id="info-va">-</span>
                </div>
                <div class="info-item">
                    <span class="info-label">Pembayaran</span>
                    <span class="info-value" id="info-type">-</span>
                </div>
                <div class="info-item">
                    <span class="info-label">Nominal Pembayaran</span>
                    <span class="info-value" id="info-total">-</span>
                </div>
            </div>
        </div>

        <div class="section" id="upload-section">
            <h2 class="section-title">Form Upload</h2>
            <div id="upload-form">
                <div class="form-group">
                    <label class="form-label">Bukti Transfer (JPG, PNG, PDF, maks 5MB)</label>
                    <input type="file" id="buktiFile" accept="image/*,.pdf" style="display: none;">
                    <div class="file-upload-box" id="upload-box">...</div>
                    <div class="file-preview" id="file-preview" style="display: none;">...</div>
                </div>
                <div class="form-group">
                    <label for="tanggalTransfer" class="form-label">Tanggal Transfer</label>
                    <input type="date" class="form-control" id="tanggalTransfer">
                </div>
                <div class="button-group">
                    <button id="back-btn" class="btn btn-secondary">Kembali</button>
                    <button class="btn btn-primary" id="submitBtn">Kirim Bukti</button>
                </div>
            </div>
        </div>
    </main>

    <script>
        document.addEventListener('DOMContentLoaded', function() {
            const params = new URLSearchParams(window.location.search);
            
            // Get parameters from URL
            const tagihan_id = params.get('tagihan_id');
            const va_number = params.get('va_number');
            const jenis_pembayaran = params.get('jenis_pembayaran');
            const total = params.get('total');
            const method = params.get('method');
            
            // Validate required parameters
            if (!tagihan_id || !va_number || !total || !method) {
                alert('Parameter tidak valid.');
                window.location.href = 'mhs_tagihan.php';
                return;
            }

            // --- 1. Populate Info ---
            document.getElementById('main-title').textContent = 'Upload Bukti Pembayaran';
            const formatRupiah = (angka) => 'Rp ' + (parseFloat(angka) || 0).toLocaleString('id-ID');
            document.getElementById('info-va').textContent = va_number;
            document.getElementById('info-type').textContent = jenis_pembayaran || 'Pembayaran';
            document.getElementById('info-total').textContent = formatRupiah(total);
            document.getElementById('tanggalTransfer').valueAsDate = new Date();

            // --- 2. Handle File Input ---
            let selectedFile = null;
            const fileInput = document.getElementById('buktiFile');
            const uploadBox = document.getElementById('upload-box');
            uploadBox.innerHTML = '<strong>Klik di sini</strong> untuk upload bukti';
            uploadBox.addEventListener('click', () => fileInput.click());
            fileInput.addEventListener('change', (e) => {
                selectedFile = e.target.files[0];
                if (selectedFile) {
                    uploadBox.textContent = `File dipilih: ${selectedFile.name}`;
                }
            });

            // --- 3. Handle Buttons ---
            const backBtn = document.getElementById('back-btn');
            backBtn.addEventListener('click', () => {
                window.location.href = `mhs_tagihan.php`;
            });
            
            const submitBtn = document.getElementById('submitBtn');
            submitBtn.addEventListener('click', async () => {
                if (!selectedFile) {
                    alert('Silakan pilih file bukti pembayaran.');
                    return;
                }

                // Validate file size (max 5MB)
                const maxSize = 5 * 1024 * 1024; // 5MB in bytes
                if (selectedFile.size > maxSize) {
                    alert('Ukuran file terlalu besar. Maksimal 5MB.');
                    return;
                }

                // Validate file type
                const allowedTypes = ['image/jpeg', 'image/png', 'application/pdf'];
                if (!allowedTypes.includes(selectedFile.type)) {
                    alert('Tipe file tidak didukung. Hanya JPG, PNG, atau PDF.');
                    return;
                }

                submitBtn.disabled = true;
                submitBtn.textContent = 'Mengunggah...';

                try {
                    // Create FormData for file upload
                    const formData = new FormData();
                    formData.append('bukti_file', selectedFile);
                    formData.append('tagihan_id', tagihan_id);
                    formData.append('va_number', va_number);
                    formData.append('tanggal_transfer', document.getElementById('tanggalTransfer').value);

                    // Upload to backend API
                    const response = await fetch('/projek_plbs/api/upload_payment_proof.php', {
                        method: 'POST',
                        body: formData,
                        credentials: 'same-origin'  // Include session cookies
                    });

                    console.log('Upload response status:', response.status);
                    
                    const result = await response.json();

                    if (result.status === 'success') {
                        alert('✅ Bukti pembayaran berhasil diunggah! Menunggu verifikasi admin.');
                        // Redirect to Riwayat Pembayaran to see the uploaded payment
                        window.location.href = `mhs_riwayat_pembayaran.php`;
                    } else {
                        alert('❌ ' + (result.message || 'Gagal mengunggah bukti pembayaran.'));
                        submitBtn.disabled = false;
                        submitBtn.textContent = 'Kirim Bukti';
                    }
                } catch (error) {
                    console.error('Upload error:', error);
                    console.error('Error details:', error.message);
                    alert('❌ Terjadi kesalahan saat mengunggah: ' + error.message);
                    submitBtn.disabled = false;
                    submitBtn.textContent = 'Kirim Bukti';
                }
            });
        });
    </script>
</body>
</html>

