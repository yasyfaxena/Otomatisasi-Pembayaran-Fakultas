<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header('Location: login_admin_fakultas.php');
    exit;
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Monitoring Cicilan - Tabel</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.13.1/font/bootstrap-icons.min.css">
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }

        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: #f5f5f5;
            display: flex;
        }

        .sidebar {
            width: 260px;
            background-color: #1a1a1a;
            color: white;
            height: 100vh;
            position: fixed;
            left: 0;
            top: 0;
        }

        .logo {
            padding: 20px;
            text-align: center;
            border-bottom: 1px solid #333;
        }

        .logo img { width: 80px; height: auto; }

        .user-info {
            padding: 30px 20px;
            text-align: center;
            border-bottom: 1px solid #333;
        }

        .user-id { font-size: 14px; margin-bottom: 8px; color: #999; }
        .user-name { font-size: 16px; font-weight: 600; }

        .user-actions {
            display: flex;
            gap: 8px;
            justify-content: center;
            margin-top: 12px;
        }

        .user-actions a {
            padding: 8px 12px;
            background: #dc3545;
            color: white;
            text-decoration: none;
            border-radius: 5px;
            font-size: 12px;
            transition: background 0.3s;
        }

        .user-actions a:hover {
            background: #c82333;
        }

        .menu { padding: 20px 0; }

        .menu-item {
            padding: 15px 20px;
            cursor: pointer;
            display: flex;
            align-items: center;
            gap: 12px;
            transition: background-color 0.3s;
            text-decoration: none;
            color: white;
        }

        .menu-item:hover { background-color: #333; }
        .menu-item.active { background-color: #4CAF50; }

        .menu-icon {
            width: 24px; height: 24px;
            display: flex; align-items: center; justify-content: center;
        }
        .menu a {
            text-decoration: none;
            color: inherit;
        }


        .main-content { margin-left: 260px; flex: 1; padding: 20px 40px; }

        .header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 30px;
            background: white;
            padding: 15px 25px;
            border-radius: 8px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
        }

        .header-title {
            font-size: 20px;
            color: #666;
            display: flex;
            align-items: center;
            gap: 15px;
        }

        .menu-dots { font-size: 24px; cursor: pointer; color: #999; }


        .section {
            background: white;
            border-radius: 8px;
            padding: 30px;
            margin-bottom: 30px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
        }

        .section-title {
            font-size: 22px;
            margin-bottom: 25px;
            color: #333;
            font-weight: 600;
            border-bottom: 2px solid #4169E1;
            padding-bottom: 10px;
        }

        .table-container {
            overflow-x: auto;
            margin-bottom: 20px;
            border: 1px solid #e9ecef;
            border-radius: 8px;
        }

        .cicilan-table { width: 100%; border-collapse: collapse; }

        .cicilan-table th {
            background-color: #f8f9fa;
            color: #333;
            font-weight: 600;
            text-align: left;
            padding: 15px 12px;
            border-bottom: 2px solid #dee2e6;
            font-size: 14px;
            white-space: nowrap;
        }

        .cicilan-table td {
            padding: 15px 12px;
            border-bottom: 1px solid #e9ecef;
            vertical-align: middle;
        }

        .cicilan-table tbody tr:last-child td { border-bottom: none; }
        .cicilan-table tbody tr:hover { background-color: #f8f9fa; }

        .data-cell { font-size: 14px; color: #333; font-weight: 500; }

        .status-badge {
            display: inline-block;
            padding: 6px 12px;
            border-radius: 20px;
            font-size: 12px;
            font-weight: 600;
            min-width: 100px;
            text-align: center;
            white-space: nowrap;
        }

        .status-belum-bayar { background-color: #f8d7da; color: #721c24; border: 1px solid #f5c6cb; }
        .status-cicilan { background-color: #fff3cd; color: #856404; border: 1px solid #ffeaa7; }
        .status-lunas { background-color: #d4edda; color: #155724; border: 1px solid #c3e6cb; }

        .action-cell { min-width: 140px; }

        .action-buttons {
            display: flex;
            gap: 6px;
            flex-wrap: nowrap;
            align-items: center;
        }

        .action-btn {
            padding: 6px 10px;
            border: none;
            border-radius: 4px;
            font-size: 12px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 4px;
            white-space: nowrap;
            min-width: 70px;
            height: 32px;
            flex: 1;
        }

        .btn-laporan { background-color: #17a2b8; color: white; }
        .btn-laporan:hover { background-color: #138496; transform: translateY(-2px); box-shadow: 0 4px 8px rgba(23, 162, 184, 0.3); }

        .filter-section {
            display: flex;
            gap: 15px;
            margin-bottom: 25px;
            flex-wrap: wrap;
            align-items: center;
            background-color: #f8f9fa;
            padding: 15px;
            border-radius: 6px;
        }

        .filter-group { display: flex; flex-direction: column; min-width: 180px; }
        .filter-label { font-size: 13px; font-weight: 600; margin-bottom: 5px; color: #495057; }

        .filter-select, .filter-input {
            padding: 8px 12px;
            border: 1px solid #ced4da;
            border-radius: 4px;
            font-size: 14px;
            background-color: white;
        }

        .filter-buttons { display: flex; gap: 10px; align-self: flex-end; margin-top: 10px; }

        .summary-stats {
            display: flex;
            gap: 20px;
            margin-bottom: 25px;
            flex-wrap: wrap;
        }

        .stat-card {
            flex: 1;
            min-width: 200px;
            background: white;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
        }

        .stat-title { font-size: 14px; color: #6c757d; margin-bottom: 10px; }
        .stat-value { font-size: 24px; font-weight: 700; color: #333; }

        .stat-total { border-left: 4px solid #007bff; }
        .stat-cicilan { border-left: 4px solid #ffc107; }
        .stat-lunas { border-left: 4px solid #28a745; }

        .pagination-container {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-top: 30px;
            padding-top: 20px;
            border-top: 1px solid #e9ecef;
        }

        .pagination-info { font-size: 14px; color: #6c757d; }

        .pagination-controls { display: flex; gap: 10px; align-items: center; }

        .page-btn {
            padding: 8px 16px;
            background-color: white;
            border: 1px solid #dee2e6;
            border-radius: 4px;
            cursor: pointer;
            font-size: 14px;
            font-weight: 600;
            display: flex;
            align-items: center;
            gap: 6px;
            transition: all 0.3s;
        }

        .page-btn:hover:not(:disabled) { background-color: #007bff; color: white; border-color: #007bff; }
        .page-btn:disabled { opacity: 0.5; cursor: not-allowed; }

        @media (max-width: 1200px) {
            .main-content { margin-left: 0; padding: 15px; }
            .sidebar { display: none; }
            .cicilan-table { font-size: 13px; }
            .action-buttons { flex-direction: row; flex-wrap: wrap; }
            .action-btn { min-width: 60px; font-size: 11px; padding: 5px 8px; }
        }

        @media (max-width: 768px) {
            .pagination-container { flex-direction: column; gap: 15px; }
            .filter-section { flex-direction: column; align-items: stretch; }
            .filter-buttons { align-self: stretch; justify-content: center; }
            .action-buttons { flex-direction: column; }
            .action-btn { width: 100%; }
            .summary-stats { flex-direction: column; }
        }
    </style>
</head>
<body>
    <div class="sidebar">
        <div class="logo">
            <img src="pictures/logo umi.png" alt="Logo">
        </div>
        <div class="user-info">
            <div class="user-name">Admin Fakultas</div>
            <div class="user-actions">
                <a href="#" onclick="logout(); return false;" style="background: #f59e0b;">Logout</a>
            </div>
        </div>
       <div class="menu">
            <a href="dashboard_admin_fakultas.php" class="menu-item">
                <div class="menu-icon"><i class="bi bi-house-door"></i></div>
                <div>Dashboard</div>
            </a>

            <a href="fk_aktivasi_KRS.php" class="menu-item">
                <div class="menu-icon"><i class="bi bi-clipboard-check"></i></div>
                <div>Aktivasi KRS</div>
            </a>

            <a href="fk_daftar_tagihan.php" class="menu-item">
                <div class="menu-icon"><i class="bi bi-card-checklist"></i></div>
                <div>Daftar Tagihan Mahasiswa</div>
            </a>

            <a href="fk_monitoring_cicilan.php" class="menu-item active">
                <div class="menu-icon"><i class="bi bi-graph-up"></i></div>
                <div>Monitoring Cicilan</div>
            </a>
        </div>
    </div>

    <div class="main-content">
        <div class="header">
            <div class="header-title">
                <span class="menu-dots">⋮</span>
                <span>Monitoring Cicilan Mahasiswa</span>
            </div>
        </div>

        <div class="section">
            <div class="section-title">📊 Status Cicilan Mahasiswa</div>

            <div class="summary-stats">
                <div class="stat-card stat-total">
                    <div class="stat-title">Total Mahasiswa</div>
                    <div class="stat-value" id="totalMahasiswa">15</div>
                </div>
                <div class="stat-card stat-cicilan">
                    <div class="stat-title">Dalam Cicilan</div>
                    <div class="stat-value" id="totalCicilan">8</div>
                </div>
                <div class="stat-card stat-lunas">
                    <div class="stat-title">Sudah Lunas</div>
                    <div class="stat-value" id="totalLunas">6</div>
                </div>
            </div>

            <div class="filter-section">
                <div class="filter-group">
                    <label class="filter-label">Semester</label>
                    <select class="filter-select" id="filterSemester">
                        <option value="">Semua Semester</option>
                        <option value="1">Semester 1</option>
                        <option value="2">Semester 2</option>
                        <option value="3">Semester 3</option>
                        <option value="4">Semester 4</option>
                        <option value="5">Semester 5</option>
                        <option value="6">Semester 6</option>
                    </select>
                </div>
                <div class="filter-group">
                    <label class="filter-label">Status Pembayaran</label>
                    <select class="filter-select" id="filterStatus">
                        <option value="">Semua Status</option>
                        <option value="belum">Belum Bayar</option>
                        <option value="cicilan">Cicilan</option>
                        <option value="lunas">Lunas</option>
                    </select>
                </div>
                <div class="filter-group">
                    <label class="filter-label">Cari NIM/Nama</label>
                    <input type="text" class="filter-input" id="filterSearch" placeholder="Ketik NIM atau nama...">
                </div>
                <div class="filter-buttons">
                    <button onclick="resetFilter()" style="padding: 8px 16px; background-color: #6c757d; color: white; border: none; border-radius: 4px; cursor: pointer;">Reset</button>
                </div>
            </div>

            <div class="table-container">
                <table class="cicilan-table">
                    <thead>
                        <tr>
                            <th>No</th>
                            <th>Nama Mahasiswa</th>
                            <th>NIM</th>
                            <th>Semester</th>
                            <th>Total Tagihan</th>
                            <th>Total Dibayar</th>
                            <th>Sisa Cicilan</th>
                            <th>Status Pembayaran</th>
                            <th>Aksi</th>
                        </tr>
                    </thead>
                    <tbody id="tableBody">
                        <!-- Akan diisi oleh JavaScript -->
                    </tbody>
                </table>
            </div>

            <div class="pagination-container">
                <div class="pagination-info">
                    <span id="paginationText">Menampilkan 1-10 dari 15 mahasiswa</span>
                </div>
                <div class="pagination-controls">
                    <button class="page-btn" onclick="previousPage()" id="prevBtn"><i class="bi bi-chevron-left"></i> Sebelumnya</button>
                    <button class="page-btn" onclick="nextPage()" id="nextBtn">Selanjutnya <i class="bi bi-chevron-right"></i></button>
                </div>
            </div>
        </div>
    </div>

    <script src="js/auth.js"></script>
    <script>
        // Data cicilan mahasiswa - diambil dari API backend
        let dataSheet = [];
        let currentPage = 1;
        let itemsPerPage = 10;
        let filteredData = [];

        // Load cicilan monitoring data dari API
        async function loadCicilanData() {
            const token = localStorage.getItem('auth_token');
            
            try {
                const response = await fetch(
                    '/projek_plbs/api/index.php/api/admin-fakultas/monitoring-cicilan?page=1&limit=500',
                    {
                        method: 'GET',
                        credentials: 'include',
                        headers: {
                            'Authorization': `Bearer ${token}`,
                            'Content-Type': 'application/json'
                        }
                    }
                );

                if (!response.ok) {
                    throw new Error(`HTTP ${response.status}`);
                }

                const data = await response.json();

                if (data.status === 'success' && data.data && data.data.daftar) {
                    // Transform API response ke format yang diharapkan frontend
                    dataSheet = data.data.daftar.map((item, index) => ({
                        no: index + 1,
                        nama: item.nama_mahasiswa,
                        nim: item.nim,
                        semester: parseInt(item.semester || '1', 10),
                        totalTagihan: item.total_tagihan,
                        totalDibayar: item.total_dibayar,
                        sisaCicilan: item.sisa_cicilan,
                        persentaseDibayar: item.persentase_dibayar || 0,
                        status: calculateStatus(item.total_dibayar, item.total_tagihan),
                        mahasiswaId: item.mahasiswa_id,
                        jenisCicilan: item.jenis_tagihan
                    }));

                    filteredData = [...dataSheet];
                    renderTable();
                    console.log(`✓ Loaded ${dataSheet.length} cicilan monitoring records from API`);
                } else {
                    console.warn('Failed to load cicilan data:', data.message);
                    alert('Gagal mengambil data cicilan. Silakan refresh halaman.');
                }
            } catch (error) {
                console.error('Error loading cicilan data:', error);
                alert('Terjadi kesalahan saat mengambil data cicilan. Cek koneksi internet Anda.');
            }
        }

        // Helper function untuk menentukan status berdasarkan data pembayaran
        function calculateStatus(totalDibayar, totalTagihan) {
            if (totalDibayar === 0) return 'belum';
            if (totalDibayar >= totalTagihan) return 'lunas';
            return 'cicilan';
        }

        function formatCurrency(value) {
            return new Intl.NumberFormat('id-ID', { style: 'currency', currency: 'IDR', minimumFractionDigits: 0 }).format(value);
        }

        function getStatusBadge(status) {
            if (status === 'belum') return 'status-belum-bayar';
            if (status === 'cicilan') return 'status-cicilan';
            if (status === 'lunas') return 'status-lunas';
        }

        function getStatusText(status) {
            if (status === 'belum') return 'Belum Bayar';
            if (status === 'cicilan') return 'Cicilan';
            if (status === 'lunas') return 'Lunas';
        }

        function renderTable() {
            const tableBody = document.getElementById('tableBody');
            tableBody.innerHTML = '';

            const start = (currentPage - 1) * itemsPerPage;
            const end = start + itemsPerPage;
            const pageData = filteredData.slice(start, end);

            pageData.forEach((row, index) => {
                const tr = document.createElement('tr');
                tr.innerHTML = `
                    <td class="data-cell">${start + index + 1}</td>
                    <td class="data-cell">${row.nama}</td>
                    <td class="data-cell">${row.nim}</td>
                    <td class="data-cell">${row.semester}</td>
                    <td class="data-cell">${formatCurrency(row.totalTagihan)}</td>
                    <td class="data-cell">${formatCurrency(row.totalDibayar)}</td>
                    <td class="data-cell">${formatCurrency(row.sisaCicilan)}</td>
                    <td class="data-cell">
                        <span class="status-badge ${getStatusBadge(row.status)}">
                            ${getStatusText(row.status)}
                        </span>
                    </td>
                    <td class="action-cell">
                        <div class="action-buttons">
                            <button class="action-btn btn-laporan" onclick="viewReport(${row.mahasiswaId}, '${row.nim}', '${row.nama}')">
                                <i class="bi bi-file-earmark"></i> Laporan
                            </button>
                        </div>
                    </td>
                `;
                tableBody.appendChild(tr);
            });

            updatePagination();
        }

        function updatePagination() {
            const totalPages = Math.ceil(filteredData.length / itemsPerPage);
            document.getElementById('paginationText').textContent = 
                `Menampilkan ${Math.min((currentPage - 1) * itemsPerPage + 1, filteredData.length)}-${Math.min(currentPage * itemsPerPage, filteredData.length)} dari ${filteredData.length} mahasiswa`;
            
            document.getElementById('prevBtn').disabled = currentPage === 1;
            document.getElementById('nextBtn').disabled = currentPage === totalPages;

            const totalBelumBayar = filteredData.filter(d => d.status === 'belum').length;
            const totalCicilan = filteredData.filter(d => d.status === 'cicilan').length;
            const totalLunas = filteredData.filter(d => d.status === 'lunas').length;

            document.getElementById('totalMahasiswa').textContent = filteredData.length;
            document.getElementById('totalCicilan').textContent = totalCicilan;
            document.getElementById('totalLunas').textContent = totalLunas;
        }

        function nextPage() {
            const totalPages = Math.ceil(filteredData.length / itemsPerPage);
            if (currentPage < totalPages) {
                currentPage++;
                renderTable();
                window.scrollTo({ top: 0, behavior: 'smooth' });
            }
        }

        function previousPage() {
            if (currentPage > 1) {
                currentPage--;
                renderTable();
                window.scrollTo({ top: 0, behavior: 'smooth' });
            }
        }

        function applyFilter() {
            const semester = document.getElementById('filterSemester').value;
            const status = document.getElementById('filterStatus').value;
            const search = document.getElementById('filterSearch').value.toLowerCase();

            filteredData = dataSheet.filter(row => {
                const matchSemester = !semester || row.semester.toString() === semester;
                const matchStatus = !status || row.status === status;
                const matchSearch = !search || row.nama.toLowerCase().includes(search) || row.nim.includes(search);
                return matchSemester && matchStatus && matchSearch;
            });

            currentPage = 1;
            renderTable();
        }

        function resetFilter() {
            document.getElementById('filterSemester').value = '';
            document.getElementById('filterStatus').value = '';
            document.getElementById('filterSearch').value = '';
            filteredData = [...dataSheet];
            currentPage = 1;
            renderTable();
        }

        function viewReport(mahasiswaId, nim, nama) {
            window.location.href = `fk_laporan_pembayaran.php?mahasiswa_id=${mahasiswaId}&nim=${nim}&nama=${encodeURIComponent(nama)}`;
        }

        // Event listeners untuk filter
        document.getElementById('filterSemester').addEventListener('change', applyFilter);
        document.getElementById('filterStatus').addEventListener('change', applyFilter);
        document.getElementById('filterSearch').addEventListener('keyup', applyFilter);

        // Initial render dengan authentication
        document.addEventListener('DOMContentLoaded', function() {
            // Setup authentication
            requireAuth('admin_fakultas');
            
            // Update user info in sidebar
            const user = getCurrentUser();
            if (user) {
                document.querySelector('.user-name').textContent = user.nama_lengkap || 'Admin';
            }
            
            // Load cicilan data from API
            loadCicilanData();
        });
    </script>
</body>
</html>


