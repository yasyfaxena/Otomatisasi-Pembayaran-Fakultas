<?php
session_start();
?>
<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Login Admin Universitas</title>

<!-- Font Awesome -->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">

<style>
:root {
    --primary: #246140;
    --primary-dark: #113120;
    --bg: #f5f7fa;
    --card: #ffffff;
    --text: #333;
    --muted: #777;
}

* {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
    font-family: 'Segoe UI', Tahoma, sans-serif;
}

body {
    min-height: 100vh;
    background: var(--bg);
}

/* ===== LAYOUT ===== */
.login-wrapper {
    display: flex;
    min-height: 100vh;
}

/* ===== LEFT (LOGO) ===== */
.login-left {
    flex: 1;
    background: linear-gradient(135deg, #113120, #246140);
    color: white;
    display: flex;
    align-items: center;
    justify-content: center;
    padding: 40px;
}

.brand {
    text-align: center;
}

.brand img {
    max-width: 250px;
    width: 100%;
    height: auto;
    margin-bottom: 20px;
}

.brand h1 {
    font-size: 26px;
    margin-bottom: 10px;
}

.brand p {
    font-size: 14px;
    opacity: 0.9;
}

/* ===== RIGHT (FORM) ===== */
.login-right {
    flex: 1;
    display: flex;
    align-items: center;
    justify-content: center;
    padding: 40px;
}

.login-box {
    width: 100%;
    max-width: 380px;
    background: var(--card);
    padding: 35px;
    border-radius: 14px;
    box-shadow: 0 15px 40px rgba(0,0,0,0.12);
}

.login-box h2 {
    text-align: center;
    color: var(--primary-dark);
    margin-bottom: 5px;
}

.login-box p {
    text-align: center;
    font-size: 14px;
    color: var(--muted);
    margin-bottom: 25px;
}

.form-group {
    margin-bottom: 18px;
}

.form-group label {
    font-size: 14px;
    display: block;
    margin-bottom: 6px;
}

.input-wrapper {
    position: relative;
}

.input-wrapper i {
    position: absolute;
    top: 50%;
    left: 12px;
    transform: translateY(-50%);
    color: var(--muted);
}

.input-wrapper input {
    width: 100%;
    padding: 12px 12px 12px 38px;
    border-radius: 8px;
    border: 1px solid #ddd;
    font-size: 14px;
    outline: none;
    transition: 0.3s;
}

.input-wrapper input:focus {
    border-color: var(--primary);
    box-shadow: 0 0 0 2px rgba(36,97,64,0.15);
}

.btn-login {
    width: 100%;
    padding: 12px;
    background: linear-gradient(135deg, #113120, #246140);
    border: none;
    border-radius: 10px;
    color: white;
    font-size: 15px;
    font-weight: 600;
    cursor: pointer;
    transition: 0.3s;
}

.btn-login:hover:not(:disabled) {
    opacity: 0.9;
    transform: translateY(-1px);
}

.btn-login:disabled {
    opacity: 0.6;
    cursor: not-allowed;
}

.message {
    display: none;
    margin-bottom: 15px;
    padding: 12px;
    border-radius: 8px;
    text-align: center;
    font-size: 14px;
}

.message.error {
    background: #fee;
    color: #c33;
    border: 1px solid #fcc;
}

.message.success {
    background: #efe;
    color: #3c3;
    border: 1px solid #cfc;
}

.login-footer {
    text-align: center;
    margin-top: 18px;
    font-size: 13px;
}

.login-footer a {
    color: var(--primary);
    text-decoration: none;
    font-weight: 600;
}

.login-footer a:hover {
    text-decoration: underline;
}

/* ===== RESPONSIVE ===== */
@media (max-width: 768px) {
    .login-wrapper {
        flex-direction: column;
    }

    .login-left {
        min-height: 220px;
    }

    .brand img {
        max-width: 130px;
    }
}
</style>
</head>

<body>

<div class="login-wrapper">

    <!-- KIRI : LOGO -->
    <div class="login-left">
        <div class="brand">
            <img src="pictures/logo umi.png" alt="Logo Universitas">
            <h1>Universitas Muslim Indonesia</h1>
            <p>Admin Universitas</p>
        </div>
    </div>

    <!-- KANAN : FORM LOGIN -->
    <div class="login-right">
        <div class="login-box">
            <h2>Login Admin Universitas</h2>
            <p>Masukkan akun administrator universitas</p>

            <div id="errorMessage" class="message error"></div>
            <div id="successMessage" class="message success"></div>

            <form id="loginForm">
                <div class="form-group">
                    <label>Username / Email</label>
                    <div class="input-wrapper">
                        <i class="fas fa-user-shield"></i>
                        <input type="text" id="username" name="username" placeholder="Masukkan username" required>
                    </div>
                </div>

                <div class="form-group">
                    <label>Password</label>
                    <div class="input-wrapper">
                        <i class="fas fa-lock"></i>
                        <input type="password" id="password" name="password" placeholder="Masukkan password" required>
                    </div>
                </div>

                <button type="submit" class="btn-login" id="loginBtn">
                    <i class="fas fa-right-to-bracket"></i> Login
                </button>
            </form>

            <div class="login-footer">
                <a href="lupa_password.php">Lupa password?</a>
            </div>
        </div>
    </div>

</div>

<script>
document.getElementById('loginForm').addEventListener('submit', async function(e) {
    e.preventDefault();

    const username = document.getElementById('username').value.trim();
    const password = document.getElementById('password').value;
    const loginBtn = document.getElementById('loginBtn');
    const errorMsg = document.getElementById('errorMessage');
    const successMsg = document.getElementById('successMessage');

    // Clear messages
    errorMsg.style.display = 'none';
    successMsg.style.display = 'none';

    if (!username || !password) {
        errorMsg.textContent = 'Username dan password harus diisi';
        errorMsg.style.display = 'block';
        return;
    }

    loginBtn.disabled = true;
    loginBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Sedang login...';

    try {
        const response = await fetch('/projek_plbs/api/index.php/api/auth/login', {
            method: 'POST',
            credentials: 'include',  // ⭐ PENTING: Kirim & terima session cookie
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                username: username,
                password: password
            })
        });

        const data = await response.json();

        if (data.status === 'success') {
            // Verify role is admin_universitas
            if (data.data.role !== 'admin_universitas') {
                errorMsg.textContent = 'Akun ini bukan admin universitas. Silakan gunakan akun yang sesuai.';
                errorMsg.style.display = 'block';
                loginBtn.disabled = false;
                loginBtn.innerHTML = '<i class="fas fa-right-to-bracket"></i> Login';
                return;
            }

            // Save token dan user data
            localStorage.setItem('auth_token', data.data.token);
            localStorage.setItem('user_id', data.data.user_id);
            localStorage.setItem('username', data.data.username);
            localStorage.setItem('role', data.data.role);
            localStorage.setItem('nama_lengkap', data.data.nama_lengkap);

            successMsg.textContent = 'Login berhasil! Mengarahkan ke dashboard...';
            successMsg.style.display = 'block';

            setTimeout(() => {
                window.location.href = 'dashboard_admin_universitas.php';
            }, 1500);
        } else {
            errorMsg.textContent = data.message || 'Login gagal. Periksa kembali username dan password Anda.';
            errorMsg.style.display = 'block';
        }
    } catch (error) {
        errorMsg.textContent = 'Terjadi kesalahan: ' + error.message;
        errorMsg.style.display = 'block';
    } finally {
        loginBtn.disabled = false;
        loginBtn.innerHTML = '<i class="fas fa-right-to-bracket"></i> Login';
    }
});
</script>

</body>
</html>



