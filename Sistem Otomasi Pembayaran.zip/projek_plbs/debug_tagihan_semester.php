<?php
/**
 * DEBUG: Check why next semester tagihan doesn't appear
 */

require_once __DIR__ . '/api/config/Database.php';
require_once __DIR__ . '/api/config/helpers.php';

$db = Database::getInstance();

// Get a mahasiswa that paid semester 1 lunas
$check_query = "SELECT m.mahasiswa_id, m.nim_or_id, m.user_id, t.semester, t.status_pembayaran, t.metode_pembayaran, t.jumlah_tagihan
                FROM mahasiswa m
                LEFT JOIN tagihan t ON m.mahasiswa_id = t.mahasiswa_id AND t.jenis_tagihan = 'BPP'
                WHERE t.status_pembayaran = 'lunas'
                ORDER BY m.mahasiswa_id DESC, t.semester DESC
                LIMIT 20";

$stmt = $db->prepare($check_query);
$stmt->execute();
$results = $stmt->fetchAll();

echo "<h3>Mahasiswa dengan Pembayaran Lunas:</h3>";
echo "<table border='1' cellpadding='10'>";
echo "<tr><th>Mahasiswa ID</th><th>NIM</th><th>Semester Dibayar</th><th>Status</th><th>Metode</th><th>Jumlah</th></tr>";

$mahasiswa_ids = [];
foreach ($results as $row) {
    if (!in_array($row['mahasiswa_id'], $mahasiswa_ids)) {
        $mahasiswa_ids[] = $row['mahasiswa_id'];
    }
    echo "<tr>";
    echo "<td>" . $row['mahasiswa_id'] . "</td>";
    echo "<td>" . $row['nim_or_id'] . "</td>";
    echo "<td>" . ($row['semester'] ?? 'N/A') . "</td>";
    echo "<td>" . ($row['status_pembayaran'] ?? 'N/A') . "</td>";
    echo "<td>" . ($row['metode_pembayaran'] ?? 'N/A') . "</td>";
    echo "<td>Rp " . number_format($row['jumlah_tagihan'] ?? 0, 0, ',', '.') . "</td>";
    echo "</tr>";
}
echo "</table>";

// For first mahasiswa, check if next semester is created
if (!empty($mahasiswa_ids)) {
    $test_mhs_id = $mahasiswa_ids[0];
    echo "<h3>Debug untuk Mahasiswa ID: " . $test_mhs_id . "</h3>";
    
    $highest = getHighestPaidBPPSemester($db, $test_mhs_id);
    $next_unpaid = getNextUnpaidBPPSemester($db, $test_mhs_id);
    
    echo "Highest Paid BPP Semester: " . $highest . "<br>";
    echo "Next Unpaid BPP Semester: " . $next_unpaid . "<br>";
    
    // Check if next semester already exists
    $check_next = "SELECT * FROM tagihan 
                   WHERE mahasiswa_id = :mhs_id 
                   AND jenis_tagihan = 'BPP' 
                   AND semester = :semester";
    
    $stmt = $db->prepare($check_next);
    $stmt->execute(['mhs_id' => $test_mhs_id, 'semester' => $next_unpaid]);
    $next_sem_tagihan = $stmt->fetch();
    
    echo "<br>Tagihan untuk Semester " . $next_unpaid . ":<br>";
    if ($next_sem_tagihan) {
        echo "Status: " . $next_sem_tagihan['status_pembayaran'] . "<br>";
        echo "Metode: " . $next_sem_tagihan['metode_pembayaran'] . "<br>";
        echo "Jumlah: Rp " . number_format($next_sem_tagihan['jumlah_tagihan'], 0, ',', '.') . "<br>";
    } else {
        echo "❌ TIDAK ADA TAGIHAN UNTUK SEMESTER " . $next_unpaid . "<br>";
    }
    
    // Check if this mahasiswa paid semester 1 completely
    $check_sem1 = "SELECT * FROM tagihan 
                   WHERE mahasiswa_id = :mhs_id 
                   AND jenis_tagihan = 'BPP' 
                   AND semester = 1";
    
    $stmt = $db->prepare($check_sem1);
    $stmt->execute(['mhs_id' => $test_mhs_id]);
    $sem1 = $stmt->fetch();
    
    echo "<br>Info Semester 1:<br>";
    if ($sem1) {
        echo "Status Semester 1: " . $sem1['status_pembayaran'] . "<br>";
        echo "Total Tagihan: Rp " . number_format($sem1['jumlah_tagihan'], 0, ',', '.') . "<br>";
        
        // Check cicilan detail
        $cicilan_query = "SELECT cd.*, cp.jumlah_pembayaran, cp.tgl_pembayaran 
                         FROM cicilan_detail cd
                         LEFT JOIN cicilan_pembayaran cp ON cd.cicilan_id = cp.cicilan_id
                         WHERE cd.tagihan_id = :tagihan_id
                         ORDER BY cd.cicilan_ke ASC";
        
        $stmt = $db->prepare($cicilan_query);
        $stmt->execute(['tagihan_id' => $sem1['tagihan_id']]);
        $cicilan_details = $stmt->fetchAll();
        
        echo "<br>Detail Cicilan Semester 1:<br>";
        echo "<table border='1' cellpadding='5'>";
        echo "<tr><th>Cicilan Ke</th><th>Jumlah</th><th>Terbayar</th><th>Status</th><th>Tgl Bayar</th></tr>";
        $total_terbayar = 0;
        foreach ($cicilan_details as $cd) {
            $total_terbayar += (int)$cd['jumlah_pembayaran'];
            echo "<tr>";
            echo "<td>" . $cd['cicilan_ke'] . "</td>";
            echo "<td>Rp " . number_format($cd['jumlah_cicilan'], 0, ',', '.') . "</td>";
            echo "<td>Rp " . number_format($cd['jumlah_terbayar'], 0, ',', '.') . "</td>";
            echo "<td>" . $cd['status_cicilan'] . "</td>";
            echo "<td>" . ($cd['tgl_pembayaran'] ?? '-') . "</td>";
            echo "</tr>";
        }
        echo "</table>";
        echo "<br>Total Terbayar: Rp " . number_format($total_terbayar, 0, ',', '.') . "<br>";
    }
}
?>
