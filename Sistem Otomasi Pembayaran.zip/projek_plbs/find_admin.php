<?php
require_once __DIR__ . '/api/config/database.php';

$pdo = (new Database())->connect();
$stmt = $pdo->prepare('SELECT user_id, username, role FROM users LIMIT 5');
$stmt->execute();
$results = $stmt->fetchAll();

echo "Users in database:\n";
foreach ($results as $r) {
    echo "  ID: {$r['user_id']}, Username: {$r['username']}, Role: {$r['role']}\n";
}

?>
