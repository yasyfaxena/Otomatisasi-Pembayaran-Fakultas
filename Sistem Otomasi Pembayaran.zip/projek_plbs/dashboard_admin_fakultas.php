<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header('Location: login_admin_fakultas.php');
    exit;
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard Admin Fakultas</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.13.1/font/bootstrap-icons.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: #f5f5f5;
            display: flex;
        }

        .sidebar {
            width: 260px;
            background-color: #1a1a1a;
            color: white;
            height: 100vh;
            position: fixed;
            left: 0;
            top: 0;
            overflow-y: auto;
        }

        .logo {
            padding: 20px;
            text-align: center;
            border-bottom: 1px solid #333;
        }

        .logo img {
            width: 80px;
            height: auto;
        }

        .user-info {
            padding: 30px 20px;
            text-align: center;
            border-bottom: 1px solid #333;
        }

        .user-id {
            font-size: 14px;
            margin-bottom: 8px;
            color: #999;
        }

        .user-name {
            font-size: 16px;
            font-weight: 600;
            margin-bottom: 15px;
        }

        .user-actions {
            display: flex;
            gap: 8px;
            justify-content: center;
        }

        .user-actions a {
            padding: 8px 12px;
            background: #f59e0b;
            color: white;
            text-decoration: none;
            border-radius: 5px;
            font-size: 12px;
            transition: background 0.3s;
        }

        .user-actions a:hover {
            background: #d97706;
        }

        .user-actions a.logout {
            background: #dc3545;
        }

        .user-actions a.logout:hover {
            background: #c82333;
        }

        .menu {
            padding: 20px 0;
        }

        .menu-item {
            padding: 15px 20px;
            display: flex;
            align-items: center;
            gap: 12px;
            text-decoration: none;
            color: white;
            transition: background-color 0.3s;
        }

        .menu-item.active {
            background-color: #4CAF50;
        }

        .menu-item:hover {
            background-color: #333;
        }

        .menu-icon {
            width: 24px;
            height: 24px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 16px;
        }

        .menu a {
            text-decoration: none;
            color: inherit;
        }

        .main-content {
            margin-left: 260px;
            flex: 1;
            padding: 20px 40px;
        }

        .header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 30px;
            background: white;
            padding: 15px 25px;
            border-radius: 8px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
        }

        .header-title {
            font-size: 20px;
            color: #666;
            display: flex;
            align-items: center;
            gap: 15px;
        }

        .menu-dots {
            font-size: 24px;
            cursor: pointer;
            color: #999;
        }

        .user-avatar {
            width: 32px;
            height: 32px;
            background-color: #666;
            border-radius: 50%;
            cursor: pointer;
        }

        .section {
            background: white;
            border-radius: 8px;
            padding: 30px;
            margin-bottom: 30px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
        }

        .section-title {
            font-size: 22px;
            margin-bottom: 25px;
            color: #333;
            font-weight: 600;
            border-bottom: 2px solid #4169E1;
            padding-bottom: 10px;
        }

        .stats-container {
            display: flex;
            gap: 20px;
            margin-bottom: 30px;
            flex-wrap: wrap;
        }

        .stat-card {
            flex: 1;
            min-width: 200px;
            padding: 25px;
            border-radius: 12px;
            color: white;
            display: flex;
            align-items: center;
            gap: 20px;
            box-shadow: 0 4px 6px rgba(0,0,0,0.1);
            transition: transform 0.3s;
        }

        .stat-card:hover {
            transform: translateY(-5px);
        }

        .stat-card.blue {
            background: linear-gradient(135deg, #4169E1 0%, #2E5BBE 100%);
        }

        .stat-card.green {
            background: linear-gradient(135deg, #4CAF50 0%, #45A049 100%);
        }

        .stat-card.orange {
            background: linear-gradient(135deg, #FF9800 0%, #F57C00 100%);
        }

        .stat-card.red {
            background: linear-gradient(135deg, #EF5350 0%, #E53935 100%);
        }

        .stat-icon {
            width: 60px;
            height: 60px;
            background: rgba(255, 255, 255, 0.2);
            border-radius: 12px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 28px;
            flex-shrink: 0;
        }

        .stat-content {
            flex: 1;
        }

        .stat-label {
            font-size: 13px;
            opacity: 0.9;
            margin-bottom: 8px;
            font-weight: 500;
        }

        .stat-value {
            font-size: 28px;
            font-weight: 700;
            margin-bottom: 5px;
        }

        .stat-subtitle {
            font-size: 12px;
            opacity: 0.85;
        }

        .content-row {
            display: flex;
            gap: 30px;
            margin-top: 30px;
            flex-wrap: wrap;
        }

        .content-col {
            flex: 1;
            min-width: 300px;
        }

        .activity-list {
            list-style: none;
        }

        .activity-item {
            display: flex;
            gap: 20px;
            margin-bottom: 25px;
            padding-bottom: 20px;
            border-bottom: 1px solid #e9ecef;
        }

        .activity-item:last-child {
            border-bottom: none;
            margin-bottom: 0;
            padding-bottom: 0;
        }

        .activity-icon {
            width: 48px;
            height: 48px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 20px;
            flex-shrink: 0;
        }

        .activity-success {
            background-color: #d4edda;
            color: #155724;
        }

        .activity-warning {
            background-color: #fff3cd;
            color: #856404;
        }

        .activity-info {
            background-color: #d1ecf1;
            color: #0c5460;
        }

        .activity-content {
            flex: 1;
        }

        .activity-title {
            font-size: 15px;
            font-weight: 600;
            color: #333;
            margin-bottom: 5px;
        }

        .activity-desc {
            font-size: 13px;
            color: #666;
            line-height: 1.5;
            margin-bottom: 5px;
        }

        .activity-time {
            font-size: 12px;
            color: #999;
        }

        .payment-item {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 20px;
            border: 1px solid #e9ecef;
            border-radius: 8px;
            margin-bottom: 15px;
            transition: all 0.3s;
        }

        .payment-item:hover {
            box-shadow: 0 4px 8px rgba(0,0,0,0.1);
        }

        .payment-info h4 {
            font-size: 15px;
            color: #333;
            margin-bottom: 5px;
        }

        .payment-info p {
            font-size: 13px;
            color: #999;
        }

        .payment-amount {
            font-size: 18px;
            font-weight: 700;
            color: #333;
            min-width: 120px;
            text-align: right;
        }

        .payment-status {
            padding: 6px 16px;
            border-radius: 20px;
            font-size: 12px;
            font-weight: 600;
            min-width: 100px;
            text-align: center;
        }

        .status-paid {
            background-color: #d4edda;
            color: #155724;
        }

        .status-pending {
            background-color: #fff3cd;
            color: #856404;
        }

        .status-overdue {
            background-color: #f8d7da;
            color: #721c24;
        }

        .quick-action-card {
            flex: 1;
            min-width: 180px;
            padding: 25px;
            border-radius: 12px;
            background: white;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
            text-decoration: none;
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            gap: 15px;
            transition: all 0.3s ease;
            color: #333;
            border: 2px solid transparent;
        }

        .quick-action-card:hover {
            box-shadow: 0 8px 16px rgba(0,0,0,0.15);
            transform: translateY(-5px);
            border-color: #4CAF50;
        }

        .footer {
            text-align: center;
            padding: 20px;
            color: #666;
            font-size: 14px;
            margin-top: 40px;
            border-top: 1px solid #e0e0e0;
        }

        @media (max-width: 768px) {
            .main-content {
                margin-left: 0;
                padding: 15px;
            }

            .sidebar {
                display: none;
            }

            .stats-container {
                flex-direction: column;
            }

            .stat-card {
                flex-direction: column;
                text-align: center;
            }

            .content-row {
                flex-direction: column;
            }

            .header {
                flex-direction: column;
                align-items: flex-start;
                gap: 15px;
            }
        }
    </style>
</head>
<body>
    <!-- Sidebar -->
    <div class="sidebar">
        <div class="logo">
          <img src="pictures/logo umi.png" alt="Logo">
        </div>

        <div class="user-info">
            <div class="user-name">Admin Fakultas</div>
            <div class="user-actions">
                <a href="#" onclick="logout(); return false;">Logout</a>
            </div>
        </div>

        <nav class="menu">
            <a href="dashboard_admin_fakultas.php" class="menu-item active">
                <div class="menu-icon"><i class="bi bi-house-door"></i></div>
                <div>Dashboard</div>
            </a>
            <a href="fk_aktivasi_KRS.php" class="menu-item">
                <div class="menu-icon"><i class="bi bi-clipboard-check"></i></div>
                <div>Aktivasi KRS</div>
            </a>
            <a href="fk_daftar_tagihan.php" class="menu-item">
                <div class="menu-icon"><i class="bi bi-card-checklist"></i></div>
                <div>Daftar Tagihan Mahasiswa</div>
            </a>
            <a href="fk_monitoring_cicilan.php" class="menu-item">
                <div class="menu-icon"><i class="bi bi-graph-up"></i></div>
                <div>Monitoring Cicilan</div>
            </a>
        </nav>
    </div>

    <!-- Main Content -->
    <div class="main-content">
        <!-- Header -->
        <div class="header">
            <div class="header-title">
                <i class="bi bi-list" style="color: #999; cursor: pointer; font-size: 20px;"></i>
                <span>Dashboard Admin Fakultas</span>
            </div>
            <div style="display: flex; align-items: center; gap: 15px;">
                <div class="menu-dots">
                    <i class="bi bi-three-dots-vertical"></i>
                </div>
                <?php
                // NO AVATAR for admin_fakultas (role-based logic)
                // Avatar only shown for mahasiswa role
                ?>
            </div>
        </div>

        <!-- Stats Section -->
        <div class="section">
            <div class="stats-container">
                <div class="stat-card blue">
                    <div class="stat-icon">
                        <i class="bi bi-people"></i>
                    </div>
                    <div class="stat-content">
                        <div class="stat-label">Total Mahasiswa</div>
                        <div class="stat-value" id="totalMahasiswa">0</div>
                        <div class="stat-subtitle">Jumlah aktif</div>
                    </div>
                </div>

                <div class="stat-card green">
                    <div class="stat-icon">
                        <i class="bi bi-check-circle"></i>
                    </div>
                    <div class="stat-content">
                        <div class="stat-label">Pembayaran Lunas</div>
                        <div class="stat-value" id="pembayaranLunas">0</div>
                        <div class="stat-subtitle" id="persenLunas">0% mahasiswa</div>
                    </div>
                </div>

                <div class="stat-card orange">
                    <div class="stat-icon">
                        <i class="bi bi-hourglass-split"></i>
                    </div>
                    <div class="stat-content">
                        <div class="stat-label">Status Cicilan</div>
                        <div class="stat-value" id="statusCicilan">0</div>
                        <div class="stat-subtitle">Dalam proses</div>
                    </div>
                </div>

                <div class="stat-card red">
                    <div class="stat-icon">
                        <i class="bi bi-exclamation-circle"></i>
                    </div>
                    <div class="stat-content">
                        <div class="stat-label">Belum Bayar</div>
                        <div class="stat-value" id="belumBayar">0</div>
                        <div class="stat-subtitle">Perlu tindakan</div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Quick Actions -->
        <div class="section">
            <h2 class="section-title">Akses Cepat</h2>
            <div class="stats-container">
                <a href="fk_aktivasi_KRS.php" class="quick-action-card">
                    <div style="width: 60px; height: 60px; background: #e3f2fd; border-radius: 12px; display: flex; align-items: center; justify-content: center; font-size: 28px; color: #4169E1;"><i class="bi bi-clipboard-check"></i></div>
                    <span style="font-size: 16px; font-weight: 600;">Aktivasi KRS</span>
                </a>
                <a href="fk_daftar_tagihan.php" class="quick-action-card">
                    <div style="width: 60px; height: 60px; background: #f3e5f5; border-radius: 12px; display: flex; align-items: center; justify-content: center; font-size: 28px; color: #9c27b0;"><i class="bi bi-card-checklist"></i></div>
                    <span style="font-size: 16px; font-weight: 600;">Daftar Tagihan</span>
                </a>
                <a href="fk_monitoring_cicilan.php" class="quick-action-card">
                    <div style="width: 60px; height: 60px; background: #e8f5e9; border-radius: 12px; display: flex; align-items: center; justify-content: center; font-size: 28px; color: #4CAF50;"><i class="bi bi-eye"></i></div>
                    <span style="font-size: 16px; font-weight: 600;">Monitoring Cicilan</span>
                </a>
                <a href="fk_laporan_pembayaran.php" class="quick-action-card">
                    <div style="width: 60px; height: 60px; background: #fff3e0; border-radius: 12px; display: flex; align-items: center; justify-content: center; font-size: 28px; color: #FF9800;"><i class="bi bi-bar-chart"></i></div>
                    <span style="font-size: 16px; font-weight: 600;">Laporan Pembayaran</span>
                </a>
            </div>
        </div>

        <!-- Content Row -->
        <div class="content-row">
            <!-- Recent Activity -->
            <div class="content-col">
                <div class="section">
                    <h2 class="section-title">Aktivitas Terbaru</h2>
                    <div class="activity-list" id="activityList">
                        <!-- Populated by JavaScript -->
                        <p style="color: #999; text-align: center; padding: 20px;">Memuat data aktivitas...</p>
                    </div>
                </div>
            </div>

            <!-- Payment Status -->
            <div class="content-col">
                <div class="section">
                    <h2 class="section-title">Status Pembayaran</h2>
                    <div id="paymentStatus">
                        <!-- Populated by JavaScript -->
                        <p style="color: #999; text-align: center; padding: 20px;">Memuat data pembayaran...</p>
                    </div>
                </div>
            </div>
        </div>

        <!-- Footer -->
        <div class="footer">
            <p>&copy; 2025 PLBS - Sistem Pembayaran Kampus. Hak Cipta Dilindungi.</p>
            <p>Versi 2.1.0 | Terakhir diperbarui: 25 Agustus 2025</p>
        </div>
    </div>

    <script src="js/auth.js"></script>
    <script>
        // Fungsi untuk format Rupiah
        function formatRupiah(angka) {
            return new Intl.NumberFormat('id-ID', {
                style: 'currency',
                currency: 'IDR'
            }).format(angka);
        }

        // Fungsi untuk mendapatkan token dari localStorage
        function getAuthToken() {
            return localStorage.getItem('auth_token');
        }

        // ===== FETCH DASHBOARD STATISTICS =====
        async function fetchDashboardData() {
            try {
                const token = getAuthToken();
                if (!token) {
                    console.error('No auth token found');
                    return;
                }

                const response = await fetch('/projek_plbs/api/index.php/api/admin-fakultas/dashboard-info', {
                    method: 'GET',
                    credentials: 'include',
                    headers: {
                        'Authorization': `Bearer ${token}`,
                        'Content-Type': 'application/json'
                    }
                });

                if (!response.ok) {
                    throw new Error(`HTTP error! status: ${response.status}`);
                }

                const data = await response.json();

                if (data.status === 'success') {
                    updateDashboard(data.data);
                } else {
                    console.error('API Error:', data.message);
                }
            } catch (error) {
                console.error('Error fetching dashboard data:', error);
            }
        }

        // ===== UPDATE DASHBOARD WITH STATISTICS =====
        function updateDashboard(dashboardData) {
            try {
                const { statistik } = dashboardData;

                // Update stat cards dengan data dari API
                document.getElementById('totalMahasiswa').textContent = statistik.total_mahasiswa || 0;
                document.getElementById('pembayaranLunas').textContent = statistik.mahasiswa_lunas || 0;
                
                const total = statistik.total_mahasiswa || 0;
                const lunas = statistik.mahasiswa_lunas || 0;
                const persen = total > 0 ? Math.round((lunas / total) * 100) : 0;
                document.getElementById('persenLunas').textContent = persen + '% mahasiswa';

                document.getElementById('statusCicilan').textContent = statistik.mahasiswa_cicilan || 0;
                document.getElementById('belumBayar').textContent = statistik.mahasiswa_belum_bayar || 0;

            } catch (error) {
                console.error('Error updating dashboard:', error);
            }
        }

        // ===== FETCH VALIDATED BILLING DATA =====
        async function fetchValidatedBilling() {
            try {
                const token = getAuthToken();
                if (!token) return;

                const response = await fetch('/projek_plbs/api/index.php/api/admin-fakultas/daftar-tagihan-validasi?page=1&limit=10', {
                    method: 'GET',
                    credentials: 'include',
                    headers: {
                        'Authorization': `Bearer ${token}`,
                        'Content-Type': 'application/json'
                    }
                });

                if (!response.ok) throw new Error(`HTTP error! status: ${response.status}`);

                const data = await response.json();
                if (data.status === 'success') {
                    updateValidatedBillingUI(data.data);
                }
            } catch (error) {
                console.error('Error fetching validated billing:', error);
            }
        }

        // ===== UPDATE VALIDATED BILLING UI =====
        function updateValidatedBillingUI(billingData) {
            const { summary } = billingData;
            
            // Update summary cards if they exist
            const totalLunasCard = document.querySelector('[data-stat="total-tagihan-lunas"]');
            const totalMhsCard = document.querySelector('[data-stat="total-mahasiswa-lunas"]');
            const totalPembayaranCard = document.querySelector('[data-stat="total-pembayaran-valid"]');

            if (totalLunasCard) totalLunasCard.textContent = summary.total_tagihan_lunas || 0;
            if (totalMhsCard) totalMhsCard.textContent = summary.total_mahasiswa || 0;
            if (totalPembayaranCard) totalPembayaranCard.textContent = formatRupiah(summary.total_pembayaran || 0);
        }

        // ===== FETCH INSTALLMENT MONITORING =====
        async function fetchMonitoringCicilan() {
            try {
                const token = getAuthToken();
                if (!token) return;

                const response = await fetch('/projek_plbs/api/index.php/api/admin-fakultas/monitoring-cicilan?page=1&limit=10', {
                    method: 'GET',
                    credentials: 'include',
                    headers: {
                        'Authorization': `Bearer ${token}`,
                        'Content-Type': 'application/json'
                    }
                });

                if (!response.ok) throw new Error(`HTTP error! status: ${response.status}`);

                const data = await response.json();
                if (data.status === 'success') {
                    console.log('Monitoring cicilan data loaded:', data.data);
                }
            } catch (error) {
                console.error('Error fetching monitoring cicilan:', error);
            }
        }

        // ===== FETCH PAYMENT HISTORY =====
        async function fetchRiwayatPembayaran() {
            try {
                const token = getAuthToken();
                if (!token) return;

                const response = await fetch('/projek_plbs/api/index.php/api/admin-fakultas/riwayat-pembayaran?page=1&limit=5', {
                    method: 'GET',
                    credentials: 'include',
                    headers: {
                        'Authorization': `Bearer ${token}`,
                        'Content-Type': 'application/json'
                    }
                });

                if (!response.ok) throw new Error(`HTTP error! status: ${response.status}`);

                const data = await response.json();
                if (data.status === 'success') {
                    updateActivityUI(data.data.riwayat);
                }
            } catch (error) {
                console.error('Error fetching payment history:', error);
            }
        }

        // ===== UPDATE ACTIVITY LIST =====
        function updateActivityUI(activities) {
            const activityList = document.getElementById('activityList');
            if (!activityList || !activities || activities.length === 0) return;

            activityList.innerHTML = '';

            activities.forEach(activity => {
                const statusClass = activity.status === 'valid' ? 'activity-success' : 
                                   activity.status === 'menunggu_validasi' ? 'activity-warning' : 
                                   'activity-info';

                const statusIcon = activity.status === 'valid' ? 'bi-check-circle' : 
                                  activity.status === 'menunggu_validasi' ? 'bi-exclamation-triangle' : 
                                  'bi-info-circle';

                const activityItem = document.createElement('div');
                activityItem.className = 'activity-item';
                activityItem.innerHTML = `
                    <div class="activity-icon ${statusClass}">
                        <i class="bi ${statusIcon}"></i>
                    </div>
                    <div class="activity-content">
                        <div class="activity-title">${activity.nama_mahasiswa}</div>
                        <div class="activity-desc">${activity.jenis_tagihan} - ${formatRupiah(activity.jumlah)} (${activity.status.toUpperCase()})</div>
                        <div class="activity-time">${new Date(activity.tanggal).toLocaleDateString('id-ID')}</div>
                    </div>
                `;
                activityList.appendChild(activityItem);
            });
        }

        // ===== FETCH BILLING DATA FOR DISPLAY =====
        async function fetchDaftarPembayaran() {
            try {
                const token = getAuthToken();
                if (!token) return;

                const response = await fetch('/projek_plbs/api/index.php/api/admin-fakultas/daftar-pembayaran?page=1&limit=3', {
                    method: 'GET',
                    credentials: 'include',
                    headers: {
                        'Authorization': `Bearer ${token}`,
                        'Content-Type': 'application/json'
                    }
                });

                if (!response.ok) throw new Error(`HTTP error! status: ${response.status}`);

                const data = await response.json();
                if (data.status === 'success') {
                    updatePaymentStatusUI(data.data.daftar);
                }
            } catch (error) {
                console.error('Error fetching daftar pembayaran:', error);
            }
        }

        // ===== UPDATE PAYMENT STATUS UI =====
        function updatePaymentStatusUI(payments) {
            const paymentStatus = document.getElementById('paymentStatus');
            if (!paymentStatus || !payments || payments.length === 0) return;

            paymentStatus.innerHTML = '';

            payments.forEach(payment => {
                const statusClass = payment.status_pembayaran === 'lunas' ? 'status-paid' : 
                                   payment.status_pembayaran === 'belum_bayar' ? 'status-pending' : 
                                   'status-overdue';

                const paymentItem = document.createElement('div');
                paymentItem.className = 'payment-item';
                paymentItem.innerHTML = `
                    <div class="payment-info">
                        <h4>${payment.nama_mahasiswa}</h4>
                        <p>${payment.jenis_tagihan} - Semester ${payment.semester}</p>
                    </div>
                    <div class="payment-amount">${formatRupiah(payment.jumlah_pembayaran)}</div>
                    <div class="payment-status ${statusClass}">${payment.status_pembayaran.toUpperCase()}</div>
                `;
                paymentStatus.appendChild(paymentItem);
            });
        }

        // Auth check
        document.addEventListener('DOMContentLoaded', function() {
            requireAuth('admin_fakultas');
            
            const user = getCurrentUser();
            
            // Update user info di sidebar
            document.querySelector('.user-name').textContent = user.nama_lengkap || 'Admin Fakultas';

            // Fetch semua data dashboard
            fetchDashboardData();
            fetchValidatedBilling();
            fetchMonitoringCicilan();
            fetchRiwayatPembayaran();
            fetchDaftarPembayaran();

            // Auto-refresh setiap 30 detik
            setInterval(function() {
                fetchDashboardData();
                fetchValidatedBilling();
            }, 30000);
        });

        // Active menu item based on current page
        document.addEventListener('DOMContentLoaded', function() {
            const currentPage = window.location.pathname.split('/').pop() || 'dashboard_admin_fakultas.php';
            const menuItems = document.querySelectorAll('.menu-item');
            
            menuItems.forEach(item => {
                const link = item.getAttribute('href');
                if (link === currentPage || (currentPage === '' && link === 'dashboard_admin_fakultas.php')) {
                    item.classList.add('active');
                } else {
                    item.classList.remove('active');
                }
            });
        });
    </script>
</body>
</html>
