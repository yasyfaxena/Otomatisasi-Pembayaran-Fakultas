<?php
/**
 * Update Admin Password
 * Set admin_fakultas password to: Admin123
 */

define('DB_HOST', 'localhost');
define('DB_USER', 'root');
define('DB_PASS', '');
define('DB_NAME', 'pembayaran_bpp_terpusat');

try {
    $pdo = new PDO('mysql:host=' . DB_HOST . ';dbname=' . DB_NAME, DB_USER, DB_PASS);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    
    echo "🔐 Updating Admin Passwords\n";
    echo str_repeat("=", 60) . "\n\n";
    
    // Hash for "Admin123"
    $password_hash = '$2y$10$WpMrPWB7yqFQCzE0UNi8KOG9Yyml5Pd00qQRWMJI0QDR9Yns6ZY12';
    
    // Update admin_fakultas
    echo "1️⃣ Updating admin_fakultas password...\n";
    $stmt = $pdo->prepare('UPDATE users SET password_hash = ? WHERE username = ?');
    $result = $stmt->execute([$password_hash, 'admin_fakultas']);
    
    if ($result) {
        echo "   ✅ admin_fakultas password updated\n";
        echo "   Username: admin_fakultas\n";
        echo "   Password: Admin123\n";
    }
    
    // Update admin_universitas (use same password for now)
    echo "\n2️⃣ Updating admin_universitas password...\n";
    $stmt = $pdo->prepare('UPDATE users SET password_hash = ? WHERE username = ?');
    $result = $stmt->execute([$password_hash, 'admin_univ']);
    
    if ($result) {
        echo "   ✅ admin_universitas password updated\n";
        echo "   Username: admin_univ\n";
        echo "   Password: Admin123\n";
    }
    
    echo "\n" . str_repeat("=", 60) . "\n";
    echo "\n✅ PASSWORD UPDATE COMPLETE!\n\n";
    
    echo "🎯 You can now login with:\n";
    echo "   Admin Fakultas:\n";
    echo "   - Username: admin_fakultas\n";
    echo "   - Password: Admin123\n\n";
    echo "   Admin Universitas:\n";
    echo "   - Username: admin_univ\n";
    echo "   - Password: Admin123\n\n";
    
    echo "🧪 Test Login:\n";
    echo "   1. Open: http://localhost:8000/login_admin_fakultas.php\n";
    echo "   2. Enter: admin_fakultas / Admin123\n";
    echo "   3. Should see dashboard (no 401 error)\n";
    
} catch (Exception $e) {
    echo "❌ Error: " . $e->getMessage();
}
?>
