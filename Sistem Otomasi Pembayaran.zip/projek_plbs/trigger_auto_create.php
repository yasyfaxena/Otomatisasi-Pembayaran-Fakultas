<?php
/**
 * Script untuk trigger auto-create tagihan semester berikutnya
 * untuk mahasiswa yang sudah lunas
 */

require_once __DIR__ . '/api/config/database.php';
require_once __DIR__ . '/api/config/helpers.php';

try {
    $pdo = getDBConnection();
    
    echo "<h2>Trigger Auto-Create Tagihan</h2>";
    echo "<pre>";
    
    // Get semua mahasiswa yang punya tagihan lunas
    $query = "SELECT DISTINCT m.mahasiswa_id, m.prodi_id, m.semester_aktif, m.tahun_akademik,
                     MAX(t.semester) as semester_lunas_tertinggi
              FROM mahasiswa m
              JOIN tagihan t ON m.mahasiswa_id = t.mahasiswa_id
              WHERE t.jenis_tagihan = 'BPP'
                AND t.status_pembayaran = 'lunas'
              GROUP BY m.mahasiswa_id";
    
    $stmt = $pdo->prepare($query);
    $stmt->execute();
    $mahasiswa_list = $stmt->fetchAll();
    
    echo "Ditemukan " . count($mahasiswa_list) . " mahasiswa dengan tagihan lunas\n\n";
    
    foreach ($mahasiswa_list as $mhs) {
        $mahasiswa_id = $mhs['mahasiswa_id'];
        $semester_lunas = (int) $mhs['semester_lunas_tertinggi'];
        $next_semester = $semester_lunas + 1;
        
        echo "Mahasiswa ID: {$mahasiswa_id}\n";
        echo "  Semester lunas tertinggi: {$semester_lunas}\n";
        echo "  Semester berikutnya: {$next_semester}\n";
        
        // Cek apakah tagihan semester berikutnya sudah ada
        $check = "SELECT tagihan_id FROM tagihan 
                  WHERE mahasiswa_id = :mahasiswa_id 
                    AND jenis_tagihan = 'BPP' 
                    AND semester = :semester";
        $stmt = $pdo->prepare($check);
        $stmt->execute([
            'mahasiswa_id' => $mahasiswa_id,
            'semester' => $next_semester
        ]);
        $existing = $stmt->fetch();
        
        if ($existing) {
            echo "  ✓ Tagihan semester {$next_semester} sudah ada (ID: {$existing['tagihan_id']})\n\n";
            continue;
        }
        
        // Auto-create tagihan semester berikutnya
        if ($next_semester <= 8) {
            $result = autoCreateBPPTagihan(
                $pdo,
                $mahasiswa_id,
                (int) $mhs['semester_aktif'],
                $mhs['tahun_akademik'],
                (int) $mhs['prodi_id']
            );
            
            if ($result) {
                echo "  ✓ Berhasil create tagihan semester {$next_semester} (ID: {$result})\n\n";
            } else {
                echo "  ✗ Gagal create tagihan semester {$next_semester} (tarif tidak ditemukan?)\n\n";
            }
        } else {
            echo "  - Sudah melewati semester 8, tidak perlu create BPP lagi\n\n";
        }
        
        // Auto-create Proposal jika semester 6 sudah lunas
        if ($semester_lunas >= 6) {
            $proposal_result = autoCreateProposalTagihan(
                $pdo,
                $mahasiswa_id,
                $mhs['tahun_akademik'],
                (int) $mhs['prodi_id']
            );
            
            if ($proposal_result) {
                echo "  ✓ Berhasil create tagihan PROPOSAL (ID: {$proposal_result})\n";
            }
        }
        
        // Auto-create Skripsi jika semester 7 sudah lunas
        if ($semester_lunas >= 7) {
            $skripsi_result = autoCreateSkripsiTagihan(
                $pdo,
                $mahasiswa_id,
                $mhs['tahun_akademik'],
                (int) $mhs['prodi_id']
            );
            
            if ($skripsi_result) {
                echo "  ✓ Berhasil create tagihan SKRIPSI (ID: {$skripsi_result})\n";
            }
        }
        
        echo "\n";
    }
    
    echo "</pre>";
    echo "<p><strong>Selesai!</strong> Silakan refresh dashboard mahasiswa untuk melihat tagihan baru.</p>";
    
} catch (Exception $e) {
    echo "<pre>Error: " . $e->getMessage() . "</pre>";
}
