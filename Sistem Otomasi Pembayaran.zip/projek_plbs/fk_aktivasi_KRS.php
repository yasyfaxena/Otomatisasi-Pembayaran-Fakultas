<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header('Location: login_admin_fakultas.php');
    exit;
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Validasi Bukti Pembayaran - Tabel</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.13.1/font/bootstrap-icons.min.css">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: #f5f5f5;
            display: flex;
        }

        .sidebar {
            width: 260px;
            background-color: #1a1a1a;
            color: white;
            height: 100vh;
            position: fixed;
            left: 0;
            top: 0;
        }

        .logo {
            padding: 20px;
            text-align: center;
            border-bottom: 1px solid #333;
        }

        .logo img {
            width: 80px;
            height: auto;
        }

        .user-info {
            padding: 30px 20px;
            text-align: center;
            border-bottom: 1px solid #333;
        }

        .user-name {
            font-size: 16px;
            font-weight: 600;
            margin-bottom: 15px;
        }

        .user-actions {
            display: flex;
            gap: 8px;
            justify-content: center;
        }

        .user-actions a {
            padding: 8px 12px;
            background: #f59e0b;
            color: white;
            text-decoration: none;
            border-radius: 5px;
            font-size: 12px;
            transition: background 0.3s;
        }

        .user-actions a:hover {
            background: #d97706;
        }

        .menu {
            padding: 20px 0;
        }

        .menu-item {
            padding: 15px 20px;
            cursor: pointer;
            display: flex;
            align-items: center;
            gap: 12px;
            transition: background-color 0.3s;
        }

        .menu-item.active { 
            background-color: #4CAF50;
        }

        .menu-item:hover {
            background-color: #333;
        }

        .menu-icon {
            width: 24px;
            height: 24px;
            display: flex;
            align-items: center;
            justify-content: center;
        }

        .menu a {
            text-decoration: none;
            color: inherit;
        }

        .main-content {
            margin-left: 260px;
            flex: 1;
            padding: 20px 40px;
        }

        .header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 30px;
            background: white;
            padding: 15px 25px;
            border-radius: 8px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
        }

        .header-title {
            font-size: 20px;
            color: #666;
            display: flex;
            align-items: center;
            gap: 15px;
        }

        .menu-dots {
            font-size: 24px;
            cursor: pointer;
            color: #999;
        }



        .section {
            background: white;
            border-radius: 8px;
            padding: 30px;
            margin-bottom: 30px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
        }

        .section-title {
            font-size: 22px;
            margin-bottom: 25px;
            color: #333;
            font-weight: 600;
            border-bottom: 2px solid #4169E1;
            padding-bottom: 10px;
        }

        /* Tabel Styling */
        .table-container {
            overflow-x: auto;
            margin-bottom: 20px;
            border: 1px solid #e9ecef;
            border-radius: 8px;
        }

        .payment-table {
            width: 100%;
            border-collapse: collapse;
        }

        .payment-table th {
            background-color: #f8f9fa;
            color: #333;
            font-weight: 600;
            text-align: left;
            padding: 15px 12px;
            border-bottom: 2px solid #dee2e6;
            font-size: 14px;
            white-space: nowrap;
        }

        .payment-table td {
            padding: 15px 12px;
            border-bottom: 1px solid #e9ecef;
            vertical-align: middle;
        }

        .payment-table tbody tr:last-child td {
            border-bottom: none;
        }

        .payment-table tbody tr:hover {
            background-color: #f8f9fa;
        }

        .data-cell {
            font-size: 14px;
            color: #333;
            font-weight: 500;
        }

        /* Bukti Pembayaran dalam Tabel */
        .proof-cell {
            text-align: center;
        }

        .proof-btn {
            background-color: #6c757d;
            color: white;
            border: none;
            padding: 8px 16px;
            border-radius: 4px;
            cursor: pointer;
            font-size: 12px;
            font-weight: 600;
            transition: all 0.3s;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            gap: 6px;
            min-width: 100px;
        }

        .proof-btn:hover {
            background-color: #5a6268;
            transform: translateY(-2px);
            box-shadow: 0 4px 8px rgba(0,0,0,0.1);
        }

        .proof-btn:disabled {
            background-color: #e9ecef;
            color: #6c757d;
            cursor: not-allowed;
            transform: none;
            box-shadow: none;
        }

        /* Bukti pembayaran langsung tampil di modal */
        .proof-image-direct {
            max-width: 100%;
            max-height: 200px;
            border-radius: 8px;
            border: 1px solid #dee2e6;
            cursor: zoom-in;
            transition: transform 0.3s;
        }

        .proof-image-direct:hover {
            transform: scale(1.02);
        }

        /* Status Badge KRS */
        .status-badge {
            display: inline-block;
            padding: 6px 12px;
            border-radius: 20px;
            font-size: 12px;
            font-weight: 600;
            min-width: 120px;
            text-align: center;
            white-space: nowrap;
        }

        .status-krs-active {
            background-color: #d4edda;
            color: #155724;
            border: 1px solid #c3e6cb;
        }

        .status-krs-inactive {
            background-color: #fff3cd;
            color: #856404;
            border: 1px solid #ffeaa7;
        }

        /* Action Buttons */
        .action-cell {
            min-width: 200px;
        }

        .action-buttons {
            display: flex;
            gap: 6px;
            flex-wrap: nowrap;
            align-items: center;
        }

        .action-btn {
            padding: 6px 10px;
            border: none;
            border-radius: 4px;
            font-size: 12px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 4px;
            white-space: nowrap;
            min-width: 70px;
            height: 32px;
            flex: 1;
        }

        .btn-details {
            background-color: #007bff;
            color: white;
        }

        .btn-details:hover {
            background-color: #0056b3;
            transform: translateY(-2px);
        }

        .btn-activate-krs {
            background-color: #28a745;
            color: white;
        }

        .btn-activate-krs:hover {
            background-color: #218838;
            transform: translateY(-2px);
            box-shadow: 0 4px 8px rgba(40, 167, 69, 0.3);
        }

        .btn-deactivate-krs {
            background-color: #dc3545;
            color: white;
        }

        .btn-deactivate-krs:hover {
            background-color: #c82333;
            transform: translateY(-2px);
            box-shadow: 0 4px 8px rgba(220, 53, 69, 0.3);
        }

        /* Filter Section */
        .filter-section {
            display: flex;
            gap: 15px;
            margin-bottom: 25px;
            flex-wrap: wrap;
            align-items: center;
            background-color: #f8f9fa;
            padding: 15px;
            border-radius: 6px;
        }

        .filter-group {
            display: flex;
            flex-direction: column;
            min-width: 180px;
        }

        .filter-label {
            font-size: 13px;
            font-weight: 600;
            margin-bottom: 5px;
            color: #495057;
        }

        .filter-select {
            padding: 8px 12px;
            border: 1px solid #ced4da;
            border-radius: 4px;
            font-size: 14px;
            background-color: white;
        }

        .filter-buttons {
            display: flex;
            gap: 10px;
            align-self: flex-end;
            margin-top: 10px;
        }

        /* Modal untuk preview gambar bukti */
        .image-modal {
            display: none;
            position: fixed;
            z-index: 1000;
            left: 0;
            top: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(0,0,0,0.9);
        }

        .image-modal-content {
            margin: auto;
            display: block;
            max-width: 90%;
            max-height: 90%;
            position: absolute;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
        }

        .close-image-modal {
            position: absolute;
            top: 20px;
            right: 35px;
            color: #f1f1f1;
            font-size: 40px;
            font-weight: bold;
            cursor: pointer;
        }

        .close-image-modal:hover {
            color: #bbb;
        }

        /* Modal untuk detail pembayaran */
        .detail-modal {
            display: none;
            position: fixed;
            z-index: 1001;
            left: 0;
            top: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(0,0,0,0.5);
            animation: fadeIn 0.3s ease-out;
        }

        @keyframes fadeIn {
            from { opacity: 0; }
            to { opacity: 1; }
        }

        .detail-modal-content {
            background-color: white;
            margin: 30px auto;
            width: 95%;
            max-width: 600px;
            border-radius: 12px;
            box-shadow: 0 5px 20px rgba(0,0,0,0.15);
            overflow: hidden;
            animation: slideIn 0.4s ease-out;
            max-height: 85vh;
            display: flex;
            flex-direction: column;
        }

        @keyframes slideIn {
            from { transform: translateY(-30px); opacity: 0; }
            to { transform: translateY(0); opacity: 1; }
        }

        .detail-modal-header {
            background: #f8f9fa;
            color: #333;
            padding: 20px 25px;
            border-bottom: 1px solid #e9ecef;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .detail-modal-title {
            font-size: 18px;
            font-weight: 600;
            display: flex;
            align-items: center;
            justify-content: center; /* Tengahkan judul */
            gap: 10px;
            flex: 1; /* Ambil ruang yang tersedia */
        }

        .close-detail-modal {
            color: #6c757d;
            font-size: 28px;
            font-weight: bold;
            cursor: pointer;
            width: 36px;
            height: 36px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            transition: all 0.3s;
            position: relative;
            right: 0;
        }

        .close-detail-modal:hover {
            background: #e9ecef;
            color: #333;
        }

        .detail-modal-body {
            padding: 25px;
            flex: 1;
            overflow-y: auto;
        }

        /* Detail info dalam satu container */
        .detail-container {
            background: #f8f9fa;
            border-radius: 8px;
            padding: 25px;
        }

        .detail-row {
            display: flex;
            margin-bottom: 16px;
            padding-bottom: 16px;
            border-bottom: 1px solid #e9ecef;
            align-items: center;
        }

        .detail-row:last-child {
            margin-bottom: 0;
            padding-bottom: 0;
            border-bottom: none;
        }

        .detail-label {
            flex: 0 0 160px;
            font-size: 14px;
            color: #666;
            font-weight: 500;
        }

        .detail-value {
            flex: 1;
            font-size: 14px;
            color: #333;
            font-weight: 500;
        }

        .detail-value strong {
            font-weight: 600;
        }

        .detail-status {
            display: inline-block;
            padding: 6px 12px;
            border-radius: 20px;
            font-size: 13px;
            font-weight: 600;
        }

        .status-approved-modal {
            background-color: #d4edda;
            color: #155724;
        }

        .status-krs-active-modal {
            background-color: #d4edda;
            color: #155724;
        }

        .status-krs-inactive-modal {
            background-color: #fff3cd;
            color: #856404;
        }

        .no-proof {
            color: #6c757d;
            font-style: italic;
        }

        /* Catatan */
        .detail-notes {
            margin-top: 25px;
            padding: 20px;
            background-color: #fff;
            border: 1px solid #e9ecef;
            border-radius: 8px;
        }

        .notes-title {
            font-size: 15px;
            font-weight: 600;
            color: #333;
            margin-bottom: 12px;
            display: flex;
            align-items: center;
            gap: 8px;
        }

        .notes-content {
            font-size: 14px;
            color: #333;
            line-height: 1.6;
            white-space: pre-line;
        }

        .no-notes {
            color: #6c757d;
            font-style: italic;
        }

        /* Footer modal - HANYA TOMBOL UNTUK KRS SAJA */
        .detail-modal-footer {
            padding: 20px 25px;
            background-color: #f8f9fa;
            border-top: 1px solid #e9ecef;
            display: flex;
            justify-content: flex-end;
            gap: 10px;
        }

        .modal-btn {
            padding: 10px 20px;
            border: none;
            border-radius: 6px;
            font-size: 14px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 8px;
            min-width: 140px;
        }

        .modal-btn-success {
            background-color: #28a745;
            color: white;
        }

        .modal-btn-success:hover {
            background-color: #218838;
            transform: translateY(-2px);
        }

        .modal-btn-warning {
            background-color: #ffc107;
            color: #212529;
        }

        .modal-btn-warning:hover {
            background-color: #e0a800;
            transform: translateY(-2px);
        }

        /* Pagination dengan Prev/Next */
        .pagination-container {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-top: 30px;
            padding-top: 20px;
            border-top: 1px solid #e9ecef;
        }

        .pagination-info {
            font-size: 14px;
            color: #6c757d;
        }

        .pagination-controls {
            display: flex;
            gap: 10px;
            align-items: center;
        }

        .page-btn {
            padding: 8px 16px;
            background-color: white;
            border: 1px solid #dee2e6;
            border-radius: 4px;
            cursor: pointer;
            font-size: 14px;
            font-weight: 600;
            display: flex;
            align-items: center;
            gap: 6px;
            transition: all 0.3s;
        }

        .page-btn:hover:not(:disabled) {
            background-color: #007bff;
            color: white;
            border-color: #007bff;
        }

        .page-btn:disabled {
            opacity: 0.5;
            cursor: not-allowed;
        }

        .page-numbers {
            display: flex;
            gap: 5px;
        }

        .page-number {
            padding: 8px 12px;
            background-color: white;
            border: 1px solid #dee2e6;
            border-radius: 4px;
            cursor: pointer;
            font-size: 14px;
            min-width: 40px;
            text-align: center;
        }

        .page-number.active {
            background-color: #007bff;
            color: white;
            border-color: #007bff;
        }

        .page-number:hover:not(.active) {
            background-color: #e9ecef;
        }

        /* Summary Stats */
        .summary-stats {
            display: flex;
            gap: 20px;
            margin-bottom: 25px;
            flex-wrap: wrap;
        }

        .stat-card {
            flex: 1;
            min-width: 200px;
            background: white;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
        }

        .stat-title {
            font-size: 14px;
            color: #6c757d;
            margin-bottom: 10px;
        }

        .stat-value {
            font-size: 24px;
            font-weight: 700;
            color: #333;
        }

        .stat-total { border-left: 4px solid #007bff; }
        .stat-approved { border-left: 4px solid #28a745; }
        .stat-krs-active { border-left: 4px solid #28a745; }
        .stat-krs-inactive { border-left: 4px solid #ffc107; }

        /* Responsive */
        @media (max-width: 1200px) {
            .main-content {
                margin-left: 0;
                padding: 15px;
            }
            
            .sidebar {
                display: none;
            }
            
            .payment-table {
                font-size: 13px;
            }
            
            .action-buttons {
                flex-direction: row;
                flex-wrap: wrap;
            }
            
            .action-btn {
                min-width: 60px;
                font-size: 11px;
                padding: 5px 8px;
            }
        }

        @media (max-width: 768px) {
            .pagination-container {
                flex-direction: column;
                gap: 15px;
            }
            
            .page-numbers {
                order: -1;
            }
            
            .filter-section {
                flex-direction: column;
                align-items: stretch;
            }
            
            .filter-buttons {
                align-self: stretch;
                justify-content: center;
            }
            
            .action-buttons {
                flex-direction: column;
            }
            
            .action-btn {
                width: 100%;
            }
            
            .detail-modal-content {
                width: 95%;
                margin: 20px auto;
                max-height: 90vh;
            }
            
            .detail-row {
                flex-direction: column;
                gap: 5px;
                align-items: flex-start;
                margin-bottom: 20px;
            }
            
            .detail-label {
                flex: none;
                margin-bottom: 2px;
            }
            
            .detail-value {
                flex: none;
                width: 100%;
            }
            
            .detail-modal-footer {
                flex-direction: column;
            }
            
            .modal-btn {
                width: 100%;
                justify-content: center;
            }
        }
    </style>
</head>
<body>
    <div class="sidebar">
        <div class="logo">
            <img src="pictures/logo umi.png" alt="Logo">
        </div>
        <div class="user-info">
            <div class="user-name">Admin Fakultas</div>
            <div class="user-actions">
                <a href="#" onclick="logout(); return false;">Logout</a>
            </div>
        </div>
        <div class="menu">
            <a href="dashboard_admin_fakultas.php" class="menu-item">
                <div class="menu-icon"><i class="bi bi-house-door"></i></div>
                <div>Dashboard</div>
            </a>
            <a href="fk_aktivasi_KRS.php" class="menu-item active">
                <div class="menu-icon"><i class="bi bi-clipboard-check"></i></div>
                <div>Aktivasi KRS</div>
            </a>
            <a href="fk_daftar_tagihan.php" class="menu-item">
                <div class="menu-icon"><i class="bi bi-card-checklist"></i></div>
                <div>Daftar Tagihan Mahasiswa</div>
            </a>
            <a href="fk_monitoring_cicilan.php" class="menu-item">
                <div class="menu-icon"><i class="bi bi-graph-up"></i></div>
                <div>Monitoring Cicilan</div>
            </a>
        </div>
    </div>

    <div class="main-content">
        <div class="header">
            <div class="header-title">
                <span class="menu-dots">⋮</span>
                <span>Manajemen KRS Mahasiswa</span>
            </div>
        </div>

        <div class="section">
            <h2 class="section-title">Daftar Pembayaran Mahasiswa (Sudah Divalidasi)</h2>
            
            <!-- Summary Statistics -->
            <div class="summary-stats">
                <div class="stat-card stat-total">
                    <div class="stat-title">Total Pembayaran</div>
                    <div class="stat-value" id="totalCount">0</div>
                </div>
                <div class="stat-card stat-approved">
                    <div class="stat-title">Disetujui</div>
                    <div class="stat-value" id="approvedCount">0</div>
                </div>
                <div class="stat-card stat-krs-active">
                    <div class="stat-title">Sudah Aktif KRS</div>
                    <div class="stat-value" id="krsActiveCount">0</div>
                </div>
                <div class="stat-card stat-krs-inactive">
                    <div class="stat-title">Belum Aktif KRS</div>
                    <div class="stat-value" id="krsInactiveCount">0</div>
                </div>
            </div>

            <!-- Filter Section -->
            <div class="filter-section">
                <div class="filter-group">
                    <label class="filter-label">Status KRS</label>
                    <select class="filter-select" id="krsStatusFilter">
                        <option value="all">Semua Status</option>
                        <option value="active">Sudah Aktif KRS</option>
                        <option value="inactive">Belum Aktif KRS</option>
                    </select>
                </div>
                
                <div class="filter-group">
                    <label class="filter-label">Jenis Pembayaran</label>
                    <select class="filter-select" id="typeFilter">
                        <option value="all">Semua Jenis</option>
                        <option value="BPP">BPP</option>
                        <option value="UKT">UKT</option>
                        <option value="SPP">SPP</option>
                        <option value="Lainnya">Lainnya</option>
                    </select>
                </div>
                
                <div class="filter-group">
                    <label class="filter-label">Periode</label>
                    <select class="filter-select" id="periodFilter">
                        <option value="all">Semua Periode</option>
                        <option value="2025/2026">2025/2026</option>
                        <option value="2024/2025">2024/2025</option>
                        <option value="2023/2024">2023/2024</option>
                    </select>
                </div>
                
                <div class="filter-buttons">
                    <button class="action-btn btn-details" onclick="resetFilters()">
                        Reset Filter
                    </button>
                </div>
            </div>

            <!-- Payment Table -->
            <div class="table-container">
                <table class="payment-table">
                    <thead>
                        <tr>
                            <th width="5%">No</th>
                            <th width="10%">NIM</th>
                            <th width="15%">Nama Mahasiswa</th>
                            <th width="10%">Jenis</th>
                            <th width="10%">Periode</th>
                            <th width="12%">Jumlah</th>
                            <th width="10%">Tanggal Upload</th>
                            <th width="10%">Status KRS</th>
                            <th width="13%">Bukti Pembayaran</th>
                            <th width="15%" class="action-cell">Aksi</th>
                        </tr>
                    </thead>
                    <tbody id="paymentTableBody">
                        <!-- Data akan diisi oleh JavaScript -->
                    </tbody>
                </table>
            </div>

            <!-- Pagination dengan Prev/Next -->
            <div class="pagination-container">
                <div class="pagination-info" id="pageInfo">
                    Menampilkan 0-0 dari 0 data
                </div>
                <div class="pagination-controls">
                    <button class="page-btn" id="prevBtn" onclick="prevPage()" disabled>
                        ← Prev
                    </button>
                    <div class="page-numbers" id="pageNumbers">
                        <!-- Nomor halaman akan diisi oleh JavaScript -->
                    </div>
                    <button class="page-btn" id="nextBtn" onclick="nextPage()">
                        Next →
                    </button>
                </div>
            </div>
        </div>
    </div>

    <!-- Modal untuk preview gambar bukti -->
    <div id="imageModal" class="image-modal" onclick="closeImageModal()">
        <span class="close-image-modal">&times;</span>
        <img class="image-modal-content" id="modalImage">
    </div>

    <!-- Modal untuk detail pembayaran -->
    <div id="detailModal" class="detail-modal">
        <div class="detail-modal-content">
            <div class="detail-modal-header">
                <div class="detail-modal-title">Detail Pembayaran</div>
                <span class="close-detail-modal" onclick="closeDetailModal()">&times;</span>
            </div>
            
            <div class="detail-modal-body" id="detailModalBody">
                <!-- Detail akan diisi oleh JavaScript -->
            </div>
            
            <div class="detail-modal-footer" id="detailModalFooter">
                <!-- Footer hanya akan berisi tombol untuk KRS -->
            </div>
        </div>
    </div>

    <script src="js/auth.js"></script>
    <script>
        // Data pembayaran dari backend API
        let paymentData = [];
        let currentPaymentDetail = null;
        let currentPage = 1;
        let itemsPerPage = 5;
        let filteredData = [];

        // Fungsi untuk fetch data dari API
        async function loadPaymentData() {
            try {
                const token = getAuthToken();
                if (!token) {
                    console.error('No auth token found');
                    return;
                }

                const response = await fetch('/projek_plbs/api/index.php/api/admin-fakultas/daftar-pembayaran?page=1&limit=100', {
                    method: 'GET',
                    credentials: 'include',
                    headers: {
                        'Authorization': `Bearer ${token}`,
                        'Content-Type': 'application/json'
                    }
                });

                if (!response.ok) {
                    throw new Error(`HTTP error! status: ${response.status}`);
                }

                const data = await response.json();

                if (data.status === 'success') {
                    // Transform API response - HANYA AMBIL PEMBAYARAN VALID
                    paymentData = data.data.daftar
                        .filter(item => item.status_validasi === 'valid')  // FILTER HANYA VALID
                        .map((item, index) => ({
                            id: item.pembayaran_id,
                            tagihan_id: item.tagihan_id || item.pembayaran_id,  // SIMPAN tagihan_id untuk aktivasi KRS
                            mahasiswa_id: item.mahasiswa_id || null,
                            nim: item.nim,
                            name: item.nama_mahasiswa,
                            paymentType: item.jenis_tagihan,
                            paymentMethod: item.status_pembayaran === 'lunas' ? 'Lunas' : 'Cicilan',
                            period: `${item.semester}/${item.tahun_akademik}`,
                            semester: item.semester,
                            tahun_akademik: item.tahun_akademik,
                            amount: item.jumlah_pembayaran,
                            uploadDate: item.tgl_pembayaran,
                            transactionType: 'VA Bank',
                            status: 'approved',  // Semua sudah valid
                            krsStatus: item.status_krs === 'disetujui' || item.status_krs === 'aktif' ? 'active' : 'inactive',
                            notes: `${item.jenis_tagihan} Semester ${item.semester} telah divalidasi.`,
                            proofImage: item.bukti_pembayaran ? `/projek_plbs/uploads/bukti_pembayaran/${item.bukti_pembayaran}` : null
                        }));

                    filteredData = [...paymentData];
                    renderTable();
                } else {
                    console.error('API Error:', data.message);
                    alert('Gagal memuat data pembayaran: ' + data.message);
                }
            } catch (error) {
                console.error('Error loading payment data:', error);
                alert('Gagal memuat data pembayaran dari server');
            }
        }

        // Fungsi untuk get auth token
        function getAuthToken() {
            return localStorage.getItem('auth_token');
        }

        // Format tanggal
        function formatDate(dateString) {
            const date = new Date(dateString);
            const day = date.getDate().toString().padStart(2, '0');
            const month = (date.getMonth() + 1).toString().padStart(2, '0');
            const year = date.getFullYear();
            const hours = date.getHours().toString().padStart(2, '0');
            const minutes = date.getMinutes().toString().padStart(2, '0');
            
            return `${day}/${month}/${year} ${hours}:${minutes}`;
        }

        // Format Rupiah
        function formatRupiah(angka) {
            return 'Rp ' + angka.toLocaleString('id-ID');
        }

        // Update statistik
        function updateStats() {
            const total = filteredData.length;
            const approved = filteredData.filter(p => p.status === 'approved').length;
            const krsActive = filteredData.filter(p => p.krsStatus === 'active').length;
            const krsInactive = filteredData.filter(p => p.krsStatus === 'inactive').length;
            
            document.getElementById('totalCount').textContent = total;
            document.getElementById('approvedCount').textContent = approved;
            document.getElementById('krsActiveCount').textContent = krsActive;
            document.getElementById('krsInactiveCount').textContent = krsInactive;
        }

        // Render tabel
        function renderTable() {
            const tableBody = document.getElementById('paymentTableBody');
            tableBody.innerHTML = '';
            
            // Hitung data yang ditampilkan
            const startIndex = (currentPage - 1) * itemsPerPage;
            const endIndex = startIndex + itemsPerPage;
            const currentData = filteredData.slice(startIndex, endIndex);
            
            if (currentData.length === 0) {
                tableBody.innerHTML = `
                    <tr>
                        <td colspan="10" style="text-align: center; padding: 40px; color: #6c757d;">
                            Tidak ada data pembayaran yang ditemukan.
                        </td>
                    </tr>
                `;
                updatePagination();
                updateStats();
                return;
            }
            
            currentData.forEach((item, index) => {
                const row = document.createElement('tr');
                const globalIndex = startIndex + index;
                
                // Status badge KRS
                let statusBadge = '';
                if (item.krsStatus === 'active') {
                    statusBadge = `<span class="status-badge status-krs-active">Sudah Aktif KRS</span>`;
                } else {
                    statusBadge = `<span class="status-badge status-krs-inactive">Belum Aktif KRS</span>`;
                }
                
                // Tombol Lihat Bukti
                let proofButton = '';
                if (item.proofImage) {
                    proofButton = `
                        <button class="proof-btn" onclick="viewProof(${item.id})" title="Klik untuk melihat bukti pembayaran">
                            👁 Lihat
                        </button>
                    `;
                } else {
                    proofButton = `
                        <button class="proof-btn" disabled title="Tidak ada bukti pembayaran">
                            Tidak Tersedia
                        </button>
                    `;
                }
                
                // Action buttons - HANYA TOMBOL UNTUK KRS
                let actionButtons = '';
                if (item.krsStatus === 'active') {
                    actionButtons = `
                        <div class="action-buttons">
                            <button class="action-btn btn-details" onclick="viewPaymentDetails(${item.id})" title="Lihat detail">
                                📋 Detail
                            </button>
                            <button class="action-btn btn-deactivate-krs" onclick="deactivateKRS(${item.id})" title="Nonaktifkan KRS">
                                ✕ Nonaktifkan
                            </button>
                        </div>
                    `;
                } else {
                    actionButtons = `
                        <div class="action-buttons">
                            <button class="action-btn btn-details" onclick="viewPaymentDetails(${item.id})" title="Lihat detail">
                                📋 Detail
                            </button>
                            <button class="action-btn btn-activate-krs" onclick="activateKRS(${item.id})" title="Aktifkan KRS">
                                ✓ Aktifkan
                            </button>
                        </div>
                    `;
                }
                
                // Data langsung ditampilkan tanpa label duplikat
                row.innerHTML = `
                    <td class="data-cell">${globalIndex + 1}</td>
                    <td class="data-cell">${item.nim}</td>
                    <td class="data-cell">${item.name}</td>
                    <td class="data-cell">${item.paymentType}</td>
                    <td class="data-cell">${item.period}</td>
                    <td class="data-cell">${formatRupiah(item.amount)}</td>
                    <td class="data-cell">${formatDate(item.uploadDate)}</td>
                    <td>${statusBadge}</td>
                    <td class="proof-cell">${proofButton}</td>
                    <td class="action-cell">${actionButtons}</td>
                `;
                
                tableBody.appendChild(row);
            });
            
            updatePagination();
            updateStats();
        }

        // Update pagination controls
        function updatePagination() {
            const totalPages = Math.ceil(filteredData.length / itemsPerPage);
            const pageNumbersContainer = document.getElementById('pageNumbers');
            const prevBtn = document.getElementById('prevBtn');
            const nextBtn = document.getElementById('nextBtn');
            const pageInfo = document.getElementById('pageInfo');
            
            // Update info
            const startIndex = (currentPage - 1) * itemsPerPage + 1;
            const endIndex = Math.min(currentPage * itemsPerPage, filteredData.length);
            pageInfo.textContent = `Menampilkan ${startIndex}-${endIndex} dari ${filteredData.length} data`;
            
            // Update button states
            prevBtn.disabled = currentPage === 1;
            nextBtn.disabled = currentPage === totalPages || totalPages === 0;
            
            // Update page numbers
            pageNumbersContainer.innerHTML = '';
            
            // Tampilkan maksimal 5 nomor halaman
            let startPage = Math.max(1, currentPage - 2);
            let endPage = Math.min(totalPages, startPage + 4);
            
            // Sesuaikan jika terlalu dekat ke akhir
            if (endPage - startPage < 4) {
                startPage = Math.max(1, endPage - 4);
            }
            
            for (let i = startPage; i <= endPage; i++) {
                const pageBtn = document.createElement('button');
                pageBtn.className = `page-number ${i === currentPage ? 'active' : ''}`;
                pageBtn.textContent = i;
                pageBtn.onclick = () => goToPage(i);
                pageNumbersContainer.appendChild(pageBtn);
            }
        }

        // Pagination functions
        function goToPage(page) {
            currentPage = page;
            renderTable();
        }

        function prevPage() {
            if (currentPage > 1) {
                currentPage--;
                renderTable();
            }
        }

        function nextPage() {
            const totalPages = Math.ceil(filteredData.length / itemsPerPage);
            if (currentPage < totalPages) {
                currentPage++;
                renderTable();
            }
        }

        // Fungsi untuk mengaktifkan KRS via API - GUNAKAN TAGIHAN_ID
        async function activateKRS(id) {
            const payment = paymentData.find(p => p.id === id);
            
            if (!payment) {
                alert('Data pembayaran tidak ditemukan');
                return;
            }
            
            if (confirm(`Aktifkan KRS untuk ${payment.name} (NIM: ${payment.nim})?`)) {
                try {
                    const token = getAuthToken();
                    const tagihanId = payment.tagihan_id || payment.id;  // Gunakan tagihan_id

                    const response = await fetch(`/projek_plbs/api/index.php/api/admin/krs/${tagihanId}/aktivasi`, {
                        method: 'POST',
                        credentials: 'include',
                        headers: {
                            'Authorization': `Bearer ${token}`,
                            'Content-Type': 'application/json'
                        }
                    });

                    const result = await response.json();
                    
                    if (result.status === 'success') {
                        payment.krsStatus = 'active';
                        applyFilters();
                        alert(`✓ KRS untuk ${payment.name} telah diaktifkan!`);
                    } else {
                        alert('Gagal mengaktifkan KRS: ' + result.message);
                    }
                } catch (error) {
                    console.error('Error activating KRS:', error);
                    alert('Gagal mengaktifkan KRS: ' + error.message);
                }
            }
        }

        // Fungsi untuk menonaktifkan KRS via API
        async function deactivateKRS(id) {
            const payment = paymentData.find(p => p.id === id);
            
            if (!payment) {
                alert('Data pembayaran tidak ditemukan');
                return;
            }
            
            if (confirm(`Nonaktifkan KRS untuk ${payment.name} (NIM: ${payment.nim})?`)) {
                try {
                    const token = getAuthToken();
                    const tagihanId = payment.tagihan_id || payment.id;

                    const response = await fetch(`/projek_plbs/api/index.php/api/admin/krs/${tagihanId}/deaktivasi`, {
                        method: 'POST',
                        credentials: 'include',
                        headers: {
                            'Authorization': `Bearer ${token}`,
                            'Content-Type': 'application/json'
                        }
                    });

                    const result = await response.json();
                    
                    if (result.status === 'success') {
                        payment.krsStatus = 'inactive';
                        applyFilters();
                        alert(`✕ KRS untuk ${payment.name} telah dinonaktifkan!`);
                    } else {
                        alert('Gagal menonaktifkan KRS: ' + result.message);
                    }
                } catch (error) {
                    console.error('Error deactivating KRS:', error);
                    alert('Gagal menonaktifkan KRS: ' + error.message);
                }
            }
        }

        // Fungsi untuk melihat detail pembayaran
        function viewPaymentDetails(id) {
            const payment = paymentData.find(p => p.id === id);
            currentPaymentDetail = payment;
            
            // Status KRS text dan class
            let krsStatusText = '';
            let krsStatusClass = '';
            if (payment.krsStatus === 'active') {
                krsStatusText = 'Sudah Aktif KRS';
                krsStatusClass = 'status-krs-active-modal';
            } else {
                krsStatusText = 'Belum Aktif KRS';
                krsStatusClass = 'status-krs-inactive-modal';
            }
            
            // Bukti pembayaran langsung tampil
            let proofContent = '';
            if (payment.proofImage) {
                proofContent = `
                    <img 
                        src="${payment.proofImage}" 
                        alt="Bukti Pembayaran"
                        class="proof-image-direct"
                        onclick="viewProof(${payment.id})"
                        title="Klik untuk memperbesar"
                    >
                `;
            } else {
                proofContent = `<div class="no-proof">Tidak ada bukti pembayaran</div>`;
            }

            const detailHTML = `
                <div class="detail-container">
                    <!-- Informasi Mahasiswa -->
                    <div class="detail-row">
                        <div class="detail-label">NIM</div>
                        <div class="detail-value"><strong>${payment.nim}</strong></div>
                    </div>
                    
                    <div class="detail-row">
                        <div class="detail-label">Nama Mahasiswa</div>
                        <div class="detail-value">${payment.name}</div>
                    </div>
                    
                    <!-- Informasi Pembayaran -->
                    <div class="detail-row">
                        <div class="detail-label">Jenis Pembayaran</div>
                        <div class="detail-value">${payment.paymentType}</div>
                    </div>
                    
                    <div class="detail-row">
                        <div class="detail-label">Periode</div>
                        <div class="detail-value">${payment.period}</div>
                    </div>
                    
                    <div class="detail-row">
                        <div class="detail-label">Jumlah</div>
                        <div class="detail-value"><strong>${formatRupiah(payment.amount)}</strong></div>
                    </div>
                    
                    <!-- Informasi Transaksi -->
                    <div class="detail-row">
                        <div class="detail-label">Tanggal Upload</div>
                        <div class="detail-value">${formatDate(payment.uploadDate)}</div>
                    </div>
                    
                    <div class="detail-row">
                        <div class="detail-label">Jenis Transaksi</div>
                        <div class="detail-value">${payment.transactionType}</div>
                    </div>
                    
                    <div class="detail-row">
                        <div class="detail-label">Status Pembayaran</div>
                        <div class="detail-value">
                            <span class="detail-status status-approved-modal">Disetujui</span>
                        </div>
                    </div>
                    
                    <div class="detail-row">
                        <div class="detail-label">Status KRS</div>
                        <div class="detail-value">
                            <span class="detail-status ${krsStatusClass}">${krsStatusText}</span>
                        </div>
                    </div>
                    
                    <div class="detail-row">
                        <div class="detail-label">Bukti Pembayaran</div>
                        <div class="detail-value">
                            ${proofContent}
                        </div>
                    </div>
                </div>
                
                <!-- Catatan -->
                <div class="detail-notes">
                    <div class="notes-title">📝 Catatan</div>
                    <div class="notes-content">
                        ${payment.notes ? payment.notes : '<div class="no-notes">Belum ada catatan</div>'}
                    </div>
                </div>
            `;
            
            document.getElementById('detailModalBody').innerHTML = detailHTML;
            
            // Buat footer tombol berdasarkan status KRS (hanya tombol KRS, tanpa tombol tutup)
            let footerHTML = '';
            if (payment.krsStatus === 'active') {
                footerHTML = `
                    <button class="modal-btn modal-btn-warning" onclick="deactivateKRSFromModal()">
                        ✕ Nonaktifkan KRS
                    </button>
                `;
            } else {
                footerHTML = `
                    <button class="modal-btn modal-btn-success" onclick="activateKRSFromModal()">
                        ✓ Aktifkan KRS
                    </button>
                `;
            }
            
            document.getElementById('detailModalFooter').innerHTML = footerHTML;
            
            // Tampilkan modal
            document.getElementById('detailModal').style.display = 'block';
        }

        // Fungsi untuk menutup modal detail
        function closeDetailModal() {
            document.getElementById('detailModal').style.display = 'none';
            currentPaymentDetail = null;
        }

        // Fungsi untuk mengaktifkan KRS dari modal
        async function activateKRSFromModal() {
            if (currentPaymentDetail) {
                if (confirm(`Aktifkan KRS untuk ${currentPaymentDetail.name}?`)) {
                    try {
                        const token = getAuthToken();
                        const tagihanId = currentPaymentDetail.tagihan_id || currentPaymentDetail.id;

                        const response = await fetch(`/projek_plbs/api/index.php/api/admin/krs/${tagihanId}/aktivasi`, {
                            method: 'POST',
                            credentials: 'include',
                            headers: {
                                'Authorization': `Bearer ${token}`,
                                'Content-Type': 'application/json'
                            }
                        });

                        const result = await response.json();
                        
                        if (result.status === 'success') {
                            currentPaymentDetail.krsStatus = 'active';
                            applyFilters();
                            closeDetailModal();
                            alert('✓ KRS berhasil diaktifkan!');
                        } else {
                            alert('Gagal mengaktifkan KRS: ' + result.message);
                        }
                    } catch (error) {
                        console.error('Error activating KRS:', error);
                        alert('Gagal mengaktifkan KRS: ' + error.message);
                    }
                }
            }
        }

        // Fungsi untuk menonaktifkan KRS dari modal
        async function deactivateKRSFromModal() {
            if (currentPaymentDetail) {
                if (confirm(`Nonaktifkan KRS untuk ${currentPaymentDetail.name}?`)) {
                    try {
                        const token = getAuthToken();
                        const tagihanId = currentPaymentDetail.tagihan_id || currentPaymentDetail.id;

                        const response = await fetch(`/projek_plbs/api/index.php/api/admin/krs/${tagihanId}/deaktivasi`, {
                            method: 'POST',
                            credentials: 'include',
                            headers: {
                                'Authorization': `Bearer ${token}`,
                                'Content-Type': 'application/json'
                            }
                        });

                        const result = await response.json();
                        
                        if (result.status === 'success') {
                            currentPaymentDetail.krsStatus = 'inactive';
                            applyFilters();
                            closeDetailModal();
                            alert('✕ KRS telah dinonaktifkan.');
                        } else {
                            alert('Gagal menonaktifkan KRS: ' + result.message);
                        }
                    } catch (error) {
                        console.error('Error deactivating KRS:', error);
                        alert('Gagal menonaktifkan KRS: ' + error.message);
                    }
                }
            }
        }

        // Fungsi untuk melihat bukti pembayaran
        function viewProof(id) {
            const payment = paymentData.find(p => p.id === id);
            if (!payment.proofImage) return;
            
            const modal = document.getElementById('imageModal');
            const modalImg = document.getElementById('modalImage');
            
            modal.style.display = 'block';
            modalImg.src = payment.proofImage;
            
            // Cegah modal gambar tertutup saat gambar diklik
            modalImg.onclick = function(event) {
                event.stopPropagation();
            };
        }

        // Fungsi untuk menutup modal gambar
        function closeImageModal() {
            document.getElementById('imageModal').style.display = 'none';
        }

        // Filter functions
        function applyFilters() {
            const krsStatusFilter = document.getElementById('krsStatusFilter').value;
            const typeFilter = document.getElementById('typeFilter').value;
            const periodFilter = document.getElementById('periodFilter').value;
            
            filteredData = paymentData.filter(payment => {
                // Filter berdasarkan status KRS
                if (krsStatusFilter !== 'all' && payment.krsStatus !== krsStatusFilter) {
                    return false;
                }
                
                // Filter berdasarkan jenis pembayaran
                if (typeFilter !== 'all' && payment.paymentType !== typeFilter) {
                    return false;
                }
                
                // Filter berdasarkan periode (menggunakan includes untuk pencarian parsial)
                if (periodFilter !== 'all' && !payment.period.includes(periodFilter)) {
                    return false;
                }
                
                return true;
            });
            
            // Reset ke halaman pertama
            currentPage = 1;
            renderTable();
        }

        function resetFilters() {
            document.getElementById('krsStatusFilter').value = 'all';
            document.getElementById('typeFilter').value = 'all';
            document.getElementById('periodFilter').value = 'all';
            
            filteredData = [...paymentData];
            currentPage = 1;
            renderTable();
        }

        // Menu interaction
        const menuItems = document.querySelectorAll('.menu-item');
        menuItems.forEach(item => {
            item.addEventListener('click', function() {
                menuItems.forEach(mi => mi.classList.remove('active'));
                this.classList.add('active');
            });
        });

        // Close modal dengan ESC key
        document.addEventListener('keydown', function(event) {
            if (event.key === 'Escape') {
                closeDetailModal();
                closeImageModal();
            }
        });

        // Event listener untuk filter
        document.querySelectorAll('.filter-select').forEach(select => {
            select.addEventListener('change', applyFilters);
        });

        // Initialize
        document.addEventListener('DOMContentLoaded', function() {
            requireAuth('admin_fakultas');
            
            const user = getCurrentUser();
            
            // Update user info di sidebar
            document.querySelector('.user-name').textContent = user.nama_lengkap || 'Admin Fakultas';
            
            // Load payment data dari API
            loadPaymentData();
            
            // Event listener untuk close modal gambar
            document.querySelector('.close-image-modal').onclick = closeImageModal;
            
            console.log('Sistem manajemen KRS siap digunakan.');
        });
    </script>

    <script src="js/auth.js"></script>
</body>
</html>
