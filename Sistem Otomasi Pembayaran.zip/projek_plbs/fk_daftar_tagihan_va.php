<!--
ADMIN VALIDATION PAGE - DAFTAR TAGIHAN YANG MENUNGGU VALIDASI
Fitur utama:
1. Menampilkan pembayaran PENDING dan PAID dari localStorage
2. Admin dapat klik [VALID] untuk memvalidasi pembayaran
3. Auto-trigger KRS activation saat validasi
4. Auto-generate notifikasi ke mahasiswa
-->
<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header('Location: login_admin_fakultas.php');
    exit;
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tagihan Validasi - Admin Fakultas</title>
    <script src="va_system_module.js"></script>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.13.1/font/bootstrap-icons.min.css">
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }

        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: #f5f5f5;
            display: flex;
        }

        .sidebar {
            width: 260px;
            background-color: #1a1a1a;
            color: white;
            height: 100vh;
            position: fixed;
            left: 0;
            top: 0;
            overflow-y: auto;
        }

        .logo {
            padding: 20px;
            text-align: center;
            border-bottom: 1px solid #333;
        }

        .logo img { width: 80px; height: auto; }

        .user-info {
            padding: 30px 20px;
            text-align: center;
            border-bottom: 1px solid #333;
        }

        .user-id { font-size: 14px; margin-bottom: 8px; color: #999; }
        .user-name { font-size: 16px; font-weight: 600; }

        .menu { padding: 20px 0; }

        .menu-item {
            padding: 15px 20px;
            cursor: pointer;
            display: flex;
            align-items: center;
            gap: 12px;
            transition: background-color 0.3s;
            text-decoration: none;
            color: white;
        }

        .menu-item:hover { background-color: #333; }
        .menu-item.active { background-color: #4CAF50; }

        .main-content { margin-left: 260px; flex: 1; padding: 20px 40px; }

        .header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 30px;
            background: white;
            padding: 15px 25px;
            border-radius: 8px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
        }

        .header-title { font-size: 20px; color: #666; display: flex; align-items: center; gap: 15px; }

        .section {
            background: white;
            border-radius: 8px;
            padding: 30px;
            margin-bottom: 30px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
        }

        .section-title {
            font-size: 18px;
            font-weight: 600;
            color: #333;
            margin-bottom: 20px;
            border-bottom: 2px solid #4CAF50;
            padding-bottom: 15px;
        }

        .stat-card {
            display: inline-block;
            width: 30%;
            padding: 20px;
            background: #f8f9fa;
            border-radius: 6px;
            margin-right: 3%;
            margin-bottom: 20px;
            text-align: center;
            border-left: 4px solid #4CAF50;
        }

        .stat-title { font-size: 13px; color: #666; margin-bottom: 8px; }
        .stat-value { font-size: 24px; font-weight: 600; color: #333; }

        .table-container {
            width: 100%;
            overflow-x: auto;
        }

        .bills-table {
            width: 100%;
            border-collapse: collapse;
            font-size: 13px;
        }

        .bills-table th {
            background: #f8f9fa;
            padding: 12px;
            text-align: left;
            font-weight: 600;
            border-bottom: 2px solid #dee2e6;
            color: #333;
        }

        .bills-table td {
            padding: 12px;
            border-bottom: 1px solid #e9ecef;
        }

        .bills-table tr:hover {
            background: #f8f9fa;
        }

        .status-badge {
            padding: 4px 10px;
            border-radius: 4px;
            font-size: 12px;
            font-weight: 600;
            display: inline-block;
        }

        .status-pending {
            background: #fff3cd;
            color: #856404;
        }

        .status-paid {
            background: #cfe2ff;
            color: #084298;
        }

        .status-validated {
            background: #d1e7dd;
            color: #0a3622;
        }

        .va-number {
            font-family: 'Courier New', monospace;
            font-weight: 600;
            color: #4169E1;
            font-size: 12px;
        }

        .action-buttons {
            display: flex;
            gap: 6px;
        }

        .action-btn {
            padding: 6px 12px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            font-size: 12px;
            font-weight: 600;
            transition: all 0.3s;
        }

        .btn-valid {
            background: #28a745;
            color: white;
        }

        .btn-valid:hover {
            background: #218838;
            transform: translateY(-1px);
        }

        .btn-valid:disabled {
            background: #ccc;
            cursor: not-allowed;
            transform: none;
        }

        .btn-tolak {
            background: #dc3545;
            color: white;
        }

        .btn-tolak:hover {
            background: #c82333;
            transform: translateY(-1px);
        }

        .btn-detail {
            background: #17a2b8;
            color: white;
        }

        .btn-detail:hover {
            background: #138496;
            transform: translateY(-1px);
        }

        .amount {
            color: #155724;
            font-weight: 600;
        }

        .modal {
            display: none;
            position: fixed;
            z-index: 1000;
            left: 0;
            top: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(0,0,0,0.5);
            animation: fadeIn 0.3s;
        }

        .modal.show { display: flex; }

        .modal-content {
            background-color: white;
            margin: auto;
            padding: 30px;
            border-radius: 12px;
            max-width: 600px;
            width: 90%;
            max-height: 80vh;
            overflow-y: auto;
            box-shadow: 0 5px 20px rgba(0,0,0,0.3);
        }

        .modal-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 20px;
            padding-bottom: 15px;
            border-bottom: 1px solid #e9ecef;
        }

        .modal-title { font-size: 18px; font-weight: 600; color: #333; }

        .close-btn {
            font-size: 28px;
            font-weight: bold;
            color: #aaa;
            cursor: pointer;
        }

        .close-btn:hover { color: #000; }

        .form-group {
            margin-bottom: 15px;
        }

        .form-label {
            display: block;
            font-weight: 600;
            color: #333;
            margin-bottom: 6px;
            font-size: 13px;
        }

        .form-control {
            width: 100%;
            padding: 8px 12px;
            border: 1px solid #ddd;
            border-radius: 4px;
            font-size: 13px;
        }

        .form-control:focus {
            outline: none;
            border-color: #4CAF50;
            box-shadow: 0 0 0 3px rgba(76, 175, 80, 0.1);
        }

        .info-box {
            background: #e3f2fd;
            border-left: 4px solid #2196F3;
            padding: 12px;
            border-radius: 4px;
            margin-bottom: 15px;
            font-size: 13px;
        }

        .info-box strong { color: #1976d2; }

        .modal-buttons {
            display: flex;
            gap: 10px;
            justify-content: flex-end;
            margin-top: 25px;
        }

        .btn {
            padding: 10px 20px;
            border: none;
            border-radius: 6px;
            cursor: pointer;
            font-weight: 600;
            transition: all 0.3s;
        }

        .btn-primary {
            background: #4CAF50;
            color: white;
        }

        .btn-primary:hover { background: #45a049; }

        .btn-secondary {
            background: #6c757d;
            color: white;
        }

        .btn-secondary:hover { background: #5a6268; }

        @keyframes fadeIn { from { opacity: 0; } to { opacity: 1; } }

        @media (max-width: 1200px) {
            .main-content { margin-left: 0; padding: 15px; }
            .sidebar { display: none; }
        }
    </style>
</head>
<body>
    <div class="sidebar">
        <div class="logo">
            <img src="pictures/logo umi.png" alt="Logo">
        </div>
        <div class="user-info">
            <div class="user-id">ADMIN-FK</div>
            <div class="user-name">Admin Fakultas</div>
        </div>
        <div class="menu">
            <a href="dashboard_admin_fakultas.php" class="menu-item">
                <div>📊</div>
                <div>Dashboard</div>
            </a>
            <a href="fk_aktivasi_KRS.php" class="menu-item">
                <div>✓</div>
                <div>Aktivasi KRS</div>
            </a>
            <a href="fk_daftar_tagihan.php" class="menu-item active">
                <div>💳</div>
                <div>Daftar Tagihan</div>
            </a>
            <a href="fk_monitoring_cicilan.php" class="menu-item">
                <div>📈</div>
                <div>Monitoring Cicilan</div>
            </a>
        </div>
    </div>

    <div class="main-content">
        <div class="header">
            <div class="header-title">
                📋 Daftar Pembayaran Menunggu Validasi
            </div>
        </div>

        <div class="section">
            <h2 class="section-title">📊 Statistik</h2>
            
            <div class="stat-card">
                <div class="stat-title">Total Pending</div>
                <div class="stat-value" id="statPending">0</div>
            </div>
            
            <div class="stat-card">
                <div class="stat-title">Total Sudah Bayar</div>
                <div class="stat-value" id="statPaid">0</div>
            </div>
            
            <div class="stat-card">
                <div class="stat-title">Total Nominal</div>
                <div class="stat-value" id="statTotal">Rp 0</div>
            </div>
        </div>

        <div class="section">
            <h2 class="section-title">📋 Daftar Pembayaran</h2>
            
            <div class="table-container">
                <table class="bills-table">
                    <thead>
                        <tr>
                            <th width="4%">No</th>
                            <th width="9%">NIM</th>
                            <th width="14%">Nama</th>
                            <th width="11%">Semester</th>
                            <th width="12%">Jenis</th>
                            <th width="14%">VA Number</th>
                            <th width="11%">Nominal</th>
                            <th width="10%">Status</th>
                            <th width="15%">Aksi</th>
                        </tr>
                    </thead>
                    <tbody id="paymentTableBody">
                        <!-- Generated by JavaScript -->
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <!-- Modal Validasi Pembayaran -->
    <div id="validationModal" class="modal">
        <div class="modal-content">
            <div class="modal-header">
                <div class="modal-title">✓ Validasi Pembayaran</div>
                <span class="close-btn" onclick="closeValidationModal()">&times;</span>
            </div>

            <div class="info-box">
                <strong>📌 PENTING:</strong> Pastikan bukti transfer sesuai dengan nominal dan VA yang ditampilkan sebelum klik VALID.
            </div>

            <div class="form-group">
                <label class="form-label">NIM Mahasiswa:</label>
                <div id="validationNim" style="padding: 8px; background: #f8f9fa; border-radius: 4px; font-weight: 600;">-</div>
            </div>

            <div class="form-group">
                <label class="form-label">Semester:</label>
                <div id="validationSemester" style="padding: 8px; background: #f8f9fa; border-radius: 4px; font-weight: 600;">-</div>
            </div>

            <div class="form-group">
                <label class="form-label">Nomor VA Sistem:</label>
                <div id="validationVASystem" class="va-number" style="padding: 8px; background: #f8f9fa; border-radius: 4px;">-</div>
            </div>

            <div class="form-group">
                <label class="form-label">VA dari Bukti Transfer:</label>
                <input type="text" class="form-control" id="validationVABukti" placeholder="Masukkan VA dari bukti transfer">
                <small style="color: #666;">Harus sama dengan VA Sistem di atas</small>
            </div>

            <div class="form-group">
                <label class="form-label">Nominal Tagihan:</label>
                <div id="validationAmountSystem" class="amount" style="padding: 8px; background: #f8f9fa; border-radius: 4px;">Rp 0</div>
            </div>

            <div class="form-group">
                <label class="form-label">Nominal dari Bukti:</label>
                <input type="text" class="form-control" id="validationAmountBukti" placeholder="Masukkan nominal dari bukti" inputmode="numeric">
                <small style="color: #666;">Harus sama dengan nominal tagihan di atas</small>
            </div>

            <div class="form-group">
                <label class="form-label">Tanggal Transfer:</label>
                <input type="date" class="form-control" id="validationDate">
            </div>

            <div class="form-group">
                <label class="form-label">Catatan Validasi (Opsional):</label>
                <textarea class="form-control" id="validationNotes" rows="2" placeholder="Catatan atau observasi..."></textarea>
            </div>

            <div class="modal-buttons">
                <button class="btn btn-secondary" onclick="closeValidationModal()">❌ Batal</button>
                <button class="btn btn-primary" onclick="submitValidation()">✓ Validasi Pembayaran</button>
            </div>
        </div>
    </div>

    <!-- Modal Tolak Pembayaran -->
    <div id="rejectModal" class="modal">
        <div class="modal-content">
            <div class="modal-header">
                <div class="modal-title">✗ Tolak Pembayaran</div>
                <span class="close-btn" onclick="closeRejectModal()">&times;</span>
            </div>

            <div class="form-group">
                <label class="form-label">Alasan Penolakan:</label>
                <textarea class="form-control" id="rejectReason" rows="4" placeholder="Jelaskan alasan penolakan pembayaran ini..."></textarea>
            </div>

            <div class="modal-buttons">
                <button class="btn btn-secondary" onclick="closeRejectModal()">❌ Batal</button>
                <button class="btn btn-primary" style="background: #dc3545;" onclick="submitReject()">Tolak Pembayaran</button>
            </div>
        </div>
    </div>

    <script>
        let currentValidationPayment = null;
        let currentRejectPayment = null;

        document.addEventListener('DOMContentLoaded', function() {
            loadPendingPayments();
            updateStats();
        });

        /**
         * Load pembayaran yang belum divalidasi dari localStorage
         */
        function loadPendingPayments() {
            const allPayments = JSON.parse(localStorage.getItem('payments') || '{}');
            const tbody = document.getElementById('paymentTableBody');
            tbody.innerHTML = '';

            let rowNum = 1;
            let paymentsList = [];

            // Collect all payments from localStorage
            Object.entries(allPayments).forEach(([key, value]) => {
                const payment = JSON.parse(value);
                // Only show PAID (waiting validation) and WAITING_PAYMENT
                if (payment.status === 'PAID' || payment.status === 'WAITING_PAYMENT') {
                    paymentsList.push(payment);
                }
            });

            // Sort by created_at descending (newest first)
            paymentsList.sort((a, b) => 
                new Date(b.created_at) - new Date(a.created_at)
            );

            if (paymentsList.length === 0) {
                tbody.innerHTML = `
                    <tr>
                        <td colspan="9" style="text-align: center; padding: 40px; color: #6c757d;">
                            ✓ Tidak ada pembayaran yang menunggu validasi
                        </td>
                    </tr>
                `;
                return;
            }

            paymentsList.forEach((payment) => {
                const row = document.createElement('tr');

                const statusText = payment.status === 'PAID' ? 'SUDAH BAYAR' : 'MENUNGGU PEMBAYARAN';
                const statusClass = payment.status === 'PAID' ? 'status-paid' : 'status-pending';

                row.innerHTML = `
                    <td>${rowNum++}</td>
                    <td><strong>${payment.nim}</strong></td>
                    <td>Mahasiswa ${payment.nim}</td>
                    <td>Semester ${payment.semester.semester_num}<br><small>${payment.semester_display}</small></td>
                    <td>${payment.jenis === 'BPP_LUNAS' ? 'BPP Lunas' : 'BPP Cicilan'}</td>
                    <td class="va-number">${payment.va_data.va_number}</td>
                    <td class="amount">${formatCurrency(payment.amount_total)}</td>
                    <td><span class="status-badge ${statusClass}">${statusText}</span></td>
                    <td>
                        <div class="action-buttons">
                            ${payment.status === 'PAID' ? 
                                `<button class="action-btn btn-valid" onclick="openValidationModal('${payment.payment_id}')">✓ VALID</button>
                                <button class="action-btn btn-tolak" onclick="openRejectModal('${payment.payment_id}')">✗ TOLAK</button>` :
                                `<button class="action-btn btn-detail">⏳ Menunggu</button>`
                            }
                        </div>
                    </td>
                `;

                tbody.appendChild(row);
            });
        }

        /**
         * Update statistik
         */
        function updateStats() {
            const allPayments = JSON.parse(localStorage.getItem('payments') || '{}');
            
            let pending = 0, paid = 0, total = 0;

            Object.entries(allPayments).forEach(([key, value]) => {
                const payment = JSON.parse(value);
                if (payment.status === 'WAITING_PAYMENT') pending++;
                if (payment.status === 'PAID') paid++;
                if (payment.status === 'PAID' || payment.status === 'WAITING_PAYMENT') {
                    total += payment.amount_total;
                }
            });

            document.getElementById('statPending').textContent = pending;
            document.getElementById('statPaid').textContent = paid;
            document.getElementById('statTotal').textContent = formatCurrency(total);
        }

        /**
         * Open validation modal
         */
        function openValidationModal(paymentId) {
            const allPayments = JSON.parse(localStorage.getItem('payments') || '{}');
            
            for (const key in allPayments) {
                const payment = JSON.parse(allPayments[key]);
                if (payment.payment_id === paymentId) {
                    currentValidationPayment = payment;
                    
                    document.getElementById('validationNim').textContent = payment.nim;
                    document.getElementById('validationSemester').textContent = 
                        `Semester ${payment.semester.semester_num} (${payment.semester_display})`;
                    document.getElementById('validationVASystem').textContent = 
                        payment.va_data.va_number;
                    document.getElementById('validationAmountSystem').textContent = 
                        formatCurrency(payment.amount_total);
                    document.getElementById('validationVABukti').value = '';
                    document.getElementById('validationAmountBukti').value = '';
                    document.getElementById('validationDate').value = new Date().toISOString().split('T')[0];
                    document.getElementById('validationNotes').value = '';
                    
                    document.getElementById('validationModal').classList.add('show');
                    break;
                }
            }
        }

        /**
         * Close validation modal
         */
        function closeValidationModal() {
            document.getElementById('validationModal').classList.remove('show');
            currentValidationPayment = null;
        }

        /**
         * Submit validation - CRITICAL LOGIC
         */
        function submitValidation() {
            if (!currentValidationPayment) {
                alert('Error: Data pembayaran tidak ditemukan');
                return;
            }

            const vaFromBukti = document.getElementById('validationVABukti').value.trim();
            const amountFromBukti = parseInt(document.getElementById('validationAmountBukti').value);

            // Validation
            if (!vaFromBukti) {
                alert('⚠️ Silakan masukkan VA dari bukti transfer');
                return;
            }

            if (!amountFromBukti || amountFromBukti <= 0) {
                alert('⚠️ Silakan masukkan nominal yang valid');
                return;
            }

            // Check VA match
            if (vaFromBukti !== currentValidationPayment.va_data.va_number) {
                alert(`❌ VA TIDAK SESUAI!\n\nVA Sistem: ${currentValidationPayment.va_data.va_number}\nVA Bukti: ${vaFromBukti}\n\nPastikan VA benar sebelum validasi.`);
                return;
            }

            // Check amount match
            if (amountFromBukti !== currentValidationPayment.amount_total) {
                alert(`❌ NOMINAL TIDAK SESUAI!\n\nNominal Tagihan: ${formatCurrency(currentValidationPayment.amount_total)}\nNominal Bukti: ${formatCurrency(amountFromBukti)}\n\nPastikan nominal benar sebelum validasi.`);
                return;
            }

            // All validation passed - call VA system validation
            const result = adminValidatePayment(currentValidationPayment.payment_id, {
                va_from_bukti: vaFromBukti,
                amount_paid: amountFromBukti
            });

            if (result.success) {
                let message = '✓ Pembayaran berhasil divalidasi!\n\n';
                
                if (result.krs_activated) {
                    message += '✓ KRS berhasil diaktifkan otomatis\n';
                } else {
                    message += '⚠️ KRS belum bisa diaktifkan (pembayaran belum mencukupi)\n';
                }

                message += '\n✓ Notifikasi sudah dikirim ke mahasiswa';

                alert(message);
                closeValidationModal();
                loadPendingPayments();
                updateStats();
            } else {
                alert(`❌ Error: ${result.message}`);
            }
        }

        /**
         * Open reject modal
         */
        function openRejectModal(paymentId) {
            const allPayments = JSON.parse(localStorage.getItem('payments') || '{}');
            
            for (const key in allPayments) {
                const payment = JSON.parse(allPayments[key]);
                if (payment.payment_id === paymentId) {
                    currentRejectPayment = payment;
                    document.getElementById('rejectReason').value = '';
                    document.getElementById('rejectModal').classList.add('show');
                    break;
                }
            }
        }

        /**
         * Close reject modal
         */
        function closeRejectModal() {
            document.getElementById('rejectModal').classList.remove('show');
            currentRejectPayment = null;
        }

        /**
         * Submit rejection
         */
        function submitReject() {
            if (!currentRejectPayment) {
                alert('Error: Data pembayaran tidak ditemukan');
                return;
            }

            const reason = document.getElementById('rejectReason').value.trim();

            if (!reason) {
                alert('⚠️ Silakan masukkan alasan penolakan');
                return;
            }

            // Get all payments
            const allPayments = JSON.parse(localStorage.getItem('payments') || '{}');
            
            // Find and update
            for (const key in allPayments) {
                const payment = JSON.parse(allPayments[key]);
                if (payment.payment_id === currentRejectPayment.payment_id) {
                    payment.status = 'REJECTED';
                    payment.rejection_reason = reason;
                    payment.rejected_at = new Date().toISOString();
                    
                    allPayments[key] = JSON.stringify(payment);
                    localStorage.setItem('payments', JSON.stringify(allPayments));
                    
                    // Send notification
                    sendNotificationToStudent(
                        payment.nim,
                        'Pembayaran Ditolak',
                        `Pembayaran untuk Semester ${payment.semester.semester_num} ditolak. Alasan: ${reason}. Silakan hubungi admin.`,
                        'error'
                    );

                    alert(`✓ Pembayaran ditolak.\n\n✓ Notifikasi sudah dikirim ke mahasiswa: ${payment.nim}`);
                    closeRejectModal();
                    loadPendingPayments();
                    updateStats();
                    break;
                }
            }
        }

        /**
         * Get payment record
         */
        function getPaymentRecord(paymentId) {
            const allPayments = JSON.parse(localStorage.getItem('payments') || '{}');
            for (const key in allPayments) {
                const payment = JSON.parse(allPayments[key]);
                if (payment.payment_id === paymentId) {
                    return payment;
                }
            }
            return null;
        }
    </script>
</body>
</html>

