<?php
require 'api/config/database.php';
$db = new Database();
$conn = $db->connect();

echo "=== RESET TEST DATA ===\n\n";

// Delete pembayaran records
$conn->exec('DELETE FROM pembayaran WHERE mahasiswa_id = 2');
echo "✅ Deleted pembayaran records\n";

// Reset tagihan status to belum_bayar
$conn->exec("UPDATE tagihan SET status_pembayaran = 'belum_bayar' WHERE mahasiswa_id = 2");
echo "✅ Reset tagihan status to belum_bayar\n";

// Reset metode_pembayaran
$conn->exec("UPDATE tagihan SET metode_pembayaran = NULL WHERE mahasiswa_id = 2");
echo "✅ Reset metode_pembayaran\n";

echo "\n=== DATA SETELAH RESET ===\n\n";

$result = $conn->query('SELECT tagihan_id, status_pembayaran, metode_pembayaran FROM tagihan WHERE mahasiswa_id = 2 LIMIT 1');
$row = $result->fetch();
echo "Tagihan 19:\n";
echo "  Status: " . $row['status_pembayaran'] . "\n";
echo "  Metode: " . ($row['metode_pembayaran'] ?: 'NULL') . "\n";

echo "\n✅ READY FOR TESTING\n";
?>
