<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header('Location: mhs_login.php');
    exit;
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tagihan Mahasiswa</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.13.1/font/bootstrap-icons.min.css">
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }

        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: #f5f5f5;
            padding: 20px;
        }

        .container {
            max-width: 1200px;
            margin: 0 auto;
        }

        .header {
            background: white;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
            margin-bottom: 30px;
        }

        .header h1 {
            color: #333;
            margin-bottom: 10px;
        }

        .header p {
            color: #666;
            margin: 0;
        }

        .main-content {
            background: white;
            border-radius: 8px;
            padding: 30px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
        }

        .section-title {
            font-size: 22px;
            margin-bottom: 25px;
            color: #333;
            font-weight: 600;
            border-bottom: 2px solid #4169E1;
            padding-bottom: 10px;
        }

        /* Styles akan ditambahkan oleh tagihan-manager.js */
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1>Tagihan Mahasiswa</h1>
            <p>Sistem akan otomatis menghitung dan menampilkan tagihan berdasarkan data tarif terbaru</p>
        </div>

        <div class="main-content">
            <h2 class="section-title">Tagihan Aktif</h2>
            
            <!-- Container untuk menampilkan tagihan -->
            <div id="tagihan-container">
                <!-- Konten akan dimuat oleh JavaScript -->
            </div>
        </div>
    </div>

    <!-- Include JavaScript untuk menangani proses tagihan -->
    <script src="js/tagihan-manager.js"></script>
</body>
</html>