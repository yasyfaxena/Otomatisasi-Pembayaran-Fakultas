@echo off
REM ============================================
REM Auto-Create Tagihan - Windows Task Scheduler
REM ============================================
REM Script ini akan dijalankan otomatis setiap hari
REM untuk membuat tagihan semester berikutnya
REM untuk semua mahasiswa yang eligible
REM ============================================

echo [%date% %time%] Starting auto-create tagihan...

REM Panggil endpoint trigger menggunakan curl
curl -X GET "http://localhost/projek_plbs/api/trigger/auto-create-tagihan" -H "Content-Type: application/json"

echo.
echo [%date% %time%] Auto-create tagihan completed.
