# 🚀 QUICK FIX SCRIPT - API 404/401 ERROR RESOLUTION (WINDOWS)
# 
# PowerShell script to quickly diagnose and fix API routing issues
# Execute commands one by one in PowerShell

Write-Host "================================"
Write-Host "API ROUTING QUICK FIX GUIDE (WINDOWS)" -ForegroundColor Cyan
Write-Host "================================" -ForegroundColor Cyan
Write-Host ""
Write-Host "✅ WHAT WE'VE ALREADY DONE:" -ForegroundColor Green
Write-Host "   1. Created api\.htaccess with rewrite rules"
Write-Host "   2. Updated api\routes\api.php to support query parameters"
Write-Host "   3. Created api\test_routing.php for testing"
Write-Host ""

Write-Host "================================"
Write-Host "STEP 1: TEST WITH QUERY PARAMETER" -ForegroundColor Yellow
Write-Host "================================"
Write-Host ""
Write-Host "This is the FASTEST way to see if your backend works" -ForegroundColor Cyan
Write-Host ""
Write-Host "📝 Edit login_admin_universitas.php:"
Write-Host "   Line ~295: Change fetch URL from:"
Write-Host "   '/projek_plbs/api/index.php/api/auth/login'"
Write-Host "   "
Write-Host "   To:"
Write-Host "   '/projek_plbs/api/index.php?path=/api/auth/login'" -ForegroundColor Green
Write-Host ""
Write-Host "Then try to login"
Write-Host "Expected: Either success OR 401 (means routing works!)"
Write-Host ""

Write-Host "================================"
Write-Host "STEP 2: TEST API WITH BROWSER" -ForegroundColor Yellow
Write-Host "================================"
Write-Host ""
Write-Host "Open browser and go to:" -ForegroundColor Cyan
Write-Host "http://localhost:8000/api/test_routing.php" -ForegroundColor Green
Write-Host ""
Write-Host "Click the three buttons to see which URL format works:"
Write-Host "✓ SUCCESS = That URL format works"
Write-Host "✗ NOT FOUND = Try another format"
Write-Host "⚠ UNAUTHORIZED = Routing OK, auth failed"
Write-Host ""

Write-Host "================================"
Write-Host "STEP 3: CHECK ERROR LOGS" -ForegroundColor Yellow
Write-Host "================================"
Write-Host ""
Write-Host "PowerShell command:" -ForegroundColor Cyan
Write-Host "Get-Content logs/api_errors.log" -ForegroundColor Green
Write-Host ""
Write-Host "Or open in VS Code:"
Write-Host "code logs/api_errors.log" -ForegroundColor Green
Write-Host ""
Write-Host "Expected:"
Write-Host "- EMPTY = API not being called (routing issue)"
Write-Host "- Errors = API called, but something failed"
Write-Host ""

Write-Host "================================"
Write-Host "STEP 4: RUN DIAGNOSTIC" -ForegroundColor Yellow
Write-Host "================================"
Write-Host ""
Write-Host "PowerShell command:" -ForegroundColor Cyan
Write-Host "php api\ENDPOINT_DIAGNOSTIC.php" -ForegroundColor Green
Write-Host ""
Write-Host "Expected: All ✅ items"
Write-Host ""

Write-Host "================================"
Write-Host "STEP 5: VERIFY DATABASE USERS" -ForegroundColor Yellow
Write-Host "================================"
Write-Host ""
Write-Host "Run this PowerShell command:" -ForegroundColor Cyan
Write-Host "php api\scripts\quick_verify.php" -ForegroundColor Green
Write-Host ""
Write-Host "Or check database using MySQL client:"
Write-Host "mysql -u root projek_plbs -e 'SELECT username, password_hash, is_active FROM users;'" -ForegroundColor Green
Write-Host ""

Write-Host "================================"
Write-Host "STEP 6: FIX IF NEEDED" -ForegroundColor Yellow
Write-Host "================================"
Write-Host ""
Write-Host "If credentials don't work, generate new hash:" -ForegroundColor Cyan
Write-Host "php api\scripts\generate_password_hash.php" -ForegroundColor Green
Write-Host ""

Write-Host "================================"
Write-Host "TESTING WITH CURL" -ForegroundColor Yellow
Write-Host "================================"
Write-Host ""
Write-Host "Format 1 (PATH_INFO - requires .htaccess):" -ForegroundColor Cyan
Write-Host @"
curl -X POST http://localhost:8000/projek_plbs/api/index.php/api/auth/login `
  -H 'Content-Type: application/json' `
  -d '{"username":"admin_universitas","password":"password123"}'
"@ -ForegroundColor Green
Write-Host ""

Write-Host "Format 2 (Query Parameter - works anywhere):" -ForegroundColor Cyan
Write-Host @"
curl -X POST 'http://localhost:8000/projek_plbs/api/index.php?path=/api/auth/login' `
  -H 'Content-Type: application/json' `
  -d '{"username":"admin_universitas","password":"password123"}'
"@ -ForegroundColor Green
Write-Host ""

Write-Host "================================"
Write-Host "QUICK TEST COMMANDS" -ForegroundColor Yellow
Write-Host "================================"
Write-Host ""
Write-Host "All commands below, run in PowerShell:" -ForegroundColor Cyan
Write-Host ""

Write-Host "1. Check if .htaccess exists:" -ForegroundColor Yellow
Write-Host "   Test-Path api\.htaccess" -ForegroundColor Green
Write-Host ""

Write-Host "2. View .htaccess content:" -ForegroundColor Yellow
Write-Host "   Get-Content api\.htaccess" -ForegroundColor Green
Write-Host ""

Write-Host "3. Check error log:" -ForegroundColor Yellow
Write-Host "   Get-Content logs/api_errors.log -Tail 20" -ForegroundColor Green
Write-Host ""

Write-Host "4. Run diagnostic:" -ForegroundColor Yellow
Write-Host "   php api\ENDPOINT_DIAGNOSTIC.php" -ForegroundColor Green
Write-Host ""

Write-Host "5. Test PHP directly:" -ForegroundColor Yellow
Write-Host @"
php -r "
\`$_SERVER['REQUEST_METHOD'] = 'POST';
\`$_SERVER['REQUEST_URI'] = '/api/auth/login';
\`$_GET['path'] = '/api/auth/login';
require 'api/index.php';
" 
"@ -ForegroundColor Green
Write-Host ""

Write-Host "================================"
Write-Host "WHICH SOLUTION TO IMPLEMENT" -ForegroundColor Cyan
Write-Host "================================"
Write-Host ""
Write-Host "Option A: Use .htaccess (RECOMMENDED)" -ForegroundColor Green
Write-Host "  ✅ Already created at: api\.htaccess"
Write-Host "  ✅ Should work automatically with Apache"
Write-Host "  ✅ Cleaner URLs for frontend"
Write-Host "  ✅ Best for production"
Write-Host ""
Write-Host "Option B: Use Query Parameter (FALLBACK)" -ForegroundColor Green
Write-Host "  ✅ Router already supports it"
Write-Host "  ✅ Just change frontend URL to ?path=/api/auth/login"
Write-Host "  ✅ Works on any server"
Write-Host "  ✅ Good temporary workaround"
Write-Host ""

Write-Host "================================"
Write-Host "IMPLEMENTATION CHECKLIST" -ForegroundColor Cyan
Write-Host "================================"
Write-Host ""
Write-Host "✅ Files Created/Updated:" -ForegroundColor Green
Write-Host "   [✓] api\.htaccess - htaccess rewrite rules"
Write-Host "   [✓] api\routes\api.php - Router enhanced"
Write-Host "   [✓] api\test_routing.php - Interactive test page"
Write-Host ""
Write-Host "⏳ YOUR ACTION ITEMS:" -ForegroundColor Yellow
Write-Host "   [ ] Edit login form URL (choose htaccess OR query param)"
Write-Host "   [ ] Test login with new format"
Write-Host "   [ ] Verify Network tab shows 200 OK"
Write-Host "   [ ] Check database credentials are correct"
Write-Host "   [ ] If 401: Use password generator script"
Write-Host ""

Write-Host "================================"
Write-Host "EXPECTED RESPONSES" -ForegroundColor Cyan
Write-Host "================================"
Write-Host ""
Write-Host "✅ GOOD RESPONSES:" -ForegroundColor Green
Write-Host "   200 OK + {\"status\":\"success\",...} = Perfect!"
Write-Host "   401 UNAUTHORIZED = Routing OK, wrong username/password"
Write-Host ""
Write-Host "❌ BAD RESPONSES:" -ForegroundColor Red
Write-Host "   404 NOT FOUND = Routing not working"
Write-Host "   500 INTERNAL ERROR = Check error logs"
Write-Host ""

Write-Host "================================"
Write-Host "FILES REFERENCE" -ForegroundColor Cyan
Write-Host "================================"
Write-Host ""
Write-Host "✅ CREATED/UPDATED:" -ForegroundColor Green
Write-Host "   api\.htaccess - NEW (rewrite rules)"
Write-Host "   api\routes\api.php - UPDATED (Router)"
Write-Host "   api\test_routing.php - NEW (testing)"
Write-Host ""
Write-Host "✅ ALREADY CORRECT:" -ForegroundColor Green
Write-Host "   api\index.php - entry point"
Write-Host "   api\controllers\AuthController.php - login logic"
Write-Host "   api\config\database.php - DB config"
Write-Host ""
Write-Host "⏳ CHECK IF ERRORS:" -ForegroundColor Yellow
Write-Host "   logs\api_errors.log - error logs"
Write-Host ""

Write-Host "================================"
Write-Host "INTERACTIVE TEST PAGE" -ForegroundColor Cyan
Write-Host "================================"
Write-Host ""
Write-Host "OPEN IN BROWSER:" -ForegroundColor Yellow
Write-Host "http://localhost:8000/api/test_routing.php" -ForegroundColor Green
Write-Host ""
Write-Host "This page will test all 3 URL formats and show which works" -ForegroundColor Cyan
Write-Host ""

Write-Host "================================"
Write-Host "TROUBLESHOOTING" -ForegroundColor Cyan
Write-Host "================================"
Write-Host ""
Write-Host "If getting 404:" -ForegroundColor Yellow
Write-Host "  1. Check api\.htaccess exists"
Write-Host "  2. Verify Apache mod_rewrite is enabled"
Write-Host "  3. Try query parameter format instead"
Write-Host "  4. Check RewriteBase in .htaccess"
Write-Host ""
Write-Host "If getting 401:" -ForegroundColor Yellow
Write-Host "  1. Routing works! ✅"
Write-Host "  2. Check username/password in database"
Write-Host "  3. Verify password is hashed with password_hash()"
Write-Host "  4. Use password generator: php api\scripts\generate_password_hash.php"
Write-Host ""
Write-Host "If getting 500:" -ForegroundColor Yellow
Write-Host "  1. Check logs\api_errors.log for error details"
Write-Host "  2. Run diagnostic: php api\ENDPOINT_DIAGNOSTIC.php"
Write-Host "  3. Verify database connection"
Write-Host ""

Write-Host ""
Write-Host "================================" -ForegroundColor Cyan
Write-Host "Ready to fix! Choose your method and start testing." -ForegroundColor Green
Write-Host "================================" -ForegroundColor Cyan
