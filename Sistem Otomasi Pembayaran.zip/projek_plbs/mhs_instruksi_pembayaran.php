<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header('Location: mhs_login.php');
    exit;
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Instruksi Pembayaran</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: #f5f5f5;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }

        .instruction-container {
            width: 100%;
            max-width: 600px;
            background: white;
            border-radius: 12px;
            padding: 30px 40px;
            box-shadow: 0 6px 20px rgba(0,0,0,0.1);
            border: 1px solid #e0e0e0;
            text-align: center;
        }

        .page-header {
            margin-bottom: 25px;
            padding-bottom: 15px;
            border-bottom: 1px solid #eee;
        }
        .page-title {
            font-size: 24px;
            font-weight: 700;
            color: #1B5E20; /* Green for success */
        }

        .payment-details {
            text-align: left;
            margin-bottom: 25px;
        }
        .detail-row {
            display: grid;
            grid-template-columns: 180px 1fr;
            align-items: center;
            margin-bottom: 15px;
            font-size: 16px;
        }
        .detail-label { color: #555; font-weight: 600; }
        .detail-value { color: #333; font-weight: 600; }

        .va-number-section {
            margin-top: 20px;
            padding: 20px;
            background-color: #e3f2fd;
            border-radius: 8px;
            border: 1px dashed #2196F3;
        }
        .va-label {
            font-size: 16px;
            color: #1d4b73;
            margin-bottom: 8px;
        }
        .va-number {
            font-size: 28px;
            font-weight: 700;
            color: #0d47a1;
            letter-spacing: 2px;
        }

        .payment-channels, .payment-status {
            text-align: left;
            margin-top: 25px;
        }
        .section-title { font-size: 16px; font-weight: 700; color: #333; margin-bottom: 10px; }
        .channels-list { list-style: none; padding-left: 5px; color: #555; }
        .channels-list li { margin-bottom: 5px; }

        .status { padding: 8px 18px; border-radius: 20px; font-size: 14px; font-weight: 700; display: inline-block; text-transform: uppercase; }
        .status-oranye { background-color: #FFF3E0; color: #E65100; }
        
        .action-buttons {
            display: flex;
            justify-content: center;
            gap: 15px;
            margin-top: 30px;
        }

        .btn {
            border: none;
            padding: 12px 25px;
            border-radius: 8px;
            cursor: pointer;
            font-weight: 700;
            font-size: 15px;
            transition: all 0.3s;
            text-decoration: none;
            display: inline-block;
        }
        .btn-blue { background-color: #2196F3; color: white; }
        .btn-blue:hover { background-color: #1976D2; }

    </style>
</head>
<body>
    <div class="instruction-container">
        <header class="page-header">
            <h1 class="page-title">PEMBAYARAN BERHASIL DIBUAT</h1>
        </header>

        <div class="payment-details">
            <div class="detail-row">
                <span class="detail-label">Jenis Pembayaran</span>
                <span class="detail-value" id="jenis-pembayaran">-</span>
            </div>
            <div class="detail-row">
                <span class="detail-label">Total Tagihan</span>
                <span class="detail-value" id="total-tagihan">-</span>
            </div>
            <div class="va-number-section">
                <div class="va-label">Nomor Virtual Account Anda</div>
                <div class="va-number" id="va-number">8888 1302 0220 029</div>
            </div>
        </div>

        <div class="payment-channels">
            <h3 class="section-title">Silakan lakukan pembayaran melalui:</h3>
            <ul class="channels-list">
                <li>- ATM</li>
                <li>- Mobile Banking</li>
                <li>- Teller Bank</li>
            </ul>
        </div>

        <div class="payment-status">
             <h3 class="section-title">Status Pembayaran:</h3>
             <span class="status status-oranye">Menunggu Validasi</span>
        </div>

        <div class="action-buttons">
            <a href="mhs_riwayat_pembayaran.php" class="btn btn-blue">Lihat Riwayat Pembayaran</a>
        </div>
    </div>

    <script>
        document.addEventListener('DOMContentLoaded', function() {
            const params = new URLSearchParams(window.location.search);
            const type = params.get('type');
            const total = params.get('total');
            const semester = params.get('semester');

            function formatRupiah(angka) {
                return 'Rp ' + parseInt(angka).toLocaleString('id-ID');
            }
            
            // --- SIMULASI PEMBENTUKAN VA ---
            function createVA(type, nim) {
                let vaPrefix;
                const baseNim = nim.replace(/\s/g, '');

                if (type.includes('BPP Lunas')) vaPrefix = '8888';
                else if (type.includes('BPP Cicilan')) vaPrefix = '9999';
                else if (type.includes('Skripsi')) vaPrefix = '7777';
                else if (type.includes('Proposal')) vaPrefix = '6666';
                else vaPrefix = '1111';
                
                // Format: PREFIX 1302 0220 029
                return `${vaPrefix} ${baseNim.slice(0, 4)} ${baseNim.slice(4, 8)} ${baseNim.slice(8)}`;
            }
            
            const nim = "13020220029"; // Data NIM mahasiswa (bisa diambil dari sesi login)
            const vaNumber = createVA(type, nim);

            let displayType = type;
            if (type === 'BPP Cicilan') {
                displayType = `BPP Semester 5 (Cicilan)`;
            } else if (type === 'BPP Lunas') {
                displayType = `BPP Semester 5 (Lunas)`;
            }

            document.getElementById('jenis-pembayaran').textContent = displayType;
            document.getElementById('total-tagihan').textContent = formatRupiah(total);
            document.getElementById('va-number').textContent = vaNumber;
        });
    </script>
</body>
</html>

