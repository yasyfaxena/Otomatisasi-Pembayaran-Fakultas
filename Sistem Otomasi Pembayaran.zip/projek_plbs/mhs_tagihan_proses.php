<?php
/**
 * BACKEND: Proses Tagihan Mahasiswa
 */

ob_start();
session_start();
ob_clean();
header('Content-Type: application/json; charset=utf-8');
ini_set('display_errors', 1);
error_reporting(E_ALL);

if (!isset($_SESSION['user_id'])) {
    http_response_code(401);
    echo json_encode(['status' => 'error', 'message' => 'Unauthorized', 'code' => 'UNAUTHORIZED']);
    exit;
}

try {
    require_once __DIR__ . '/api/config/database.php';
    require_once __DIR__ . '/api/config/helpers.php';
    require_once __DIR__ . '/api/helpers/payment_helper.php';
    
    $database = new Database();
    $conn = $database->connect();
    $user_id = $_SESSION['user_id'];
    
    // Step 2: Ambil data mahasiswa dari database berdasarkan user_id (PDO)
    $query = "
        SELECT 
            m.mahasiswa_id,
            m.nim,
            m.semester_aktif,
            m.tahun_akademik,
            m.prodi_id,
            ps.fakultas_id,
            u.nama_lengkap
        FROM mahasiswa m
        JOIN users u ON m.user_id = u.user_id
        JOIN program_studi ps ON m.prodi_id = ps.prodi_id
        WHERE m.user_id = :user_id
        LIMIT 1
    ";
    
    $stmt = $conn->prepare($query);
    if (!$stmt) {
        throw new Exception('Failed to prepare statement: ' . print_r($conn->errorInfo(), true));
    }
    
    $stmt->bindParam(':user_id', $user_id, PDO::PARAM_INT);
    $stmt->execute();
    $mahasiswa = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$mahasiswa) {
        http_response_code(404);
        echo json_encode([
            'status' => 'error',
            'message' => 'Data mahasiswa tidak ditemukan untuk user_id: ' . $user_id,
            'code' => 'MAHASISWA_NOT_FOUND'
        ]);
        exit;
    }
    
    $mahasiswa_id = $mahasiswa['mahasiswa_id'];
    $semester_aktif = $mahasiswa['semester_aktif'];
    $tahun_akademik = $mahasiswa['tahun_akademik'];
    $prodi_id = $mahasiswa['prodi_id'];
    $fakultas_id = $mahasiswa['fakultas_id'];
    
    // Step 3: AUTO-CREATE BPP TAGIHAN jika belum ada untuk semester aktif
    $bpp_autocreated = false;
    $check_bpp = "
        SELECT tagihan_id FROM tagihan 
        WHERE mahasiswa_id = :mahasiswa_id 
            AND jenis_tagihan = 'BPP'
            AND semester = :semester_aktif
            AND tahun_akademik = :tahun_akademik
        LIMIT 1
    ";
    
    $stmt = $conn->prepare($check_bpp);
    $stmt->bindParam(':mahasiswa_id', $mahasiswa_id, PDO::PARAM_INT);
    $stmt->bindParam(':semester_aktif', $semester_aktif, PDO::PARAM_INT);
    $stmt->bindParam(':tahun_akademik', $tahun_akademik, PDO::PARAM_STR);
    $stmt->execute();
    $bpp_exists = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$bpp_exists) {
        // BPP tidak ada, ambil tarif BPP untuk prodi ini dengan validasi lengkap
        // VALIDASI TARIF:
        // - is_active = 1 (tarif aktif)
        // - jenis_tagihan = 'BPP' (jenis tagihan harus BPP)
        // - prodi_id cocok
        // - semester BETWEEN semester_dari AND semester_sampai
        $tarif_query = "
            SELECT nominal FROM tarif 
            WHERE prodi_id = :prodi_id 
                AND jenis_tagihan = 'BPP'
                AND is_active = 1
                AND :semester_aktif BETWEEN semester_dari AND semester_sampai
            LIMIT 1
        ";
        
        $stmt = $conn->prepare($tarif_query);
        $stmt->bindParam(':prodi_id', $prodi_id, PDO::PARAM_INT);
        $stmt->bindParam(':semester_aktif', $semester_aktif, PDO::PARAM_INT);
        $stmt->execute();
        $tarif = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if ($tarif) {
            // Create BPP tagihan baru
            $insert_bpp = "
                INSERT INTO tagihan 
                (mahasiswa_id, jenis_tagihan, semester, tahun_akademik, 
                 jumlah_tagihan, status_pembayaran, metode_pembayaran, 
                 tgl_jatuh_tempo, created_at)
                VALUES 
                (:mahasiswa_id, 'BPP', :semester, :tahun_akademik, 
                 :jumlah_tagihan, 'belum_bayar', 'lunas', 
                 DATE_ADD(NOW(), INTERVAL 14 DAY), NOW())
            ";
            
            $stmt = $conn->prepare($insert_bpp);
            $stmt->bindParam(':mahasiswa_id', $mahasiswa_id, PDO::PARAM_INT);
            $stmt->bindParam(':semester', $semester_aktif, PDO::PARAM_INT);
            $stmt->bindParam(':tahun_akademik', $tahun_akademik, PDO::PARAM_STR);
            $nominal_value = (float)$tarif['nominal'];
            $stmt->bindParam(':jumlah_tagihan', $nominal_value, PDO::PARAM_STR);
            $stmt->execute();
            
            $bpp_autocreated = true;
            error_log("BPP auto-created untuk mahasiswa_id=$mahasiswa_id, semester=$semester_aktif, nominal=$nominal_value");
        }
    }
    
    // Step 3.3: AUTO-CREATE PROPOSAL TAGIHAN jika eligible
    // Syarat: BPP Semester 6 sudah lunas
    $proposal_autocreated = false;
    try {
        error_log("[mhs_tagihan_proses] Attempting to create PROPOSAL for mahasiswa_id=$mahasiswa_id");
        $proposal_result = autoCreateProposalTagihan($conn, $mahasiswa_id, $tahun_akademik, $prodi_id);
        if ($proposal_result) {
            error_log("[mhs_tagihan_proses] SUCCESS: PROPOSAL tagihan_id=$proposal_result created for mahasiswa_id=$mahasiswa_id");
            $proposal_autocreated = true;
        } else {
            error_log("[mhs_tagihan_proses] INFO: PROPOSAL not created (null result) for mahasiswa_id=$mahasiswa_id - may not be eligible or already exists");
        }
    } catch (Exception $e) {
        error_log("[mhs_tagihan_proses] ERROR creating PROPOSAL tagihan: " . $e->getMessage());
    }
    
    // Step 3.4: AUTO-CREATE SKRIPSI TAGIHAN jika eligible
    // Syarat: BPP Semester 6 sudah lunas
    $skripsi_autocreated = false;
    try {
        error_log("[mhs_tagihan_proses] Attempting to create SKRIPSI for mahasiswa_id=$mahasiswa_id");
        $skripsi_result = autoCreateSkripsiTagihan($conn, $mahasiswa_id, $tahun_akademik, $prodi_id);
        if ($skripsi_result) {
            error_log("[mhs_tagihan_proses] SUCCESS: SKRIPSI tagihan_id=$skripsi_result created for mahasiswa_id=$mahasiswa_id");
            $skripsi_autocreated = true;
        } else {
            error_log("[mhs_tagihan_proses] INFO: SKRIPSI not created (null result) for mahasiswa_id=$mahasiswa_id - may not be eligible or already exists");
        }
    } catch (Exception $e) {
        error_log("[mhs_tagihan_proses] ERROR creating SKRIPSI tagihan: " . $e->getMessage());
    }
    
    // Step 3.5: AUTO-CREATE NEXT BPP SEMESTER jika eligible
    // Check apakah ada tagihan lunas yang bisa trigger next semester
    try {
        // Get highest paid BPP semester
        $highest_paid = getHighestPaidBPPSemester($conn, $mahasiswa_id);
        
        // If student has paid some BPP, try to auto-create next semester
        if ($highest_paid && $highest_paid < 7) {
            $next_semester = $highest_paid + 1;
            
            // Check apakah tagihan semester berikutnya sudah ada
            $check_next = "
                SELECT COUNT(*) as count FROM tagihan 
                WHERE mahasiswa_id = :mahasiswa_id 
                    AND jenis_tagihan = 'BPP'
                    AND semester = :semester
                    AND tahun_akademik = :tahun_akademik
            ";
            $stmt = $conn->prepare($check_next);
            $stmt->bindParam(':mahasiswa_id', $mahasiswa_id, PDO::PARAM_INT);
            $stmt->bindParam(':semester', $next_semester, PDO::PARAM_INT);
            $stmt->bindParam(':tahun_akademik', $tahun_akademik, PDO::PARAM_STR);
            $stmt->execute();
            $next_exists = $stmt->fetch(PDO::FETCH_ASSOC);
            
            // If tidak ada, auto-create
            if ((int)$next_exists['count'] === 0) {
                // Get tarif untuk semester berikutnya
                $tarif_query = "
                    SELECT nominal FROM tarif 
                    WHERE prodi_id = :prodi_id 
                        AND jenis_tagihan = 'BPP'
                        AND is_active = 1
                        AND :semester BETWEEN semester_dari AND semester_sampai
                    LIMIT 1
                ";
                $stmt = $conn->prepare($tarif_query);
                $stmt->bindParam(':prodi_id', $prodi_id, PDO::PARAM_INT);
                $stmt->bindParam(':semester', $next_semester, PDO::PARAM_INT);
                $stmt->execute();
                $tarif_next = $stmt->fetch(PDO::FETCH_ASSOC);
                
                if ($tarif_next && $tarif_next['nominal']) {
                    // Create next semester BPP tagihan
                    $insert_next = "
                        INSERT INTO tagihan 
                        (mahasiswa_id, jenis_tagihan, semester, tahun_akademik, 
                         jumlah_tagihan, status_pembayaran, metode_pembayaran, 
                         tgl_jatuh_tempo, created_at)
                        VALUES 
                        (:mahasiswa_id, 'BPP', :semester, :tahun_akademik, 
                         :jumlah_tagihan, 'belum_bayar', 'lunas', 
                         DATE_ADD(NOW(), INTERVAL 14 DAY), NOW())
                    ";
                    $stmt = $conn->prepare($insert_next);
                    $stmt->bindParam(':mahasiswa_id', $mahasiswa_id, PDO::PARAM_INT);
                    $stmt->bindParam(':semester', $next_semester, PDO::PARAM_INT);
                    $stmt->bindParam(':tahun_akademik', $tahun_akademik, PDO::PARAM_STR);
                    $nominal_next = (float)$tarif_next['nominal'];
                    $stmt->bindParam(':jumlah_tagihan', $nominal_next, PDO::PARAM_STR);
                    $stmt->execute();
                    
                    error_log("BPP Semester $next_semester auto-created untuk mahasiswa_id=$mahasiswa_id");
                }
            }
        }
    } catch (Exception $e) {
        error_log("Error creating next BPP semester: " . $e->getMessage());
    }
    
    // Step 3.5: Ambil data tagihan yang belum lunas (PDO)
    $query = "
        SELECT 
            t.tagihan_id,
            t.jenis_tagihan,
            t.semester,
            t.tahun_akademik,
            t.jumlah_tagihan,
            t.status_pembayaran,
            t.metode_pembayaran,
            t.tgl_jatuh_tempo,
            t.created_at
        FROM tagihan t
        WHERE t.mahasiswa_id = :mahasiswa_id
            AND t.status_pembayaran != 'lunas'
            AND t.tahun_akademik = :tahun_akademik
        ORDER BY 
            CASE UPPER(t.jenis_tagihan)
                WHEN 'BPP' THEN 1
                WHEN 'PROPOSAL' THEN 2
                WHEN 'SKRIPSI' THEN 3
                ELSE 4
            END,
            t.semester ASC
    ";
    
    $stmt = $conn->prepare($query);
    if (!$stmt) {
        throw new Exception('Failed to prepare tagihan query');
    }
    
    $stmt->bindParam(':mahasiswa_id', $mahasiswa_id, PDO::PARAM_INT);
    $stmt->bindParam(':tahun_akademik', $tahun_akademik, PDO::PARAM_STR);
    $stmt->execute();
    $tagihanList = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    if (!is_array($tagihanList)) {
        $tagihanList = [];
    }
    
    // Step 3.6: Ambil program studi (nama_prodi) untuk mahasiswa
    $nama_prodi = '';
    if ($prodi_id) {
        $prodi_query = "
            SELECT nama_prodi FROM program_studi 
            WHERE prodi_id = :prodi_id LIMIT 1
        ";
        $stmt = $conn->prepare($prodi_query);
        $stmt->bindParam(':prodi_id', $prodi_id, PDO::PARAM_INT);
        $stmt->execute();
        $prodi = $stmt->fetch(PDO::FETCH_ASSOC);
        if ($prodi) {
            $nama_prodi = $prodi['nama_prodi'];
        }
    }
    
    // Step 3.7: Ambil Virtual Account data untuk setiap tagihan
    $vaDataByTagihan = [];
    if (!empty($tagihanList)) {
        foreach ($tagihanList as $t) {
            $va_query = "
                SELECT 
                    va_id,
                    nomor_va,
                    status_va,
                    metode_pembayaran,
                    jumlah_va
                FROM virtual_account 
                WHERE tagihan_id = :tagihan_id
                LIMIT 1
            ";
            
            $stmt = $conn->prepare($va_query);
            $stmt->bindParam(':tagihan_id', $t['tagihan_id'], PDO::PARAM_INT);
            $stmt->execute();
            $va = $stmt->fetch(PDO::FETCH_ASSOC);
            
            if ($va) {
                $vaDataByTagihan[$t['tagihan_id']] = [
                    'va_id' => (int)$va['va_id'],
                    'nomor_va' => $va['nomor_va'],
                    'status_va' => $va['status_va'],
                    'metode_pembayaran' => $va['metode_pembayaran'],
                    'jumlah_va' => $va['jumlah_va']
                ];
            } else {
                // VA belum ada untuk tagihan ini
                $vaDataByTagihan[$t['tagihan_id']] = null;
            }
        }
        
        // Enhance tagihan dengan payment flags
        foreach ($tagihanList as &$t) {
            $t['jumlah_tagihan'] = (float)$t['jumlah_tagihan'];
            $t['virtual_account'] = $vaDataByTagihan[$t['tagihan_id']] ?? null;
            
            try {
                // KRUSIAL: Tambahkan payment flags dan sisa tagihan
                $t = enhanceTagihanData($conn, $t);
            } catch (Exception $e) {
                error_log('Error enhanceTagihanData: ' . $e->getMessage());
                // Set default values jika error
                $t['can_pay_lunas'] = false;
                $t['can_pay_cicilan'] = false;
                $t['sisa_tagihan'] = $t['jumlah_tagihan'];
            }
            
            // Jika metode cicilan, tambahkan info nominal cicilan
            if ($t['metode_pembayaran'] === 'cicilan') {
                $t['nominal_cicilan'] = (float)$t['jumlah_tagihan'] / 2;
                $t['jumlah_cicilan'] = 2;
                
                // Check if first cicilan is already paid
                $cek_cicilan_pertama = "
                    SELECT status_cicilan FROM cicilan_detail 
                    WHERE tagihan_id = :tagihan_id AND nomor_cicilan = 1
                    LIMIT 1
                ";
                $stmt_cicilan = $conn->prepare($cek_cicilan_pertama);
                $stmt_cicilan->bindParam(':tagihan_id', $t['tagihan_id'], PDO::PARAM_INT);
                $stmt_cicilan->execute();
                $cicilan_pertama = $stmt_cicilan->fetch(PDO::FETCH_ASSOC);
                
                // cicilan_first_paid = true jika cicilan pertama sudah dibayar (lunas atau sebagian_dibayar)
                $t['cicilan_first_paid'] = ($cicilan_pertama && in_array($cicilan_pertama['status_cicilan'], ['lunas', 'sebagian_dibayar'])) ? true : false;
            } else {
                $t['cicilan_first_paid'] = false;
            }
        }
        unset($t);
    }
    
    // Step 4: Ambil cicilan aktif
    $cicilanList = [];
    $has_active_installment = false;
    
    if (!empty($tagihanList)) {
        foreach ($tagihanList as $t) {
            if ($t['metode_pembayaran'] === 'cicilan') {
                $has_active_installment = true;
                break;
            }
        }
    }
    
    // Step 5: Return response JSON
    $response = [
        'status' => 'success',
        'data' => [
            'mahasiswa' => [
                'mahasiswa_id' => (int)$mahasiswa_id,
                'nim' => $mahasiswa['nim'],
                'nama_lengkap' => $mahasiswa['nama_lengkap'],
                'semester_aktif' => (int)$mahasiswa['semester_aktif'],
                'tahun_akademik' => $mahasiswa['tahun_akademik'],
                'prodi_id' => (int)$prodi_id,
                'fakultas_id' => (int)$fakultas_id,
                'nama_prodi' => $nama_prodi
            ],
            'tagihan' => $tagihanList,
            'cicilan' => $cicilanList,
            'info' => [
                'bpp_autocreated' => $bpp_autocreated,
                'proposal_autocreated' => $proposal_autocreated,
                'skripsi_autocreated' => $skripsi_autocreated,
                'has_active_installment' => $has_active_installment,
                'cicilan_calculation_rule' => 'nominal_cicilan = 50% dari total BPP'
            ]
        ]
    ];

    
    http_response_code(200);
    echo json_encode($response);
    
} catch (PDOException $e) {
    error_log('PDO Error di mhs_tagihan_proses.php: ' . $e->getMessage());
    error_log('Code: ' . $e->getCode());
    error_log('File: ' . $e->getFile() . ':' . $e->getLine());
    
    http_response_code(500);
    echo json_encode([
        'status' => 'error',
        'message' => 'Database error: ' . $e->getMessage(),
        'code' => 'DB_ERROR',
        'error_code' => $e->getCode()
    ]);
} catch (Exception $e) {
    error_log('Error di mhs_tagihan_proses.php: ' . $e->getMessage());
    error_log('File: ' . $e->getFile() . ':' . $e->getLine());
    error_log('Trace: ' . $e->getTraceAsString());
    
    http_response_code(500);
    echo json_encode([
        'status' => 'error',
        'message' => 'Server error: ' . $e->getMessage(),
        'code' => 'INTERNAL_ERROR'
    ]);
}
?>
