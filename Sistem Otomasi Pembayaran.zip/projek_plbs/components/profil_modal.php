<!-- Modal Profil Mahasiswa -->
<!-- Only shown when mahasiswa clicks their avatar -->
<div id="profilModal" style="
    display: none;
    position: fixed;
    z-index: 9999;
    left: 0;
    top: 0;
    width: 100%;
    height: 100%;
    background-color: rgba(0,0,0,0.5);
">
    <div style="
        background-color: white;
        margin: 5% auto;
        padding: 0;
        border-radius: 12px;
        width: 90%;
        max-width: 500px;
        box-shadow: 0 8px 32px rgba(0,0,0,0.2);
        overflow: hidden;
    ">
        <!-- Header -->
        <div style="
            background: linear-gradient(135deg, #4169E1 0%, #2E5BBE 100%);
            color: white;
            padding: 20px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        ">
            <h3 style="margin: 0; font-size: 20px;">Detail Profil Mahasiswa</h3>
            <span onclick="closeProfilModal()" style="
                cursor: pointer;
                font-size: 28px;
                font-weight: bold;
                line-height: 1;
            ">&times;</span>
        </div>

        <!-- Content -->
        <div style="padding: 30px;">
            <!-- Avatar -->
            <div style="text-align: center; margin-bottom: 25px;">
                <img id="modalFotoProfile" src="" alt="Foto Profil" style="
                    width: 120px;
                    height: 120px;
                    border-radius: 50%;
                    object-fit: cover;
                    border: 4px solid #4169E1;
                    box-shadow: 0 4px 12px rgba(0,0,0,0.1);
                ">
            </div>

            <!-- Profile Data -->
            <div style="display: flex; flex-direction: column; gap: 15px;">
                <div style="display: flex; border-bottom: 1px solid #e0e0e0; padding-bottom: 10px;">
                    <div style="width: 140px; font-weight: 600; color: #666;">NIM</div>
                    <div style="flex: 1; color: #333;" id="modalNIM">-</div>
                </div>
                
                <div style="display: flex; border-bottom: 1px solid #e0e0e0; padding-bottom: 10px;">
                    <div style="width: 140px; font-weight: 600; color: #666;">Nama Lengkap</div>
                    <div style="flex: 1; color: #333;" id="modalNamaLengkap">-</div>
                </div>
                
                <div style="display: flex; border-bottom: 1px solid #e0e0e0; padding-bottom: 10px;">
                    <div style="width: 140px; font-weight: 600; color: #666;">Email</div>
                    <div style="flex: 1; color: #333;" id="modalEmail">-</div>
                </div>
                
                <div style="display: flex; border-bottom: 1px solid #e0e0e0; padding-bottom: 10px;">
                    <div style="width: 140px; font-weight: 600; color: #666;">Fakultas</div>
                    <div style="flex: 1; color: #333;" id="modalFakultas">-</div>
                </div>
                
                <div style="display: flex; border-bottom: 1px solid #e0e0e0; padding-bottom: 10px;">
                    <div style="width: 140px; font-weight: 600; color: #666;">Jurusan</div>
                    <div style="flex: 1; color: #333;" id="modalJurusan">-</div>
                </div>
                
                <div style="display: flex; border-bottom: 1px solid #e0e0e0; padding-bottom: 10px;">
                    <div style="width: 140px; font-weight: 600; color: #666;">Semester Aktif</div>
                    <div style="flex: 1; color: #333;" id="modalSemesterAktif">-</div>
                </div>
                
                <div style="display: flex; border-bottom: 1px solid #e0e0e0; padding-bottom: 10px;">
                    <div style="width: 140px; font-weight: 600; color: #666;">Status</div>
                    <div style="flex: 1;" id="modalStatus">
                        <span style="
                            padding: 4px 12px;
                            border-radius: 12px;
                            font-size: 12px;
                            font-weight: 600;
                            background-color: #E8F5E9;
                            color: #1B5E20;
                        ">AKTIF</span>
                    </div>
                </div>
            </div>
        </div>

        <!-- Footer -->
        <div style="
            background-color: #f5f5f5;
            padding: 15px 30px;
            text-align: right;
        ">
            <button onclick="closeProfilModal()" style="
                background-color: #4169E1;
                color: white;
                border: none;
                padding: 10px 24px;
                border-radius: 6px;
                font-weight: 600;
                cursor: pointer;
                transition: background-color 0.3s;
            " onmouseover="this.style.backgroundColor='#2E5BBE'" 
               onmouseout="this.style.backgroundColor='#4169E1'">
                Tutup
            </button>
        </div>
    </div>
</div>

<script>
// Open modal and fetch profile data from API
function openProfilModal() {
    const modal = document.getElementById('profilModal');
    modal.style.display = 'block';
    
    // Fetch profile data from database via API
    fetchProfilMahasiswa();
}

// Close modal
function closeProfilModal() {
    const modal = document.getElementById('profilModal');
    modal.style.display = 'none';
}

// Close modal when clicking outside
window.onclick = function(event) {
    const modal = document.getElementById('profilModal');
    if (event.target === modal) {
        closeProfilModal();
    }
}

// Fetch mahasiswa profile from API
async function fetchProfilMahasiswa() {
    try {
        const token = localStorage.getItem('auth_token');
        if (!token) {
            console.error('No auth token found');
            return;
        }

        const response = await fetch('/projek_plbs/api/index.php/api/mahasiswa/profil', {
            method: 'GET',
            credentials: 'include',
            headers: {
                'Authorization': `Bearer ${token}`,
                'Content-Type': 'application/json'
            }
        });

        if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`);
        }

        const data = await response.json();

        if (data.status === 'success') {
            updateProfilModal(data.data);
        } else {
            console.error('API Error:', data.message);
        }
    } catch (error) {
        console.error('Error fetching profile:', error);
    }
}

// Update modal with profile data from database
function updateProfilModal(profil) {
    // Generate consistent avatar based on NIM
    const avatarUrl = `https://api.dicebear.com/7.x/avataaars/svg?seed=${profil.nim || 'default'}`;
    
    // Update modal avatar
    const modalAvatar = document.getElementById('modalFotoProfile');
    if (modalAvatar) {
        modalAvatar.src = avatarUrl;
    }
    
    // Update header avatar to match modal
    const headerAvatar = document.getElementById('headerAvatar');
    if (headerAvatar) {
        headerAvatar.src = avatarUrl;
    }
    
    // Update all fields with data from API
    const fields = {
        'modalNIM': profil.nim || '-',
        'modalNamaLengkap': profil.nama_lengkap || '-',
        'modalEmail': profil.email || '-',
        'modalFakultas': profil.fakultas || '-',
        'modalJurusan': profil.jurusan || '-',
        'modalSemesterAktif': profil.semester_aktif || '-'
    };
    
    // Set each field
    for (const [id, value] of Object.entries(fields)) {
        const element = document.getElementById(id);
        if (element) {
            element.textContent = value;
        }
    }
    
    // Update status badge
    const statusElement = document.getElementById('modalStatus');
    if (statusElement) {
        const status = profil.status_mahasiswa || 'aktif';
        const statusConfig = {
            'aktif': { bg: '#E8F5E9', color: '#1B5E20', text: 'AKTIF' },
            'cuti': { bg: '#FFF3E0', color: '#E65100', text: 'CUTI' },
            'alumni': { bg: '#E3F2FD', color: '#1565C0', text: 'ALUMNI' },
            'non_aktif': { bg: '#FFEBEE', color: '#C62828', text: 'NON AKTIF' }
        };
        
        const config = statusConfig[status] || statusConfig['aktif'];
        statusElement.innerHTML = `<span style="
            padding: 4px 12px;
            border-radius: 12px;
            font-size: 12px;
            font-weight: 600;
            background-color: ${config.bg};
            color: ${config.color};
        ">${config.text}</span>`;
    }
}
</script>
