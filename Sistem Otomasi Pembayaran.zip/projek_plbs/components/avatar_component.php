<?php
/**
 * Avatar Component - Role-Based UI Logic
 * 
 * Purpose: Render avatar/profile photo ONLY for mahasiswa role
 * Admin roles (admin_fakultas, admin_universitas) do NOT show avatar
 * 
 * Usage:
 * include 'components/avatar_component.php';
 * renderAvatar($_SESSION['role'], $foto_profil_path);
 */

/**
 * Render avatar based on user role (SERVER-SIDE LOGIC)
 * 
 * @param string $role - User role from session
 * @param string $foto_profil - Photo path from database (mahasiswa only)
 * @return void - Echoes HTML or nothing
 */
function renderAvatar($role, $foto_profil = null) {
    // RULE: Only mahasiswa role shows avatar
    if ($role !== 'mahasiswa') {
        return; // No output for admin roles
    }
    
    // Default avatar if no photo
    $avatar_path = $foto_profil ?: 'uploads/avatars/default_avatar.png';
    
    // Render clickable avatar for mahasiswa
    echo '<div class="user-avatar" id="mahasiswaAvatar" style="
        width: 40px;
        height: 40px;
        border-radius: 50%;
        background-image: url(\'' . htmlspecialchars($avatar_path) . '\');
        background-size: cover;
        background-position: center;
        cursor: pointer;
        border: 2px solid #4169E1;
    " onclick="openProfilModal()"></div>';
}

/**
 * Get mahasiswa photo from database
 * 
 * @param PDO $pdo - Database connection
 * @param int $user_id - User ID from session
 * @return string|null - Photo path or null
 */
function getMahasiswaFoto($pdo, $user_id) {
    try {
        $query = "SELECT foto_profil FROM mahasiswa WHERE user_id = :user_id LIMIT 1";
        $stmt = $pdo->prepare($query);
        $stmt->execute(['user_id' => $user_id]);
        $result = $stmt->fetch(PDO::FETCH_ASSOC);
        
        return $result ? $result['foto_profil'] : null;
    } catch (Exception $e) {
        error_log("Error fetching mahasiswa foto: " . $e->getMessage());
        return null;
    }
}
