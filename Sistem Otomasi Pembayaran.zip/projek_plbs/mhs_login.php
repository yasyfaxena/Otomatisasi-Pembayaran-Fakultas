<?php
session_start();
// Login page - tidak perlu check session karena belum login
?>
<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Login Sistem</title>

<!-- Font & Icon -->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">

<style>
:root {
    --primary: #246140;
    --primary-dark: #113120;
    --bg: #f5f7fa;
    --card: #ffffff;
    --text: #333;
    --muted: #777;
}

* {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
    font-family: 'Segoe UI', Tahoma, sans-serif;
}

body {
    min-height: 100vh;
    background-image: url("pictures/background_fikom.jpg");
    background-size: cover;      /* Membuat gambar menutupi seluruh area */
    background-position: center; /* Memusatkan gambar */
    background-repeat: no-repeat; /* Mencegah pengulangan gambar */
    background-attachment: fixed; /* Membuat background tetap saat scroll */
    display: flex;
    align-items: center;
    justify-content: center;
    padding: 20px; /* Memberikan ruang di tepi pada layar kecil */
}

.login-container {
    width: 100%;
    max-width: 420px;
    background: var(--card);
    padding: 35px 30px;
    border-radius: 14px;
    box-shadow: 0 15px 40px rgba(0,0,0,0.12);
}

.login-header {
    text-align: center;
    margin-bottom: 25px;
}

.login-header h2 {
    color: var(--primary-dark);
    font-size: 24px;
    margin-bottom: 5px;
}

.login-header p {
    font-size: 14px;
    color: var(--muted);
}

.form-group {
    margin-bottom: 18px;
}

.form-group label {
    display: block;
    margin-bottom: 6px;
    font-size: 14px;
    color: var(--text);
}

.input-wrapper {
    position: relative;
}

.input-wrapper i {
    position: absolute;
    top: 50%;
    left: 12px;
    transform: translateY(-50%);
    color: var(--muted);
}

.input-wrapper input {
    width: 100%;
    padding: 12px 12px 12px 38px;
    border-radius: 8px;
    border: 1px solid #ddd;
    font-size: 14px;
    outline: none;
    transition: 0.3s;
}

.input-wrapper input:focus {
    border-color: var(--primary);
    box-shadow: 0 0 0 2px rgba(36,97,64,0.15);
}

.login-actions {
    display: flex;
    justify-content: space-between;
    align-items: center;
    font-size: 13px;
    margin-bottom: 20px;
}

.login-actions a {
    color: var(--primary);
    text-decoration: none;
}

.login-actions a:hover {
    text-decoration: underline;
}

.btn-login {
    width: 100%;
    padding: 12px;
    background: linear-gradient(135deg, var(--primary), var(--primary-dark));
    border: none;
    border-radius: 10px;
    color: white;
    font-size: 15px;
    font-weight: 600;
    cursor: pointer;
    transition: 0.3s;
}

.btn-login:hover {
    opacity: 0.9;
    transform: translateY(-1px);
}

.login-footer {
    text-align: center;
    margin-top: 22px;
    font-size: 14px;
    color: var(--muted);
}

.login-footer a {
    color: var(--primary);
    text-decoration: none;
    font-weight: 600;
}

.login-footer a:hover {
    text-decoration: underline;
}

/* Responsive */
@media (max-width: 480px) {
    body {
        padding: 15px;
    }
    .login-container {
        padding: 30px 22px;
    }
}
</style>
</head>

<body>

<div class="login-container">
    <div class="login-header">
        <h2>Login Sistem</h2>
        <p>Silakan masuk menggunakan akun Anda</p>
    </div>

    <form id="loginForm">
        <div class="form-group">
            <label>Email / Username</label>
            <div class="input-wrapper">
                <i class="fas fa-user"></i>
                <input type="text" id="username" name="username" placeholder="Masukkan email atau username" required>
            </div>
        </div>

        <div class="form-group">
            <label>Password</label>
            <div class="input-wrapper">
                <i class="fas fa-lock"></i>
                <input type="password" id="password" name="password" placeholder="Masukkan password" required>
            </div>
        </div>

        <div class="login-actions">
            <label>
                <input type="checkbox" id="remember"> Ingat saya
            </label>
            <a href="lupa_password.php">Lupa password?</a>
        </div>

        <button type="submit" class="btn-login" id="loginBtn">
            <i class="fas fa-sign-in-alt"></i> Sign In
        </button>

        <div id="errorMessage" style="display: none; margin-top: 15px; padding: 12px; background: #fee; color: #c33; border-radius: 8px; text-align: center;"></div>
        <div id="successMessage" style="display: none; margin-top: 15px; padding: 12px; background: #efe; color: #3c3; border-radius: 8px; text-align: center;"></div>
    </form>

    <div class="login-footer">
        Belum punya akun?
        <a href="register.php">Daftar</a>
    </div>
</div>

<script>
document.getElementById('loginForm').addEventListener('submit', async function(e) {
    e.preventDefault();

    const username = document.getElementById('username').value.trim();
    const password = document.getElementById('password').value;
    const loginBtn = document.getElementById('loginBtn');
    const errorMsg = document.getElementById('errorMessage');
    const successMsg = document.getElementById('successMessage');

    // Clear previous messages
    errorMsg.style.display = 'none';
    successMsg.style.display = 'none';

    // Validate
    if (!username || !password) {
        errorMsg.textContent = 'Username dan password harus diisi';
        errorMsg.style.display = 'block';
        return;
    }

    // Disable button
    loginBtn.disabled = true;
    loginBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Sedang login...';

    try {
        const response = await fetch('/projek_plbs/api/index.php/api/auth/login', {
            method: 'POST',
            credentials: 'include',  // ⭐ PENTING: Kirim & terima session cookie
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                username: username,
                password: password
            })
        });

        const data = await response.json();

        if (data.status === 'success') {
            // Save token dan user data termasuk NIM
            localStorage.setItem('auth_token', data.data.token);
            localStorage.setItem('user_id', data.data.user_id);
            localStorage.setItem('username', data.data.username);
            localStorage.setItem('role', data.data.role);
            localStorage.setItem('nama_lengkap', data.data.nama_lengkap);
            
            // Save mahasiswa-specific data
            if (data.data.nim) {
                localStorage.setItem('nim', data.data.nim);
                localStorage.setItem('mahasiswa_id', data.data.mahasiswa_id);
                localStorage.setItem('semester_aktif', data.data.semester_aktif);
                localStorage.setItem('tahun_akademik', data.data.tahun_akademik);
            }

            successMsg.textContent = 'Login berhasil! Mengarahkan ke dashboard...';
            successMsg.style.display = 'block';

            // Redirect ke dashboard mahasiswa menggunakan PHP (PERUBAHAN: .php bukan .php)
            setTimeout(() => {
                window.location.href = 'dashboard_mahasiswa.php';
            }, 1500);
        } else {
            errorMsg.textContent = data.message || 'Login gagal. Periksa kembali username dan password Anda.';
            errorMsg.style.display = 'block';
        }
    } catch (error) {
        errorMsg.textContent = 'Terjadi kesalahan: ' + error.message;
        errorMsg.style.display = 'block';
    } finally {
        loginBtn.disabled = false;
        loginBtn.innerHTML = '<i class="fas fa-sign-in-alt"></i> Sign In';
    }
});
</script>

</body>
</html>

