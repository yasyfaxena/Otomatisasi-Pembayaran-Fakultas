<?php
require_once 'api/config/database.php';

$db = new Database();
$pdo = $db->connect();

echo "<h2>Check & Fix Mahasiswa NIM Data</h2>";

// Check mahasiswa without NIM
$query = "SELECT m.mahasiswa_id, m.nim, u.user_id, u.username, u.nama_lengkap 
          FROM mahasiswa m 
          JOIN users u ON m.user_id = u.user_id 
          WHERE m.nim IS NULL OR m.nim = ''";

$stmt = $pdo->query($query);
$mahasiswa_no_nim = $stmt->fetchAll(PDO::FETCH_ASSOC);

if (empty($mahasiswa_no_nim)) {
    echo "<p style='color: green;'>✓ Semua mahasiswa sudah memiliki NIM</p>";
} else {
    echo "<p style='color: red;'>✗ Ditemukan " . count($mahasiswa_no_nim) . " mahasiswa tanpa NIM:</p>";
    echo "<table border='1' cellpadding='5'>";
    echo "<tr><th>Mahasiswa ID</th><th>User ID</th><th>Username</th><th>Nama</th><th>NIM</th><th>Action</th></tr>";
    
    foreach ($mahasiswa_no_nim as $mhs) {
        echo "<tr>";
        echo "<td>{$mhs['mahasiswa_id']}</td>";
        echo "<td>{$mhs['user_id']}</td>";
        echo "<td>{$mhs['username']}</td>";
        echo "<td>{$mhs['nama_lengkap']}</td>";
        echo "<td>" . ($mhs['nim'] ?: '<span style="color:red;">KOSONG</span>') . "</td>";
        echo "<td>";
        
        // Generate NIM otomatis jika kosong
        if (empty($mhs['nim'])) {
            $new_nim = 'MHS' . str_pad($mhs['mahasiswa_id'], 6, '0', STR_PAD_LEFT);
            echo "<form method='post' style='display:inline;'>";
            echo "<input type='hidden' name='mahasiswa_id' value='{$mhs['mahasiswa_id']}'>";
            echo "<input type='text' name='nim' value='$new_nim' size='15'>";
            echo "<button type='submit' name='update_nim'>Update</button>";
            echo "</form>";
        }
        
        echo "</td>";
        echo "</tr>";
    }
    echo "</table>";
}

// Handle update
if (isset($_POST['update_nim'])) {
    $mahasiswa_id = (int)$_POST['mahasiswa_id'];
    $nim = trim($_POST['nim']);
    
    if (!empty($nim)) {
        $update = "UPDATE mahasiswa SET nim = :nim WHERE mahasiswa_id = :id";
        $stmt = $pdo->prepare($update);
        $stmt->execute(['nim' => $nim, 'id' => $mahasiswa_id]);
        
        echo "<p style='color: green;'>✓ NIM berhasil diupdate untuk mahasiswa_id: $mahasiswa_id</p>";
        echo "<script>setTimeout(() => location.reload(), 1000);</script>";
    }
}

// Show all mahasiswa
echo "<h3>Semua Data Mahasiswa:</h3>";
$query_all = "SELECT m.mahasiswa_id, m.nim, u.username, u.nama_lengkap, ps.nama_prodi
              FROM mahasiswa m
              JOIN users u ON m.user_id = u.user_id
              LEFT JOIN program_studi ps ON m.prodi_id = ps.prodi_id
              ORDER BY m.mahasiswa_id";

$stmt = $pdo->query($query_all);
$all_mahasiswa = $stmt->fetchAll(PDO::FETCH_ASSOC);

echo "<table border='1' cellpadding='5'>";
echo "<tr><th>ID</th><th>NIM</th><th>Username</th><th>Nama</th><th>Prodi</th></tr>";
foreach ($all_mahasiswa as $mhs) {
    $nim_display = $mhs['nim'] ?: '<span style="color:red;">KOSONG</span>';
    echo "<tr>";
    echo "<td>{$mhs['mahasiswa_id']}</td>";
    echo "<td>$nim_display</td>";
    echo "<td>{$mhs['username']}</td>";
    echo "<td>{$mhs['nama_lengkap']}</td>";
    echo "<td>{$mhs['nama_prodi']}</td>";
    echo "</tr>";
}
echo "</table>";
?>
